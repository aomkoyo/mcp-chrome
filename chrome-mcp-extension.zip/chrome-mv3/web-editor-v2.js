var webEditorV2 = (function() {
	//#region ../../node_modules/.pnpm/wxt@0.20.25_@types+node@22.19.17_eslint@9.39.4_jiti@2.6.1__jiti@2.6.1_rollup@4.60.2_yaml@2.8.3/node_modules/wxt/dist/utils/define-unlisted-script.mjs
	function defineUnlistedScript(arg) {
		if (arg == null || typeof arg === "function") return { main: arg };
		return arg;
	}
	//#endregion
	//#region entrypoints/web-editor-v2/constants.ts
	/** Log prefix for console messages */
	var WEB_EDITOR_V2_LOG_PREFIX = "[WebEditorV2]";
	/** Shadow host element ID */
	var WEB_EDITOR_V2_HOST_ID = "__mcp_web_editor_v2_host__";
	/** Overlay container ID (for Canvas and visual feedback) */
	var WEB_EDITOR_V2_OVERLAY_ID = "__mcp_web_editor_v2_overlay__";
	/** UI container ID (for panels and controls) */
	var WEB_EDITOR_V2_UI_ID = "__mcp_web_editor_v2_ui__";
	/** Maximum z-index to ensure editor is always on top */
	var WEB_EDITOR_V2_Z_INDEX = 2147483647;
	var WEB_EDITOR_V2_COLORS = {
		hover: "#3b82f6",
		selected: "#22c55e",
		selectionBorder: "#6366f1",
		dragGhost: "rgba(99, 102, 241, 0.3)",
		insertionLine: "#f59e0b",
		guideLine: "#ec4899",
		distanceLabelBg: "rgba(15, 23, 42, 0.92)",
		distanceLabelBorder: "rgba(51, 65, 85, 0.5)",
		distanceLabelText: "rgba(255, 255, 255, 0.98)"
	};
	/** Font used for distance label pills */
	var WEB_EDITOR_V2_DISTANCE_LABEL_FONT = "600 11px system-ui, -apple-system, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif";
	//#endregion
	//#region common/message-types.ts
	var BACKGROUND_MESSAGE_TYPES = {
		SWITCH_SEMANTIC_MODEL: "switch_semantic_model",
		GET_MODEL_STATUS: "get_model_status",
		UPDATE_MODEL_STATUS: "update_model_status",
		GET_STORAGE_STATS: "get_storage_stats",
		CLEAR_ALL_DATA: "clear_all_data",
		GET_SERVER_STATUS: "get_server_status",
		REFRESH_SERVER_STATUS: "refresh_server_status",
		SERVER_STATUS_CHANGED: "server_status_changed",
		INITIALIZE_SEMANTIC_ENGINE: "initialize_semantic_engine",
		RR_START_RECORDING: "rr_start_recording",
		RR_STOP_RECORDING: "rr_stop_recording",
		RR_PAUSE_RECORDING: "rr_pause_recording",
		RR_RESUME_RECORDING: "rr_resume_recording",
		RR_GET_RECORDING_STATUS: "rr_get_recording_status",
		RR_LIST_FLOWS: "rr_list_flows",
		RR_FLOWS_CHANGED: "rr_flows_changed",
		RR_GET_FLOW: "rr_get_flow",
		RR_DELETE_FLOW: "rr_delete_flow",
		RR_PUBLISH_FLOW: "rr_publish_flow",
		RR_UNPUBLISH_FLOW: "rr_unpublish_flow",
		RR_RUN_FLOW: "rr_run_flow",
		RR_SAVE_FLOW: "rr_save_flow",
		RR_EXPORT_FLOW: "rr_export_flow",
		RR_EXPORT_ALL: "rr_export_all",
		RR_IMPORT_FLOW: "rr_import_flow",
		RR_LIST_RUNS: "rr_list_runs",
		RR_LIST_TRIGGERS: "rr_list_triggers",
		RR_SAVE_TRIGGER: "rr_save_trigger",
		RR_DELETE_TRIGGER: "rr_delete_trigger",
		RR_REFRESH_TRIGGERS: "rr_refresh_triggers",
		RR_SCHEDULE_FLOW: "rr_schedule_flow",
		RR_UNSCHEDULE_FLOW: "rr_unschedule_flow",
		RR_LIST_SCHEDULES: "rr_list_schedules",
		ELEMENT_MARKER_LIST_ALL: "element_marker_list_all",
		ELEMENT_MARKER_LIST_FOR_URL: "element_marker_list_for_url",
		ELEMENT_MARKER_SAVE: "element_marker_save",
		ELEMENT_MARKER_UPDATE: "element_marker_update",
		ELEMENT_MARKER_DELETE: "element_marker_delete",
		ELEMENT_MARKER_VALIDATE: "element_marker_validate",
		ELEMENT_MARKER_START: "element_marker_start_from_popup",
		ELEMENT_PICKER_UI_EVENT: "element_picker_ui_event",
		ELEMENT_PICKER_FRAME_EVENT: "element_picker_frame_event",
		WEB_EDITOR_TOGGLE: "web_editor_toggle",
		WEB_EDITOR_APPLY: "web_editor_apply",
		WEB_EDITOR_STATUS_QUERY: "web_editor_status_query",
		WEB_EDITOR_APPLY_BATCH: "web_editor_apply_batch",
		WEB_EDITOR_TX_CHANGED: "web_editor_tx_changed",
		WEB_EDITOR_HIGHLIGHT_ELEMENT: "web_editor_highlight_element",
		WEB_EDITOR_REVERT_ELEMENT: "web_editor_revert_element",
		WEB_EDITOR_SELECTION_CHANGED: "web_editor_selection_changed",
		WEB_EDITOR_CLEAR_SELECTION: "web_editor_clear_selection",
		WEB_EDITOR_CANCEL_EXECUTION: "web_editor_cancel_execution",
		WEB_EDITOR_PROPS_REGISTER_EARLY_INJECTION: "web_editor_props_register_early_injection",
		WEB_EDITOR_OPEN_SOURCE: "web_editor_open_source",
		QUICK_PANEL_SEND_TO_AI: "quick_panel_send_to_ai",
		QUICK_PANEL_CANCEL_AI: "quick_panel_cancel_ai",
		QUICK_PANEL_TABS_QUERY: "quick_panel_tabs_query",
		QUICK_PANEL_TAB_ACTIVATE: "quick_panel_tab_activate",
		QUICK_PANEL_TAB_CLOSE: "quick_panel_tab_close"
	};
	//#endregion
	//#region \0@oxc-project+runtime@0.126.0/helpers/typeof.js
	function _typeof(o) {
		"@babel/helpers - typeof";
		return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
			return typeof o;
		} : function(o) {
			return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
		}, _typeof(o);
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.126.0/helpers/toPrimitive.js
	function toPrimitive(t, r) {
		if ("object" != _typeof(t) || !t) return t;
		var e = t[Symbol.toPrimitive];
		if (void 0 !== e) {
			var i = e.call(t, r || "default");
			if ("object" != _typeof(i)) return i;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return ("string" === r ? String : Number)(t);
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.126.0/helpers/toPropertyKey.js
	function toPropertyKey(t) {
		var i = toPrimitive(t, "string");
		return "symbol" == _typeof(i) ? i : i + "";
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.126.0/helpers/defineProperty.js
	function _defineProperty(e, r, t) {
		return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
			value: t,
			enumerable: !0,
			configurable: !0,
			writable: !0
		}) : e[r] = t, e;
	}
	//#endregion
	//#region entrypoints/web-editor-v2/utils/disposables.ts
	/**
	* Manages a collection of disposable resources.
	* Resources are disposed in reverse order (LIFO).
	*/
	var Disposer = class {
		constructor() {
			_defineProperty(this, "disposed", false);
			_defineProperty(this, "disposers", []);
		}
		/** Whether this disposer has already been disposed */
		get isDisposed() {
			return this.disposed;
		}
		/**
		* Add a dispose function to be called during cleanup.
		* If already disposed, the function is called immediately.
		*/
		add(dispose) {
			if (this.disposed) {
				try {
					dispose();
				} catch (_unused) {}
				return;
			}
			this.disposers.push(dispose);
		}
		listen(target, type, listener, options) {
			target.addEventListener(type, listener, options);
			this.add(() => target.removeEventListener(type, listener, options));
		}
		/**
		* Add a ResizeObserver and automatically disconnect it on dispose.
		*/
		observeResize(target, callback, options) {
			const observer = new ResizeObserver(callback);
			observer.observe(target, options);
			this.add(() => observer.disconnect());
			return observer;
		}
		/**
		* Add a MutationObserver and automatically disconnect it on dispose.
		*/
		observeMutation(target, callback, options) {
			const observer = new MutationObserver(callback);
			observer.observe(target, options);
			this.add(() => observer.disconnect());
			return observer;
		}
		/**
		* Add a requestAnimationFrame and automatically cancel it on dispose.
		* Returns a function to manually cancel the frame.
		*/
		requestAnimationFrame(callback) {
			const id = requestAnimationFrame(callback);
			let cancelled = false;
			const cancel = () => {
				if (cancelled) return;
				cancelled = true;
				cancelAnimationFrame(id);
			};
			this.add(cancel);
			return cancel;
		}
		/**
		* Dispose all registered resources in reverse order.
		* Safe to call multiple times.
		*/
		dispose() {
			if (this.disposed) return;
			this.disposed = true;
			for (let i = this.disposers.length - 1; i >= 0; i--) try {
				this.disposers[i]();
			} catch (_unused2) {}
			this.disposers.length = 0;
		}
	};
	//#endregion
	//#region entrypoints/web-editor-v2/ui/shadow-host.ts
	/**
	* Shadow DOM Host
	*
	* Creates an isolated container for the Web Editor UI using Shadow DOM.
	* Provides:
	* - Style isolation (no CSS bleed in/out)
	* - Event isolation (UI events don't bubble to page)
	* - Overlay container for Canvas/visual feedback
	* - UI container for panels/controls
	*/
	var SHADOW_HOST_STYLES = `
  :host {
    all: initial;

    /* Design tokens aligned with attr-ui.html design spec */
    /* Surface colors */
    --we-surface-bg: #ffffff;
    --we-surface-secondary: #fafafa;

    /* Control colors - input containers use gray bg */
    --we-control-bg: #f3f3f3;
    --we-control-bg-hover: #e8e8e8;
    --we-control-border-hover: #e0e0e0;
    --we-control-bg-focus: #ffffff;
    --we-control-border-focus: #3b82f6;

    /* Border colors */
    --we-border-subtle: #e5e5e5;
    --we-border-strong: #d4d4d4;
    --we-border-section: #f3f3f3;

    /* Text colors */
    --we-text-primary: #333333;
    --we-text-secondary: #737373;
    --we-text-muted: #a3a3a3;

    /* Accent surfaces (used by CSS/Props panels) */
    --we-accent-info-bg: rgba(59, 130, 246, 0.08);
    --we-accent-brand-bg: rgba(99, 102, 241, 0.12);
    --we-accent-brand-border: rgba(99, 102, 241, 0.25);
    --we-accent-warning-bg: rgba(251, 191, 36, 0.14);
    --we-accent-warning-border: rgba(251, 191, 36, 0.25);
    --we-accent-danger-bg: rgba(248, 113, 113, 0.12);
    --we-accent-danger-border: rgba(248, 113, 113, 0.25);

    /* Shadows - Tailwind-like shadow-xl */
    --we-shadow-subtle: 0 1px 2px rgba(0, 0, 0, 0.05);
    --we-shadow-panel: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
    --we-shadow-tab: 0 1px 2px rgba(0, 0, 0, 0.05);

    /* Radii */
    --we-radius-panel: 8px;
    --we-radius-control: 6px;
    --we-radius-tab: 4px;

    /* Sizes */
    --we-icon-btn-size: 24px;

    /* Focus ring - blue inset border style */
    --we-focus-ring: #3b82f6;

    /* Motion - bounce easing for toolbar animations */
    --we-ease-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  /* Overlay container - for Canvas and visual feedback */
  #${WEB_EDITOR_V2_OVERLAY_ID} {
    position: fixed;
    inset: 0;
    pointer-events: none;
    contain: layout style;
  }

  /* ==========================================================================
   * Resize Handles (Phase 4.9)
   * ========================================================================== */

  /* Handles layer - covers viewport, pass-through by default */
  .we-handles-layer {
    position: absolute;
    inset: 0;
    pointer-events: none;
    contain: layout style paint;
  }

  /* Selection frame - positioned by selection rect */
  .we-selection-frame {
    position: absolute;
    top: 0;
    left: 0;
    width: 0;
    height: 0;
    transform: translate3d(0, 0, 0);
    pointer-events: none;
    will-change: transform, width, height;
  }

  /* Individual resize handle */
  .we-resize-handle {
    position: absolute;
    width: 8px;
    height: 8px;
    border-radius: 2px;
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid ${WEB_EDITOR_V2_COLORS.selectionBorder};
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
    pointer-events: auto;
    touch-action: none;
    user-select: none;
    transition: background-color 0.1s ease, border-color 0.1s ease, transform 0.1s ease;
  }

  .we-resize-handle:hover {
    background: ${WEB_EDITOR_V2_COLORS.selectionBorder};
    border-color: ${WEB_EDITOR_V2_COLORS.selectionBorder};
    transform: translate(-50%, -50%) scale(1.15);
  }

  .we-resize-handle:active {
    transform: translate(-50%, -50%) scale(1.0);
  }

  /* Handle positions - all use translate(-50%, -50%) as base */
  .we-resize-handle[data-dir="n"]  { left: 50%; top: 0; transform: translate(-50%, -50%); cursor: ns-resize; }
  .we-resize-handle[data-dir="s"]  { left: 50%; top: 100%; transform: translate(-50%, -50%); cursor: ns-resize; }
  .we-resize-handle[data-dir="e"]  { left: 100%; top: 50%; transform: translate(-50%, -50%); cursor: ew-resize; }
  .we-resize-handle[data-dir="w"]  { left: 0; top: 50%; transform: translate(-50%, -50%); cursor: ew-resize; }
  .we-resize-handle[data-dir="nw"] { left: 0; top: 0; transform: translate(-50%, -50%); cursor: nwse-resize; }
  .we-resize-handle[data-dir="ne"] { left: 100%; top: 0; transform: translate(-50%, -50%); cursor: nesw-resize; }
  .we-resize-handle[data-dir="sw"] { left: 0; top: 100%; transform: translate(-50%, -50%); cursor: nesw-resize; }
  .we-resize-handle[data-dir="se"] { left: 100%; top: 100%; transform: translate(-50%, -50%); cursor: nwse-resize; }

  /* Size HUD - shows W×H while resizing */
  .we-size-hud {
    position: absolute;
    left: 50%;
    top: 0;
    transform: translate(-50%, calc(-100% - 8px));
    padding: 3px 8px;
    font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 11px;
    font-weight: 600;
    line-height: 1.2;
    color: rgba(255, 255, 255, 0.98);
    background: rgba(15, 23, 42, 0.92);
    border: 1px solid rgba(51, 65, 85, 0.5);
    border-radius: 4px;
    pointer-events: none;
    user-select: none;
    white-space: nowrap;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
  }

  /* ==========================================================================
   * Performance HUD (Phase 5.3)
   * ========================================================================== */

  .we-perf-hud {
    position: fixed;
    left: 12px;
    bottom: 12px;
    padding: 8px 10px;
    border-radius: 10px;
    background: rgba(15, 23, 42, 0.78);
    border: 1px solid rgba(51, 65, 85, 0.45);
    color: rgba(255, 255, 255, 0.96);
    font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 12px;
    line-height: 1.25;
    pointer-events: none;
    user-select: none;
    white-space: nowrap;
    z-index: 10;
    box-shadow: 0 4px 14px rgba(0, 0, 0, 0.18);
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    font-variant-numeric: tabular-nums;
  }

  .we-perf-hud-line + .we-perf-hud-line {
    margin-top: 4px;
  }

  /* UI container - for panels and controls */
  /* Position below toolbar: 16px (toolbar top) + 40px (toolbar height) + 8px (gap) = 64px */
  #${WEB_EDITOR_V2_UI_ID} {
    position: fixed;
    top: 64px;
    right: 16px;
    pointer-events: auto;
    /* Inter font with system fallbacks (aligned with design spec) */
    font-family: "Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 11px;
    line-height: 1.4;
    color: var(--we-text-primary);
    -webkit-font-smoothing: antialiased;
  }

  /* Panel styles */
  /* max-height: 100vh - 64px (top offset) - 16px (bottom margin) = 100vh - 80px */
  .we-panel {
    width: 280px;
    max-width: calc(100vw - 32px);
    max-height: calc(100vh - 80px);
    background: var(--we-surface-bg);
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-panel);
    box-shadow: var(--we-shadow-panel);
    overflow: hidden;
    contain: layout style paint;
  }

  .we-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding: 8px 12px;
    background: var(--we-surface-bg);
    border-bottom: 1px solid var(--we-border-subtle);
    user-select: none;
  }

  .we-title {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    font-weight: 600;
    color: var(--we-text-primary);
  }

  .we-badge {
    font-size: 10px;
    font-weight: 500;
    padding: 2px 6px;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    color: white;
    border-radius: 4px;
  }

  .we-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 6px 12px;
    font-size: 12px;
    font-weight: 500;
    color: #475569;
    background: white;
    border: 1px solid rgba(148, 163, 184, 0.5);
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.15s ease;
  }

  .we-btn:hover {
    background: #f8fafc;
    border-color: rgba(148, 163, 184, 0.7);
  }

  .we-btn:active {
    background: #f1f5f9;
  }

  .we-btn:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-btn:disabled {
    opacity: 0.55;
    cursor: not-allowed;
  }

  .we-btn--primary {
    background: linear-gradient(135deg, #0f172a, #1e293b);
    color: #ffffff;
    border-color: rgba(15, 23, 42, 0.5);
  }

  .we-btn--primary:hover:not(:disabled) {
    background: linear-gradient(135deg, #1e293b, #334155);
    border-color: rgba(15, 23, 42, 0.65);
  }

  .we-btn--danger {
    color: #b91c1c;
    border-color: rgba(248, 113, 113, 0.45);
  }

  .we-btn--danger:hover:not(:disabled) {
    background: rgba(248, 113, 113, 0.08);
    border-color: rgba(248, 113, 113, 0.6);
  }

  /* Icon button (28x28) - used for window controls (close/minimize, etc.) */
  .we-icon-btn {
    width: var(--we-icon-btn-size);
    height: var(--we-icon-btn-size);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    background: var(--we-control-bg);
    border: 0;
    border-radius: var(--we-radius-control);
    color: var(--we-text-secondary);
    cursor: pointer;
    transition: background 0.15s ease, box-shadow 0.15s ease;
  }

  .we-icon-btn:hover {
    background: var(--we-control-bg-hover);
    color: var(--we-text-primary);
  }

  .we-icon-btn:active {
    background: var(--we-control-bg-hover);
  }

  .we-icon-btn:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-icon-btn svg {
    width: 16px;
    height: 16px;
    display: block;
  }

  /* Drag handle (grip) - used for repositioning floating UI */
  .we-drag-handle {
    width: var(--we-icon-btn-size);
    height: var(--we-icon-btn-size);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    padding: 0;
    background: transparent;
    border: 0;
    border-radius: var(--we-radius-control);
    color: var(--we-text-muted);
    cursor: grab;
    touch-action: none;
    user-select: none;
    transition: background 0.15s ease, color 0.15s ease, box-shadow 0.15s ease;
  }

  .we-drag-handle:hover {
    background: var(--we-control-bg);
    color: var(--we-text-secondary);
  }

  .we-drag-handle:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-drag-handle:active,
  .we-drag-handle[data-dragging="true"] {
    cursor: grabbing;
    background: var(--we-control-bg-hover);
    color: var(--we-text-primary);
  }

  .we-drag-handle svg {
    width: 14px;
    height: 14px;
    display: block;
  }

  /* ==========================================================================
   * Toolbar (Redesigned per toolbar-ui.html design spec)
   * - Bounce easing animations
   * - Collapsible pill (580x40 <-> 40x40)
   * - Grip icon rotation on collapse
   * ========================================================================== */

  .we-toolbar {
    position: fixed;
    left: 50%;
    top: 16px;
    transform: translateX(-50%);
    width: 580px;
    height: 40px;
    max-width: calc(100vw - 32px);
    display: flex;
    align-items: center;
    background: #ffffff;
    border-radius: 999px;
    box-shadow: 0 -4px 10px -6px rgba(15, 23, 42, 0.18),
      0 10px 15px -3px rgba(203, 213, 225, 0.5),
      0 4px 6px -4px rgba(203, 213, 225, 0.5);
    pointer-events: auto;
    user-select: none;
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
    font-size: 11px;
    color: #475569;
    transition: width 500ms var(--we-ease-bounce), height 500ms var(--we-ease-bounce);
    overflow: visible;
    will-change: width, height;
  }

  .we-toolbar[data-position="bottom"] {
    top: auto;
    bottom: 16px;
  }

  /* Dragged toolbar: use left/top (inline styles) instead of docked centering */
  .we-toolbar[data-dragged="true"] {
    left: auto;
    right: auto;
    top: auto;
    bottom: auto;
    transform: none;
  }

  /* Collapsed toolbar - 40x40 circle */
  .we-toolbar[data-minimized="true"] {
    width: 40px;
    height: 40px;
  }

  /* Toolbar content row (collapses with toolbar) */
  .we-toolbar-content {
    display: flex;
    align-items: center;
    flex: 1;
    min-width: 0;
    gap: 10px;
    white-space: nowrap;
    padding-right: 8px;
    transition: opacity 350ms ease, transform 400ms var(--we-ease-bounce);
    will-change: opacity, transform;
  }

  .we-toolbar[data-minimized="true"] .we-toolbar-content {
    opacity: 0;
    transform: translateX(-16px) scale(0.95);
    pointer-events: none;
  }

  .we-toolbar[data-minimized="false"] .we-toolbar-content {
    opacity: 1;
    transform: translateX(0) scale(1);
    pointer-events: auto;
  }

  /* Grip toggle button (40x40, hover slate-50, active scale-90) */
  .we-toolbar .we-drag-handle {
    width: 40px;
    height: 40px;
    flex-shrink: 0;
    border-radius: 999px;
    cursor: pointer;
    transition: background-color 150ms ease, transform 150ms ease;
  }

  .we-toolbar .we-drag-handle:hover {
    background: #f8fafc;
  }

  .we-toolbar .we-drag-handle:active {
    transform: scale(0.9);
  }

  /* Grip icon rotation (collapsed 90deg -> expanded 0deg) */
  .we-toolbar .we-drag-handle svg {
    width: 16px;
    height: 16px;
    color: #94a3b8;
    transition: transform 500ms var(--we-ease-bounce);
    transform: rotate(0deg);
  }

  .we-toolbar[data-minimized="true"] .we-drag-handle svg {
    transform: rotate(90deg);
  }

  /* Status indicator: green dot + "Editor" label */
  .we-toolbar-indicator {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px;
    background: #f1f5f9;
    border-radius: 999px;
  }

  .we-toolbar-indicator-dot {
    width: 6px;
    height: 6px;
    border-radius: 999px;
    background: #10b981;
  }

  .we-toolbar-indicator-label {
    font-size: 11px;
    font-weight: 700;
    color: #334155;
    letter-spacing: 0.04em;
  }

  /* Status-driven dot color + pulse */
  .we-toolbar[data-status="progress"] .we-toolbar-indicator-dot {
    background: #6366f1;
    animation: we-toolbar-dot-pulse 1.5s ease-in-out infinite;
  }

  .we-toolbar[data-status="success"] .we-toolbar-indicator-dot {
    background: #10b981;
  }

  .we-toolbar[data-status="error"] .we-toolbar-indicator-dot {
    background: #ef4444;
  }

  @keyframes we-toolbar-dot-pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.55; }
  }

  /* Undo/Redo counts */
  .we-toolbar-history {
    display: flex;
    gap: 10px;
    font-size: 10px;
    font-weight: 500;
    color: #94a3b8;
    font-variant-numeric: tabular-nums;
  }

  .we-toolbar-history-value {
    color: #475569;
    font-weight: 700;
  }

  /* Divider */
  .we-toolbar-divider {
    width: 1px;
    height: 16px;
    background: #e2e8f0;
  }

  /* Structure group (Structure button + divider + Undo/Redo icons) */
  .we-toolbar-structure-group {
    display: inline-flex;
    align-items: center;
    background: #f1f5f9;
    border-radius: 999px;
    padding: 2px;
  }

  .we-toolbar-structure-btn {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    font-size: 11px;
    font-weight: 500;
    color: #64748b;
    background: transparent;
    border: 0;
    border-radius: 999px;
    cursor: pointer;
    transition: color 150ms ease, background-color 150ms ease;
  }

  .we-toolbar-structure-btn:hover:not(:disabled) {
    color: #1e293b;
    background: #ffffff;
  }

  .we-toolbar-structure-btn:disabled {
    opacity: 0.55;
    cursor: not-allowed;
  }

  .we-toolbar-structure-btn svg {
    width: 10px;
    height: 10px;
    opacity: 0.5;
    display: block;
  }

  .we-toolbar-structure-separator {
    width: 1px;
    height: 12px;
    background: #e2e8f0;
  }

  .we-toolbar-group-icon-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 4px;
    background: transparent;
    border: 0;
    border-radius: 999px;
    color: #94a3b8;
    cursor: pointer;
    transition: color 150ms ease, background-color 150ms ease;
  }

  .we-toolbar-group-icon-btn:hover:not(:disabled) {
    color: #334155;
    background: #ffffff;
  }

  .we-toolbar-group-icon-btn:disabled {
    opacity: 0.45;
    cursor: not-allowed;
  }

  .we-toolbar-group-icon-btn svg {
    width: 14px;
    height: 14px;
    display: block;
  }

  /* End actions container: pushes apply + close to far right */
  .we-toolbar-end-actions {
    margin-left: auto;
    display: inline-flex;
    align-items: center;
    gap: 10px;
  }

  /* Apply button (indigo-500) */
  .we-toolbar-apply-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 6px 16px;
    font-size: 11px;
    font-weight: 700;
    color: #ffffff;
    background: #6366f1;
    border: 0;
    border-radius: 999px;
    cursor: pointer;
    transition: background-color 150ms ease, transform 150ms ease, box-shadow 150ms ease;
    box-shadow: 0 4px 6px -1px rgba(99, 102, 241, 0.25),
      0 2px 4px -2px rgba(99, 102, 241, 0.25);
  }

  .we-toolbar-apply-btn:hover:not(:disabled) {
    background: #4f46e5;
  }

  .we-toolbar-apply-btn:active:not(:disabled) {
    transform: scale(0.95);
  }

  .we-toolbar-apply-btn:disabled {
    opacity: 0.55;
    cursor: not-allowed;
    box-shadow: none;
  }

  /* Close button (red hover) */
  .we-toolbar-close-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 6px;
    background: transparent;
    border: 0;
    border-radius: 999px;
    color: #94a3b8;
    cursor: pointer;
    transition: color 150ms ease, background-color 150ms ease;
  }

  .we-toolbar-close-btn:hover:not(:disabled) {
    color: #ef4444;
    background: #fef2f2;
  }

  .we-toolbar-close-btn:disabled {
    opacity: 0.45;
    cursor: not-allowed;
  }

  .we-toolbar-close-btn svg {
    width: 14px;
    height: 14px;
    display: block;
  }

  /* Screen-reader-only utility */
  .we-sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border: 0;
  }

  /* Respect reduced motion preference */
  @media (prefers-reduced-motion: reduce) {
    .we-toolbar,
    .we-toolbar-content,
    .we-toolbar .we-drag-handle,
    .we-toolbar .we-drag-handle svg,
    .we-toolbar-structure-btn,
    .we-toolbar-group-icon-btn,
    .we-toolbar-apply-btn,
    .we-toolbar-close-btn {
      transition: none;
    }
  }

  /* ==========================================================================
     Breadcrumbs (Phase 2.2) - Anchored to selection element
     ========================================================================== */
  .we-breadcrumbs {
    position: fixed;
    /* left/top set dynamically via JS based on selection rect */
    left: 16px;
    top: 72px;
    width: auto;
    max-width: min(600px, calc(100vw - 400px));
    display: flex;
    align-items: center;
    gap: 2px;
    padding: 6px 12px;
    background: #5494D7;
    border: none;
    border-radius: 0;
    box-shadow: 0 2px 8px rgba(84, 148, 215, 0.3);
    pointer-events: auto;
    user-select: none;
    overflow-x: auto;
    white-space: nowrap;
    scrollbar-width: none;
    z-index: 5;
  }

  .we-breadcrumbs[data-hidden="true"] {
    display: none;
  }

  .we-breadcrumbs[data-position="bottom"] {
    top: auto;
    bottom: 72px;
  }

  .we-breadcrumbs::-webkit-scrollbar {
    display: none;
  }

  .we-crumb {
    display: inline-flex;
    align-items: center;
    max-width: 220px;
    padding: 2px 6px;
    border-radius: 3px;
    border: none;
    background: transparent;
    color: #ffffff;
    font-size: 12px;
    font-weight: 500;
    line-height: 1.2;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    transition: background 0.15s ease;
  }

  .we-crumb:hover {
    background: rgba(255, 255, 255, 0.15);
  }

  .we-crumb:active {
    background: rgba(255, 255, 255, 0.25);
  }

  .we-crumb:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.5);
  }

  .we-crumb--current {
    background: rgba(255, 255, 255, 0.2);
  }

  .we-crumb-sep {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 14px;
    flex: 0 0 auto;
    color: rgba(255, 255, 255, 0.7);
    font-size: 12px;
  }

  .we-crumb-sep--shadow {
    color: rgba(255, 255, 255, 0.9);
  }

  .we-body {
    padding: 14px;
    color: #475569;
    font-size: 12px;
  }

  .we-status {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: rgba(34, 197, 94, 0.1);
    border-radius: 6px;
    color: #15803d;
    font-size: 12px;
  }

  .we-status-dot {
    width: 8px;
    height: 8px;
    background: #22c55e;
    border-radius: 50%;
    animation: pulse 2s ease-in-out infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }

  /* ==========================================================================
     Property Panel (Phase 3)
     ========================================================================== */

  .we-prop-panel {
    display: flex;
    flex-direction: column;
    max-height: calc(100vh - 80px);
  }

  /* Dragged property panel: becomes a floating fixed panel positioned via left/top (inline styles) */
  .we-prop-panel[data-dragged="true"][data-minimized="false"] {
    position: fixed;
    left: auto;
    right: auto;
    top: auto;
    bottom: auto;
  }

  /* Minimized property panel - becomes a small icon button fixed at top-right */
  .we-prop-panel[data-minimized="true"] {
    position: fixed;
    top: 16px;
    right: 16px;
    width: auto;
    max-height: none;
    background: transparent;
    border: 0;
    box-shadow: none;
    overflow: visible;
    z-index: 10;
  }

  .we-prop-panel[data-minimized="true"] .we-header {
    padding: 0;
    background: transparent;
    border-bottom: 0;
  }

  /* Symmetric header layout: drag (left) | tabs (center) | minimize (right) */
  .we-prop-panel .we-header {
    padding: 8px;
    gap: 4px;
  }

  .we-prop-panel .we-header .we-prop-tabs {
    flex: 1;
    justify-content: center;
  }

  /* Minimize button chevron rotation */
  .we-minimize-btn svg {
    transition: transform 200ms ease;
  }

  .we-prop-panel[data-minimized="true"] .we-minimize-btn svg {
    transform: rotate(180deg);
  }

  /* Header tooltips: show below to avoid being clipped by panel overflow */
  .we-prop-panel .we-header [data-tooltip]::after {
    bottom: auto;
    top: calc(100% + 6px);
  }

  .we-prop-panel .we-header [data-tooltip]::before {
    bottom: auto;
    top: calc(100% + 2px);
    border-top-color: transparent;
    border-bottom-color: var(--we-text-primary);
  }

  /* Tab container with pill/segmented style (aligned with design spec) */
  .we-prop-tabs {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    padding: 2px;
    background: var(--we-control-bg);
    border-radius: var(--we-radius-tab);
  }

  .we-tab {
    border: 0;
    background: transparent;
    color: var(--we-text-secondary);
    padding: 4px 10px;
    border-radius: var(--we-radius-tab);
    cursor: pointer;
    font-size: 12px;
    font-weight: 500;
    transition: all 0.1s ease;
  }

  .we-tab:hover {
    color: var(--we-text-primary);
  }

  .we-tab:focus-visible {
    outline: none;
    box-shadow: inset 0 0 0 2px var(--we-focus-ring);
  }

  /* Active tab: white background with subtle shadow */
  .we-tab[aria-selected="true"] {
    background: var(--we-surface-bg);
    color: var(--we-text-primary);
    box-shadow: var(--we-shadow-tab);
  }

  .we-prop-body {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding: 12px;
    padding-bottom: 80px; /* Extra space for scrolling (design spec: pb-20) */
    display: flex;
    flex-direction: column;
    gap: 12px;
    scrollbar-width: none; /* Firefox */
    -ms-overflow-style: none; /* IE 10+ */
  }

  /* Hide scrollbar for webkit browsers */
  .we-prop-body::-webkit-scrollbar {
    width: 0;
    height: 0;
  }

  /* Force hidden state for property panel sections during minimization */
  .we-prop-body[hidden],
  .we-prop-tabs[hidden] {
    display: none;
  }

  .we-prop-tab-content {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .we-prop-tab-content[hidden] {
    display: none;
  }

  .we-prop-empty {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px 12px;
    color: #64748b;
    font-size: 12px;
    text-align: center;
  }

  .we-prop-empty[hidden] {
    display: none;
  }

  .we-prop-panel[data-empty="true"] .we-prop-tab-content {
    display: none;
  }

  /* ==========================================================================
     Components Tree (Phase 3.2)
     ========================================================================== */

  .we-tree {
    font-size: 12px;
    line-height: 1.4;
  }

  .we-tree-empty {
    padding: 24px 12px;
    color: #64748b;
    text-align: center;
  }

  .we-tree-empty[hidden] {
    display: none;
  }

  .we-tree-list {
    display: flex;
    flex-direction: column;
  }

  .we-tree-list[hidden] {
    display: none;
  }

  .we-tree-item {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 6px 8px;
    cursor: pointer;
    border-radius: 4px;
    transition: background 0.12s;
    color: #475569;
  }

  .we-tree-item:hover {
    background: rgba(59, 130, 246, 0.08);
  }

  .we-tree-item--selected {
    background: rgba(59, 130, 246, 0.12);
    color: #1d4ed8;
    font-weight: 500;
  }

  .we-tree-item--selected:hover {
    background: rgba(59, 130, 246, 0.16);
  }

  .we-tree-item--ancestor {
    color: #64748b;
  }

  .we-tree-item--child {
    color: #64748b;
    font-size: 11px;
  }

  .we-tree-indent {
    color: #94a3b8;
    font-family: monospace;
    user-select: none;
  }

  .we-tree-icon {
    flex-shrink: 0;
    color: #94a3b8;
    font-size: 10px;
  }

  .we-tree-item--selected .we-tree-icon {
    color: #3b82f6;
  }

  .we-tree-label {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  }

  /* ==========================================================================
     Control Groups (Section style - aligned with design spec)
     Uses separator lines instead of card borders
     ========================================================================== */

  .we-group {
    /* No card-style border, use separator lines between sections */
    border: 0;
    border-radius: 0;
    overflow: visible;
    background: transparent;
  }

  /* Section separator - top border for non-first groups */
  .we-group + .we-group {
    border-top: 1px solid var(--we-border-section);
    padding-top: 12px;
    margin-top: 4px;
  }

  .we-group-header {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
    padding: 0 0 8px 0;
    background: transparent;
  }

  .we-group-toggle {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
    padding: 0;
    background: transparent;
    border: 0;
    cursor: pointer;
    color: #333333;
    font-size: 11px;
    font-weight: 600;
    text-align: left;
    transition: color 0.1s ease;
  }

  .we-group-toggle:hover {
    color: var(--we-text-primary);
  }

  .we-group-toggle:focus-visible {
    outline: none;
    box-shadow: inset 0 0 0 2px var(--we-focus-ring);
    border-radius: 2px;
  }

  .we-group-toggle--static {
    cursor: default;
    pointer-events: none;
  }

  .we-group-header-actions {
    display: flex;
    align-items: center;
    gap: 2px;
    flex: 0 0 auto;
  }

  .we-group-body {
    padding: 0;
    background: transparent;
    border-top: 0;
  }

  .we-group[data-collapsed="true"] .we-group-body {
    display: none;
  }

  .we-chevron {
    width: 12px;
    height: 12px;
    flex: 0 0 auto;
    color: var(--we-text-muted);
    transition: transform 0.1s ease;
  }

  .we-group[data-collapsed="true"] .we-chevron {
    transform: rotate(-90deg);
  }

  /* ==========================================================================
     Form Controls (for Design controls)
     ========================================================================== */

  /* Field row: vertical stack (label on top, control below) */
  .we-field {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 4px;
  }

  /* Horizontal field variant (label left, control right) */
  .we-field--horizontal {
    flex-direction: row;
    align-items: center;
    gap: 8px;
  }

  .we-field-label {
    flex: 0 0 auto;
    width: auto;
    font-size: 10px;
    font-weight: 500;
    color: var(--we-text-secondary);
  }

  /* Fixed width label for horizontal layout */
  .we-field--horizontal .we-field-label {
    width: 48px;
  }

  .we-field-label--short {
    width: 20px;
  }

  /* Hint text (small label above icon groups for H/V distinction) */
  .we-field-hint {
    font-size: 9px;
    color: var(--we-text-muted);
    text-align: center;
    line-height: 1;
  }

  /* Content container for complex controls (icon groups, grids, etc.) */
  .we-field-content {
    width: 100%;
    min-width: 0;
  }

  /* Input styling aligned with design spec:
   * - Gray background by default
   * - Inset border on hover
   * - White background + blue inset border on focus
   */
  .we-input {
    flex: 1 1 auto;
    flex-shrink: 0; /* Prevent height shrinking in column flex containers */
    min-width: 0;
    height: 28px; /* Design spec: h-[28px] */
    padding: 0 8px;
    font-size: 11px;
    line-height: 26px; /* Ensure vertical centering: 28px - 2px border */
    font-family: inherit;
    color: var(--we-text-primary);
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    outline: none;
    transition: background 0.1s ease, border-color 0.1s ease, box-shadow 0.1s ease;
  }

  .we-input::placeholder {
    color: var(--we-text-muted);
  }

  .we-input:hover:not(:focus) {
    border-color: var(--we-control-border-hover);
  }

  .we-input:focus {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  /* ==========================================================================
   * Input Container (Phase 2.1)
   *
   * A wrapper for inputs with prefix/suffix support.
   * Container handles hover/focus-within styling instead of input itself.
   * ========================================================================== */
  .we-input-container {
    min-width: 0;
    display: flex;
    align-items: center;
    height: 28px; /* Design spec: h-[28px] - must be explicit, not flex-controlled */
    flex-shrink: 0; /* Prevent height shrinking in column flex containers */
    padding: 0 8px;
    gap: 4px;
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    transition: background 0.1s ease, border-color 0.1s ease, box-shadow 0.1s ease;
  }

  /* In row flex containers, allow input-container to grow horizontally */
  .we-field-row > .we-input-container,
  .we-radius-control .we-field-row > .we-input-container {
    flex: 1 1 0;
  }

  .we-input-container:hover:not(:focus-within) {
    border-color: var(--we-control-border-hover);
  }

  .we-input-container:focus-within {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  .we-input-container__input {
    flex: 1;
    min-width: 0;
    height: 100%;
    padding: 0;
    font-size: 11px;
    line-height: 26px; /* Ensure vertical centering within 28px container */
    font-family: inherit;
    color: var(--we-text-primary);
    background: transparent;
    border: none;
    outline: none;
  }

  .we-input-container__input::placeholder {
    color: var(--we-text-muted);
  }

  /* Number inputs: right-aligned text in containers */
  .we-input-container__input[inputmode="decimal"],
  .we-input-container__input[inputmode="numeric"] {
    text-align: right;
  }

  /* Prefix and suffix elements */
  .we-input-container__prefix,
  .we-input-container__suffix {
    flex: 0 0 auto;
    font-size: 10px;
    color: var(--we-text-muted);
    user-select: none;
    pointer-events: none;
  }

  .we-input-container__prefix {
    margin-right: 2px;
  }

  .we-input-container__suffix {
    margin-left: 2px;
  }

  /* Icon in prefix/suffix */
  .we-input-container__prefix svg,
  .we-input-container__suffix svg {
    width: 12px;
    height: 12px;
    display: block;
  }

  /* ==========================================================================
   * Slider Input (Opacity and other numeric ranges)
   * ========================================================================== */
  .we-slider-input {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    min-width: 0;
  }

  .we-slider-input__slider {
    flex: 1 1 auto;
    min-width: 0;
    height: 28px;
    margin: 0;
    padding: 0;
    background: transparent;
    -webkit-appearance: none;
    appearance: none;
    cursor: pointer;
  }

  .we-slider-input__slider:disabled {
    opacity: 0.55;
    cursor: not-allowed;
  }

  .we-slider-input__slider::-webkit-slider-runnable-track {
    height: 4px;
    background: linear-gradient(
      to right,
      var(--we-control-border-focus) 0%,
      var(--we-control-border-focus) var(--progress, 0%),
      var(--we-control-bg) var(--progress, 0%),
      var(--we-control-bg) 100%
    );
    border: 1px solid var(--we-control-border-hover);
    border-radius: 999px;
  }

  .we-slider-input__slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 12px;
    height: 12px;
    margin-top: -5px; /* (12px thumb - 4px track) / 2 + border */
    border-radius: 999px;
    background: var(--we-control-bg-focus);
    border: 1px solid var(--we-border-strong);
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.15);
  }

  .we-slider-input__slider:focus-visible {
    outline: none;
  }

  .we-slider-input__slider:focus-visible::-webkit-slider-thumb {
    border-color: var(--we-control-border-focus);
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25);
  }

  .we-slider-input__slider::-moz-range-track {
    height: 4px;
    background: linear-gradient(
      to right,
      var(--we-control-border-focus) 0%,
      var(--we-control-border-focus) var(--progress, 0%),
      var(--we-control-bg) var(--progress, 0%),
      var(--we-control-bg) 100%
    );
    border: 1px solid var(--we-control-border-hover);
    border-radius: 999px;
  }

  .we-slider-input__slider::-moz-range-thumb {
    width: 12px;
    height: 12px;
    border-radius: 999px;
    background: var(--we-control-bg-focus);
    border: 1px solid var(--we-border-strong);
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.15);
  }

  .we-slider-input__slider:focus-visible::-moz-range-thumb {
    border-color: var(--we-control-border-focus);
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25);
  }

  .we-slider-input__number {
    flex: 0 0 auto;
  }

  /* ==========================================================================
   * Icon Button Group (Phase 4.1)
   *
   * A single-select grid of icon buttons (e.g. flex-direction control).
   * ========================================================================== */
  .we-icon-button-group {
    display: grid;
    gap: 4px;
  }

  .we-icon-button-group__btn {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 28px; /* Design spec: h-[28px] */
    padding: 4px;
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    cursor: pointer;
    transition: background-color 0.1s ease, border-color 0.1s ease;
  }

  .we-icon-button-group__btn:hover:not(:disabled) {
    background: var(--we-control-bg-hover);
  }

  .we-icon-button-group__btn:focus-visible {
    outline: none;
    border-color: var(--we-control-border-focus);
    box-shadow: inset 0 0 0 2px var(--we-control-border-focus); /* Design spec: 2px inset */
  }

  .we-icon-button-group__btn[data-selected="true"] {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  .we-icon-button-group__btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .we-icon-button-group__btn svg {
    width: 14px;
    height: 14px;
    color: var(--we-text-secondary);
  }

  .we-icon-button-group__btn[data-selected="true"] svg {
    color: var(--we-control-border-focus);
  }

  /* ==========================================================================
   * Toggle Button
   *
   * A pressable toggle button (e.g. flip X/Y controls).
   * ========================================================================== */
  .we-toggle-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 4px;
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    cursor: pointer;
    transition: background-color 0.1s ease, border-color 0.1s ease;
  }

  .we-toggle-btn:hover:not(:disabled) {
    background: var(--we-control-bg-hover);
  }

  .we-toggle-btn[aria-pressed="true"] {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  .we-toggle-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .we-toggle-btn svg {
    width: 14px;
    height: 14px;
    color: var(--we-text-secondary);
  }

  .we-toggle-btn[aria-pressed="true"] svg {
    color: var(--we-control-border-focus);
  }

  /* ==========================================================================
   * Alignment Grid (Phase 4.2)
   *
   * 3×3 single-select grid for justify-content + align-items.
   * ========================================================================== */
  .we-alignment-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    padding: 8px;
    min-height: 90px;
    background: #f9f9f9;
    border: 1px solid #f0f0f0;
    border-radius: var(--we-radius-control);
    place-items: center;
  }

  .we-alignment-grid__cell {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    padding: 0;
    background: transparent;
    border: none;
    border-radius: 2px;
    cursor: pointer;
    transition: background-color 0.1s ease;
  }

  .we-alignment-grid__cell:hover:not(:disabled) {
    background: rgba(0, 0, 0, 0.05);
  }

  .we-alignment-grid__cell:focus-visible {
    outline: 2px solid var(--we-control-border-focus);
    outline-offset: 1px;
  }

  .we-alignment-grid__cell:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  /* Inactive dot */
  .we-alignment-grid__dot {
    width: 2px;
    height: 2px;
    background: var(--we-text-muted);
    border-radius: 50%;
  }

  /* Active marker (3 bars showing alignment) */
  .we-alignment-grid__marker {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    width: 12px;
    height: 12px;
  }

  .we-alignment-grid__bar {
    height: 2px;
    background: var(--we-control-border-focus);
    border-radius: 1px;
  }

  .we-alignment-grid__bar--1 { width: 8px; }
  .we-alignment-grid__bar--2 { width: 12px; }
  .we-alignment-grid__bar--3 { width: 4px; }

  /* ==========================================================================
   * Grid + Gap Two Column Layout (Layout Control)
   * ========================================================================== */

  .we-grid-gap-row {
    display: flex;
    gap: 8px;
  }

  .we-grid-gap-col {
    flex: 1;
    min-width: 0;
  }

  /* Keep Grid label space for alignment; hide text only when both columns are visible (grid mode) */
  .we-grid-gap-col--grid:not([hidden]):has(+ .we-grid-gap-col--gap:not([hidden])) .we-field-label {
    visibility: hidden;
  }

  .we-grid-gap-col .we-field-content {
    width: 100%;
    overflow: visible;
  }

  /* Gap inputs vertical layout */
  .we-grid-gap-inputs {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  /* ==========================================================================
   * Grid Dimensions Picker (Layout Control)
   * ========================================================================== */

  .we-grid-dimensions-preview {
    width: 100%;
    height: 64px; /* Match two rows of gap inputs: 28px + 8px gap + 28px */
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    font-size: 12px;
    font-family: inherit;
    color: var(--we-text-primary);
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    cursor: pointer;
    transition: background-color 0.1s ease, border-color 0.1s ease;
  }

  .we-grid-dimensions-preview:hover:not(:disabled) {
    background: var(--we-control-bg-hover);
  }

  .we-grid-dimensions-preview:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .we-grid-dimensions-popover {
    position: absolute;
    top: calc(100% + 4px);
    left: 0;
    min-width: 220px;
    padding: 10px;
    background: var(--we-surface-bg);
    border: 1px solid var(--we-border-subtle);
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.12);
    z-index: 60;
  }

  .we-grid-dimensions-popover[hidden] {
    display: none;
  }

  .we-grid-dimensions-inputs {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-bottom: 10px;
  }

  .we-grid-dimensions-times {
    font-size: 12px;
    color: var(--we-text-muted);
    user-select: none;
  }

  .we-grid-dimensions-matrix {
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    gap: 3px;
    padding: 6px;
    background: var(--we-surface-secondary);
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-control);
  }

  .we-grid-dimensions-cell {
    width: 100%;
    aspect-ratio: 1 / 1;
    background: transparent;
    border: 1px solid rgba(0, 0, 0, 0.10);
    border-radius: 2px;
    padding: 0;
    cursor: pointer;
    transition: background-color 0.08s ease, border-color 0.08s ease;
  }

  .we-grid-dimensions-cell[data-active="true"] {
    border-color: rgba(59, 130, 246, 0.65);
    background: rgba(59, 130, 246, 0.10);
  }

  .we-grid-dimensions-cell[data-selected="true"] {
    border-color: rgba(59, 130, 246, 0.9);
    background: rgba(59, 130, 246, 0.16);
  }

  .we-grid-dimensions-tooltip {
    margin-top: 8px;
    text-align: center;
    font-size: 11px;
    color: var(--we-text-secondary);
  }

  .we-grid-dimensions-tooltip[hidden] {
    display: none;
  }

  .we-input--short {
    width: 56px;
    flex: 0 0 auto;
  }

  /* Number inputs: right-aligned text */
  .we-input[type="text"][inputmode="decimal"],
  .we-input[type="number"] {
    text-align: right;
  }

  .we-select {
    flex: 1 1 auto;
    flex-shrink: 0; /* Prevent height shrinking in column flex containers */
    min-width: 0;
    height: 28px; /* Design spec: h-[28px] */
    padding: 0 24px 0 8px;
    font-size: 11px;
    line-height: 26px; /* Ensure vertical centering: 28px - 2px border */
    font-family: inherit;
    color: var(--we-text-primary);
    background: var(--we-control-bg) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 10 10'%3E%3Cpath fill='%23737373' d='M2.5 3.5l2.5 3 2.5-3'/%3E%3C/svg%3E") no-repeat right 8px center;
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    outline: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    cursor: pointer;
    transition: background-color 0.1s ease, border-color 0.1s ease, box-shadow 0.1s ease;
  }

  .we-select:hover:not(:focus) {
    border-color: var(--we-control-border-hover);
  }

  .we-select:focus {
    background-color: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  /* Field row for multiple inputs side by side */
  .we-field-row {
    display: flex;
    align-items: stretch;
    gap: 8px;
  }

  /* Size field with mode select + input stacked vertically */
  .we-size-field {
    display: flex;
    flex-direction: column;
    gap: 4px;
    flex: 1;
    min-width: 0;
  }

  .we-size-mode-select {
    width: 100%;
  }

  .we-field-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  /* ==========================================================================
     Effects (Box Shadow List)
     ========================================================================== */

  .we-effects-toolbar {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 6px;
  }

  .we-effects-list {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .we-effects-item-wrap {
    position: relative;
  }

  .we-effects-item {
    height: 28px;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 0 6px;
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    transition: background-color 0.1s ease, border-color 0.1s ease, opacity 0.1s ease;
  }

  .we-effects-item:hover {
    background: var(--we-control-bg-hover);
  }

  .we-effects-item[data-open="true"] {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  .we-effects-item[data-enabled="false"] {
    opacity: 0.55;
  }

  .we-effects-name {
    flex: 1;
    min-width: 0;
    padding: 0;
    border: 0;
    background: transparent;
    text-align: left;
    font-size: 11px;
    color: var(--we-text-primary);
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .we-effects-name:focus-visible {
    outline: none;
    box-shadow: inset 0 0 0 2px var(--we-focus-ring);
    border-radius: 4px;
  }

  .we-effects-icon-btn {
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: 0;
    border-radius: var(--we-radius-control);
    color: var(--we-text-secondary);
    cursor: pointer;
    padding: 0;
    transition: background-color 0.1s ease, color 0.1s ease;
  }

  .we-effects-icon-btn:hover:not(:disabled) {
    background: rgba(0, 0, 0, 0.06);
    color: var(--we-text-primary);
  }

  .we-effects-icon-btn:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-effects-icon-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .we-effects-icon-btn svg {
    width: 14px;
    height: 14px;
  }

  .we-effects-popover {
    position: absolute;
    top: calc(100% + 6px);
    left: 0;
    width: 220px;
    max-width: 220px;
    padding: 10px;
    background: var(--we-surface-bg);
    border: 1px solid var(--we-border-subtle);
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.12);
    z-index: 60;
  }

  .we-effects-popover[hidden] {
    display: none;
  }

  .we-effects-popover-content {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  /* ==========================================================================
     Gradient Preview Bar (Phase 4B)
     ========================================================================== */

  .we-gradient-bar-row {
    width: 100%;
    padding: 4px 0 8px;
  }

  .we-gradient-bar {
    position: relative;
    width: 100%;
    height: 60px;
    border-radius: 14px;
    border: 1px solid var(--we-border-subtle);
    background-color: var(--we-control-bg);
    background-image: none; /* set inline by GradientControl */
    box-shadow:
      inset 0 1px 2px rgba(0, 0, 0, 0.08),
      inset 0 0 0 1px rgba(255, 255, 255, 0.5);
    overflow: hidden;
  }

  /* Gradient thumbs container */
  .we-gradient-bar-thumbs {
    position: absolute;
    inset: 0;
    pointer-events: none; /* thumbs enable pointer events individually */
  }

  /* Gradient thumb (color stop marker) */
  .we-gradient-thumb {
    pointer-events: auto;
    position: absolute;
    top: 50%;
    left: 0;
    transform: translate(-50%, -50%);
    z-index: 1;
    width: 32px;
    height: 32px;
    border-radius: 6px;
    border: 2px solid rgba(255, 255, 255, 0.98);
    background-color: transparent; /* set inline */
    cursor: pointer;
    padding: 0;
    box-sizing: border-box;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
    touch-action: none;
    user-select: none;
    transition: box-shadow 0.15s ease, z-index 0s;
  }

  .we-gradient-thumb:hover {
    box-shadow:
      0 0 0 2px rgba(59, 130, 246, 0.25),
      0 1px 3px rgba(0, 0, 0, 0.2);
  }

  .we-gradient-thumb:focus-visible {
    outline: none;
    box-shadow:
      0 0 0 3px rgba(59, 130, 246, 0.4),
      0 1px 3px rgba(0, 0, 0, 0.2);
  }

  /* Selected thumb state - raise above unselected thumbs */
  .we-gradient-thumb--active {
    z-index: 2;
    box-shadow:
      0 0 0 3px rgba(59, 130, 246, 0.4),
      0 1px 3px rgba(0, 0, 0, 0.2);
  }

  /* Dragging thumb - always on top when overlapping at same position */
  .we-gradient-thumb--dragging {
    z-index: 3;
  }

  /* Dragging state - cursor feedback on entire bar */
  .we-gradient-bar--dragging {
    cursor: grabbing;
  }

  .we-gradient-bar--dragging .we-gradient-thumb {
    cursor: grabbing;
  }

  /* ==========================================================================
     Gradient Stops List (Phase 4D)
     ========================================================================== */

  .we-gradient-stops-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0 4px;
  }

  .we-gradient-stops-title {
    font-size: 10px;
    font-weight: 600;
    color: var(--we-text-secondary);
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .we-gradient-stops-add,
  .we-gradient-stop-remove {
    font-size: 14px;
    font-weight: 500;
    line-height: 1;
  }

  .we-gradient-stops-add:disabled,
  .we-gradient-stop-remove:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }

  .we-gradient-stops-list {
    border: 1px solid var(--we-border-subtle);
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.6);
    padding: 6px;
    display: flex;
    flex-direction: column;
    gap: 4px;
    max-height: 180px;
    overflow-y: auto;
    overscroll-behavior: contain;
  }

  .we-gradient-stop-row {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 5px 6px;
    border-radius: 8px;
    border: 1px solid transparent;
    background: rgba(255, 255, 255, 0.85);
    cursor: pointer;
    user-select: none;
    transition: border-color 0.15s ease, background 0.15s ease;
  }

  .we-gradient-stop-row:hover {
    background: rgba(59, 130, 246, 0.06);
  }

  .we-gradient-stop-row:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.35);
  }

  .we-gradient-stop-row--active {
    border-color: rgba(59, 130, 246, 0.6);
    box-shadow: 0 0 0 1px rgba(59, 130, 246, 0.2);
  }

  .we-gradient-stop-pos {
    flex: 0 0 auto;
    min-width: 44px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    text-align: right;
    font-variant-numeric: tabular-nums;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    color: var(--we-text-secondary);
    padding: 3px 6px;
    border-radius: 6px;
    background: var(--we-control-bg);
    cursor: pointer;
    transition: box-shadow 0.15s ease;
  }

  .we-gradient-stop-pos:hover {
    background: var(--we-control-bg-hover, var(--we-control-bg));
  }

  .we-gradient-stop-pos:focus-within {
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25);
  }

  /* Static position display (visible when row is not selected) */
  .we-gradient-stop-pos-static {
    display: block;
    width: 100%;
    text-align: right;
  }

  /* Position editor slot (visible when row is selected) */
  .we-gradient-stop-pos-editor {
    display: none;
    width: 100%;
  }

  /* Show editor and hide static in active row */
  .we-gradient-stop-row--active .we-gradient-stop-pos-static {
    display: none;
  }

  .we-gradient-stop-row--active .we-gradient-stop-pos-editor {
    display: block;
  }

  /* Position input styling */
  .we-gradient-stop-pos-input {
    width: 100%;
    border: 0;
    padding: 0;
    margin: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    text-align: right;
    outline: none;
    cursor: text;
  }

  .we-gradient-stop-pos-input::placeholder {
    color: var(--we-text-muted);
  }

  .we-gradient-stop-color {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 3px 8px;
    border-radius: 6px;
    background: var(--we-control-bg);
  }

  /* Static color display (visible when row is not selected) */
  .we-gradient-stop-color-static {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 0;
    border: 0;
    background: transparent;
    color: inherit;
    cursor: pointer;
    text-align: left;
    font-family: inherit;
  }

  .we-gradient-stop-color-static:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25);
    border-radius: 4px;
  }

  /* Color editor slot (visible when row is selected) */
  .we-gradient-stop-color-editor {
    flex: 1;
    min-width: 0;
    display: none;
  }

  /* When row is active: hide static, show editor */
  .we-gradient-stop-row--active .we-gradient-stop-color {
    padding: 0;
    background: transparent;
  }

  .we-gradient-stop-row--active .we-gradient-stop-color-static {
    display: none;
  }

  .we-gradient-stop-row--active .we-gradient-stop-color-editor {
    display: block;
  }

  .we-gradient-stop-swatch {
    flex: 0 0 auto;
    width: 14px;
    height: 14px;
    border-radius: 3px;
    border: 1px solid rgba(0, 0, 0, 0.12);
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.2);
    background: transparent;
  }

  .we-gradient-stop-color-text {
    flex: 1;
    min-width: 0;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    color: var(--we-text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* Spacing section (Padding / Margin) */
  .we-spacing-section {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .we-spacing-section + .we-spacing-section {
    margin-top: 10px;
  }

  .we-spacing-header {
    font-size: 10px;
    font-weight: 600;
    color: #6b7280;
  }

  /* Spacing 2x2 grid layout */
  .we-spacing-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
  }

  /* ==========================================================================
   * Border Radius Control
   * ========================================================================== */

  .we-radius-control {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .we-radius-corners-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
  }

  /* ==========================================================================
     CSS Panel (Phase 4.6)
     ========================================================================== */

  .we-css-panel {
    font-size: 11px;
    line-height: 1.5;
  }

  /* Code-semantic elements use monospace font */
  .we-css-rule-selector,
  .we-css-decl-name,
  .we-css-decl-value,
  .we-css-decl-colon,
  .we-css-decl-semi,
  .we-css-decl-important,
  .we-css-rule-source,
  .we-css-rule-spec {
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  }

  /* ==========================================================================
     Class Editor (Phase 4.7)
     ========================================================================== */

  .we-css-class-editor-mount {
    margin-bottom: 12px;
  }

  .we-class-editor {
    position: relative;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 6px;
    padding: 8px 10px;
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-panel);
    background: var(--we-surface-bg);
    font-family: system-ui, -apple-system, sans-serif;
  }

  .we-class-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    flex: 0 1 auto;
  }

  .we-class-chip {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 999px;
    background: var(--we-accent-brand-bg);
    border: 1px solid var(--we-accent-brand-border);
    color: #4338ca;
    font-size: 11px;
    line-height: 1.2;
  }

  .we-class-chip-text {
    word-break: break-all;
  }

  .we-class-chip-remove {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 16px;
    height: 16px;
    padding: 0;
    border: none;
    border-radius: 999px;
    background: transparent;
    color: rgba(67, 56, 202, 0.8);
    cursor: pointer;
    font-size: 14px;
    line-height: 1;
    transition: background-color 0.15s ease;
  }

  .we-class-chip-remove:hover {
    background: rgba(99, 102, 241, 0.15);
    color: #4338ca;
  }

  .we-class-input {
    flex: 1 1 100px;
    min-width: 80px;
    padding: 5px 8px;
    font-size: 12px;
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-control);
    background: var(--we-control-bg-focus);
    outline: none;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
  }

  .we-class-input:focus {
    border-color: var(--we-control-border-focus);
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-class-input:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .we-class-input::placeholder {
    color: #94a3b8;
  }

  .we-class-suggestions {
    position: absolute;
    top: calc(100% + 4px);
    left: 0;
    right: 0;
    background: var(--we-surface-bg);
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-panel);
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.12);
    overflow: hidden;
    z-index: 20;
  }

  .we-class-suggestions[hidden] {
    display: none;
  }

  .we-class-suggestion {
    display: block;
    width: 100%;
    text-align: left;
    padding: 8px 10px;
    border: none;
    background: transparent;
    cursor: pointer;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    color: #0f172a;
    transition: background-color 0.1s ease;
  }

  .we-class-suggestion:hover {
    background: rgba(99, 102, 241, 0.08);
  }

  .we-class-suggestion:focus {
    outline: none;
    background: rgba(99, 102, 241, 0.12);
  }

  .we-css-info {
    padding: 8px 10px;
    background: var(--we-accent-info-bg);
    border-radius: var(--we-radius-control);
    color: var(--we-text-secondary);
    font-size: 10px;
    margin-bottom: 8px;
  }

  .we-css-info[hidden] {
    display: none;
  }

  .we-css-warnings {
    margin-bottom: 8px;
  }

  .we-css-warnings[hidden] {
    display: none;
  }

  .we-css-warning {
    padding: 6px 10px;
    background: var(--we-accent-warning-bg);
    border: 1px solid var(--we-accent-warning-border);
    border-radius: var(--we-radius-control);
    color: #92400e;
    font-size: 10px;
    margin-bottom: 4px;
  }

  .we-css-warning-more {
    padding: 4px 10px;
    color: #92400e;
    font-size: 10px;
    font-style: italic;
  }

  .we-css-empty {
    padding: 24px 12px;
    color: #64748b;
    text-align: center;
    font-family: system-ui, sans-serif;
    font-size: 12px;
  }

  .we-css-empty[hidden] {
    display: none;
  }

  .we-css-sections {
    display: flex;
    flex-direction: column;
    gap: 0;
  }

  .we-css-section {
    border: 0;
    border-radius: 0;
    overflow: visible;
    background: transparent;
  }

  .we-css-section + .we-css-section {
    border-top: 1px solid var(--we-border-section);
    padding-top: 12px;
    margin-top: 4px;
  }

  .we-css-section[data-kind="inherited"] {
    background: transparent;
  }

  .we-css-section-header {
    padding: 0 0 8px 0;
    background: transparent;
    border-bottom: 0;
    font-weight: 600;
    color: var(--we-text-primary);
    font-size: 11px;
    text-transform: none;
    letter-spacing: normal;
  }

  .we-css-section-rules {
    padding: 0;
  }

  /* Flat list style (computed-like view) */
  .we-css-rule {
    margin: 0;
    padding: 0;
    background: transparent;
    border: 0;
    border-radius: 0;
  }

  .we-css-rule + .we-css-rule {
    border-top: 1px solid var(--we-border-section);
    padding-top: 10px;
    margin-top: 10px;
  }

  .we-css-rule[data-origin="inline"] {
    background: transparent;
  }

  .we-css-rule-header {
    display: flex;
    align-items: baseline;
    gap: 8px;
    flex-wrap: nowrap;
    margin-bottom: 8px;
    padding-bottom: 0;
    border-bottom: 0;
  }

  .we-css-rule-selector {
    flex: 1 1 auto;
    min-width: 0;
    font-weight: 500;
    color: var(--we-text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-css-rule[data-origin="inline"] .we-css-rule-selector {
    color: #92400e;
    font-style: italic;
  }

  .we-css-rule-source {
    flex-shrink: 0;
    color: var(--we-text-muted);
    font-size: 10px;
    margin-left: auto;
    max-width: 45%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-css-rule-spec {
    flex-shrink: 0;
    color: var(--we-text-muted);
    font-size: 9px;
    padding: 1px 4px;
    background: var(--we-control-bg);
    border-radius: 3px;
  }

  .we-css-decls {
    padding-left: 0;
  }

  /* Two-column grid layout for declarations */
  .we-css-decl {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1.4fr);
    column-gap: 12px;
    align-items: baseline;
    padding: 5px 0;
    color: var(--we-text-primary);
  }


  .we-css-decl[data-status="overridden"] {
    text-decoration: line-through;
    color: var(--we-text-muted);
  }

  .we-css-decl-name {
    color: var(--we-text-secondary);
    overflow-wrap: anywhere;
  }

  /* Hide punctuation for computed-like view */
  .we-css-decl-colon,
  .we-css-decl-semi {
    display: none;
  }

  /* Value container for flex layout with !important */
  .we-css-decl-value-container {
    display: flex;
    align-items: baseline;
    gap: 4px;
    min-width: 0;
  }

  .we-css-decl-value {
    color: var(--we-text-primary);
    margin-left: 0;
    min-width: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-css-decl[data-status="overridden"] .we-css-decl-name,
  .we-css-decl[data-status="overridden"] .we-css-decl-value {
    color: var(--we-text-muted);
  }

  .we-css-decl-important {
    flex-shrink: 0;
    color: #dc2626;
    font-weight: 600;
    font-size: 10px;
  }

  .we-css-decl[data-status="overridden"] .we-css-decl-important {
    color: #b8c4d0;
  }

  /* ==========================================================================
   * Token Picker (Phase 5.4)
   * ========================================================================== */

  .we-token-picker {
    position: absolute;
    top: calc(100% + 4px);
    left: 0;
    right: 0;
    background: white;
    border: 1px solid rgba(226, 232, 240, 0.95);
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.12);
    overflow: hidden;
    z-index: 30;
  }

  .we-token-picker[hidden] {
    display: none;
  }

  .we-token-filter {
    width: 100%;
    padding: 8px 10px;
    border: none;
    border-bottom: 1px solid rgba(226, 232, 240, 0.8);
    background: transparent;
    font-family: inherit;
    font-size: 11px;
    color: #0f172a;
    outline: none;
  }

  .we-token-filter::placeholder {
    color: #94a3b8;
  }

  .we-token-toggle-row {
    padding: 6px 10px;
    border-bottom: 1px solid rgba(226, 232, 240, 0.6);
    background: rgba(248, 250, 252, 0.5);
  }

  .we-token-toggle-label {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 10px;
    color: #64748b;
    cursor: pointer;
  }

  .we-token-toggle-checkbox {
    width: 12px;
    height: 12px;
    margin: 0;
    cursor: pointer;
  }

  .we-token-list {
    overflow-y: auto;
    overscroll-behavior: contain;
  }

  .we-token-list[hidden] {
    display: none;
  }

  .we-token-item {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    text-align: left;
    padding: 8px 10px;
    border: none;
    background: transparent;
    cursor: pointer;
    transition: background-color 0.1s ease;
  }

  .we-token-item:hover {
    background: rgba(99, 102, 241, 0.06);
  }

  .we-token-item--selected,
  .we-token-item:focus {
    outline: none;
    background: rgba(99, 102, 241, 0.1);
  }

  .we-token-swatch {
    flex-shrink: 0;
    width: 14px;
    height: 14px;
    border-radius: 3px;
    border: 1px solid rgba(0, 0, 0, 0.1);
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.2);
  }

  .we-token-name {
    flex: 1;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    color: #0f172a;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-token-value {
    flex-shrink: 0;
    max-width: 80px;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 10px;
    color: #64748b;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-token-empty {
    padding: 16px 10px;
    text-align: center;
    color: #94a3b8;
    font-size: 11px;
  }

  .we-token-empty[hidden] {
    display: none;
  }

  /* Token button for input fields */
  .we-token-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    padding: 0;
    border: none;
    border-radius: 4px;
    background: rgba(99, 102, 241, 0.08);
    color: #6366f1;
    cursor: pointer;
    transition: background-color 0.15s ease;
  }

  .we-token-btn:hover {
    background: rgba(99, 102, 241, 0.15);
  }

  .we-token-btn:focus {
    outline: none;
    box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.3);
  }

  .we-token-btn-icon {
    width: 12px;
    height: 12px;
  }

  /* ==========================================================================
   * Token Pill (Phase 5.3)
   *
   * Compact pill UI for displaying a CSS var() reference in input fields.
   * Used when ColorField value is a standalone var(--token) expression.
   * ========================================================================== */

  .we-token-pill {
    flex: 1;
    min-width: 0;
    height: 28px;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 0 6px 0 4px;
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    transition: background 0.1s ease, border-color 0.1s ease;
  }

  .we-token-pill:hover:not([data-disabled="true"]) {
    border-color: var(--we-control-border-hover);
  }

  .we-token-pill:focus-within {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  .we-token-pill[data-disabled="true"] {
    opacity: 0.5;
    pointer-events: none;
  }

  .we-token-pill[hidden] {
    display: none;
  }

  /* Leading slot: holds external element (ColorField swatch) or internal swatch */
  .we-token-pill__leading {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
  }

  /* Internal swatch (used when no external leading element provided) */
  .we-token-pill__swatch {
    width: 16px;
    height: 16px;
    border-radius: 4px;
    border: 1px solid rgba(0, 0, 0, 0.1);
    background: transparent;
  }

  /* Main clickable area */
  .we-token-pill__main {
    flex: 1;
    min-width: 0;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding: 0;
    border: none;
    background: transparent;
    color: var(--we-text-primary);
    cursor: pointer;
    font-size: 11px;
    text-align: left;
  }

  .we-token-pill__main:focus {
    outline: none;
  }

  .we-token-pill__main:disabled {
    cursor: default;
  }

  /* Token name with ellipsis */
  .we-token-pill__name {
    min-width: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
  }

  /* Link icon (rotated 45° to indicate variable binding) */
  .we-token-pill__icon {
    width: 14px;
    height: 14px;
    flex: 0 0 auto;
    color: var(--we-text-muted);
    transform: rotate(45deg);
  }

  /* Clear button (hover to reveal) */
  .we-token-pill__clear {
    width: 18px;
    height: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    border: none;
    border-radius: 4px;
    background: transparent;
    color: var(--we-text-muted);
    font-size: 14px;
    line-height: 1;
    cursor: pointer;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.12s ease, background 0.12s ease, color 0.12s ease;
  }

  .we-token-pill:hover .we-token-pill__clear {
    opacity: 1;
    pointer-events: auto;
  }

  .we-token-pill__clear:hover {
    background: rgba(15, 23, 42, 0.06);
    color: var(--we-text-primary);
  }

  .we-token-pill__clear:focus {
    outline: none;
    opacity: 1;
    pointer-events: auto;
  }

  .we-token-pill__clear:disabled {
    cursor: default;
  }

  /* ==========================================================================
     Props Panel (Phase 7.3)
     ========================================================================== */

  .we-props-panel {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .we-props-meta {
    padding: 0 0 8px 0;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .we-props-meta-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    color: var(--we-text-primary);
    font-size: 11px;
    font-weight: 600;
  }

  .we-props-component {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .we-props-badge {
    flex: 0 0 auto;
    font-size: 10px;
    font-weight: 600;
    padding: 2px 6px;
    border-radius: 999px;
    background: var(--we-accent-brand-bg);
    color: #1d4ed8;
  }

  .we-props-status {
    font-size: 11px;
    color: #64748b;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  }

  .we-props-warning {
    font-size: 11px;
    color: #92400e;
    background: var(--we-accent-warning-bg);
    border: 1px solid var(--we-accent-warning-border);
    border-radius: var(--we-radius-control);
    padding: 6px 8px;
  }

  .we-props-error {
    font-size: 11px;
    color: #b91c1c;
    background: var(--we-accent-danger-bg);
    border: 1px solid var(--we-accent-danger-border);
    border-radius: var(--we-radius-control);
    padding: 6px 8px;
  }

  .we-props-source {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 11px;
    padding: 4px 0;
  }

  .we-props-source[hidden] {
    display: none;
  }

  .we-props-source-label {
    flex: 0 0 auto;
    color: #64748b;
    font-weight: 500;
  }

  .we-props-source-path {
    flex: 1 1 auto;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: var(--we-text-primary);
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  }

  .we-btn-small {
    padding: 2px 8px;
    font-size: 11px;
  }

  /* Source open button - minimal link style */
  .we-props-source-btn {
    flex: 0 0 auto;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 2px;
    margin-left: 2px;
    border: none;
    background: none;
    color: #64748b;
    cursor: pointer;
    transition: color 0.12s ease;
  }

  .we-props-source-btn:hover:not(:disabled) {
    color: #3b82f6;
  }

  .we-props-source-btn:disabled {
    opacity: 0.35;
    cursor: not-allowed;
  }

  .we-props-source-btn svg {
    display: block;
  }

  /* Tooltip - fixed position, mounted at shadow root level */
  .we-tooltip {
    position: fixed;
    transform: translateX(-50%);
    padding: 4px 8px;
    font-size: 11px;
    font-weight: 500;
    line-height: 1.2;
    color: #fff;
    background: rgba(15, 23, 42, 0.92);
    border-radius: 4px;
    white-space: nowrap;
    pointer-events: none;
    z-index: 10000;
  }

  .we-tooltip[hidden] {
    display: none;
  }

  .we-props-title-left {
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
  }

  .we-props-title-actions {
    display: flex;
    align-items: center;
    gap: 2px;
    margin-left: auto;
  }

  /* Action button - minimal icon style for title bar */
  .we-props-action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 4px;
    border: none;
    background: none;
    color: var(--we-text-secondary);
    cursor: pointer;
    transition: color 0.12s ease;
  }

  .we-props-action-btn:hover:not(:disabled) {
    color: var(--we-text-primary);
  }

  .we-props-action-btn:disabled {
    opacity: 0.35;
    cursor: not-allowed;
  }

  .we-props-action-btn svg {
    display: block;
  }

  .we-props-list {
    overflow: hidden;
  }

  .we-props-empty {
    padding: 16px 12px;
    color: #64748b;
    font-size: 12px;
    text-align: center;
  }

  .we-props-empty[hidden] {
    display: none;
  }

  /* Loading animations */
  @keyframes we-shimmer {
    to {
      background-position: 200% center;
    }
  }

  @keyframes we-spin {
    to {
      transform: rotate(360deg);
    }
  }

  .we-props-empty.we-loading {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
  }

  .we-props-empty.we-loading svg {
    flex-shrink: 0;
    color: #94a3b8;
  }

  .we-props-empty.we-loading span {
    background: linear-gradient(
      90deg,
      #64748b 0%,
      #94a3b8 50%,
      #64748b 100%
    );
    background-size: 200% auto;
    color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
    animation: we-shimmer 2s linear infinite;
  }

  .we-props-group {
    padding: 0 0 8px 0;
    margin-top: 4px;
    color: var(--we-text-primary);
    font-size: 11px;
    font-weight: 600;
    border-top: 1px solid var(--we-border-section);
    padding-top: 12px;
  }

  .we-props-group:first-child {
    border-top: 0;
    margin-top: 0;
    padding-top: 0;
  }

  .we-props-group + .we-props-row {
    border-top: 0;
  }

  .we-props-rows {
    display: flex;
    flex-direction: column;
  }

  .we-props-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    border-top: 1px solid var(--we-border-section);
  }

  .we-props-row:first-child {
    border-top: 0;
  }

  .we-props-key {
    flex: 0 0 110px;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    color: #334155;
  }

  .we-props-value {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;
  }

  .we-props-value--readonly {
    justify-content: flex-start;
    color: #475569;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-props-input {
    width: 140px;
    max-width: 100%;
  }

  .we-props-input--invalid {
    border-color: rgba(248, 113, 113, 0.85);
  }

  .we-props-bool {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: 11px;
    color: #475569;
    cursor: pointer;
  }

  .we-props-checkbox {
    width: 14px;
    height: 14px;
    accent-color: #6366f1;
    cursor: pointer;
  }

  .we-props-checkbox:disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }

  /* ==========================================================================
   * Color Field (Phase 4.4)
   * ========================================================================== */

  .we-color-field {
    flex: 1;
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
  }

  .we-color-swatch {
    flex: 0 0 auto;
    width: 24px;
    height: 24px;
    padding: 0;
    position: relative;
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-control);
    background: var(--we-control-bg);
    cursor: pointer;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
    overflow: hidden;
  }

  .we-color-swatch:hover {
    border-color: var(--we-border-strong);
  }

  .we-color-swatch:focus-visible,
  .we-color-swatch:focus-within {
    outline: none;
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-color-swatch:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  /* Native color input overlays the swatch for direct click interaction */
  .we-color-native-input {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    cursor: pointer;
    border: none;
    padding: 0;
    margin: 0;
  }

  .we-color-text {
    flex: 1;
    min-width: 0;
  }

  /* ==========================================================================
   * Tooltip (data-tooltip)
   *
   * CSS-only tooltips using the data-tooltip attribute.
   * Shows on hover/focus with minimal delay.
   * ========================================================================== */

  [data-tooltip] {
    position: relative;
  }

  [data-tooltip]::after {
    content: attr(data-tooltip);
    position: absolute;
    bottom: calc(100% + 6px);
    left: 50%;
    transform: translateX(-50%);
    padding: 4px 8px;
    font-size: 11px;
    font-family: inherit;
    font-weight: 400;
    line-height: 1.3;
    white-space: nowrap;
    color: var(--we-surface-bg);
    background-color: var(--we-text-primary);
    border-radius: var(--we-radius-control);
    opacity: 0;
    visibility: hidden;
    transition:
      opacity 100ms ease,
      visibility 100ms ease;
    pointer-events: none;
    z-index: 99999;
  }

  [data-tooltip]::before {
    content: '';
    position: absolute;
    bottom: calc(100% + 2px);
    left: 50%;
    transform: translateX(-50%);
    border: 4px solid transparent;
    border-top-color: var(--we-text-primary);
    opacity: 0;
    visibility: hidden;
    transition:
      opacity 100ms ease,
      visibility 100ms ease;
    pointer-events: none;
    z-index: 99999;
  }

  [data-tooltip]:hover::after,
  [data-tooltip]:focus-visible::after,
  [data-tooltip]:focus-within::after {
    opacity: 1;
    visibility: visible;
  }

  [data-tooltip]:hover::before,
  [data-tooltip]:focus-visible::before,
  [data-tooltip]:focus-within::before {
    opacity: 1;
    visibility: visible;
  }

  /* ==========================================================================
   * Global Hidden Rule
   * Ensures [hidden] attribute always hides elements, even when they have
   * explicit display values (flex, inline-flex, etc.)
   * ========================================================================== */
  [hidden] {
    display: none !important;
  }
`;
	/**
	* Set a CSS property with !important flag
	*/
	function setImportantStyle(element, property, value) {
		element.style.setProperty(property, value, "important");
	}
	/**
	* Mount the Shadow DOM host and return a manager interface
	*/
	function mountShadowHost(options = {}) {
		var _document$documentEle;
		const disposer = new Disposer();
		let elements = null;
		const existing = document.getElementById(WEB_EDITOR_V2_HOST_ID);
		if (existing) try {
			existing.remove();
		} catch (_unused) {}
		const host = document.createElement("div");
		host.id = WEB_EDITOR_V2_HOST_ID;
		host.setAttribute("data-mcp-web-editor", "v2");
		setImportantStyle(host, "position", "fixed");
		setImportantStyle(host, "inset", "0");
		setImportantStyle(host, "z-index", String(WEB_EDITOR_V2_Z_INDEX));
		setImportantStyle(host, "pointer-events", "none");
		setImportantStyle(host, "contain", "layout style paint");
		setImportantStyle(host, "isolation", "isolate");
		const shadowRoot = host.attachShadow({ mode: "open" });
		const styleEl = document.createElement("style");
		styleEl.textContent = SHADOW_HOST_STYLES;
		shadowRoot.append(styleEl);
		const overlayRoot = document.createElement("div");
		overlayRoot.id = WEB_EDITOR_V2_OVERLAY_ID;
		const uiRoot = document.createElement("div");
		uiRoot.id = WEB_EDITOR_V2_UI_ID;
		shadowRoot.append(overlayRoot, uiRoot);
		((_document$documentEle = document.documentElement) !== null && _document$documentEle !== void 0 ? _document$documentEle : document.body).append(host);
		disposer.add(() => host.remove());
		elements = {
			host,
			shadowRoot,
			overlayRoot,
			uiRoot
		};
		const blockedEvents = [
			"pointerdown",
			"pointerup",
			"pointermove",
			"pointerenter",
			"pointerleave",
			"mousedown",
			"mouseup",
			"mousemove",
			"mouseenter",
			"mouseleave",
			"click",
			"dblclick",
			"contextmenu",
			"keydown",
			"keyup",
			"keypress",
			"wheel",
			"touchstart",
			"touchmove",
			"touchend",
			"touchcancel",
			"focus",
			"blur",
			"input",
			"change"
		];
		const stopPropagation = (event) => {
			event.stopPropagation();
		};
		for (const eventType of blockedEvents) {
			disposer.listen(uiRoot, eventType, stopPropagation);
			disposer.listen(overlayRoot, eventType, stopPropagation);
		}
		const isOverlayElement = (node) => {
			if (!(node instanceof Node)) return false;
			if (node === host) return true;
			const root = typeof node.getRootNode === "function" ? node.getRootNode() : null;
			return root instanceof ShadowRoot && root.host === host;
		};
		const isEventFromUi = (event) => {
			try {
				if (typeof event.composedPath === "function") return event.composedPath().some((el) => isOverlayElement(el));
			} catch (_unused2) {}
			return isOverlayElement(event.target);
		};
		return {
			getElements: () => elements,
			isOverlayElement,
			isEventFromUi,
			dispose: () => {
				elements = null;
				disposer.dispose();
			}
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/floating-drag.ts
	var WINDOW_CAPTURE = {
		capture: true,
		passive: false
	};
	function blockEvent(event) {
		if (event.cancelable) event.preventDefault();
		event.stopImmediatePropagation();
		event.stopPropagation();
	}
	function clampNumber$1(value, min, max) {
		if (!Number.isFinite(value)) return min;
		return Math.min(Math.max(min, max), Math.max(Math.min(min, max), value));
	}
	function clampPosition(position, size, clampMargin, viewport) {
		const margin = Number.isFinite(clampMargin) ? Math.max(0, clampMargin) : 0;
		const maxLeft = Math.max(margin, viewport.width - margin - size.width);
		const maxTop = Math.max(margin, viewport.height - margin - size.height);
		return {
			left: clampNumber$1(position.left, margin, maxLeft),
			top: clampNumber$1(position.top, margin, maxTop)
		};
	}
	function roundPosition(position) {
		return {
			left: Math.round(position.left),
			top: Math.round(position.top)
		};
	}
	/**
	* Install drag behavior on a floating UI element.
	*
	* @returns Cleanup function to remove all event listeners
	*/
	function installFloatingDrag(options) {
		var _options$clickThresho, _options$moveThreshol;
		const { handleEl, targetEl, onPositionChange, clampMargin } = options;
		const clickThresholdMs = Math.max(0, (_options$clickThresho = options.clickThresholdMs) !== null && _options$clickThresho !== void 0 ? _options$clickThresho : 0);
		const moveThresholdPx = Math.max(0, (_options$moveThreshol = options.moveThresholdPx) !== null && _options$moveThreshol !== void 0 ? _options$moveThreshol : 0);
		const delayedActivation = clickThresholdMs > 0;
		const moveThresholdSq = moveThresholdPx * moveThresholdPx;
		let session = null;
		let disposed = false;
		let activationTimer = null;
		function teardownWindowListeners() {
			window.removeEventListener("pointermove", onWindowPointerMove, WINDOW_CAPTURE);
			window.removeEventListener("pointerup", onWindowPointerUp, WINDOW_CAPTURE);
			window.removeEventListener("pointercancel", onWindowPointerCancel, WINDOW_CAPTURE);
			window.removeEventListener("keydown", onWindowKeyDown, WINDOW_CAPTURE);
			window.removeEventListener("blur", onWindowBlur, WINDOW_CAPTURE);
			document.removeEventListener("visibilitychange", onVisibilityChange);
		}
		function clearActivationTimer() {
			if (activationTimer !== null) {
				window.clearTimeout(activationTimer);
				activationTimer = null;
			}
		}
		function endDrag(pointerId) {
			const s = session;
			if (!s) return;
			if (s.pointerId !== pointerId) return;
			clearActivationTimer();
			try {
				handleEl.releasePointerCapture(pointerId);
			} catch (_unused) {}
			teardownWindowListeners();
			session = null;
			handleEl.dataset.dragging = "false";
		}
		function applyNextPosition(next) {
			const s = session;
			const viewport = {
				width: window.innerWidth,
				height: window.innerHeight
			};
			onPositionChange(roundPosition(clampPosition(next, s ? {
				width: s.targetWidth,
				height: s.targetHeight
			} : (() => {
				const rect = targetEl.getBoundingClientRect();
				return {
					width: rect.width,
					height: rect.height
				};
			})(), clampMargin, viewport)));
		}
		function cancelDrag() {
			const s = session;
			if (!s) return;
			applyNextPosition(s.startPosition);
			endDrag(s.pointerId);
		}
		/**
		* Suppress the next click event on handle to prevent accidental click after drag.
		*/
		function suppressClickOnce() {
			const onClick = (e) => {
				blockEvent(e);
			};
			handleEl.addEventListener("click", onClick, {
				capture: true,
				once: true
			});
			window.setTimeout(() => {
				handleEl.removeEventListener("click", onClick, { capture: true });
			}, 300);
		}
		/**
		* Activate drag mode (when using delayed activation).
		*/
		function activateDrag(pointerId) {
			const s = session;
			if (!s || s.pointerId !== pointerId || s.activated) return;
			s.activated = true;
			handleEl.dataset.dragging = "true";
			clearActivationTimer();
			try {
				handleEl.setPointerCapture(pointerId);
			} catch (_unused2) {}
		}
		function onWindowPointerMove(event) {
			const s = session;
			if (!s) return;
			if (event.pointerId !== s.pointerId) return;
			if (!s.activated) {
				if (!delayedActivation || moveThresholdSq <= 0) return;
				const dx = event.clientX - s.startClientX;
				const dy = event.clientY - s.startClientY;
				if (dx * dx + dy * dy < moveThresholdSq) return;
				activateDrag(event.pointerId);
			}
			blockEvent(event);
			applyNextPosition({
				left: event.clientX - s.offsetX,
				top: event.clientY - s.offsetY
			});
		}
		function onWindowPointerUp(event) {
			const s = session;
			if (!s) return;
			if (event.pointerId !== s.pointerId) return;
			if (s.activated) {
				blockEvent(event);
				suppressClickOnce();
			}
			endDrag(event.pointerId);
		}
		function onWindowPointerCancel(event) {
			const s = session;
			if (!s) return;
			if (event.pointerId !== s.pointerId) return;
			if (s.activated) {
				blockEvent(event);
				cancelDrag();
			} else endDrag(event.pointerId);
		}
		function onWindowKeyDown(event) {
			if (event.key !== "Escape") return;
			const s = session;
			if (!s) return;
			if (s.activated) {
				event.preventDefault();
				event.stopImmediatePropagation();
				event.stopPropagation();
				cancelDrag();
			} else endDrag(s.pointerId);
		}
		function onWindowBlur() {
			const s = session;
			if (!s) return;
			if (s.activated) cancelDrag();
			else endDrag(s.pointerId);
		}
		function onVisibilityChange() {
			const s = session;
			if (!s) return;
			if (document.visibilityState !== "hidden") return;
			if (s.activated) cancelDrag();
			else endDrag(s.pointerId);
		}
		function onHandlePointerDown(event) {
			if (disposed) return;
			if (!targetEl.isConnected) return;
			if (session) return;
			if (event.button !== 0) return;
			if (!event.isPrimary) return;
			if (!delayedActivation) blockEvent(event);
			const rect = targetEl.getBoundingClientRect();
			const startPosition = roundPosition({
				left: rect.left,
				top: rect.top
			});
			session = {
				pointerId: event.pointerId,
				startPosition,
				offsetX: event.clientX - rect.left,
				offsetY: event.clientY - rect.top,
				targetWidth: rect.width,
				targetHeight: rect.height,
				startClientX: event.clientX,
				startClientY: event.clientY,
				activated: !delayedActivation
			};
			handleEl.dataset.dragging = session.activated ? "true" : "false";
			try {
				handleEl.setPointerCapture(event.pointerId);
			} catch (_unused3) {}
			if (delayedActivation) {
				clearActivationTimer();
				const pointerId = event.pointerId;
				activationTimer = window.setTimeout(() => {
					activateDrag(pointerId);
				}, clickThresholdMs);
			}
			window.addEventListener("pointermove", onWindowPointerMove, WINDOW_CAPTURE);
			window.addEventListener("pointerup", onWindowPointerUp, WINDOW_CAPTURE);
			window.addEventListener("pointercancel", onWindowPointerCancel, WINDOW_CAPTURE);
			window.addEventListener("keydown", onWindowKeyDown, WINDOW_CAPTURE);
			window.addEventListener("blur", onWindowBlur, WINDOW_CAPTURE);
			document.addEventListener("visibilitychange", onVisibilityChange);
		}
		handleEl.dataset.dragging = "false";
		handleEl.addEventListener("pointerdown", onHandlePointerDown);
		return () => {
			disposed = true;
			handleEl.removeEventListener("pointerdown", onHandlePointerDown);
			if (session) try {
				if (session.activated) cancelDrag();
				else endDrag(session.pointerId);
			} catch (_unused4) {}
			teardownWindowListeners();
			clearActivationTimer();
			session = null;
			handleEl.dataset.dragging = "false";
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/icons.ts
	/**
	* Shared SVG Icons for Web Editor UI
	*
	* All icons are created as inline SVG elements to:
	* - Avoid external asset dependencies
	* - Support theming via `currentColor`
	* - Enable direct DOM manipulation
	*
	* Design standards:
	* - ViewBox: 20x20 (default) or 24x24 (for specific icons)
	* - Stroke width: 2px
	* - Line caps/joins: round
	*/
	function createSvgElement() {
		const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
		svg.setAttribute("viewBox", "0 0 20 20");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		return svg;
	}
	function createSvgElement24() {
		const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
		svg.setAttribute("viewBox", "0 0 24 24");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		return svg;
	}
	function createStrokePath(d) {
		const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
		path.setAttribute("d", d);
		path.setAttribute("stroke", "currentColor");
		path.setAttribute("stroke-width", "2");
		path.setAttribute("stroke-linecap", "round");
		path.setAttribute("stroke-linejoin", "round");
		return path;
	}
	/**
	* Close icon (×) for close button
	*/
	function createCloseIcon() {
		const svg = createSvgElement();
		svg.append(createStrokePath("M6 6l8 8M14 6l-8 8"));
		return svg;
	}
	/**
	* Grip icon (6 dots) for drag handle
	*/
	function createGripIcon() {
		const svg = createSvgElement();
		for (const [cx, cy] of [
			[7, 6],
			[13, 6],
			[7, 10],
			[13, 10],
			[7, 14],
			[13, 14]
		]) {
			const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
			circle.setAttribute("cx", String(cx));
			circle.setAttribute("cy", String(cy));
			circle.setAttribute("r", "1.4");
			circle.setAttribute("fill", "currentColor");
			svg.append(circle);
		}
		return svg;
	}
	/**
	* Chevron icon (▼) for collapse/expand indicator
	*/
	function createChevronIcon() {
		const svg = createSvgElement();
		svg.classList.add("we-chevron");
		svg.append(createStrokePath("M7 8l3 3 3-3"));
		return svg;
	}
	/**
	* Undo icon (↶) for undo button
	* Uses 24x24 viewBox matching toolbar-ui.html design spec
	*/
	function createUndoIcon() {
		const svg = createSvgElement24();
		svg.append(createStrokePath("M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"));
		return svg;
	}
	/**
	* Redo icon (↷) for redo button
	* Uses 24x24 viewBox matching toolbar-ui.html design spec
	*/
	function createRedoIcon() {
		const svg = createSvgElement24();
		svg.append(createStrokePath("M21 10h-10a8 8 0 00-8 8v2M21 10l-6 6m6-6l-6-6"));
		return svg;
	}
	/**
	* Chevron Up icon (^) for minimize/restore button
	* Rotates 180deg when minimized to point down
	*/
	function createChevronUpIcon() {
		const svg = createSvgElement();
		svg.append(createStrokePath("M6 12l4-4 4 4"));
		return svg;
	}
	/**
	* Chevron Down icon (small, 24x24 viewBox) for dropdown buttons
	* Matches toolbar-ui.html design spec
	*/
	function createChevronDownSmallIcon() {
		const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
		svg.setAttribute("viewBox", "0 0 24 24");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
		path.setAttribute("d", "M19 9l-7 7-7-7");
		path.setAttribute("stroke", "currentColor");
		path.setAttribute("stroke-width", "2");
		path.setAttribute("stroke-linecap", "round");
		path.setAttribute("stroke-linejoin", "round");
		svg.append(path);
		return svg;
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.126.0/helpers/asyncToGenerator.js
	function asyncGeneratorStep(n, t, e, r, o, a, c) {
		try {
			var i = n[a](c), u = i.value;
		} catch (n) {
			e(n);
			return;
		}
		i.done ? t(u) : Promise.resolve(u).then(r, o);
	}
	function _asyncToGenerator(n) {
		return function() {
			var t = this, e = arguments;
			return new Promise(function(r, o) {
				var a = n.apply(t, e);
				function _next(n) {
					asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
				}
				function _throw(n) {
					asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
				}
				_next(void 0);
			});
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/toolbar.ts
	/**
	* Check if value is Promise-like
	*/
	function isPromiseLike(value) {
		return !!value && (typeof value === "object" || typeof value === "function") && typeof value.then === "function";
	}
	/**
	* Check if value is ApplyResult
	*/
	function isApplyResult(value) {
		if (!value || typeof value !== "object") return false;
		const req = value.requestId;
		return req === void 0 || typeof req === "string";
	}
	/**
	* Format status message with optional request ID
	*/
	function formatStatusMessage(base, result) {
		const req = (result === null || result === void 0 ? void 0 : result.requestId) ? `requestId=${result.requestId}` : "";
		return req ? `${base} (${req})` : base;
	}
	var STATUS_RESET_DELAY_MS = 2400;
	var SUCCESS_STATUSES = [
		"success",
		"completed",
		"verified"
	];
	var ERROR_STATUSES = [
		"error",
		"failed",
		"timeout",
		"cancelled",
		"mismatch",
		"lost",
		"uncertain"
	];
	var PROGRESS_STATUSES = [
		"applying",
		"running",
		"starting",
		"locating",
		"verifying"
	];
	function getStatusCategory(status) {
		if (SUCCESS_STATUSES.includes(status)) return "success";
		if (ERROR_STATUSES.includes(status)) return "error";
		if (PROGRESS_STATUSES.includes(status)) return "progress";
		return "idle";
	}
	/**
	* Create a Toolbar UI component
	*/
	function createToolbar(options) {
		var _options$dock, _options$initialPosit;
		const disposer = new Disposer();
		const dock = (_options$dock = options.dock) !== null && _options$dock !== void 0 ? _options$dock : "top";
		let undoCount = 0;
		let redoCount = 0;
		let status = "idle";
		let statusMessage = "";
		let applying = false;
		let resetTimer = null;
		let minimized = false;
		let floatingPosition = (_options$initialPosit = options.initialPosition) !== null && _options$initialPosit !== void 0 ? _options$initialPosit : null;
		const root = document.createElement("div");
		root.className = "we-toolbar";
		root.dataset.position = dock;
		root.dataset.status = status;
		root.dataset.minimized = "false";
		root.dataset.dragged = floatingPosition ? "true" : "false";
		root.dataset.structureOpen = "false";
		root.setAttribute("role", "toolbar");
		root.setAttribute("aria-label", "Web Editor Toolbar");
		const dragHandle = document.createElement("button");
		dragHandle.type = "button";
		dragHandle.className = "we-drag-handle";
		dragHandle.setAttribute("aria-label", "Collapse toolbar");
		dragHandle.dataset.tooltip = "Collapse";
		dragHandle.append(createGripIcon());
		const content = document.createElement("div");
		content.className = "we-toolbar-content";
		const indicator = document.createElement("div");
		indicator.className = "we-toolbar-indicator";
		const indicatorDot = document.createElement("span");
		indicatorDot.className = "we-toolbar-indicator-dot";
		const indicatorLabel = document.createElement("span");
		indicatorLabel.className = "we-toolbar-indicator-label";
		indicatorLabel.textContent = "Editor";
		indicator.append(indicatorDot, indicatorLabel);
		const historyEl = document.createElement("div");
		historyEl.className = "we-toolbar-history";
		const undoCountLabel = document.createElement("span");
		const undoCountValue = document.createElement("b");
		undoCountValue.className = "we-toolbar-history-value";
		undoCountLabel.append("Undo: ", undoCountValue);
		const redoCountLabel = document.createElement("span");
		const redoCountValue = document.createElement("b");
		redoCountValue.className = "we-toolbar-history-value";
		redoCountLabel.append("Redo: ", redoCountValue);
		historyEl.append(undoCountLabel, redoCountLabel);
		const divider = document.createElement("div");
		divider.className = "we-toolbar-divider";
		const structureGroup = document.createElement("div");
		structureGroup.className = "we-toolbar-structure-group";
		const structureGroupSeparator = document.createElement("div");
		structureGroupSeparator.className = "we-toolbar-structure-separator";
		const applyBtn = document.createElement("button");
		applyBtn.type = "button";
		applyBtn.className = "we-toolbar-apply-btn";
		applyBtn.textContent = "Apply";
		applyBtn.setAttribute("aria-label", "Apply changes to code");
		const undoBtn = document.createElement("button");
		undoBtn.type = "button";
		undoBtn.className = "we-toolbar-group-icon-btn";
		undoBtn.setAttribute("aria-label", "Undo last change");
		undoBtn.dataset.tooltip = "Undo";
		undoBtn.append(createUndoIcon());
		const redoBtn = document.createElement("button");
		redoBtn.type = "button";
		redoBtn.className = "we-toolbar-group-icon-btn";
		redoBtn.setAttribute("aria-label", "Redo last undone change");
		redoBtn.dataset.tooltip = "Redo";
		redoBtn.append(createRedoIcon());
		const closeBtn = document.createElement("button");
		closeBtn.type = "button";
		closeBtn.className = "we-toolbar-close-btn";
		closeBtn.setAttribute("aria-label", "Close Web Editor");
		closeBtn.dataset.tooltip = "Exit Editor";
		closeBtn.append(createCloseIcon());
		const statusEl = document.createElement("span");
		statusEl.className = "we-sr-only";
		statusEl.setAttribute("aria-live", "polite");
		const DISALLOWED_TARGET_TAGS = new Set([
			"HTML",
			"BODY",
			"HEAD"
		]);
		const DISALLOWED_CONTAINER_TAGS = new Set(["HTML", "HEAD"]);
		const DEFAULT_STACK_GAP = "10px";
		const structureWrap = document.createElement("div");
		structureWrap.className = "we-structure-wrap";
		structureWrap.style.position = "relative";
		structureWrap.style.display = "inline-flex";
		const structureBtn = document.createElement("button");
		structureBtn.type = "button";
		structureBtn.className = "we-toolbar-structure-btn";
		structureBtn.setAttribute("aria-label", "Structure operations");
		structureBtn.setAttribute("aria-haspopup", "menu");
		structureBtn.setAttribute("aria-expanded", "false");
		structureBtn.append(document.createTextNode("Structure"), createChevronDownSmallIcon());
		const structureMenu = document.createElement("div");
		structureMenu.className = "we-structure-menu";
		structureMenu.setAttribute("role", "menu");
		structureMenu.setAttribute("aria-label", "Structure actions");
		Object.assign(structureMenu.style, {
			position: "absolute",
			top: "calc(100% + 8px)",
			right: "0",
			minWidth: "160px",
			padding: "6px",
			background: "rgba(255, 255, 255, 0.98)",
			border: "1px solid rgba(148, 163, 184, 0.45)",
			borderRadius: "10px",
			boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.08), 0 10px 20px -5px rgba(0, 0, 0, 0.12)",
			backdropFilter: "blur(8px)",
			display: "none",
			flexDirection: "column",
			gap: "4px",
			zIndex: "10001"
		});
		structureWrap.append(structureBtn, structureMenu);
		function buildStructureData(action) {
			switch (action) {
				case "group": return {
					action: "wrap",
					wrapperTag: "div"
				};
				case "stack": return {
					action: "wrap",
					wrapperTag: "div",
					wrapperStyles: {
						display: "flex",
						"flex-direction": "column",
						gap: DEFAULT_STACK_GAP
					}
				};
				case "ungroup": return { action: "unwrap" };
				case "duplicate": return { action: "duplicate" };
				case "delete": return { action: "delete" };
			}
		}
		function createStructureMenuItem(action, label) {
			const btn = document.createElement("button");
			btn.type = "button";
			btn.className = action === "delete" ? "we-btn we-btn--danger" : "we-btn";
			btn.textContent = label;
			btn.setAttribute("role", "menuitem");
			btn.dataset.action = action;
			Object.assign(btn.style, {
				width: "100%",
				justifyContent: "flex-start",
				padding: "6px 10px"
			});
			return btn;
		}
		const structureItems = [
			{
				action: "group",
				label: "Group",
				el: createStructureMenuItem("group", "Group")
			},
			{
				action: "stack",
				label: "Stack",
				el: createStructureMenuItem("stack", "Stack")
			},
			{
				action: "ungroup",
				label: "Ungroup",
				el: createStructureMenuItem("ungroup", "Ungroup")
			},
			{
				action: "duplicate",
				label: "Duplicate",
				el: createStructureMenuItem("duplicate", "Duplicate")
			},
			{
				action: "delete",
				label: "Delete",
				el: createStructureMenuItem("delete", "Delete")
			}
		];
		for (const item of structureItems) structureMenu.append(item.el);
		let structureOpen = false;
		function setStructureOpen(open) {
			structureOpen = open;
			structureMenu.style.display = open ? "flex" : "none";
			structureBtn.setAttribute("aria-expanded", open ? "true" : "false");
			root.dataset.structureOpen = open ? "true" : "false";
		}
		function getSelectedElement() {
			var _options$getSelectedE, _options$getSelectedE2;
			const el = (_options$getSelectedE = (_options$getSelectedE2 = options.getSelectedElement) === null || _options$getSelectedE2 === void 0 ? void 0 : _options$getSelectedE2.call(options)) !== null && _options$getSelectedE !== void 0 ? _options$getSelectedE : null;
			return (el === null || el === void 0 ? void 0 : el.isConnected) ? el : null;
		}
		function isDisallowedTarget(el) {
			var _el$tagName;
			const tag = (_el$tagName = el.tagName) === null || _el$tagName === void 0 ? void 0 : _el$tagName.toUpperCase();
			return DISALLOWED_TARGET_TAGS.has(tag);
		}
		function isDisallowedContainer(el) {
			var _el$tagName2;
			const tag = (_el$tagName2 = el.tagName) === null || _el$tagName2 === void 0 ? void 0 : _el$tagName2.toUpperCase();
			return DISALLOWED_CONTAINER_TAGS.has(tag);
		}
		function getStructureActionBlockReason(action, target) {
			if (applying) return "Operation in progress";
			if (!options.onStructure) return "Not configured";
			if (!target) return "Select an element first";
			if (isDisallowedTarget(target)) return "Cannot edit <html>, <body>, or <head>";
			const parent = target.parentElement;
			switch (action) {
				case "group":
				case "stack":
					if (!parent) return "Element has no parent";
					if (isDisallowedContainer(parent)) return "Cannot wrap under <html> or <head>";
					return null;
				case "ungroup":
					if (!parent) return "Element has no parent";
					if (isDisallowedContainer(parent)) return "Cannot unwrap under <html> or <head>";
					if (target.childElementCount !== 1) return "Ungroup requires exactly one child";
					return null;
				case "duplicate":
				case "delete":
					if (!parent) return "Element has no parent";
					if (isDisallowedContainer(parent)) return "Cannot modify under <html> or <head>";
					return null;
			}
		}
		function renderStructureControls() {
			var _getStructureActionBl;
			const target = getSelectedElement();
			let anyEnabled = false;
			for (const item of structureItems) {
				const reason = getStructureActionBlockReason(item.action, target);
				const disabled = !!reason;
				item.el.disabled = disabled;
				item.el.title = reason !== null && reason !== void 0 ? reason : "";
				anyEnabled = anyEnabled || !disabled;
			}
			structureBtn.disabled = !anyEnabled;
			structureBtn.title = !anyEnabled ? (_getStructureActionBl = getStructureActionBlockReason("group", target)) !== null && _getStructureActionBl !== void 0 ? _getStructureActionBl : "Unavailable" : "";
			if (structureBtn.disabled && structureOpen) setStructureOpen(false);
		}
		structureGroup.append(structureWrap, structureGroupSeparator, undoBtn, redoBtn);
		const endActions = document.createElement("div");
		endActions.className = "we-toolbar-end-actions";
		endActions.append(applyBtn, closeBtn);
		content.append(indicator, historyEl, divider, structureGroup, endActions);
		root.append(dragHandle, content, statusEl);
		options.container.append(root);
		disposer.add(() => root.remove());
		const CLAMP_MARGIN_PX = 16;
		function clampToViewport(position) {
			const rect = root.getBoundingClientRect();
			const viewportW = window.innerWidth;
			const viewportH = window.innerHeight;
			const margin = CLAMP_MARGIN_PX;
			const maxLeft = Math.max(margin, viewportW - margin - rect.width);
			const maxTop = Math.max(margin, viewportH - margin - rect.height);
			const left = Number.isFinite(position.left) ? position.left : 0;
			const top = Number.isFinite(position.top) ? position.top : 0;
			return {
				left: Math.round(Math.min(maxLeft, Math.max(margin, left))),
				top: Math.round(Math.min(maxTop, Math.max(margin, top)))
			};
		}
		function syncFloatingPositionStyles() {
			root.dataset.dragged = floatingPosition ? "true" : "false";
			if (!floatingPosition) {
				root.style.left = "";
				root.style.top = "";
				root.style.right = "";
				root.style.bottom = "";
				root.style.transform = "";
				return;
			}
			root.style.left = `${floatingPosition.left}px`;
			root.style.top = `${floatingPosition.top}px`;
			root.style.right = "auto";
			root.style.bottom = "auto";
			root.style.transform = "none";
		}
		function setPosition(position) {
			var _options$onPositionCh;
			floatingPosition = position ? clampToViewport(position) : null;
			syncFloatingPositionStyles();
			(_options$onPositionCh = options.onPositionChange) === null || _options$onPositionCh === void 0 || _options$onPositionCh.call(options, floatingPosition);
		}
		function getPosition() {
			return floatingPosition;
		}
		disposer.add(installFloatingDrag({
			handleEl: dragHandle,
			targetEl: root,
			clampMargin: CLAMP_MARGIN_PX,
			onPositionChange: (pos) => setPosition(pos),
			clickThresholdMs: 200,
			moveThresholdPx: 5
		}));
		if (floatingPosition !== null) setPosition(floatingPosition);
		else syncFloatingPositionStyles();
		function clearResetTimer() {
			if (resetTimer !== null) {
				window.clearTimeout(resetTimer);
				resetTimer = null;
			}
		}
		disposer.add(clearResetTimer);
		/**
		* Toggle minimized (collapsed) state of toolbar
		* Design: toolbar collapses in-place from pill (580x44) to circle (44x44)
		*/
		function setMinimized(value) {
			const wasMinimized = minimized;
			minimized = value;
			root.dataset.minimized = minimized ? "true" : "false";
			if (minimized) setStructureOpen(false);
			if (wasMinimized && !minimized && floatingPosition) {
				setPosition(floatingPosition);
				root.addEventListener("transitionend", (event) => {
					if (event.target !== root) return;
					if (event.propertyName !== "width" && event.propertyName !== "height") return;
					if (!minimized && floatingPosition) setPosition(floatingPosition);
				}, { once: true });
			}
			dragHandle.setAttribute("aria-label", minimized ? "Expand toolbar" : "Collapse toolbar");
			dragHandle.dataset.tooltip = minimized ? "Expand" : "Collapse";
		}
		function renderCounts() {
			undoCountValue.textContent = String(undoCount);
			redoCountValue.textContent = String(redoCount);
		}
		function renderButtons() {
			var _options$getApplyBloc;
			undoBtn.disabled = applying || undoCount <= 0;
			redoBtn.disabled = applying || redoCount <= 0;
			const blockReason = (_options$getApplyBloc = options.getApplyBlockReason) === null || _options$getApplyBloc === void 0 ? void 0 : _options$getApplyBloc.call(options);
			const isBlocked = !!blockReason;
			applyBtn.disabled = applying || undoCount <= 0 || !options.onApply || isBlocked;
			applyBtn.textContent = applying ? "Applying…" : "Apply";
			applyBtn.title = isBlocked ? blockReason : "";
			renderStructureControls();
		}
		function renderStatus() {
			const category = getStatusCategory(status);
			root.dataset.status = category;
			root.dataset.statusDetail = status;
			statusEl.textContent = status === "idle" ? "" : statusMessage;
		}
		function scheduleStatusReset() {
			clearResetTimer();
			resetTimer = window.setTimeout(() => setStatus("idle"), STATUS_RESET_DELAY_MS);
		}
		function setHistory(nextUndo, nextRedo) {
			undoCount = Math.max(0, Math.floor(nextUndo));
			redoCount = Math.max(0, Math.floor(nextRedo));
			renderCounts();
			renderButtons();
		}
		function setStatus(nextStatus, message) {
			status = nextStatus;
			statusMessage = (message !== null && message !== void 0 ? message : "").trim();
			renderStatus();
			const category = getStatusCategory(status);
			if (category === "success" || category === "error") scheduleStatusReset();
			else clearResetTimer();
		}
		function handleApply() {
			return _handleApply.apply(this, arguments);
		}
		function _handleApply() {
			_handleApply = _asyncToGenerator(function* () {
				if (applyBtn.disabled) return;
				if (!options.onApply) return;
				applying = true;
				renderButtons();
				setStatus("applying", "Sending…");
				try {
					const resultOrPromise = options.onApply();
					const result = isPromiseLike(resultOrPromise) ? yield resultOrPromise : resultOrPromise;
					setStatus("success", formatStatusMessage("Sent", isApplyResult(result) ? result : void 0));
				} catch (error) {
					setStatus("error", (error instanceof Error ? error.message : String(error)) || "Failed");
				} finally {
					applying = false;
					renderButtons();
				}
			});
			return _handleApply.apply(this, arguments);
		}
		disposer.listen(applyBtn, "click", (event) => {
			event.preventDefault();
			handleApply();
		});
		disposer.listen(dragHandle, "click", (event) => {
			event.preventDefault();
			setMinimized(!minimized);
		});
		disposer.listen(structureBtn, "click", (event) => {
			event.preventDefault();
			if (structureBtn.disabled) return;
			setStructureOpen(!structureOpen);
		});
		for (const item of structureItems) disposer.listen(item.el, "click", (event) => {
			event.preventDefault();
			if (item.el.disabled) return;
			if (!options.onStructure) return;
			options.onStructure(buildStructureData(item.action));
			setStructureOpen(false);
		});
		disposer.listen(window, "pointerdown", (event) => {
			if (!structureOpen) return;
			try {
				if (typeof event.composedPath === "function") {
					if (event.composedPath().some((n) => n === structureWrap)) return;
				}
			} catch (_unused) {}
			const target = event.target;
			if (target instanceof Node && structureWrap.contains(target)) return;
			setStructureOpen(false);
		}, { capture: true });
		disposer.listen(window, "keydown", (event) => {
			if (!structureOpen) return;
			if (event.key !== "Escape") return;
			event.preventDefault();
			event.stopPropagation();
			setStructureOpen(false);
		}, { capture: true });
		disposer.listen(undoBtn, "click", (event) => {
			var _options$onUndo;
			event.preventDefault();
			if (undoBtn.disabled) return;
			(_options$onUndo = options.onUndo) === null || _options$onUndo === void 0 || _options$onUndo.call(options);
		});
		disposer.listen(redoBtn, "click", (event) => {
			var _options$onRedo;
			event.preventDefault();
			if (redoBtn.disabled) return;
			(_options$onRedo = options.onRedo) === null || _options$onRedo === void 0 || _options$onRedo.call(options);
		});
		disposer.listen(closeBtn, "click", (event) => {
			var _options$onRequestClo;
			event.preventDefault();
			(_options$onRequestClo = options.onRequestClose) === null || _options$onRequestClo === void 0 || _options$onRequestClo.call(options);
		});
		const SELECTION_POLL_INTERVAL_MS = 140;
		let lastSelection = null;
		let selectionPollTimer = null;
		function scheduleSelectionPoll() {
			if (disposer.isDisposed) return;
			selectionPollTimer = window.setTimeout(() => {
				selectionPollTimer = null;
				const current = getSelectedElement();
				if (current !== lastSelection) {
					lastSelection = current;
					setStructureOpen(false);
					renderButtons();
				}
				scheduleSelectionPoll();
			}, SELECTION_POLL_INTERVAL_MS);
		}
		if (options.getSelectedElement) {
			lastSelection = getSelectedElement();
			scheduleSelectionPoll();
			disposer.add(() => {
				if (selectionPollTimer !== null) {
					window.clearTimeout(selectionPollTimer);
					selectionPollTimer = null;
				}
			});
		}
		renderCounts();
		renderButtons();
		renderStatus();
		return {
			setHistory,
			setStatus,
			getPosition,
			setPosition,
			dispose: () => disposer.dispose()
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/breadcrumbs.ts
	/** Max depth to traverse the composed tree */
	var MAX_COMPOSED_DEPTH = 64;
	/** Max characters for a truncated label */
	var MAX_LABEL_CHARS = 36;
	/** Max class parts to include in label */
	var MAX_CLASS_PARTS = 2;
	/** Separator between normal parent-child relationships */
	var NORMAL_SEPARATOR = "›";
	/** Separator when crossing Shadow DOM boundary */
	var SHADOW_SEPARATOR = "⬡";
	/** Gap between anchor element and breadcrumbs bar */
	var ANCHOR_GAP_PX = 10;
	/** Padding from viewport edges */
	var SAFE_PADDING_PX = 8;
	/** Assumed property panel width for safe area calculation */
	var PROPERTY_PANEL_WIDTH = 320;
	/**
	* Truncate a label string with ellipsis
	*/
	function truncateLabel(text, maxChars) {
		const t = text.trim();
		if (t.length <= maxChars) return t;
		return `${t.slice(0, Math.max(0, maxChars - 1)).trimEnd()}…`;
	}
	/**
	* Format an element's display label (tag + id or classes)
	*/
	function formatElementLabel$2(element) {
		var _element$id;
		const tag = element.tagName.toLowerCase();
		const id = (_element$id = element.id) === null || _element$id === void 0 ? void 0 : _element$id.trim();
		let suffix = "";
		if (id) suffix = `#${id}`;
		else {
			var _element$classList;
			const classes = Array.from((_element$classList = element.classList) !== null && _element$classList !== void 0 ? _element$classList : []).map((c) => c.trim()).filter(Boolean).slice(0, MAX_CLASS_PARTS);
			if (classes.length > 0) suffix = `.${classes.join(".")}`;
		}
		const fullLabel = `${tag}${suffix}`;
		return {
			fullLabel,
			label: truncateLabel(fullLabel, MAX_LABEL_CHARS)
		};
	}
	/**
	* Build breadcrumb items from target element to composed tree root.
	* Returns items in outer-to-inner order (root first, target last).
	*/
	function buildComposedBreadcrumbs(target) {
		const raw = [];
		let current = target;
		for (let i = 0; current && i < MAX_COMPOSED_DEPTH; i++) {
			var _current$getRootNode;
			const tag = current.tagName.toUpperCase();
			if (tag === "HTML" || tag === "BODY") break;
			const parent = current.parentElement;
			if (parent) {
				raw.push({
					element: current,
					crossToParent: false
				});
				current = parent;
				continue;
			}
			const rootNode = (_current$getRootNode = current.getRootNode) === null || _current$getRootNode === void 0 ? void 0 : _current$getRootNode.call(current);
			if (rootNode instanceof ShadowRoot && rootNode.host instanceof Element) {
				raw.push({
					element: current,
					crossToParent: true
				});
				current = rootNode.host;
				continue;
			}
			raw.push({
				element: current,
				crossToParent: false
			});
			break;
		}
		return raw.reverse().map(({ element, crossToParent }) => {
			const { label, fullLabel } = formatElementLabel$2(element);
			return {
				element,
				label,
				fullLabel,
				boundaryBefore: crossToParent
			};
		});
	}
	/**
	* Create a breadcrumbs component for displaying element ancestry.
	*/
	function createBreadcrumbs(options) {
		var _options$dock;
		const disposer = new Disposer();
		const dock = (_options$dock = options.dock) !== null && _options$dock !== void 0 ? _options$dock : "top";
		let currentTarget = null;
		let items = [];
		let anchorRect = null;
		let barW = 0;
		let barH = 0;
		const root = document.createElement("nav");
		root.className = "we-breadcrumbs";
		root.dataset.position = dock;
		root.dataset.hidden = "true";
		root.setAttribute("aria-label", "Selection breadcrumbs");
		options.container.append(root);
		disposer.add(() => root.remove());
		/**
		* Clamp a number between min and max
		*/
		function clampNumber(value, min, max) {
			if (max < min) return min;
			return Math.min(max, Math.max(min, value));
		}
		/**
		* Get the safe right boundary X (avoiding property panel)
		*/
		function getSafeRightX(viewportW) {
			return viewportW - (16 + PROPERTY_PANEL_WIDTH + 16);
		}
		/**
		* Measure bar dimensions after content change
		*/
		function measureBarDimensions() {
			const rect = root.getBoundingClientRect();
			barW = rect.width;
			barH = rect.height;
		}
		/**
		* Update position based on anchor rect
		*/
		function updatePosition() {
			if (!currentTarget) return;
			if (!anchorRect) return;
			if (!(barW > 0 && barH > 0)) return;
			const viewportW = window.innerWidth;
			const viewportH = window.innerHeight;
			const safeRightX = getSafeRightX(viewportW);
			const maxLeft = Math.min(viewportW - SAFE_PADDING_PX - barW, safeRightX - barW);
			const left = clampNumber(anchorRect.left, SAFE_PADDING_PX, maxLeft);
			const aboveTop = anchorRect.top - ANCHOR_GAP_PX - barH;
			const belowTop = anchorRect.top + anchorRect.height + ANCHOR_GAP_PX;
			const top = clampNumber(aboveTop >= SAFE_PADDING_PX ? aboveTop : belowTop, SAFE_PADDING_PX, viewportH - SAFE_PADDING_PX - barH);
			root.style.left = `${Math.round(left)}px`;
			root.style.top = `${Math.round(top)}px`;
		}
		/**
		* Render breadcrumb items to DOM
		*/
		function render() {
			root.textContent = "";
			if (!currentTarget) {
				root.dataset.hidden = "true";
				return;
			}
			root.dataset.hidden = "false";
			const frag = document.createDocumentFragment();
			for (let i = 0; i < items.length; i++) {
				const item = items[i];
				if (i > 0) {
					const sep = document.createElement("span");
					const isShadowBoundary = item.boundaryBefore;
					sep.className = isShadowBoundary ? "we-crumb-sep we-crumb-sep--shadow" : "we-crumb-sep";
					sep.textContent = isShadowBoundary ? SHADOW_SEPARATOR : NORMAL_SEPARATOR;
					sep.setAttribute("aria-hidden", "true");
					frag.append(sep);
				}
				const btn = document.createElement("button");
				btn.type = "button";
				btn.className = "we-crumb";
				btn.dataset.index = String(i);
				btn.textContent = item.label;
				btn.title = item.fullLabel;
				if (i === items.length - 1) {
					btn.classList.add("we-crumb--current");
					btn.setAttribute("aria-current", "page");
				}
				frag.append(btn);
			}
			root.append(frag);
			measureBarDimensions();
			updatePosition();
		}
		disposer.listen(root, "click", (event) => {
			var _btn$dataset$index;
			const target = event.target;
			if (!(target instanceof Element)) return;
			const btn = target.closest("button.we-crumb");
			if (!(btn instanceof HTMLButtonElement)) return;
			event.preventDefault();
			const rawIndex = (_btn$dataset$index = btn.dataset.index) !== null && _btn$dataset$index !== void 0 ? _btn$dataset$index : "";
			const index = Number(rawIndex);
			if (!Number.isInteger(index) || index < 0) return;
			const item = items[index];
			if (!item) return;
			if (item.element.isConnected) options.onSelect(item.element);
		});
		/**
		* Set the target element to build breadcrumbs for
		*/
		function setTarget(element) {
			if (disposer.isDisposed) return;
			currentTarget = element;
			items = element ? buildComposedBreadcrumbs(element) : [];
			render();
		}
		/**
		* Set the anchor rectangle for positioning (called by editor on position updates)
		*/
		function setAnchorRect(rect) {
			if (disposer.isDisposed) return;
			anchorRect = rect;
			updatePosition();
		}
		return {
			setTarget,
			setAnchorRect,
			dispose: () => disposer.dispose()
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/components/input-container.ts
	function isNonEmptyString(value) {
		return typeof value === "string" && value.trim().length > 0;
	}
	function hasAffix(value) {
		if (value === null || value === void 0) return false;
		return typeof value === "string" ? value.trim().length > 0 : true;
	}
	function joinClassNames(...parts) {
		return parts.filter(isNonEmptyString).join(" ");
	}
	/**
	* Create an input container with optional prefix/suffix
	*/
	function createInputContainer(options) {
		const { ariaLabel, type = "text", inputMode, prefix, suffix, rootClassName, inputClassName, autocomplete = "off", spellcheck = false, placeholder } = options;
		const root = document.createElement("div");
		root.className = joinClassNames("we-input-container", rootClassName);
		let prefixEl = null;
		const input = document.createElement("input");
		input.type = type;
		input.className = joinClassNames("we-input-container__input", inputClassName);
		input.setAttribute("autocomplete", autocomplete);
		input.spellcheck = spellcheck;
		input.setAttribute("aria-label", ariaLabel);
		if (inputMode) input.inputMode = inputMode;
		if (placeholder !== void 0) input.placeholder = placeholder;
		let suffixEl = null;
		function updateAffix(kind, content, existingEl) {
			if (!hasAffix(content)) {
				if (existingEl) existingEl.remove();
				return null;
			}
			const el = existingEl !== null && existingEl !== void 0 ? existingEl : document.createElement("span");
			el.className = `we-input-container__${kind}`;
			el.textContent = "";
			if (typeof content === "string") el.textContent = content;
			else el.append(content);
			return el;
		}
		if (hasAffix(prefix)) {
			prefixEl = updateAffix("prefix", prefix, null);
			if (prefixEl) root.append(prefixEl);
		}
		root.append(input);
		if (hasAffix(suffix)) {
			suffixEl = updateAffix("suffix", suffix, null);
			if (suffixEl) root.append(suffixEl);
		}
		return {
			root,
			input,
			setPrefix(content) {
				const newEl = updateAffix("prefix", content, prefixEl);
				if (newEl && !prefixEl) root.insertBefore(newEl, input);
				prefixEl = newEl;
			},
			setSuffix(content) {
				const newEl = updateAffix("suffix", content, suffixEl);
				if (newEl && !suffixEl) root.append(newEl);
				suffixEl = newEl;
			},
			getSuffixText() {
				var _suffixEl$textContent;
				if (!suffixEl) return null;
				return ((_suffixEl$textContent = suffixEl.textContent) === null || _suffixEl$textContent === void 0 ? void 0 : _suffixEl$textContent.trim()) || null;
			}
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/css-helpers.ts
	/**
	* CSS Value Helpers
	*
	* Shared utilities for parsing and normalizing CSS values.
	* Used by control components for input-container suffix management.
	*/
	/** CSS keywords that should not display a unit suffix */
	var LENGTH_KEYWORDS = new Set([
		"auto",
		"inherit",
		"initial",
		"unset",
		"none",
		"fit-content",
		"min-content",
		"max-content",
		"revert",
		"revert-layer"
	]);
	/** Regex to detect CSS function expressions */
	var LENGTH_FUNCTION_REGEX = /\b(?:calc|var|clamp|min|max|fit-content)\s*\(/i;
	/** Regex to match number with unit (e.g., "20px", "50%") */
	var NUMBER_WITH_UNIT_REGEX = /^(-?(?:\d+|\d*\.\d+|\.\d+))\s*([a-zA-Z%]+)$/;
	/** Regex to match pure numbers */
	var PURE_NUMBER_REGEX = /^-?(?:\d+|\d*\.\d+|\.\d+)$/;
	/** Regex to match numbers with trailing dot (e.g., "10.") */
	var TRAILING_DOT_NUMBER_REGEX = /^-?\d+\.$/;
	/**
	* Check if a value has an explicit CSS unit.
	* Returns false for unitless numbers (e.g., "1.5" for line-height).
	*
	* @example
	* hasExplicitUnit('100px') // true
	* hasExplicitUnit('1.5') // false
	* hasExplicitUnit('auto') // false
	*/
	function hasExplicitUnit(raw) {
		var _trimmed$split$2;
		const trimmed = raw.trim();
		if (!trimmed) return false;
		const token = (_trimmed$split$2 = trimmed.split(/\s+/)[0]) !== null && _trimmed$split$2 !== void 0 ? _trimmed$split$2 : "";
		return /^-?(?:\d+|\d*\.\d+)([a-zA-Z%]+)$/.test(token);
	}
	/**
	* Format a CSS length value for display in an input + suffix UI.
	*
	* Separates the numeric value from its unit to avoid duplication
	* (e.g., displaying "20px" in input and "px" as suffix).
	*
	* @example
	* formatLengthForDisplay('20px')    // { value: '20', suffix: 'px' }
	* formatLengthForDisplay('50%')     // { value: '50', suffix: '%' }
	* formatLengthForDisplay('auto')    // { value: 'auto', suffix: null }
	* formatLengthForDisplay('calc(...)') // { value: 'calc(...)', suffix: null }
	* formatLengthForDisplay('20')      // { value: '20', suffix: 'px' }
	* formatLengthForDisplay('')        // { value: '', suffix: 'px' }
	*/
	function formatLengthForDisplay(raw) {
		const trimmed = raw.trim();
		if (!trimmed) return {
			value: "",
			suffix: "px"
		};
		const lower = trimmed.toLowerCase();
		if (LENGTH_KEYWORDS.has(lower)) return {
			value: trimmed,
			suffix: null
		};
		if (LENGTH_FUNCTION_REGEX.test(trimmed)) return {
			value: trimmed,
			suffix: null
		};
		const unitMatch = trimmed.match(NUMBER_WITH_UNIT_REGEX);
		if (unitMatch) {
			var _unitMatch$, _unitMatch$2;
			return {
				value: (_unitMatch$ = unitMatch[1]) !== null && _unitMatch$ !== void 0 ? _unitMatch$ : "",
				suffix: ((_unitMatch$2 = unitMatch[2]) !== null && _unitMatch$2 !== void 0 ? _unitMatch$2 : "") || null
			};
		}
		if (PURE_NUMBER_REGEX.test(trimmed)) return {
			value: trimmed,
			suffix: "px"
		};
		if (TRAILING_DOT_NUMBER_REGEX.test(trimmed)) return {
			value: trimmed.slice(0, -1),
			suffix: "px"
		};
		return {
			value: trimmed,
			suffix: null
		};
	}
	/**
	* Combine an input value with a unit suffix to form a complete CSS value.
	*
	* This is the inverse of formatLengthForDisplay - it takes the separated
	* value and suffix and combines them for CSS writing.
	*
	* @param inputValue - The value from the input field
	* @param suffix - The current unit suffix (from getSuffixText)
	* @returns The complete CSS value ready for style.setProperty()
	*
	* @example
	* combineLengthValue('20', 'px')     // '20px'
	* combineLengthValue('50', '%')      // '50%'
	* combineLengthValue('auto', null)   // 'auto'
	* combineLengthValue('', 'px')       // ''
	* combineLengthValue('calc(...)', null) // 'calc(...)'
	*/
	function combineLengthValue(inputValue, suffix) {
		const trimmed = inputValue.trim();
		if (!trimmed) return "";
		const lower = trimmed.toLowerCase();
		if (LENGTH_KEYWORDS.has(lower)) return trimmed;
		if (LENGTH_FUNCTION_REGEX.test(trimmed)) return trimmed;
		if (NUMBER_WITH_UNIT_REGEX.test(trimmed)) return trimmed;
		if (TRAILING_DOT_NUMBER_REGEX.test(trimmed)) {
			const normalized = trimmed.slice(0, -1);
			return suffix ? `${normalized}${suffix}` : `${normalized}px`;
		}
		if (PURE_NUMBER_REGEX.test(trimmed)) return suffix ? `${trimmed}${suffix}` : `${trimmed}px`;
		return trimmed;
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/number-stepping.ts
	var DEFAULT_STEP = 1;
	var DEFAULT_SHIFT_STEP = 10;
	var DEFAULT_ALT_STEP = .1;
	var DEFAULT_ALLOWED_UNITS = [
		"",
		"px",
		"%",
		"rem",
		"em",
		"vh",
		"vw",
		"vmin",
		"vmax"
	];
	var MAX_FRACTION_DIGITS = 10;
	/**
	* Count decimal digits in a numeric string
	*/
	function countFractionDigits(raw) {
		const dotIndex = raw.indexOf(".");
		if (dotIndex < 0) return 0;
		return Math.max(0, raw.length - dotIndex - 1);
	}
	/**
	* Get decimal digits needed to represent a step value
	*/
	function countStepDigits(step) {
		if (!Number.isFinite(step)) return 0;
		const raw = String(step);
		if (raw.includes("e") || raw.includes("E")) return 0;
		return countFractionDigits(raw);
	}
	/**
	* Clamp fraction digits to a reasonable range
	*/
	function clampDigits(digits) {
		if (!Number.isFinite(digits)) return 0;
		return Math.max(0, Math.min(MAX_FRACTION_DIGITS, Math.trunc(digits)));
	}
	/**
	* Format a number with specified decimal digits, trimming trailing zeros
	*/
	function formatNumber(value, digits) {
		const d = clampDigits(digits);
		const fixed = value.toFixed(d);
		if (d === 0) return fixed;
		return fixed.replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "");
	}
	var NUMBER_REGEX = /^(-?(?:(?:\d+\.\d+)|(?:\d+\.)|(?:\d+)|(?:\.\d+)))$/;
	/**
	* Parse a pure number string
	*/
	function parseNumberValue(raw) {
		var _match$;
		const trimmed = raw.trim();
		if (!trimmed) return null;
		const match = trimmed.match(NUMBER_REGEX);
		if (!match) return null;
		const numRaw = (_match$ = match[1]) !== null && _match$ !== void 0 ? _match$ : "";
		const normalized = numRaw.endsWith(".") ? numRaw.slice(0, -1) : numRaw;
		const value = Number(normalized);
		if (!Number.isFinite(value)) return null;
		return {
			value,
			digits: countFractionDigits(normalized)
		};
	}
	var CSS_LENGTH_REGEX = /^(-?(?:(?:\d+\.\d+)|(?:\d+\.)|(?:\d+)|(?:\.\d+)))\s*([a-zA-Z%]*)$/;
	/**
	* Parse a CSS length value (number + optional unit)
	*/
	function parseCssLengthValue(raw, allowedUnits) {
		var _match$2, _match$3;
		const trimmed = raw.trim();
		if (!trimmed) return null;
		const match = trimmed.match(CSS_LENGTH_REGEX);
		if (!match) return null;
		const numRaw = (_match$2 = match[1]) !== null && _match$2 !== void 0 ? _match$2 : "";
		const unit = ((_match$3 = match[2]) !== null && _match$3 !== void 0 ? _match$3 : "").toLowerCase();
		if (!allowedUnits.includes(unit)) return null;
		const normalized = numRaw.endsWith(".") ? numRaw.slice(0, -1) : numRaw;
		const value = Number(normalized);
		if (!Number.isFinite(value)) return null;
		return {
			value,
			digits: countFractionDigits(normalized),
			unit
		};
	}
	/**
	* Wire up keyboard stepping for a number input
	*
	* @param disposer - Disposer for cleanup
	* @param input - The input element to enhance
	* @param options - Stepping configuration
	*/
	function wireNumberStepping(disposer, input, options) {
		const { mode, step: baseStep = DEFAULT_STEP, shiftStep = DEFAULT_SHIFT_STEP, altStep = DEFAULT_ALT_STEP, min, max, integer = false, allowedUnits = DEFAULT_ALLOWED_UNITS } = options;
		disposer.listen(input, "keydown", (event) => {
			if (event.key !== "ArrowUp" && event.key !== "ArrowDown") return;
			if (event.metaKey || event.ctrlKey) return;
			if (input.disabled || input.readOnly) return;
			const direction = event.key === "ArrowUp" ? 1 : -1;
			let delta;
			if (event.altKey) delta = altStep;
			else if (event.shiftKey) delta = shiftStep;
			else delta = baseStep;
			if (!Number.isFinite(delta) || delta === 0) return;
			const source = (input.value || input.placeholder || "").trim();
			let parsed = null;
			let unit = "";
			if (mode === "number") {
				parsed = parseNumberValue(source);
				if (!parsed && !source) parsed = {
					value: 0,
					digits: 0
				};
			} else {
				const cssResult = parseCssLengthValue(source, allowedUnits);
				if (cssResult) {
					parsed = cssResult;
					unit = cssResult.unit;
				} else if (!source) {
					parsed = {
						value: 0,
						digits: 0
					};
					unit = "";
				}
			}
			if (!parsed) return;
			const digits = integer ? 0 : Math.max(parsed.digits, countStepDigits(delta));
			let next = parsed.value + direction * delta;
			if (typeof min === "number") next = Math.max(min, next);
			if (typeof max === "number") next = Math.min(max, next);
			if (integer) next = Math.round(next);
			const formatted = formatNumber(next, digits);
			const nextRaw = mode === "css-length" ? `${formatted}${unit}` : formatted;
			event.preventDefault();
			input.value = nextRaw;
			try {
				input.dispatchEvent(new Event("input", { bubbles: true }));
			} catch (_unused) {}
		});
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/size-control.ts
	/**
	* Size Control (Phase 3.5 + Mode Selection)
	*
	* Design control for editing inline width and height styles with mode selection.
	*
	* Features:
	* - Mode selection: Fixed (custom value), Fit (fit-content/auto), Fill (100%)
	* - Live preview via TransactionManager.beginStyle().set()
	* - Shows real values (inline if set, otherwise computed)
	* - ArrowUp/ArrowDown keyboard stepping for numeric values
	* - Blur commits, Enter commits + blurs, ESC rollbacks
	* - Pure numbers default to px
	* - Empty value clears inline style
	*/
	var SIZE_MODE_OPTIONS = [
		{
			value: "fixed",
			label: "Fixed"
		},
		{
			value: "fit",
			label: "Fit"
		},
		{
			value: "fill",
			label: "Fill"
		}
	];
	/** Keywords that indicate fit mode */
	var FIT_KEYWORDS = [
		"auto",
		"fit-content",
		"max-content",
		"min-content"
	];
	/**
	* Check if element is focused in Shadow DOM context
	*/
	function isElementFocused(el) {
		try {
			const rootNode = el.getRootNode();
			if (rootNode instanceof ShadowRoot) return rootNode.activeElement === el;
			return document.activeElement === el;
		} catch (_unused) {
			return false;
		}
	}
	/**
	* Read inline style property value from element
	*/
	function readInlineValue$9(element, property) {
		try {
			const style = element.style;
			if (!style || typeof style.getPropertyValue !== "function") return "";
			return style.getPropertyValue(property).trim();
		} catch (_unused2) {
			return "";
		}
	}
	/**
	* Read computed style property value from element
	*/
	function readComputedValue$8(element, property) {
		try {
			return window.getComputedStyle(element).getPropertyValue(property).trim();
		} catch (_unused3) {
			return "";
		}
	}
	/**
	* Get bounding rect dimension as px string
	* Preserves 2 decimal places for sub-pixel accuracy
	*/
	function getBoundingRectPx(element, property) {
		try {
			const rect = element.getBoundingClientRect();
			const value = property === "width" ? rect.width : rect.height;
			if (!Number.isFinite(value)) return "0px";
			return `${Math.round(value * 100) / 100}px`;
		} catch (_unused4) {
			return "0px";
		}
	}
	/**
	* Infer size mode from CSS value
	*
	* Priority:
	* - '100%' -> fill
	* - fit keywords (auto, fit-content, etc.) -> fit
	* - Everything else (px, %, calc, var, etc.) -> fixed
	*/
	function inferSizeMode(value) {
		const trimmed = value.trim().toLowerCase();
		if (!trimmed) return "fixed";
		if (trimmed === "100%") return "fill";
		for (const keyword of FIT_KEYWORDS) if (trimmed === keyword || trimmed.startsWith(`${keyword}(`)) return "fit";
		return "fixed";
	}
	/**
	* Get the CSS value for fit mode
	* If the current value is already a fit keyword, preserve it.
	* Otherwise uses fit-content if supported, or falls back to auto.
	*/
	function getFitValue(property, currentValue) {
		const trimmed = currentValue.trim().toLowerCase();
		for (const keyword of FIT_KEYWORDS) if (trimmed === keyword || trimmed.startsWith(`${keyword}(`)) return currentValue.trim();
		try {
			var _CSS$supports, _CSS;
			if (typeof CSS !== "undefined" && ((_CSS$supports = (_CSS = CSS).supports) === null || _CSS$supports === void 0 ? void 0 : _CSS$supports.call(_CSS, property, "fit-content"))) return "fit-content";
		} catch (_unused5) {}
		return "auto";
	}
	/**
	* Create mode select element
	*/
	function createModeSelect(ariaLabel) {
		const select = document.createElement("select");
		select.className = "we-select we-size-mode-select";
		select.setAttribute("aria-label", ariaLabel);
		for (const { value, label } of SIZE_MODE_OPTIONS) {
			const option = document.createElement("option");
			option.value = value;
			option.textContent = label;
			select.appendChild(option);
		}
		return select;
	}
	/**
	* Create a Size control for editing width/height with mode selection
	*/
	function createSizeControl(options) {
		const { container, transactionManager } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		const root = document.createElement("div");
		root.className = "we-field-group";
		/**
		* Create a size field column with mode select and input
		*/
		function createSizeField(property, prefix) {
			const column = document.createElement("div");
			column.className = "we-size-field";
			const modeSelect = createModeSelect(`${property} mode`);
			const inputContainer = createInputContainer({
				ariaLabel: property.charAt(0).toUpperCase() + property.slice(1),
				inputMode: "decimal",
				prefix,
				suffix: "px"
			});
			wireNumberStepping(disposer, inputContainer.input, { mode: "css-length" });
			column.append(modeSelect, inputContainer.root);
			return {
				property,
				column,
				modeSelect,
				input: inputContainer.input,
				container: inputContainer,
				lastFixedValue: "",
				handle: null
			};
		}
		const widthField = createSizeField("width", "W");
		const heightField = createSizeField("height", "H");
		const row = document.createElement("div");
		row.className = "we-field-row";
		row.append(widthField.column, heightField.column);
		root.append(row);
		container.append(root);
		disposer.add(() => root.remove());
		const fields = {
			width: widthField,
			height: heightField
		};
		function beginTransaction(property) {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields[property];
			if (field.handle) return field.handle;
			const handle = transactionManager.beginStyle(target, property);
			field.handle = handle;
			return handle;
		}
		function commitTransaction(property) {
			const field = fields[property];
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackTransaction(property) {
			const field = fields[property];
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.rollback();
		}
		function commitAllTransactions() {
			commitTransaction("width");
			commitTransaction("height");
		}
		/**
		* Update input visibility based on mode
		* Input is only visible in fixed mode
		*/
		function updateInputVisibility(field, mode) {
			field.container.root.hidden = mode !== "fixed";
		}
		/**
		* Get fixed value for mode switching
		* Prioritizes: lastFixedValue > computed > bounding rect
		*/
		function getFixedValueCandidate(field, target) {
			const cached = field.lastFixedValue.trim();
			if (cached && inferSizeMode(cached) === "fixed") return cached;
			const computed = readComputedValue$8(target, field.property);
			if (computed && inferSizeMode(computed) === "fixed") return computed;
			return getBoundingRectPx(target, field.property);
		}
		/**
		* Sync a single field's display with element styles
		*/
		function syncField(property, force = false) {
			const field = fields[property];
			const target = currentTarget;
			if (!target || !target.isConnected) {
				field.modeSelect.value = "fixed";
				field.modeSelect.disabled = true;
				updateInputVisibility(field, "fixed");
				field.input.value = "";
				field.input.placeholder = "";
				field.input.disabled = true;
				field.container.setSuffix("px");
				return;
			}
			field.modeSelect.disabled = false;
			field.input.disabled = false;
			if (!force) {
				if (field.handle !== null || isElementFocused(field.input) || isElementFocused(field.modeSelect)) return;
			}
			const inlineValue = readInlineValue$9(target, property);
			const displayValue = inlineValue || readComputedValue$8(target, property);
			const mode = inferSizeMode(inlineValue || displayValue);
			field.modeSelect.value = mode;
			updateInputVisibility(field, mode);
			if (mode === "fixed") {
				const candidate = inlineValue || displayValue;
				if (candidate && inferSizeMode(candidate) === "fixed") field.lastFixedValue = candidate;
			}
			if (mode === "fixed") {
				const formatted = formatLengthForDisplay(displayValue);
				field.input.value = formatted.value;
				field.input.placeholder = "";
				field.container.setSuffix(formatted.suffix);
			}
		}
		function syncAllFields() {
			syncField("width");
			syncField("height");
		}
		/**
		* Wire mode select event handlers
		*/
		function wireModeSelect(property) {
			const field = fields[property];
			const select = field.modeSelect;
			const handleModeChange = () => {
				const target = currentTarget;
				if (!target || !target.isConnected) return;
				const mode = select.value;
				if (inferSizeMode(readInlineValue$9(target, property) || readComputedValue$8(target, property)) === "fixed" && mode !== "fixed") {
					const suffix = field.container.getSuffixText();
					const combined = combineLengthValue(field.input.value, suffix);
					if (combined) field.lastFixedValue = combined;
				}
				updateInputVisibility(field, mode);
				const handle = beginTransaction(property);
				if (!handle) return;
				switch (mode) {
					case "fit": {
						const currentValue = readInlineValue$9(target, property) || readComputedValue$8(target, property);
						handle.set(getFitValue(property, currentValue));
						break;
					}
					case "fill":
						handle.set("100%");
						break;
					case "fixed": {
						const fixedValue = getFixedValueCandidate(field, target);
						field.lastFixedValue = fixedValue;
						handle.set(fixedValue);
						const formatted = formatLengthForDisplay(fixedValue);
						field.input.value = formatted.value;
						field.container.setSuffix(formatted.suffix);
						break;
					}
				}
			};
			disposer.listen(select, "input", handleModeChange);
			disposer.listen(select, "change", handleModeChange);
			disposer.listen(select, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(select, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					select.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		/**
		* Wire input field event handlers
		*/
		function wireInput(property) {
			const field = fields[property];
			const input = field.input;
			disposer.listen(input, "input", () => {
				const handle = beginTransaction(property);
				if (!handle) return;
				const suffix = field.container.getSuffixText();
				const combined = combineLengthValue(input.value, suffix);
				handle.set(combined);
			});
			disposer.listen(input, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(input, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					input.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		wireModeSelect("width");
		wireModeSelect("height");
		wireInput("width");
		wireInput("height");
		function setTarget(element) {
			if (disposer.isDisposed) return;
			if (element !== currentTarget) {
				commitAllTransactions();
				fields.width.lastFixedValue = "";
				fields.height.lastFixedValue = "";
			}
			currentTarget = element;
			syncAllFields();
		}
		function refresh() {
			if (disposer.isDisposed) return;
			syncAllFields();
		}
		function dispose() {
			commitAllTransactions();
			currentTarget = null;
			disposer.dispose();
		}
		syncAllFields();
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/spacing-control.ts
	/**
	* Spacing Control (Phase 3.6)
	*
	* Grid-based editor for inline padding and margin.
	*
	* Design ref: attr-ui.html:292-370
	*
	* Features:
	* - Separate Padding and Margin sections with 2x2 grid layout
	* - Direction-indicating SVG icons as input prefixes
	* - Dynamic unit suffix display
	* - Shows real values (inline if set, otherwise computed)
	* - ArrowUp/ArrowDown keyboard stepping for numeric values
	* - Live preview via TransactionManager.beginStyle().set()
	* - Blur commits, Enter commits + blurs, ESC rollbacks
	* - Pure numbers default to px
	* - Empty value clears inline style
	*/
	var SVG_NS$6 = "http://www.w3.org/2000/svg";
	/** All spacing properties in section order */
	var SPACING_PROPERTIES = [
		"padding-top",
		"padding-right",
		"padding-bottom",
		"padding-left",
		"margin-top",
		"margin-right",
		"margin-bottom",
		"margin-left"
	];
	/** SVG path data for edge direction icons (design ref: attr-ui.html:308-368) */
	var EDGE_ICON_PATHS = {
		"padding-top": "M2 4h11M7.5 4v3.5",
		"padding-right": "M4 2v11M4 7.5h3.5",
		"padding-bottom": "M2 11h11M7.5 11v-3.5",
		"padding-left": "M11 2v11M11 7.5h-3.5",
		"margin-top": "M2 4h11M7.5 4v-3",
		"margin-right": "M11 2v11M11 7.5h3",
		"margin-bottom": "M2 11h11M7.5 11v3",
		"margin-left": "M4 2v11M4 7.5h-3"
	};
	function formatAriaLabel(property) {
		const [box, edge] = property.split("-");
		return `${box.charAt(0).toUpperCase()}${box.slice(1)} ${edge}`;
	}
	function isInputFocused(input) {
		try {
			const rootNode = input.getRootNode();
			if (rootNode instanceof ShadowRoot) return rootNode.activeElement === input;
			return document.activeElement === input;
		} catch (_unused) {
			return false;
		}
	}
	function readInlineValue$8(element, property) {
		try {
			const style = element.style;
			if (!style || typeof style.getPropertyValue !== "function") return "";
			return style.getPropertyValue(property).trim();
		} catch (_unused2) {
			return "";
		}
	}
	function readComputedValue$7(element, property) {
		try {
			return window.getComputedStyle(element).getPropertyValue(property).trim();
		} catch (_unused3) {
			return "";
		}
	}
	function createEdgeIcon(pathD) {
		const svg = document.createElementNS(SVG_NS$6, "svg");
		svg.setAttribute("viewBox", "0 0 15 15");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		svg.setAttribute("focusable", "false");
		const path = document.createElementNS(SVG_NS$6, "path");
		path.setAttribute("d", pathD);
		path.setAttribute("stroke", "currentColor");
		svg.append(path);
		return svg;
	}
	function createSpacingControl(options) {
		const { container, transactionManager } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		function createField(property) {
			const inputContainer = createInputContainer({
				ariaLabel: formatAriaLabel(property),
				inputMode: "decimal",
				prefix: createEdgeIcon(EDGE_ICON_PATHS[property]),
				suffix: "px"
			});
			wireNumberStepping(disposer, inputContainer.input, { mode: "css-length" });
			return {
				property,
				input: inputContainer.input,
				container: inputContainer,
				handle: null
			};
		}
		const fields = Object.create(null);
		for (const property of SPACING_PROPERTIES) fields[property] = createField(property);
		function createSection(title, properties) {
			const section = document.createElement("div");
			section.className = "we-spacing-section";
			const header = document.createElement("div");
			header.className = "we-spacing-header";
			header.textContent = title;
			section.append(header);
			const grid = document.createElement("div");
			grid.className = "we-spacing-grid";
			grid.append(fields[properties[0]].container.root);
			grid.append(fields[properties[1]].container.root);
			grid.append(fields[properties[2]].container.root);
			grid.append(fields[properties[3]].container.root);
			section.append(grid);
			return section;
		}
		const root = document.createElement("div");
		root.className = "we-field-group";
		root.append(createSection("Padding", [
			"padding-top",
			"padding-right",
			"padding-bottom",
			"padding-left"
		]), createSection("Margin", [
			"margin-top",
			"margin-right",
			"margin-bottom",
			"margin-left"
		]));
		container.append(root);
		disposer.add(() => root.remove());
		function beginTransaction(property) {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields[property];
			if (field.handle) return field.handle;
			const handle = transactionManager.beginStyle(target, property);
			field.handle = handle;
			return handle;
		}
		function commitTransaction(property) {
			const field = fields[property];
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackTransaction(property) {
			const field = fields[property];
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.rollback();
		}
		function commitAllTransactions() {
			for (const prop of SPACING_PROPERTIES) commitTransaction(prop);
		}
		function syncField(property, force = false) {
			const field = fields[property];
			const target = currentTarget;
			if (!target || !target.isConnected) {
				field.input.value = "";
				field.input.placeholder = "";
				field.input.disabled = true;
				field.container.setSuffix("px");
				return;
			}
			field.input.disabled = false;
			if ((field.handle !== null || isInputFocused(field.input)) && !force) return;
			const formatted = formatLengthForDisplay(readInlineValue$8(target, property) || readComputedValue$7(target, property));
			field.input.value = formatted.value;
			field.input.placeholder = "";
			field.container.setSuffix(formatted.suffix);
		}
		function syncAllFields() {
			for (const prop of SPACING_PROPERTIES) syncField(prop);
		}
		function wireField(property) {
			const field = fields[property];
			const input = field.input;
			disposer.listen(input, "input", () => {
				const handle = beginTransaction(property);
				if (!handle) return;
				const suffix = field.container.getSuffixText();
				handle.set(combineLengthValue(input.value, suffix));
			});
			disposer.listen(input, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(input, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					input.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		for (const prop of SPACING_PROPERTIES) wireField(prop);
		function setTarget(element) {
			if (disposer.isDisposed) return;
			if (element !== currentTarget) commitAllTransactions();
			currentTarget = element;
			syncAllFields();
		}
		function refresh() {
			if (disposer.isDisposed) return;
			syncAllFields();
		}
		function dispose() {
			commitAllTransactions();
			currentTarget = null;
			disposer.dispose();
		}
		syncAllFields();
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/components/icon-button-group.ts
	/**
	* Icon Button Group (Phase 4.1)
	*
	* A single-select grid of icon buttons (e.g. Flow controls for `flex-direction`).
	*
	* Design spec pattern (attr-ui.html:136-141):
	* ```html
	* <div class="grid grid-cols-4 gap-1">
	*   <button class="bg-[#F3F3F3] hover:bg-gray-200 rounded p-1 flex justify-center items-center">
	*     <svg>...</svg>
	*   </button>
	*   ...
	* </div>
	* ```
	*
	* Notes:
	* - `setValue()` updates UI without calling `onChange`.
	* - `onChange` fires only on user interaction.
	*/
	function cloneForDom(node) {
		try {
			return node.cloneNode(true);
		} catch (_unused) {
			return node;
		}
	}
	function findSelectedIndex(items, value) {
		if (value === null) return -1;
		for (let i = 0; i < items.length; i++) if (items[i].value === value) return i;
		return -1;
	}
	function findFirstEnabledIndex(buttons) {
		for (let i = 0; i < buttons.length; i++) if (!buttons[i].disabled) return i;
		return -1;
	}
	function findLastEnabledIndex(buttons) {
		for (let i = buttons.length - 1; i >= 0; i--) if (!buttons[i].disabled) return i;
		return -1;
	}
	function createIconButtonGroup(options) {
		var _options$columns, _ref, _options$value, _items$;
		const { container, ariaLabel, items, onChange } = options;
		const disposer = new Disposer();
		let isDisabled = Boolean(options.disabled);
		let currentValue = null;
		const root = document.createElement("div");
		root.className = "we-icon-button-group";
		root.setAttribute("role", "radiogroup");
		root.setAttribute("aria-label", ariaLabel);
		const columns = Math.max(1, (_options$columns = options.columns) !== null && _options$columns !== void 0 ? _options$columns : items.length);
		root.style.gridTemplateColumns = `repeat(${columns}, 1fr)`;
		container.append(root);
		disposer.add(() => root.remove());
		const buttons = [];
		function syncDisabled() {
			root.setAttribute("aria-disabled", String(isDisabled));
			for (let i = 0; i < buttons.length; i++) {
				const btn = buttons[i];
				const item = items[i];
				btn.disabled = isDisabled || Boolean(item.disabled);
			}
		}
		function syncSelection() {
			const selectedIndex = findSelectedIndex(items, currentValue);
			const tabIndex = selectedIndex >= 0 && !buttons[selectedIndex].disabled ? selectedIndex : findFirstEnabledIndex(buttons);
			for (let i = 0; i < buttons.length; i++) {
				const btn = buttons[i];
				const item = items[i];
				const selected = currentValue !== null && item.value === currentValue;
				btn.setAttribute("aria-checked", selected ? "true" : "false");
				btn.dataset.selected = selected ? "true" : "false";
				btn.tabIndex = i === tabIndex ? 0 : -1;
			}
		}
		function setValueInternal(next, emit) {
			const nextIndex = findSelectedIndex(items, next);
			if (next !== null && nextIndex < 0) next = null;
			const changed = next !== currentValue;
			currentValue = next;
			syncSelection();
			if (emit && changed && currentValue !== null) onChange === null || onChange === void 0 || onChange(currentValue);
		}
		function getActiveIndex() {
			const rootNode = root.getRootNode();
			const active = rootNode instanceof ShadowRoot ? rootNode.activeElement : document.activeElement;
			const focusIndex = buttons.findIndex((b) => b === active);
			if (focusIndex >= 0) return focusIndex;
			const selectedIndex = findSelectedIndex(items, currentValue);
			if (selectedIndex >= 0) return selectedIndex;
			const firstEnabled = findFirstEnabledIndex(buttons);
			return firstEnabled >= 0 ? firstEnabled : 0;
		}
		function findEnabledFrom(start, delta) {
			if (delta === 0) return -1;
			for (let i = start; i >= 0 && i < buttons.length; i += delta) if (!buttons[i].disabled) return i;
			return -1;
		}
		function selectByIndex(nextIndex, emit) {
			if (nextIndex < 0 || nextIndex >= items.length) return;
			const btn = buttons[nextIndex];
			if (btn.disabled) return;
			setValueInternal(items[nextIndex].value, emit);
			btn.focus();
		}
		function handleKeyDown(e) {
			if (isDisabled) return;
			if (buttons.length === 0) return;
			const active = getActiveIndex();
			let next = null;
			switch (e.key) {
				case "ArrowLeft":
					next = findEnabledFrom(active - 1, -1);
					break;
				case "ArrowRight":
					next = findEnabledFrom(active + 1, 1);
					break;
				case "ArrowUp":
					next = findEnabledFrom(active - columns, -columns);
					break;
				case "ArrowDown":
					next = findEnabledFrom(active + columns, columns);
					break;
				case "Home":
					next = findFirstEnabledIndex(buttons);
					break;
				case "End":
					next = findLastEnabledIndex(buttons);
					break;
				case "Enter":
				case " ":
					e.preventDefault();
					selectByIndex(active, true);
					return;
				default: return;
			}
			if (next !== null && next >= 0) {
				e.preventDefault();
				selectByIndex(next, true);
			}
		}
		for (let i = 0; i < items.length; i++) {
			const item = items[i];
			const btn = document.createElement("button");
			btn.type = "button";
			btn.className = "we-icon-button-group__btn";
			btn.setAttribute("role", "radio");
			btn.setAttribute("aria-label", item.ariaLabel);
			if (item.title) btn.dataset.tooltip = item.title;
			btn.dataset.value = item.value;
			btn.append(cloneForDom(item.icon));
			disposer.listen(btn, "click", (ev) => {
				ev.preventDefault();
				if (isDisabled || btn.disabled) return;
				setValueInternal(item.value, true);
				btn.focus();
			});
			disposer.listen(btn, "keydown", handleKeyDown);
			buttons.push(btn);
			root.append(btn);
		}
		syncDisabled();
		setValueInternal((_ref = (_options$value = options.value) !== null && _options$value !== void 0 ? _options$value : (_items$ = items[0]) === null || _items$ === void 0 ? void 0 : _items$.value) !== null && _ref !== void 0 ? _ref : null, false);
		return {
			root,
			getValue() {
				return currentValue;
			},
			setValue(value) {
				setValueInternal(value, false);
			},
			setDisabled(disabled) {
				isDisabled = disabled;
				syncDisabled();
				syncSelection();
			},
			dispose() {
				disposer.dispose();
			}
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/position-control.ts
	/**
	* Position Control (Phase 3.3 - Refactored)
	*
	* Edits inline positioning and transform styles:
	* - position (icon button group): static/relative/absolute/fixed/sticky
	* - X (left), Y (top), Z (z-index) inputs
	* - rotate (transform: rotate)
	* - flip X/Y (transform: scaleX/scaleY toggles)
	*/
	var SVG_NS$5 = "http://www.w3.org/2000/svg";
	var POSITION_VALUES = [
		"static",
		"relative",
		"absolute",
		"fixed",
		"sticky"
	];
	function createBaseIconSvg$2() {
		const svg = document.createElementNS(SVG_NS$5, "svg");
		svg.setAttribute("viewBox", "0 0 15 15");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		svg.setAttribute("focusable", "false");
		return svg;
	}
	function createIconContainer(svg) {
		const container = document.createElementNS(SVG_NS$5, "rect");
		container.setAttribute("x", "2");
		container.setAttribute("y", "2");
		container.setAttribute("width", "11");
		container.setAttribute("height", "11");
		container.setAttribute("rx", "1.5");
		container.setAttribute("stroke", "currentColor");
		container.setAttribute("stroke-width", "1");
		container.setAttribute("stroke-dasharray", "2 1");
		container.setAttribute("fill", "none");
		container.setAttribute("opacity", "0.5");
		svg.prepend(container);
	}
	/**
	* Tokenize transform string into individual functions.
	* Uses bracket-depth scanning to handle nested parentheses like var(), calc().
	*/
	function tokenizeTransform(transform) {
		const result = [];
		if (!transform || transform === "none") return result;
		const trimmed = transform.trim();
		let i = 0;
		while (i < trimmed.length) {
			while (i < trimmed.length && /\s/.test(trimmed[i])) i++;
			if (i >= trimmed.length) break;
			const nameStart = i;
			while (i < trimmed.length && /[\w-]/.test(trimmed[i])) i++;
			const name = trimmed.slice(nameStart, i);
			while (i < trimmed.length && /\s/.test(trimmed[i])) i++;
			if (trimmed[i] !== "(") {
				i++;
				continue;
			}
			const argsStart = i + 1;
			let depth = 1;
			i++;
			while (i < trimmed.length && depth > 0) {
				if (trimmed[i] === "(") depth++;
				else if (trimmed[i] === ")") depth--;
				i++;
			}
			const argsEnd = i - 1;
			const args = trimmed.slice(argsStart, argsEnd).trim();
			const original = trimmed.slice(nameStart, i);
			result.push({
				original,
				name: name.toLowerCase(),
				args
			});
		}
		return result;
	}
	/**
	* Parse transform string into editable state.
	* Finds rotate, scaleX, scaleY positions while preserving all functions.
	*/
	function parseTransform(transform) {
		const functions = tokenizeTransform(transform);
		let rotateIndex = -1;
		let scaleXIndex = -1;
		let scaleYIndex = -1;
		for (let i = 0; i < functions.length; i++) switch (functions[i].name) {
			case "rotate":
				if (rotateIndex === -1) rotateIndex = i;
				break;
			case "scalex":
				if (scaleXIndex === -1) scaleXIndex = i;
				break;
			case "scaley":
				if (scaleYIndex === -1) scaleYIndex = i;
				break;
		}
		return {
			functions,
			rotateIndex,
			scaleXIndex,
			scaleYIndex
		};
	}
	/**
	* Get rotate value from parsed state.
	*/
	function getRotateValue(state) {
		if (state.rotateIndex < 0) return "";
		return state.functions[state.rotateIndex].args;
	}
	/**
	* Get scaleX value from parsed state.
	*/
	function getScaleXValue(state) {
		if (state.scaleXIndex < 0) return 1;
		const val = parseFloat(state.functions[state.scaleXIndex].args);
		return isNaN(val) ? 1 : val;
	}
	/**
	* Get scaleY value from parsed state.
	*/
	function getScaleYValue(state) {
		if (state.scaleYIndex < 0) return 1;
		const val = parseFloat(state.functions[state.scaleYIndex].args);
		return isNaN(val) ? 1 : val;
	}
	/**
	* Check if element is horizontally flipped (scaleX === -1).
	*/
	function isFlippedX(state) {
		return getScaleXValue(state) === -1;
	}
	/**
	* Check if element is vertically flipped (scaleY === -1).
	*/
	function isFlippedY(state) {
		return getScaleYValue(state) === -1;
	}
	/**
	* Set rotate value in transform state (mutates functions array).
	* Adds rotate at end if not present, updates if present, removes if empty.
	*/
	function setRotateValue(state, value) {
		const rotateStr = value.trim();
		if (state.rotateIndex >= 0) if (rotateStr) state.functions[state.rotateIndex] = {
			original: `rotate(${rotateStr})`,
			name: "rotate",
			args: rotateStr
		};
		else {
			state.functions.splice(state.rotateIndex, 1);
			if (state.scaleXIndex > state.rotateIndex) state.scaleXIndex--;
			if (state.scaleYIndex > state.rotateIndex) state.scaleYIndex--;
			state.rotateIndex = -1;
		}
		else if (rotateStr) {
			state.rotateIndex = state.functions.length;
			state.functions.push({
				original: `rotate(${rotateStr})`,
				name: "rotate",
				args: rotateStr
			});
		}
	}
	/**
	* Toggle flip X in transform state.
	* If currently -1, removes scaleX. Otherwise sets to -1.
	*/
	function toggleFlipX(state) {
		if (getScaleXValue(state) === -1) {
			if (state.scaleXIndex >= 0) {
				state.functions.splice(state.scaleXIndex, 1);
				if (state.rotateIndex > state.scaleXIndex) state.rotateIndex--;
				if (state.scaleYIndex > state.scaleXIndex) state.scaleYIndex--;
				state.scaleXIndex = -1;
			}
		} else if (state.scaleXIndex >= 0) state.functions[state.scaleXIndex] = {
			original: "scaleX(-1)",
			name: "scalex",
			args: "-1"
		};
		else {
			state.scaleXIndex = state.functions.length;
			state.functions.push({
				original: "scaleX(-1)",
				name: "scalex",
				args: "-1"
			});
		}
	}
	/**
	* Toggle flip Y in transform state.
	* If currently -1, removes scaleY. Otherwise sets to -1.
	*/
	function toggleFlipY(state) {
		if (getScaleYValue(state) === -1) {
			if (state.scaleYIndex >= 0) {
				state.functions.splice(state.scaleYIndex, 1);
				if (state.rotateIndex > state.scaleYIndex) state.rotateIndex--;
				if (state.scaleXIndex > state.scaleYIndex) state.scaleXIndex--;
				state.scaleYIndex = -1;
			}
		} else if (state.scaleYIndex >= 0) state.functions[state.scaleYIndex] = {
			original: "scaleY(-1)",
			name: "scaley",
			args: "-1"
		};
		else {
			state.scaleYIndex = state.functions.length;
			state.functions.push({
				original: "scaleY(-1)",
				name: "scaley",
				args: "-1"
			});
		}
	}
	/**
	* Compose transform string from state, preserving order.
	*/
	function composeTransform(state) {
		return state.functions.map((fn) => fn.original).join(" ").trim();
	}
	/**
	* Extract numeric value from rotate angle (e.g., "45deg" -> "45")
	*/
	function extractRotateValue(rotate) {
		if (!rotate) return "";
		const match = rotate.match(/^(-?[\d.]+)/);
		return match ? match[1] : "";
	}
	/**
	* Extract unit from rotate angle (e.g., "45deg" -> "deg")
	*/
	function extractRotateUnit(rotate) {
		if (!rotate) return "deg";
		const match = rotate.match(/[\d.]+(.*)$/);
		return match && match[1] ? match[1] : "deg";
	}
	function createPositionIcon(position) {
		const svg = createBaseIconSvg$2();
		const addBlock = (x, y, w, h, opacity = 1) => {
			const rect = document.createElementNS(SVG_NS$5, "rect");
			rect.setAttribute("x", String(x));
			rect.setAttribute("y", String(y));
			rect.setAttribute("width", String(w));
			rect.setAttribute("height", String(h));
			rect.setAttribute("rx", "0.5");
			rect.setAttribute("fill", "currentColor");
			if (opacity < 1) rect.setAttribute("opacity", String(opacity));
			svg.append(rect);
		};
		const addLine = (x, y, w) => {
			const line = document.createElementNS(SVG_NS$5, "rect");
			line.setAttribute("x", String(x));
			line.setAttribute("y", String(y));
			line.setAttribute("width", String(w));
			line.setAttribute("height", "1");
			line.setAttribute("rx", "0.5");
			line.setAttribute("fill", "currentColor");
			svg.append(line);
		};
		const addPath = (d, strokeWidth = "1") => {
			const path = document.createElementNS(SVG_NS$5, "path");
			path.setAttribute("d", d);
			path.setAttribute("stroke", "currentColor");
			path.setAttribute("stroke-width", strokeWidth);
			path.setAttribute("stroke-linecap", "round");
			path.setAttribute("fill", "none");
			svg.append(path);
		};
		switch (position) {
			case "static":
				addLine(3.5, 4.5, 8);
				addLine(3.5, 7.5, 8);
				addLine(3.5, 10.5, 8);
				break;
			case "relative": {
				const ghost = document.createElementNS(SVG_NS$5, "rect");
				ghost.setAttribute("x", "3.5");
				ghost.setAttribute("y", "3.5");
				ghost.setAttribute("width", "4");
				ghost.setAttribute("height", "4");
				ghost.setAttribute("rx", "0.5");
				ghost.setAttribute("stroke", "currentColor");
				ghost.setAttribute("stroke-width", "1");
				ghost.setAttribute("stroke-dasharray", "1.5 1");
				ghost.setAttribute("fill", "none");
				ghost.setAttribute("opacity", "0.5");
				svg.append(ghost);
				addBlock(7.5, 7.5, 4, 4);
				addPath("M5.5 7.5L7.5 9.5");
				break;
			}
			case "absolute":
				addPath("M3 5.5H6M8 3V6", "0.8");
				addBlock(6, 6, 5, 5);
				break;
			case "fixed": {
				const pin = document.createElementNS(SVG_NS$5, "circle");
				pin.setAttribute("cx", "7.5");
				pin.setAttribute("cy", "4");
				pin.setAttribute("r", "1.5");
				pin.setAttribute("fill", "currentColor");
				svg.append(pin);
				addPath("M7.5 5.5V8");
				addBlock(4.5, 8, 6, 4);
				break;
			}
			case "sticky": {
				const stickyLine = document.createElementNS(SVG_NS$5, "rect");
				stickyLine.setAttribute("x", "3");
				stickyLine.setAttribute("y", "3");
				stickyLine.setAttribute("width", "9");
				stickyLine.setAttribute("height", "1.5");
				stickyLine.setAttribute("rx", "0.5");
				stickyLine.setAttribute("fill", "currentColor");
				stickyLine.setAttribute("opacity", "0.4");
				svg.append(stickyLine);
				addBlock(4.5, 5, 6, 6);
				break;
			}
		}
		createIconContainer(svg);
		return svg;
	}
	function createRotateIcon() {
		const svg = document.createElementNS(SVG_NS$5, "svg");
		svg.setAttribute("viewBox", "0 0 15 15");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		svg.setAttribute("focusable", "false");
		const path = document.createElementNS(SVG_NS$5, "path");
		path.setAttribute("stroke", "currentColor");
		path.setAttribute("stroke-width", "1.2");
		path.setAttribute("stroke-linecap", "round");
		path.setAttribute("stroke-linejoin", "round");
		path.setAttribute("d", "M12 7.5a4.5 4.5 0 1 1-1.5-3.4M12 3v3h-3");
		svg.append(path);
		return svg;
	}
	function createFlipXIcon() {
		const svg = createBaseIconSvg$2();
		const leftBlock = document.createElementNS(SVG_NS$5, "rect");
		leftBlock.setAttribute("x", "3.5");
		leftBlock.setAttribute("y", "5");
		leftBlock.setAttribute("width", "3");
		leftBlock.setAttribute("height", "5");
		leftBlock.setAttribute("rx", "0.5");
		leftBlock.setAttribute("fill", "currentColor");
		leftBlock.setAttribute("opacity", "0.4");
		const rightBlock = document.createElementNS(SVG_NS$5, "rect");
		rightBlock.setAttribute("x", "8.5");
		rightBlock.setAttribute("y", "5");
		rightBlock.setAttribute("width", "3");
		rightBlock.setAttribute("height", "5");
		rightBlock.setAttribute("rx", "0.5");
		rightBlock.setAttribute("fill", "currentColor");
		const axis = document.createElementNS(SVG_NS$5, "path");
		axis.setAttribute("d", "M7.5 3V12");
		axis.setAttribute("stroke", "currentColor");
		axis.setAttribute("stroke-width", "1");
		axis.setAttribute("stroke-dasharray", "1.5 1");
		axis.setAttribute("opacity", "0.6");
		svg.append(leftBlock, rightBlock, axis);
		createIconContainer(svg);
		return svg;
	}
	function createFlipYIcon() {
		const svg = createBaseIconSvg$2();
		const topBlock = document.createElementNS(SVG_NS$5, "rect");
		topBlock.setAttribute("x", "5");
		topBlock.setAttribute("y", "3.5");
		topBlock.setAttribute("width", "5");
		topBlock.setAttribute("height", "3");
		topBlock.setAttribute("rx", "0.5");
		topBlock.setAttribute("fill", "currentColor");
		topBlock.setAttribute("opacity", "0.4");
		const bottomBlock = document.createElementNS(SVG_NS$5, "rect");
		bottomBlock.setAttribute("x", "5");
		bottomBlock.setAttribute("y", "8.5");
		bottomBlock.setAttribute("width", "5");
		bottomBlock.setAttribute("height", "3");
		bottomBlock.setAttribute("rx", "0.5");
		bottomBlock.setAttribute("fill", "currentColor");
		const axis = document.createElementNS(SVG_NS$5, "path");
		axis.setAttribute("d", "M3 7.5H12");
		axis.setAttribute("stroke", "currentColor");
		axis.setAttribute("stroke-width", "1");
		axis.setAttribute("stroke-dasharray", "1.5 1");
		axis.setAttribute("opacity", "0.6");
		svg.append(topBlock, bottomBlock, axis);
		createIconContainer(svg);
		return svg;
	}
	function isFieldFocused$6(el) {
		try {
			const rootNode = el.getRootNode();
			if (rootNode instanceof ShadowRoot) return rootNode.activeElement === el;
			return document.activeElement === el;
		} catch (_unused) {
			return false;
		}
	}
	function readInlineValue$7(element, property) {
		try {
			const style = element.style;
			if (!style || typeof style.getPropertyValue !== "function") return "";
			return style.getPropertyValue(property).trim();
		} catch (_unused2) {
			return "";
		}
	}
	function readComputedValue$6(element, property) {
		try {
			return window.getComputedStyle(element).getPropertyValue(property).trim();
		} catch (_unused3) {
			return "";
		}
	}
	function normalizeZIndex(raw) {
		const trimmed = raw.trim();
		if (!trimmed) return "";
		if (/^-?\d+\.$/.test(trimmed)) return trimmed.slice(0, -1);
		return trimmed;
	}
	function isPositionValue(value) {
		return POSITION_VALUES.includes(value);
	}
	function createPositionControl(options) {
		const { container, transactionManager } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		const root = document.createElement("div");
		root.className = "we-field-group";
		const positionRow = document.createElement("div");
		positionRow.className = "we-field";
		const positionLabel = document.createElement("span");
		positionLabel.className = "we-field-label";
		positionLabel.textContent = "Position";
		const positionMount = document.createElement("div");
		positionMount.className = "we-field-content";
		positionRow.append(positionLabel, positionMount);
		const positionGroup = createIconButtonGroup({
			container: positionMount,
			ariaLabel: "Position type",
			columns: 5,
			items: POSITION_VALUES.map((pos) => ({
				value: pos,
				ariaLabel: pos,
				title: pos,
				icon: createPositionIcon(pos)
			})),
			onChange: (value) => {
				const handle = beginStyleTransaction("position");
				if (handle) handle.set(value);
				commitStyleTransaction("position");
				syncAllFields();
			}
		});
		disposer.add(() => positionGroup.dispose());
		const xyRow = document.createElement("div");
		xyRow.className = "we-field-row";
		const xContainer = createInputContainer({
			ariaLabel: "X (Left)",
			inputMode: "decimal",
			prefix: "X",
			suffix: "px"
		});
		const yContainer = createInputContainer({
			ariaLabel: "Y (Top)",
			inputMode: "decimal",
			prefix: "Y",
			suffix: "px"
		});
		xyRow.append(xContainer.root, yContainer.root);
		wireNumberStepping(disposer, xContainer.input, { mode: "css-length" });
		wireNumberStepping(disposer, yContainer.input, { mode: "css-length" });
		const zRow = document.createElement("div");
		zRow.className = "we-field";
		const zLabel = document.createElement("span");
		zLabel.className = "we-field-label";
		zLabel.textContent = "Z-Index";
		const zContainer = createInputContainer({
			ariaLabel: "Z-Index",
			inputMode: "numeric",
			prefix: "Z",
			suffix: null
		});
		zRow.append(zLabel, zContainer.root);
		wireNumberStepping(disposer, zContainer.input, {
			mode: "number",
			integer: true
		});
		const transformRow = document.createElement("div");
		transformRow.className = "we-field";
		const transformLabel = document.createElement("span");
		transformLabel.className = "we-field-label";
		transformLabel.textContent = "Rotate";
		const transformContent = document.createElement("div");
		transformContent.className = "we-field-content";
		transformContent.style.display = "flex";
		transformContent.style.gap = "4px";
		transformContent.style.alignItems = "center";
		const rotateContainer = createInputContainer({
			ariaLabel: "Rotate",
			inputMode: "decimal",
			prefix: createRotateIcon(),
			suffix: "deg"
		});
		rotateContainer.root.style.flex = "1";
		wireNumberStepping(disposer, rotateContainer.input, {
			mode: "number",
			step: 1,
			shiftStep: 15
		});
		const flipXBtn = document.createElement("button");
		flipXBtn.type = "button";
		flipXBtn.className = "we-toggle-btn";
		flipXBtn.setAttribute("aria-label", "Flip horizontal");
		flipXBtn.setAttribute("aria-pressed", "false");
		flipXBtn.dataset.tooltip = "Flip horizontal";
		flipXBtn.append(createFlipXIcon());
		const flipYBtn = document.createElement("button");
		flipYBtn.type = "button";
		flipYBtn.className = "we-toggle-btn";
		flipYBtn.setAttribute("aria-label", "Flip vertical");
		flipYBtn.setAttribute("aria-pressed", "false");
		flipYBtn.dataset.tooltip = "Flip vertical";
		flipYBtn.append(createFlipYIcon());
		transformContent.append(rotateContainer.root, flipXBtn, flipYBtn);
		transformRow.append(transformLabel, transformContent);
		root.append(positionRow, xyRow, zRow, transformRow);
		container.append(root);
		disposer.add(() => root.remove());
		const fields = {
			position: {
				kind: "icon-button-group",
				property: "position",
				group: positionGroup,
				handle: null
			},
			left: {
				kind: "input",
				property: "left",
				input: xContainer.input,
				container: xContainer,
				handle: null
			},
			top: {
				kind: "input",
				property: "top",
				input: yContainer.input,
				container: yContainer,
				handle: null
			},
			"z-index": {
				kind: "input",
				property: "z-index",
				input: zContainer.input,
				container: zContainer,
				handle: null
			},
			transform: {
				kind: "transform",
				rotateInput: rotateContainer.input,
				rotateContainer,
				flipXBtn,
				flipYBtn,
				handle: null,
				cached: {
					functions: [],
					rotateIndex: -1,
					scaleXIndex: -1,
					scaleYIndex: -1
				}
			}
		};
		const STYLE_PROPERTIES = [
			"position",
			"left",
			"top",
			"z-index"
		];
		const FIELD_KEYS = [
			"position",
			"left",
			"top",
			"z-index",
			"transform"
		];
		function beginStyleTransaction(property) {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields[property];
			if (field.kind === "transform") return null;
			if (field.handle) return field.handle;
			const handle = transactionManager.beginStyle(target, property);
			field.handle = handle;
			return handle;
		}
		function commitStyleTransaction(property) {
			const field = fields[property];
			if (field.kind === "transform") return;
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackStyleTransaction(property) {
			const field = fields[property];
			if (field.kind === "transform") return;
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.rollback();
		}
		function beginTransformTransaction() {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields.transform;
			if (field.handle) return field.handle;
			const handle = transactionManager.beginStyle(target, "transform");
			field.handle = handle;
			field.cached = parseTransform(readInlineValue$7(target, "transform") || readComputedValue$6(target, "transform"));
			return handle;
		}
		function commitTransformTransaction() {
			const field = fields.transform;
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackTransformTransaction() {
			const field = fields.transform;
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.rollback();
		}
		function commitAllTransactions() {
			for (const p of STYLE_PROPERTIES) commitStyleTransaction(p);
			commitTransformTransaction();
		}
		function syncField(key, force = false) {
			const field = fields[key];
			const target = currentTarget;
			if (field.kind === "icon-button-group") {
				const group = field.group;
				if (!target || !target.isConnected) {
					group.setDisabled(true);
					group.setValue(null);
					return;
				}
				group.setDisabled(false);
				if (field.handle !== null && !force) return;
				const inline = readInlineValue$7(target, "position");
				const computed = readComputedValue$6(target, "position");
				const raw = (inline || computed).trim();
				group.setValue(isPositionValue(raw) ? raw : "static");
				return;
			}
			if (field.kind === "input") {
				const input = field.input;
				if (!target || !target.isConnected) {
					input.disabled = true;
					input.value = "";
					input.placeholder = "";
					if (field.property === "z-index") field.container.setSuffix(null);
					else field.container.setSuffix("px");
					return;
				}
				input.disabled = false;
				if ((field.handle !== null || isFieldFocused$6(input)) && !force) return;
				const displayValue = readInlineValue$7(target, field.property) || readComputedValue$6(target, field.property);
				if (field.property === "z-index") {
					input.value = displayValue;
					field.container.setSuffix(null);
				} else {
					const formatted = formatLengthForDisplay(displayValue);
					input.value = formatted.value;
					field.container.setSuffix(formatted.suffix);
				}
				input.placeholder = "";
				return;
			}
			if (field.kind === "transform") {
				const { rotateInput, rotateContainer, flipXBtn, flipYBtn } = field;
				if (!target || !target.isConnected) {
					rotateInput.disabled = true;
					rotateInput.value = "";
					rotateInput.placeholder = "";
					rotateContainer.setSuffix("deg");
					flipXBtn.disabled = true;
					flipYBtn.disabled = true;
					flipXBtn.setAttribute("aria-pressed", "false");
					flipYBtn.setAttribute("aria-pressed", "false");
					return;
				}
				rotateInput.disabled = false;
				flipXBtn.disabled = false;
				flipYBtn.disabled = false;
				if ((field.handle !== null || isFieldFocused$6(rotateInput)) && !force) return;
				const state = parseTransform(readInlineValue$7(target, "transform") || readComputedValue$6(target, "transform"));
				const rotateArgs = getRotateValue(state);
				const rotateValue = extractRotateValue(rotateArgs);
				const rotateUnit = extractRotateUnit(rotateArgs);
				rotateInput.value = rotateValue;
				rotateContainer.setSuffix(rotateUnit || "deg");
				flipXBtn.setAttribute("aria-pressed", isFlippedX(state) ? "true" : "false");
				flipYBtn.setAttribute("aria-pressed", isFlippedY(state) ? "true" : "false");
			}
		}
		function syncAllFields() {
			for (const key of FIELD_KEYS) syncField(key);
		}
		function wireStyleInput(property) {
			const field = fields[property];
			const input = field.input;
			disposer.listen(input, "input", () => {
				const handle = beginStyleTransaction(property);
				if (!handle) return;
				if (property === "z-index") handle.set(normalizeZIndex(input.value));
				else {
					const suffix = field.container.getSuffixText();
					handle.set(combineLengthValue(input.value, suffix));
				}
			});
			disposer.listen(input, "blur", () => {
				commitStyleTransaction(property);
				syncAllFields();
			});
			disposer.listen(input, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitStyleTransaction(property);
					syncAllFields();
					input.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackStyleTransaction(property);
					syncField(property, true);
				}
			});
		}
		wireStyleInput("left");
		wireStyleInput("top");
		wireStyleInput("z-index");
		const transformField = fields.transform;
		disposer.listen(transformField.rotateInput, "input", () => {
			const handle = beginTransformTransaction();
			if (!handle) return;
			const value = transformField.rotateInput.value.trim();
			const unit = transformField.rotateContainer.getSuffixText() || "deg";
			const rotateStr = value ? `${value}${unit}` : "";
			setRotateValue(transformField.cached, rotateStr);
			handle.set(composeTransform(transformField.cached));
		});
		disposer.listen(transformField.rotateInput, "blur", () => {
			commitTransformTransaction();
			syncAllFields();
		});
		disposer.listen(transformField.rotateInput, "keydown", (e) => {
			if (e.key === "Enter") {
				e.preventDefault();
				commitTransformTransaction();
				syncAllFields();
				transformField.rotateInput.blur();
			} else if (e.key === "Escape") {
				e.preventDefault();
				rollbackTransformTransaction();
				syncField("transform", true);
			}
		});
		disposer.listen(transformField.flipXBtn, "click", (e) => {
			e.preventDefault();
			const handle = beginTransformTransaction();
			if (!handle) return;
			toggleFlipX(transformField.cached);
			handle.set(composeTransform(transformField.cached));
			commitTransformTransaction();
			syncAllFields();
		});
		disposer.listen(transformField.flipYBtn, "click", (e) => {
			e.preventDefault();
			const handle = beginTransformTransaction();
			if (!handle) return;
			toggleFlipY(transformField.cached);
			handle.set(composeTransform(transformField.cached));
			commitTransformTransaction();
			syncAllFields();
		});
		function setTarget(element) {
			if (disposer.isDisposed) return;
			if (element !== currentTarget) commitAllTransactions();
			currentTarget = element;
			syncAllFields();
		}
		function refresh() {
			if (disposer.isDisposed) return;
			syncAllFields();
		}
		function dispose() {
			commitAllTransactions();
			currentTarget = null;
			disposer.dispose();
		}
		syncAllFields();
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/layout-control.ts
	/**
	* Layout Control (Phase 3.4 + 4.1/4.2 - Refactored)
	*
	* Edits inline layout styles:
	* - display (icon button group): block/inline/inline-block/flex/grid/none
	* - flex-direction (icon button group, shown when display=flex)
	* - justify-content + align-items (content bars, shown when display=flex)
	* - grid-template-columns/rows (dimensions picker, shown when display=grid)
	* - flex-wrap (select, shown when display=flex)
	* - gap (input, shown when display=flex/grid)
	*/
	var SVG_NS$4 = "http://www.w3.org/2000/svg";
	var DISPLAY_VALUES = [
		"block",
		"inline",
		"inline-block",
		"flex",
		"grid",
		"none"
	];
	var FLEX_DIRECTION_VALUES = [
		"row",
		"column",
		"row-reverse",
		"column-reverse"
	];
	var FLEX_WRAP_VALUES = [
		"nowrap",
		"wrap",
		"wrap-reverse"
	];
	var ALIGNMENT_AXIS_VALUES = [
		"flex-start",
		"center",
		"flex-end"
	];
	var GRID_DIMENSION_MAX = 12;
	function isFieldFocused$5(el) {
		try {
			const rootNode = el.getRootNode();
			if (rootNode instanceof ShadowRoot) return rootNode.activeElement === el;
			return document.activeElement === el;
		} catch (_unused) {
			return false;
		}
	}
	function readInlineValue$6(element, property) {
		try {
			var _style$getPropertyVal, _style$getPropertyVal2;
			const style = element.style;
			return (_style$getPropertyVal = style === null || style === void 0 || (_style$getPropertyVal2 = style.getPropertyValue) === null || _style$getPropertyVal2 === void 0 || (_style$getPropertyVal2 = _style$getPropertyVal2.call(style, property)) === null || _style$getPropertyVal2 === void 0 ? void 0 : _style$getPropertyVal2.trim()) !== null && _style$getPropertyVal !== void 0 ? _style$getPropertyVal : "";
		} catch (_unused2) {
			return "";
		}
	}
	function readComputedValue$5(element, property) {
		try {
			return window.getComputedStyle(element).getPropertyValue(property).trim();
		} catch (_unused3) {
			return "";
		}
	}
	function isDisplayValue(value) {
		return DISPLAY_VALUES.includes(value);
	}
	function isFlexDirectionValue(value) {
		return FLEX_DIRECTION_VALUES.includes(value);
	}
	function isAlignmentAxisValue(value) {
		return ALIGNMENT_AXIS_VALUES.includes(value);
	}
	/**
	* Map computed display values to the closest option value.
	*/
	function normalizeDisplayValue(computed) {
		const trimmed = computed.trim();
		if (trimmed === "inline-flex") return "flex";
		if (trimmed === "inline-grid") return "grid";
		return trimmed;
	}
	function clampInt(value, min, max) {
		if (!Number.isFinite(value)) return min;
		return Math.min(max, Math.max(min, Math.trunc(value)));
	}
	/**
	* Split CSS value into top-level tokens (respects parentheses depth).
	*/
	function splitTopLevelTokens(value) {
		const tokens = [];
		let depth = 0;
		let current = "";
		for (let i = 0; i < value.length; i++) {
			const ch = value[i];
			if (ch === "(") depth++;
			if (ch === ")" && depth > 0) depth--;
			if (depth === 0 && /\s/.test(ch)) {
				const t = current.trim();
				if (t) tokens.push(t);
				current = "";
				continue;
			}
			current += ch;
		}
		const tail = current.trim();
		if (tail) tokens.push(tail);
		return tokens;
	}
	function parseRepeatCount(token) {
		const match = token.match(/^repeat\(\s*(\d+)\s*,/i);
		if (!match) return null;
		const n = parseInt(match[1], 10);
		return Number.isFinite(n) && n > 0 ? n : null;
	}
	/**
	* Count grid tracks from grid-template-columns/rows value.
	*/
	function countGridTracks(raw) {
		const trimmed = raw.trim();
		if (!trimmed || trimmed === "none") return null;
		const tokens = splitTopLevelTokens(trimmed);
		let count = 0;
		for (const t of tokens) {
			var _parseRepeatCount;
			if (/^\[.*\]$/.test(t)) continue;
			count += (_parseRepeatCount = parseRepeatCount(t)) !== null && _parseRepeatCount !== void 0 ? _parseRepeatCount : 1;
		}
		return count > 0 ? count : null;
	}
	function formatGridTemplate(count) {
		const n = clampInt(count, 1, GRID_DIMENSION_MAX);
		return n === 1 ? "1fr" : `repeat(${n}, 1fr)`;
	}
	function createBaseIconSvg$1() {
		const svg = document.createElementNS(SVG_NS$4, "svg");
		svg.setAttribute("viewBox", "0 0 15 15");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		svg.setAttribute("focusable", "false");
		return svg;
	}
	function applyStroke(el, strokeWidth = "1.2") {
		el.setAttribute("stroke", "currentColor");
		el.setAttribute("stroke-width", strokeWidth);
		el.setAttribute("stroke-linecap", "round");
		el.setAttribute("stroke-linejoin", "round");
	}
	function createDisplayIcon(value) {
		const svg = createBaseIconSvg$1();
		const container = document.createElementNS(SVG_NS$4, "rect");
		container.setAttribute("x", "2");
		container.setAttribute("y", "2");
		container.setAttribute("width", "11");
		container.setAttribute("height", "11");
		container.setAttribute("rx", "1.5");
		container.setAttribute("stroke", "currentColor");
		container.setAttribute("stroke-width", "1");
		container.setAttribute("stroke-dasharray", "2 1");
		container.setAttribute("fill", "none");
		container.setAttribute("opacity", "0.5");
		const addBlock = (x, y, w, h) => {
			const rect = document.createElementNS(SVG_NS$4, "rect");
			rect.setAttribute("x", String(x));
			rect.setAttribute("y", String(y));
			rect.setAttribute("width", String(w));
			rect.setAttribute("height", String(h));
			rect.setAttribute("rx", "0.5");
			rect.setAttribute("fill", "currentColor");
			svg.append(rect);
		};
		const addLine = (x, y, w) => {
			const line = document.createElementNS(SVG_NS$4, "rect");
			line.setAttribute("x", String(x));
			line.setAttribute("y", String(y));
			line.setAttribute("width", String(w));
			line.setAttribute("height", "1");
			line.setAttribute("rx", "0.5");
			line.setAttribute("fill", "currentColor");
			svg.append(line);
		};
		switch (value) {
			case "block":
				addBlock(3.5, 3.5, 8, 3);
				addBlock(3.5, 8.5, 8, 3);
				break;
			case "inline":
				addLine(3.5, 4.5, 8);
				addLine(3.5, 7.5, 5);
				addLine(3.5, 10.5, 6.5);
				break;
			case "inline-block":
				addBlock(3.5, 4.5, 3.5, 6);
				addLine(8, 5.5, 4);
				addLine(8, 8.5, 3);
				break;
			case "flex":
				addBlock(3.5, 4.5, 2.5, 6);
				addBlock(6.5, 4.5, 2.5, 6);
				addBlock(9.5, 4.5, 2.5, 6);
				break;
			case "grid":
				addBlock(3.5, 3.5, 3.5, 3.5);
				addBlock(8, 3.5, 3.5, 3.5);
				addBlock(3.5, 8, 3.5, 3.5);
				addBlock(8, 8, 3.5, 3.5);
				break;
			case "none": {
				const slash = document.createElementNS(SVG_NS$4, "path");
				slash.setAttribute("d", "M4 11L11 4");
				slash.setAttribute("stroke", "currentColor");
				slash.setAttribute("stroke-width", "1.5");
				slash.setAttribute("stroke-linecap", "round");
				svg.append(slash);
				break;
			}
		}
		svg.prepend(container);
		return svg;
	}
	function createFlowIcon(direction) {
		const svg = createBaseIconSvg$1();
		const path = document.createElementNS(SVG_NS$4, "path");
		applyStroke(path, "1.5");
		path.setAttribute("d", {
			row: "M2 7.5H13M10 4.5L13 7.5L10 10.5",
			"row-reverse": "M13 7.5H2M5 4.5L2 7.5L5 10.5",
			column: "M7.5 2V13M4.5 10L7.5 13L10.5 10",
			"column-reverse": "M7.5 13V2M4.5 5L7.5 2L10.5 5"
		}[direction]);
		svg.append(path);
		return svg;
	}
	function createHorizontalAlignIcon(value) {
		const svg = createBaseIconSvg$1();
		const container = document.createElementNS(SVG_NS$4, "rect");
		container.setAttribute("x", "2");
		container.setAttribute("y", "2");
		container.setAttribute("width", "11");
		container.setAttribute("height", "11");
		container.setAttribute("rx", "1.5");
		container.setAttribute("stroke", "currentColor");
		container.setAttribute("stroke-width", "1");
		container.setAttribute("stroke-dasharray", "2 1");
		container.setAttribute("fill", "none");
		container.setAttribute("opacity", "0.5");
		const blockX = {
			"flex-start": 3.5,
			center: 5.5,
			"flex-end": 7.5
		};
		const block1 = document.createElementNS(SVG_NS$4, "rect");
		block1.setAttribute("x", String(blockX[value]));
		block1.setAttribute("y", "4");
		block1.setAttribute("width", "4");
		block1.setAttribute("height", "3");
		block1.setAttribute("rx", "0.5");
		block1.setAttribute("fill", "currentColor");
		const block2 = document.createElementNS(SVG_NS$4, "rect");
		block2.setAttribute("x", String(blockX[value]));
		block2.setAttribute("y", "8");
		block2.setAttribute("width", "4");
		block2.setAttribute("height", "3");
		block2.setAttribute("rx", "0.5");
		block2.setAttribute("fill", "currentColor");
		svg.append(container, block1, block2);
		return svg;
	}
	function createVerticalAlignIcon$1(value) {
		const svg = createBaseIconSvg$1();
		const container = document.createElementNS(SVG_NS$4, "rect");
		container.setAttribute("x", "2");
		container.setAttribute("y", "2");
		container.setAttribute("width", "11");
		container.setAttribute("height", "11");
		container.setAttribute("rx", "1.5");
		container.setAttribute("stroke", "currentColor");
		container.setAttribute("stroke-width", "1");
		container.setAttribute("stroke-dasharray", "2 1");
		container.setAttribute("fill", "none");
		container.setAttribute("opacity", "0.5");
		const blockY = {
			"flex-start": 3.5,
			center: 5.5,
			"flex-end": 7.5
		};
		const block1 = document.createElementNS(SVG_NS$4, "rect");
		block1.setAttribute("x", "4");
		block1.setAttribute("y", String(blockY[value]));
		block1.setAttribute("width", "3");
		block1.setAttribute("height", "4");
		block1.setAttribute("rx", "0.5");
		block1.setAttribute("fill", "currentColor");
		const block2 = document.createElementNS(SVG_NS$4, "rect");
		block2.setAttribute("x", "8");
		block2.setAttribute("y", String(blockY[value]));
		block2.setAttribute("width", "3");
		block2.setAttribute("height", "4");
		block2.setAttribute("rx", "0.5");
		block2.setAttribute("fill", "currentColor");
		svg.append(container, block1, block2);
		return svg;
	}
	function createGridColumnsIcon() {
		const svg = createBaseIconSvg$1();
		const r1 = document.createElementNS(SVG_NS$4, "rect");
		r1.setAttribute("x", "3");
		r1.setAttribute("y", "4");
		r1.setAttribute("width", "3.5");
		r1.setAttribute("height", "7");
		r1.setAttribute("rx", "1");
		applyStroke(r1);
		const r2 = document.createElementNS(SVG_NS$4, "rect");
		r2.setAttribute("x", "8.5");
		r2.setAttribute("y", "4");
		r2.setAttribute("width", "3.5");
		r2.setAttribute("height", "7");
		r2.setAttribute("rx", "1");
		applyStroke(r2);
		svg.append(r1, r2);
		return svg;
	}
	function createGridRowsIcon() {
		const svg = createBaseIconSvg$1();
		const r1 = document.createElementNS(SVG_NS$4, "rect");
		r1.setAttribute("x", "4");
		r1.setAttribute("y", "3");
		r1.setAttribute("width", "7");
		r1.setAttribute("height", "3.5");
		r1.setAttribute("rx", "1");
		applyStroke(r1);
		const r2 = document.createElementNS(SVG_NS$4, "rect");
		r2.setAttribute("x", "4");
		r2.setAttribute("y", "8.5");
		r2.setAttribute("width", "7");
		r2.setAttribute("height", "3.5");
		r2.setAttribute("rx", "1");
		applyStroke(r2);
		svg.append(r1, r2);
		return svg;
	}
	function createLayoutControl(options) {
		const { container, transactionManager } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		const root = document.createElement("div");
		root.className = "we-field-group";
		const displayRow = document.createElement("div");
		displayRow.className = "we-field";
		const displayLabel = document.createElement("span");
		displayLabel.className = "we-field-label";
		displayLabel.textContent = "Display";
		const displayMount = document.createElement("div");
		displayMount.className = "we-field-content";
		displayRow.append(displayLabel, displayMount);
		const displayGroup = createIconButtonGroup({
			container: displayMount,
			ariaLabel: "Display",
			columns: 6,
			items: DISPLAY_VALUES.map((v) => ({
				value: v,
				ariaLabel: v,
				title: v,
				icon: createDisplayIcon(v)
			})),
			onChange: (value) => {
				const handle = beginTransaction("display");
				if (handle) handle.set(value);
				commitTransaction("display");
				syncAllFields();
			}
		});
		disposer.add(() => displayGroup.dispose());
		const directionRow = document.createElement("div");
		directionRow.className = "we-field";
		const directionLabel = document.createElement("span");
		directionLabel.className = "we-field-label";
		directionLabel.textContent = "Flow";
		const directionMount = document.createElement("div");
		directionMount.className = "we-field-content";
		directionRow.append(directionLabel, directionMount);
		const directionGroup = createIconButtonGroup({
			container: directionMount,
			ariaLabel: "Flex direction",
			columns: 4,
			items: FLEX_DIRECTION_VALUES.map((dir) => ({
				value: dir,
				ariaLabel: dir.replace("-", " "),
				title: dir.replace("-", " "),
				icon: createFlowIcon(dir)
			})),
			onChange: (value) => {
				const handle = beginTransaction("flex-direction");
				if (handle) handle.set(value);
				commitTransaction("flex-direction");
				syncAllFields();
			}
		});
		disposer.add(() => directionGroup.dispose());
		directionGroup.setValue(null);
		const wrapRow = document.createElement("div");
		wrapRow.className = "we-field";
		const wrapLabel = document.createElement("span");
		wrapLabel.className = "we-field-label";
		wrapLabel.textContent = "Wrap";
		const wrapSelect = document.createElement("select");
		wrapSelect.className = "we-select";
		wrapSelect.setAttribute("aria-label", "flex-wrap");
		for (const v of FLEX_WRAP_VALUES) {
			const opt = document.createElement("option");
			opt.value = v;
			opt.textContent = v;
			wrapSelect.append(opt);
		}
		wrapRow.append(wrapLabel, wrapSelect);
		const alignmentRow = document.createElement("div");
		alignmentRow.className = "we-field";
		const alignmentLabel = document.createElement("span");
		alignmentLabel.className = "we-field-label";
		alignmentLabel.textContent = "Align";
		const alignmentMount = document.createElement("div");
		alignmentMount.className = "we-field-content";
		alignmentMount.style.display = "flex";
		alignmentMount.style.gap = "4px";
		alignmentRow.append(alignmentLabel, alignmentMount);
		const justifyWrapper = document.createElement("div");
		justifyWrapper.style.flex = "1";
		justifyWrapper.style.minWidth = "0";
		justifyWrapper.style.display = "flex";
		justifyWrapper.style.flexDirection = "column";
		justifyWrapper.style.gap = "2px";
		const justifyHint = document.createElement("span");
		justifyHint.className = "we-field-hint";
		justifyHint.textContent = "H";
		const justifyMount = document.createElement("div");
		justifyWrapper.append(justifyHint, justifyMount);
		const alignWrapper = document.createElement("div");
		alignWrapper.style.flex = "1";
		alignWrapper.style.minWidth = "0";
		alignWrapper.style.display = "flex";
		alignWrapper.style.flexDirection = "column";
		alignWrapper.style.gap = "2px";
		const alignHint = document.createElement("span");
		alignHint.className = "we-field-hint";
		alignHint.textContent = "V";
		const alignMount = document.createElement("div");
		alignWrapper.append(alignHint, alignMount);
		alignmentMount.append(justifyWrapper, alignWrapper);
		const justifyGroup = createIconButtonGroup({
			container: justifyMount,
			ariaLabel: "Justify content",
			columns: 3,
			items: ALIGNMENT_AXIS_VALUES.map((v) => ({
				value: v,
				ariaLabel: `justify-content: ${v}`,
				title: v,
				icon: createHorizontalAlignIcon(v)
			})),
			onChange: (justifyContent) => {
				var _alignGroup$getValue;
				const handle = beginAlignmentTransaction();
				if (!handle) return;
				const alignItems = (_alignGroup$getValue = alignGroup.getValue()) !== null && _alignGroup$getValue !== void 0 ? _alignGroup$getValue : "center";
				handle.set({
					"justify-content": justifyContent,
					"align-items": alignItems
				});
				commitAlignmentTransaction();
				syncAllFields();
			}
		});
		const alignGroup = createIconButtonGroup({
			container: alignMount,
			ariaLabel: "Align items",
			columns: 3,
			items: ALIGNMENT_AXIS_VALUES.map((v) => ({
				value: v,
				ariaLabel: `align-items: ${v}`,
				title: v,
				icon: createVerticalAlignIcon$1(v)
			})),
			onChange: (alignItems) => {
				var _justifyGroup$getValu;
				const handle = beginAlignmentTransaction();
				if (!handle) return;
				const justifyContent = (_justifyGroup$getValu = justifyGroup.getValue()) !== null && _justifyGroup$getValu !== void 0 ? _justifyGroup$getValu : "center";
				handle.set({
					"justify-content": justifyContent,
					"align-items": alignItems
				});
				commitAlignmentTransaction();
				syncAllFields();
			}
		});
		disposer.add(() => justifyGroup.dispose());
		disposer.add(() => alignGroup.dispose());
		justifyGroup.setValue(null);
		alignGroup.setValue(null);
		const gridRow = document.createElement("div");
		gridRow.className = "we-field";
		const gridLabel = document.createElement("span");
		gridLabel.className = "we-field-label";
		gridLabel.textContent = "Grid";
		const gridMount = document.createElement("div");
		gridMount.className = "we-field-content";
		gridMount.style.position = "relative";
		gridRow.append(gridLabel, gridMount);
		const gridPreviewButton = document.createElement("button");
		gridPreviewButton.type = "button";
		gridPreviewButton.className = "we-grid-dimensions-preview";
		gridPreviewButton.setAttribute("aria-label", "Grid dimensions");
		gridPreviewButton.setAttribute("aria-expanded", "false");
		gridPreviewButton.setAttribute("aria-haspopup", "dialog");
		const gridPreviewColsValue = document.createElement("span");
		gridPreviewColsValue.textContent = "1";
		const gridPreviewTimes = document.createElement("span");
		gridPreviewTimes.textContent = " × ";
		const gridPreviewRowsValue = document.createElement("span");
		gridPreviewRowsValue.textContent = "1";
		gridPreviewButton.append(gridPreviewColsValue, gridPreviewTimes, gridPreviewRowsValue);
		const gridPopover = document.createElement("div");
		gridPopover.className = "we-grid-dimensions-popover";
		gridPopover.hidden = true;
		const gridInputs = document.createElement("div");
		gridInputs.className = "we-grid-dimensions-inputs";
		const colsContainer = createInputContainer({
			ariaLabel: "Grid columns",
			inputMode: "numeric",
			prefix: createGridColumnsIcon(),
			suffix: null
		});
		colsContainer.root.style.width = "72px";
		colsContainer.root.style.flex = "0 0 auto";
		const times = document.createElement("span");
		times.className = "we-grid-dimensions-times";
		times.textContent = "×";
		const rowsContainer = createInputContainer({
			ariaLabel: "Grid rows",
			inputMode: "numeric",
			prefix: createGridRowsIcon(),
			suffix: null
		});
		rowsContainer.root.style.width = "72px";
		rowsContainer.root.style.flex = "0 0 auto";
		gridInputs.append(colsContainer.root, times, rowsContainer.root);
		const matrix = document.createElement("div");
		matrix.className = "we-grid-dimensions-matrix";
		matrix.setAttribute("role", "grid");
		const cells = [];
		for (let r = 1; r <= GRID_DIMENSION_MAX; r++) for (let c = 1; c <= GRID_DIMENSION_MAX; c++) {
			const cell = document.createElement("button");
			cell.type = "button";
			cell.className = "we-grid-dimensions-cell";
			cell.dataset.row = String(r);
			cell.dataset.col = String(c);
			cell.setAttribute("role", "gridcell");
			cell.setAttribute("aria-label", `${c} × ${r}`);
			cells.push(cell);
			matrix.append(cell);
		}
		const tooltip = document.createElement("div");
		tooltip.className = "we-grid-dimensions-tooltip";
		tooltip.hidden = true;
		gridPopover.append(gridInputs, matrix, tooltip);
		gridMount.append(gridPreviewButton, gridPopover);
		wireNumberStepping(disposer, colsContainer.input, {
			mode: "number",
			integer: true,
			min: 1,
			max: GRID_DIMENSION_MAX
		});
		wireNumberStepping(disposer, rowsContainer.input, {
			mode: "number",
			integer: true,
			min: 1,
			max: GRID_DIMENSION_MAX
		});
		const gapRow = document.createElement("div");
		gapRow.className = "we-field";
		const gapLabel = document.createElement("span");
		gapLabel.className = "we-field-label";
		gapLabel.textContent = "Gap";
		const gapMount = document.createElement("div");
		gapMount.className = "we-field-content";
		const gapInputs = document.createElement("div");
		gapInputs.className = "we-grid-gap-inputs";
		const rowGapContainer = createInputContainer({
			ariaLabel: "Row gap",
			inputMode: "decimal",
			prefix: createGridRowsIcon(),
			suffix: "px"
		});
		const columnGapContainer = createInputContainer({
			ariaLabel: "Column gap",
			inputMode: "decimal",
			prefix: createGridColumnsIcon(),
			suffix: "px"
		});
		gapInputs.append(rowGapContainer.root, columnGapContainer.root);
		gapMount.append(gapInputs);
		gapRow.append(gapLabel, gapMount);
		wireNumberStepping(disposer, rowGapContainer.input, { mode: "css-length" });
		wireNumberStepping(disposer, columnGapContainer.input, { mode: "css-length" });
		const gridGapRow = document.createElement("div");
		gridGapRow.className = "we-grid-gap-row";
		gridGapRow.hidden = true;
		gridRow.classList.add("we-grid-gap-col", "we-grid-gap-col--grid");
		gapRow.classList.add("we-grid-gap-col", "we-grid-gap-col--gap");
		gridGapRow.append(gridRow, gapRow);
		root.append(displayRow, directionRow, wrapRow, alignmentRow, gridGapRow);
		container.append(root);
		disposer.add(() => root.remove());
		const fields = {
			display: {
				kind: "display-group",
				property: "display",
				group: displayGroup,
				handle: null,
				row: displayRow
			},
			"flex-direction": {
				kind: "flex-direction-group",
				property: "flex-direction",
				group: directionGroup,
				handle: null,
				row: directionRow
			},
			"flex-wrap": {
				kind: "select",
				property: "flex-wrap",
				element: wrapSelect,
				handle: null,
				row: wrapRow
			},
			alignment: {
				kind: "flex-alignment",
				properties: ["justify-content", "align-items"],
				justifyGroup,
				alignGroup,
				handle: null,
				row: alignmentRow
			},
			"grid-dimensions": {
				kind: "grid-dimensions",
				properties: ["grid-template-columns", "grid-template-rows"],
				previewButton: gridPreviewButton,
				previewColsValue: gridPreviewColsValue,
				previewRowsValue: gridPreviewRowsValue,
				popover: gridPopover,
				colsContainer,
				rowsContainer,
				matrix,
				tooltip,
				cells,
				handle: null,
				row: gridRow
			},
			"row-gap": {
				kind: "input",
				property: "row-gap",
				element: rowGapContainer.input,
				container: rowGapContainer,
				handle: null,
				row: gapRow
			},
			"column-gap": {
				kind: "input",
				property: "column-gap",
				element: columnGapContainer.input,
				container: columnGapContainer,
				handle: null,
				row: gapRow
			}
		};
		/** Single-property fields for iteration */
		const STYLE_PROPS = [
			"display",
			"flex-direction",
			"flex-wrap",
			"row-gap",
			"column-gap"
		];
		/** All field keys for iteration */
		const FIELD_KEYS = [
			"display",
			"flex-direction",
			"flex-wrap",
			"alignment",
			"grid-dimensions",
			"row-gap",
			"column-gap"
		];
		function beginTransaction(property) {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields[property];
			if (field.kind === "flex-alignment" || field.kind === "grid-dimensions") return null;
			if (field.handle) return field.handle;
			const handle = transactionManager.beginStyle(target, property);
			field.handle = handle;
			return handle;
		}
		function commitTransaction(property) {
			const field = fields[property];
			if (field.kind === "flex-alignment" || field.kind === "grid-dimensions") return;
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackTransaction(property) {
			const field = fields[property];
			if (field.kind === "flex-alignment" || field.kind === "grid-dimensions") return;
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.rollback();
		}
		function beginAlignmentTransaction() {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields.alignment;
			if (field.kind !== "flex-alignment") return null;
			if (field.handle) return field.handle;
			const handle = transactionManager.beginMultiStyle(target, [...field.properties]);
			field.handle = handle;
			return handle;
		}
		function commitAlignmentTransaction() {
			const field = fields.alignment;
			if (field.kind !== "flex-alignment") return;
			const handle = field.handle;
			field.handle = null;
			handle === null || handle === void 0 || handle.commit({ merge: true });
		}
		function beginGridTransaction() {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields["grid-dimensions"];
			if (field.kind !== "grid-dimensions") return null;
			if (field.handle) return field.handle;
			const handle = transactionManager.beginMultiStyle(target, [...field.properties]);
			field.handle = handle;
			return handle;
		}
		function commitGridTransaction() {
			const field = fields["grid-dimensions"];
			if (field.kind !== "grid-dimensions") return;
			const handle = field.handle;
			field.handle = null;
			handle === null || handle === void 0 || handle.commit({ merge: true });
		}
		function rollbackGridTransaction() {
			const field = fields["grid-dimensions"];
			if (field.kind !== "grid-dimensions") return;
			const handle = field.handle;
			field.handle = null;
			handle === null || handle === void 0 || handle.rollback();
		}
		function commitAllTransactions() {
			for (const p of STYLE_PROPS) commitTransaction(p);
			commitAlignmentTransaction();
			commitGridTransaction();
		}
		function updateVisibility() {
			var _displayGroup$getValu;
			const target = currentTarget;
			const trimmed = normalizeDisplayValue(target ? readInlineValue$6(target, "display") || readComputedValue$5(target, "display") : (_displayGroup$getValu = displayGroup.getValue()) !== null && _displayGroup$getValu !== void 0 ? _displayGroup$getValu : "block").trim();
			const isFlex = trimmed === "flex" || trimmed === "inline-flex";
			const isGrid = trimmed === "grid" || trimmed === "inline-grid";
			const isFlexOrGrid = isFlex || isGrid;
			directionRow.hidden = !isFlex;
			wrapRow.hidden = !isFlex;
			alignmentRow.hidden = !isFlex;
			gridGapRow.hidden = !isFlexOrGrid;
			gridRow.hidden = !isGrid;
			gapRow.hidden = !isFlexOrGrid;
		}
		function syncField(key, force = false) {
			const field = fields[key];
			const target = currentTarget;
			if (field.kind === "display-group") {
				const group = field.group;
				if (!target || !target.isConnected) {
					group.setDisabled(true);
					group.setValue(null);
					return;
				}
				group.setDisabled(false);
				if (field.handle !== null && !force) return;
				const inline = readInlineValue$6(target, "display");
				const computed = readComputedValue$5(target, "display");
				let raw = (inline || computed).trim();
				raw = normalizeDisplayValue(raw);
				group.setValue(isDisplayValue(raw) ? raw : "block");
				return;
			}
			if (field.kind === "flex-direction-group") {
				const group = field.group;
				if (!target || !target.isConnected) {
					group.setDisabled(true);
					group.setValue(null);
					return;
				}
				group.setDisabled(false);
				if (field.handle !== null && !force) return;
				const inline = readInlineValue$6(target, "flex-direction");
				const computed = readComputedValue$5(target, "flex-direction");
				const raw = (inline || computed).trim();
				group.setValue(isFlexDirectionValue(raw) ? raw : null);
				return;
			}
			if (field.kind === "flex-alignment") {
				if (!target || !target.isConnected) {
					field.justifyGroup.setDisabled(true);
					field.alignGroup.setDisabled(true);
					field.justifyGroup.setValue(null);
					field.alignGroup.setValue(null);
					return;
				}
				field.justifyGroup.setDisabled(false);
				field.alignGroup.setDisabled(false);
				if (field.handle !== null && !force) return;
				const justifyInline = readInlineValue$6(target, "justify-content");
				const justifyComputed = readComputedValue$5(target, "justify-content");
				const alignInline = readInlineValue$6(target, "align-items");
				const alignComputed = readComputedValue$5(target, "align-items");
				const justifyRaw = (justifyInline || justifyComputed).trim();
				const alignRaw = (alignInline || alignComputed).trim();
				if (isAlignmentAxisValue(justifyRaw) && isAlignmentAxisValue(alignRaw)) {
					field.justifyGroup.setValue(justifyRaw);
					field.alignGroup.setValue(alignRaw);
				} else {
					field.justifyGroup.setValue(null);
					field.alignGroup.setValue(null);
				}
				return;
			}
			if (field.kind === "grid-dimensions") {
				var _countGridTracks, _countGridTracks2;
				const { previewButton, popover, colsContainer, rowsContainer, tooltip, cells: gridCells } = field;
				if (!target || !target.isConnected) {
					previewButton.disabled = true;
					field.previewColsValue.textContent = "—";
					field.previewRowsValue.textContent = "—";
					previewButton.setAttribute("aria-expanded", "false");
					popover.hidden = true;
					colsContainer.input.disabled = true;
					rowsContainer.input.disabled = true;
					tooltip.hidden = true;
					for (const cell of gridCells) {
						cell.dataset.active = "false";
						cell.dataset.selected = "false";
					}
					return;
				}
				previewButton.disabled = false;
				colsContainer.input.disabled = false;
				rowsContainer.input.disabled = false;
				if ((field.handle !== null || isFieldFocused$5(colsContainer.input) || isFieldFocused$5(rowsContainer.input)) && !force) return;
				const colsRaw = readInlineValue$6(target, "grid-template-columns") || readComputedValue$5(target, "grid-template-columns");
				const rowsRaw = readInlineValue$6(target, "grid-template-rows") || readComputedValue$5(target, "grid-template-rows");
				const cols = clampInt((_countGridTracks = countGridTracks(colsRaw)) !== null && _countGridTracks !== void 0 ? _countGridTracks : 1, 1, GRID_DIMENSION_MAX);
				const rows = clampInt((_countGridTracks2 = countGridTracks(rowsRaw)) !== null && _countGridTracks2 !== void 0 ? _countGridTracks2 : 1, 1, GRID_DIMENSION_MAX);
				colsContainer.input.value = String(cols);
				rowsContainer.input.value = String(rows);
				field.previewColsValue.textContent = String(cols);
				field.previewRowsValue.textContent = String(rows);
				previewButton.setAttribute("aria-label", `Grid: ${cols} columns, ${rows} rows`);
				tooltip.hidden = true;
				for (const cell of gridCells) {
					var _cell$dataset$col, _cell$dataset$row;
					const c = parseInt((_cell$dataset$col = cell.dataset.col) !== null && _cell$dataset$col !== void 0 ? _cell$dataset$col : "0", 10);
					const r = parseInt((_cell$dataset$row = cell.dataset.row) !== null && _cell$dataset$row !== void 0 ? _cell$dataset$row : "0", 10);
					const selected = c > 0 && r > 0 && c <= cols && r <= rows;
					cell.dataset.selected = selected ? "true" : "false";
					cell.dataset.active = selected ? "true" : "false";
				}
				return;
			}
			if (field.kind === "input") {
				const input = field.element;
				if (!target || !target.isConnected) {
					input.disabled = true;
					input.value = "";
					input.placeholder = "";
					field.container.setSuffix("px");
					return;
				}
				input.disabled = false;
				if ((field.handle !== null || isFieldFocused$5(input)) && !force) return;
				const formatted = formatLengthForDisplay(readInlineValue$6(target, field.property) || readComputedValue$5(target, field.property));
				input.value = formatted.value;
				field.container.setSuffix(formatted.suffix);
				input.placeholder = "";
				return;
			}
			if (field.kind === "select") {
				var _select$options$0$val, _select$options$;
				const select = field.element;
				if (!target || !target.isConnected) {
					select.disabled = true;
					return;
				}
				select.disabled = false;
				if ((field.handle !== null || isFieldFocused$5(select)) && !force) return;
				const inline = readInlineValue$6(target, field.property);
				const computed = readComputedValue$5(target, field.property);
				const val = inline || computed;
				select.value = Array.from(select.options).some((o) => o.value === val) ? val : (_select$options$0$val = (_select$options$ = select.options[0]) === null || _select$options$ === void 0 ? void 0 : _select$options$.value) !== null && _select$options$0$val !== void 0 ? _select$options$0$val : "";
			}
		}
		function syncAllFields() {
			for (const key of FIELD_KEYS) syncField(key);
			updateVisibility();
		}
		function wireSelect(property) {
			const field = fields[property];
			if (field.kind !== "select") return;
			const select = field.element;
			const preview = () => {
				const handle = beginTransaction(property);
				if (handle) handle.set(select.value);
			};
			disposer.listen(select, "input", preview);
			disposer.listen(select, "change", preview);
			disposer.listen(select, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(select, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					select.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		function wireInput(property) {
			const field = fields[property];
			if (field.kind !== "input") return;
			const input = field.element;
			disposer.listen(input, "input", () => {
				const handle = beginTransaction(property);
				if (!handle) return;
				const suffix = field.container.getSuffixText();
				handle.set(combineLengthValue(input.value, suffix));
			});
			disposer.listen(input, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(input, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					input.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		wireSelect("flex-wrap");
		wireInput("row-gap");
		wireInput("column-gap");
		let gridHoverCols = null;
		let gridHoverRows = null;
		function renderGridSelection(field, cols, rows) {
			var _gridHoverCols, _gridHoverRows;
			const activeCols = (_gridHoverCols = gridHoverCols) !== null && _gridHoverCols !== void 0 ? _gridHoverCols : cols;
			const activeRows = (_gridHoverRows = gridHoverRows) !== null && _gridHoverRows !== void 0 ? _gridHoverRows : rows;
			for (const cell of field.cells) {
				var _cell$dataset$col2, _cell$dataset$row2;
				const c = parseInt((_cell$dataset$col2 = cell.dataset.col) !== null && _cell$dataset$col2 !== void 0 ? _cell$dataset$col2 : "0", 10);
				const r = parseInt((_cell$dataset$row2 = cell.dataset.row) !== null && _cell$dataset$row2 !== void 0 ? _cell$dataset$row2 : "0", 10);
				const selected = c > 0 && r > 0 && c <= cols && r <= rows;
				const active = c > 0 && r > 0 && c <= activeCols && r <= activeRows;
				cell.dataset.selected = selected ? "true" : "false";
				cell.dataset.active = active ? "true" : "false";
			}
			if (gridHoverCols !== null && gridHoverRows !== null) {
				field.tooltip.textContent = `${gridHoverCols} × ${gridHoverRows}`;
				field.tooltip.hidden = false;
			} else field.tooltip.hidden = true;
		}
		function setGridPopoverOpen(field, open) {
			field.popover.hidden = !open;
			field.previewButton.setAttribute("aria-expanded", open ? "true" : "false");
			gridHoverCols = null;
			gridHoverRows = null;
			renderGridSelection(field, clampInt(parseInt(field.colsContainer.input.value || "1", 10) || 1, 1, GRID_DIMENSION_MAX), clampInt(parseInt(field.rowsContainer.input.value || "1", 10) || 1, 1, GRID_DIMENSION_MAX));
		}
		function previewGridDimensions(cols, rows) {
			const handle = beginGridTransaction();
			if (!handle) return;
			handle.set({
				"grid-template-columns": formatGridTemplate(cols),
				"grid-template-rows": formatGridTemplate(rows)
			});
		}
		const gridField = fields["grid-dimensions"];
		if (gridField.kind === "grid-dimensions") {
			disposer.listen(gridField.previewButton, "click", (e) => {
				e.preventDefault();
				setGridPopoverOpen(gridField, gridField.popover.hidden);
				if (!gridField.popover.hidden) {
					gridField.colsContainer.input.focus();
					gridField.colsContainer.input.select();
				}
			});
			const rootNode = gridField.previewButton.getRootNode();
			const clickTarget = rootNode instanceof ShadowRoot ? rootNode : document;
			const handleOutsideClick = (e) => {
				if (gridField.kind !== "grid-dimensions") return;
				if (gridField.popover.hidden) return;
				const target = e.target;
				if (!gridRow.contains(target)) setGridPopoverOpen(gridField, false);
			};
			clickTarget.addEventListener("click", handleOutsideClick, true);
			disposer.add(() => {
				clickTarget.removeEventListener("click", handleOutsideClick, true);
			});
			const wireGridInput = (input) => {
				disposer.listen(input, "input", () => {
					const cols = clampInt(parseInt(gridField.colsContainer.input.value || "1", 10) || 1, 1, GRID_DIMENSION_MAX);
					const rows = clampInt(parseInt(gridField.rowsContainer.input.value || "1", 10) || 1, 1, GRID_DIMENSION_MAX);
					renderGridSelection(gridField, cols, rows);
					previewGridDimensions(cols, rows);
				});
				disposer.listen(input, "blur", () => {
					commitGridTransaction();
					syncAllFields();
				});
				disposer.listen(input, "keydown", (ev) => {
					if (ev.key === "Enter") {
						ev.preventDefault();
						commitGridTransaction();
						syncAllFields();
						return;
					}
					if (ev.key === "Escape") {
						ev.preventDefault();
						rollbackGridTransaction();
						setGridPopoverOpen(gridField, false);
						syncField("grid-dimensions", true);
					}
				});
			};
			wireGridInput(gridField.colsContainer.input);
			wireGridInput(gridField.rowsContainer.input);
			disposer.listen(gridField.matrix, "mouseover", (e) => {
				var _cell$dataset$col3, _cell$dataset$row3;
				const cell = e.target.closest(".we-grid-dimensions-cell");
				if (!cell) return;
				gridHoverCols = clampInt(parseInt((_cell$dataset$col3 = cell.dataset.col) !== null && _cell$dataset$col3 !== void 0 ? _cell$dataset$col3 : "1", 10) || 1, 1, GRID_DIMENSION_MAX);
				gridHoverRows = clampInt(parseInt((_cell$dataset$row3 = cell.dataset.row) !== null && _cell$dataset$row3 !== void 0 ? _cell$dataset$row3 : "1", 10) || 1, 1, GRID_DIMENSION_MAX);
				renderGridSelection(gridField, clampInt(parseInt(gridField.colsContainer.input.value || "1", 10) || 1, 1, GRID_DIMENSION_MAX), clampInt(parseInt(gridField.rowsContainer.input.value || "1", 10) || 1, 1, GRID_DIMENSION_MAX));
			});
			disposer.listen(gridField.matrix, "mouseleave", () => {
				gridHoverCols = null;
				gridHoverRows = null;
				renderGridSelection(gridField, clampInt(parseInt(gridField.colsContainer.input.value || "1", 10) || 1, 1, GRID_DIMENSION_MAX), clampInt(parseInt(gridField.rowsContainer.input.value || "1", 10) || 1, 1, GRID_DIMENSION_MAX));
			});
			disposer.listen(gridField.matrix, "click", (e) => {
				var _cell$dataset$col4, _cell$dataset$row4;
				const cell = e.target.closest(".we-grid-dimensions-cell");
				if (!cell) return;
				const cols = clampInt(parseInt((_cell$dataset$col4 = cell.dataset.col) !== null && _cell$dataset$col4 !== void 0 ? _cell$dataset$col4 : "1", 10) || 1, 1, GRID_DIMENSION_MAX);
				const rows = clampInt(parseInt((_cell$dataset$row4 = cell.dataset.row) !== null && _cell$dataset$row4 !== void 0 ? _cell$dataset$row4 : "1", 10) || 1, 1, GRID_DIMENSION_MAX);
				gridField.colsContainer.input.value = String(cols);
				gridField.rowsContainer.input.value = String(rows);
				previewGridDimensions(cols, rows);
				commitGridTransaction();
				setGridPopoverOpen(gridField, false);
				syncAllFields();
			});
		}
		function setTarget(element) {
			if (disposer.isDisposed) return;
			if (element !== currentTarget) commitAllTransactions();
			currentTarget = element;
			syncAllFields();
		}
		function refresh() {
			if (disposer.isDisposed) return;
			syncAllFields();
		}
		function dispose() {
			commitAllTransactions();
			currentTarget = null;
			disposer.dispose();
		}
		syncAllFields();
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/token-picker.ts
	/**
	* Token Picker Control (Phase 5.4)
	*
	* A dropdown picker for selecting CSS design tokens (custom properties).
	* Integrates with DesignTokensService for token discovery and resolution.
	*
	* Features:
	* - Shows available tokens for the current element context
	* - Filter tokens by typing
	* - Preview token computed value
	* - Select token to apply var(--token) to a CSS property
	* - "Show all" toggle for full root token list vs context tokens
	*
	* Usage pattern:
	* - Attach to an input field as an "enhancement"
	* - When user clicks the token button, show dropdown
	* - On selection, callback returns the var(--token) value
	*/
	var DEFAULT_MAX_VISIBLE = 8;
	var FILTER_DEBOUNCE_MS = 100;
	/**
	* Create a token picker component.
	*/
	function createTokenPicker(options) {
		const { container, tokensService, onSelect, maxVisible = DEFAULT_MAX_VISIBLE } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		let contextTokens = [];
		let filteredTokens = [];
		let showAllTokens = false;
		let filterText = "";
		let filterTimeoutId = null;
		let selectedIndex = -1;
		const root = document.createElement("div");
		root.className = "we-token-picker";
		root.hidden = true;
		const filterInput = document.createElement("input");
		filterInput.type = "text";
		filterInput.className = "we-token-filter";
		filterInput.placeholder = "Filter tokens...";
		filterInput.autocomplete = "off";
		filterInput.spellcheck = false;
		const toggleRow = document.createElement("div");
		toggleRow.className = "we-token-toggle-row";
		const toggleLabel = document.createElement("label");
		toggleLabel.className = "we-token-toggle-label";
		const toggleCheckbox = document.createElement("input");
		toggleCheckbox.type = "checkbox";
		toggleCheckbox.className = "we-token-toggle-checkbox";
		const toggleText = document.createElement("span");
		toggleText.textContent = "Show all root tokens";
		toggleLabel.append(toggleCheckbox, toggleText);
		toggleRow.append(toggleLabel);
		const listContainer = document.createElement("div");
		listContainer.className = "we-token-list";
		listContainer.style.maxHeight = `${maxVisible * 36}px`;
		const emptyState = document.createElement("div");
		emptyState.className = "we-token-empty";
		emptyState.textContent = "No tokens found";
		emptyState.hidden = true;
		root.append(filterInput, toggleRow, listContainer, emptyState);
		container.append(root);
		disposer.add(() => root.remove());
		function loadTokens() {
			if (!currentTarget || !currentTarget.isConnected) {
				contextTokens = [];
				filteredTokens = [];
				return;
			}
			if (showAllTokens) {
				const root = currentTarget.getRootNode();
				contextTokens = tokensService.getRootTokens(root).tokens.map((token) => {
					return {
						token,
						computedValue: tokensService.resolveToken(currentTarget, token.name).computedValue
					};
				});
			} else contextTokens = [...tokensService.getContextTokens(currentTarget).tokens];
			applyFilter();
		}
		function applyFilter() {
			const query = filterText.toLowerCase().trim();
			if (!query) filteredTokens = contextTokens;
			else filteredTokens = contextTokens.filter((ct) => {
				const name = ct.token.name.toLowerCase();
				const value = ct.computedValue.toLowerCase();
				return name.includes(query) || value.includes(query);
			});
			selectedIndex = filteredTokens.length > 0 ? 0 : -1;
			renderList();
		}
		function renderList() {
			listContainer.innerHTML = "";
			if (filteredTokens.length === 0) {
				emptyState.hidden = false;
				listContainer.hidden = true;
				return;
			}
			emptyState.hidden = true;
			listContainer.hidden = false;
			for (let i = 0; i < filteredTokens.length; i++) {
				const ct = filteredTokens[i];
				const item = createTokenItem(ct, i);
				listContainer.append(item);
			}
			updateSelectedHighlight();
		}
		function createTokenItem(ct, index) {
			const item = document.createElement("button");
			item.type = "button";
			item.className = "we-token-item";
			item.dataset.index = String(index);
			item.dataset.name = ct.token.name;
			const nameEl = document.createElement("span");
			nameEl.className = "we-token-name";
			nameEl.textContent = ct.token.name;
			const valueEl = document.createElement("span");
			valueEl.className = "we-token-value";
			valueEl.textContent = ct.computedValue || "(unset)";
			const computedLower = ct.computedValue.toLowerCase();
			if ((computedLower.startsWith("#") || computedLower.startsWith("rgb") || computedLower.startsWith("hsl") || /^[a-z]+$/.test(computedLower)) && ct.computedValue) {
				const swatch = document.createElement("span");
				swatch.className = "we-token-swatch";
				swatch.style.backgroundColor = ct.computedValue;
				item.append(swatch);
			}
			item.append(nameEl, valueEl);
			return item;
		}
		function updateSelectedHighlight() {
			const items = listContainer.querySelectorAll(".we-token-item");
			items.forEach((item, i) => {
				item.classList.toggle("we-token-item--selected", i === selectedIndex);
			});
			if (selectedIndex >= 0 && selectedIndex < items.length) items[selectedIndex].scrollIntoView({ block: "nearest" });
		}
		function selectToken(index) {
			if (index < 0 || index >= filteredTokens.length) return;
			const ct = filteredTokens[index];
			const cssValue = tokensService.formatCssVar(ct.token.name);
			hide();
			onSelect(ct.token.name, cssValue);
		}
		function selectCurrent() {
			if (selectedIndex >= 0) selectToken(selectedIndex);
		}
		disposer.listen(filterInput, "input", () => {
			filterText = filterInput.value;
			if (filterTimeoutId) clearTimeout(filterTimeoutId);
			filterTimeoutId = setTimeout(() => {
				filterTimeoutId = null;
				applyFilter();
			}, FILTER_DEBOUNCE_MS);
		});
		disposer.listen(filterInput, "keydown", (e) => {
			switch (e.key) {
				case "ArrowDown":
					e.preventDefault();
					if (filteredTokens.length > 0) {
						selectedIndex = Math.min(selectedIndex + 1, filteredTokens.length - 1);
						updateSelectedHighlight();
					}
					break;
				case "ArrowUp":
					e.preventDefault();
					if (filteredTokens.length > 0) {
						selectedIndex = Math.max(selectedIndex - 1, 0);
						updateSelectedHighlight();
					}
					break;
				case "Enter":
					e.preventDefault();
					selectCurrent();
					break;
				case "Escape":
					e.preventDefault();
					hide();
					break;
			}
		});
		disposer.listen(toggleCheckbox, "change", () => {
			showAllTokens = toggleCheckbox.checked;
			loadTokens();
		});
		disposer.listen(listContainer, "click", (e) => {
			var _item$dataset$index;
			const item = e.target.closest(".we-token-item");
			if (!item) return;
			const index = parseInt((_item$dataset$index = item.dataset.index) !== null && _item$dataset$index !== void 0 ? _item$dataset$index : "-1", 10);
			if (index >= 0) selectToken(index);
		});
		disposer.listen(root, "mousedown", (e) => {
			e.preventDefault();
		});
		function setTarget(element) {
			if (disposer.isDisposed) return;
			currentTarget = element && element.isConnected ? element : null;
			filterText = "";
			filterInput.value = "";
			if (root.hidden) return;
			loadTokens();
		}
		function show() {
			if (disposer.isDisposed) return;
			if (!root.hidden) return;
			root.hidden = false;
			loadTokens();
			filterInput.focus();
		}
		function hide() {
			if (disposer.isDisposed) return;
			root.hidden = true;
			filterText = "";
			filterInput.value = "";
			selectedIndex = -1;
		}
		function toggle() {
			if (root.hidden) {
				show();
				return true;
			} else {
				hide();
				return false;
			}
		}
		function isVisible() {
			return !root.hidden;
		}
		function refresh() {
			if (disposer.isDisposed) return;
			if (root.hidden) return;
			loadTokens();
		}
		function dispose() {
			if (filterTimeoutId) {
				clearTimeout(filterTimeoutId);
				filterTimeoutId = null;
			}
			currentTarget = null;
			contextTokens = [];
			filteredTokens = [];
			disposer.dispose();
		}
		return {
			setTarget,
			show,
			hide,
			toggle,
			isVisible,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/components/token-pill.ts
	/**
	* Token Pill Component (Phase 5.3)
	*
	* A compact pill UI for displaying a CSS custom property (var()) reference.
	* Used in ColorField and potentially other inputs to show token-bound values.
	*
	* Features:
	* - Displays token name with optional color swatch preview
	* - Click pill to open Token Picker
	* - Hover to reveal clear (×) button for detaching token
	* - Supports external leading element injection (e.g., ColorField swatch)
	*
	* Design reference: token.png and attr-ui.html:699-727
	*/
	var SVG_NS$3 = "http://www.w3.org/2000/svg";
	var LINK_ICON_PATH = "M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m0-5.656a4 4 0 015.656 0l4 4a4 4 0 11-5.656 5.656l-1.1-1.102";
	/**
	* Create a token pill component.
	*/
	function createTokenPill(options) {
		const { container, ariaLabel, tokenName, previewColor = null, leadingElement = null, disabled = false, onClick, onClear } = options;
		const disposer = new Disposer();
		let isDisabled = Boolean(disabled);
		let currentTokenName = String(tokenName !== null && tokenName !== void 0 ? tokenName : "");
		let currentPreviewColor = typeof previewColor === "string" ? previewColor : null;
		let currentLeadingElement = leadingElement !== null && leadingElement !== void 0 ? leadingElement : null;
		const root = document.createElement("div");
		root.className = "we-token-pill";
		root.dataset.disabled = isDisabled ? "true" : "false";
		root.setAttribute("role", "group");
		root.setAttribute("aria-label", ariaLabel);
		const leadingSlot = document.createElement("div");
		leadingSlot.className = "we-token-pill__leading";
		const internalSwatch = document.createElement("div");
		internalSwatch.className = "we-token-pill__swatch";
		internalSwatch.setAttribute("aria-hidden", "true");
		const mainBtn = document.createElement("button");
		mainBtn.type = "button";
		mainBtn.className = "we-token-pill__main";
		mainBtn.setAttribute("aria-label", ariaLabel);
		mainBtn.dataset.tooltip = "Change token";
		const nameEl = document.createElement("span");
		nameEl.className = "we-token-pill__name";
		const linkIcon = document.createElementNS(SVG_NS$3, "svg");
		linkIcon.setAttribute("viewBox", "0 0 24 24");
		linkIcon.setAttribute("fill", "none");
		linkIcon.setAttribute("aria-hidden", "true");
		linkIcon.classList.add("we-token-pill__icon");
		const iconPath = document.createElementNS(SVG_NS$3, "path");
		iconPath.setAttribute("d", LINK_ICON_PATH);
		iconPath.setAttribute("stroke", "currentColor");
		iconPath.setAttribute("stroke-width", "2");
		iconPath.setAttribute("stroke-linecap", "round");
		iconPath.setAttribute("stroke-linejoin", "round");
		linkIcon.append(iconPath);
		mainBtn.append(nameEl, linkIcon);
		const clearBtn = document.createElement("button");
		clearBtn.type = "button";
		clearBtn.className = "we-token-pill__clear";
		clearBtn.setAttribute("aria-label", "Clear token");
		clearBtn.dataset.tooltip = "Clear token";
		clearBtn.textContent = "×";
		root.append(leadingSlot, mainBtn, clearBtn);
		container.append(root);
		disposer.add(() => root.remove());
		/** Sync leading slot content (external element or internal swatch) */
		function syncLeading() {
			while (leadingSlot.firstChild) leadingSlot.removeChild(leadingSlot.firstChild);
			if (currentLeadingElement) leadingSlot.append(currentLeadingElement);
			else {
				var _currentPreviewColor;
				internalSwatch.style.backgroundColor = (_currentPreviewColor = currentPreviewColor) !== null && _currentPreviewColor !== void 0 ? _currentPreviewColor : "";
				leadingSlot.append(internalSwatch);
			}
		}
		/** Sync token name display */
		function syncText() {
			nameEl.textContent = currentTokenName;
		}
		/** Sync disabled state */
		function syncDisabled() {
			root.dataset.disabled = isDisabled ? "true" : "false";
			mainBtn.disabled = isDisabled;
			clearBtn.disabled = isDisabled;
			if (currentLeadingElement instanceof HTMLButtonElement) currentLeadingElement.disabled = isDisabled;
		}
		disposer.listen(mainBtn, "click", (e) => {
			e.preventDefault();
			if (isDisabled) return;
			onClick === null || onClick === void 0 || onClick();
		});
		disposer.listen(clearBtn, "click", (e) => {
			e.preventDefault();
			e.stopPropagation();
			if (isDisabled) return;
			onClear === null || onClear === void 0 || onClear();
		});
		disposer.listen(root, "keydown", (e) => {
			if (isDisabled) return;
			if (e.key === "Backspace" || e.key === "Delete") {
				const path = e.composedPath();
				if (path.includes(mainBtn) || path.includes(root)) {
					e.preventDefault();
					onClear === null || onClear === void 0 || onClear();
				}
			}
		});
		syncLeading();
		syncText();
		syncDisabled();
		return {
			root,
			setTokenName(name) {
				currentTokenName = String(name !== null && name !== void 0 ? name : "");
				syncText();
			},
			setPreviewColor(color) {
				currentPreviewColor = typeof color === "string" ? color : null;
				if (!currentLeadingElement) {
					var _currentPreviewColor2;
					internalSwatch.style.backgroundColor = (_currentPreviewColor2 = currentPreviewColor) !== null && _currentPreviewColor2 !== void 0 ? _currentPreviewColor2 : "";
				}
			},
			setLeadingElement(el) {
				currentLeadingElement = el !== null && el !== void 0 ? el : null;
				syncLeading();
				syncDisabled();
			},
			setDisabled(disabled) {
				isDisabled = Boolean(disabled);
				syncDisabled();
			},
			focus() {
				try {
					mainBtn.focus();
				} catch (_unused) {}
			},
			dispose() {
				disposer.dispose();
			}
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/color-field.ts
	/**
	* Color Field (Phase 5.3 - Token Support)
	*
	* A reusable color field component for the Web Editor property panel.
	*
	* Features:
	* - Swatch button opens the native system color picker
	* - Hidden <input type="color"> provides native UX
	* - Text input accepts hex/rgb/var(...) formats
	* - Token Pill mode: displays var(--token) as a pill with swatch preview
	* - Integrated Token Picker for selecting design tokens
	*
	* Mode switching:
	* - When value is a standalone var(--xxx), displays as Token Pill
	* - When value is a literal color or complex expression, displays as text input
	*/
	var DEFAULT_COLOR_HEX = "#000000";
	var TOKEN_BTN_ICON_SVG = `
  <svg class="we-token-btn-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M12 3a9 9 0 100 18h1a2 2 0 002-2v-1a2 2 0 012-2h1a3 3 0 003-3 10 10 0 00-9-10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="7.5" cy="10.5" r="1" fill="currentColor"/>
    <circle cx="10.5" cy="7.5" r="1" fill="currentColor"/>
    <circle cx="13.5" cy="10.5" r="1" fill="currentColor"/>
  </svg>
`;
	/**
	* Clamp a byte value to 0-255
	*/
	function clampByte$1(n) {
		if (!Number.isFinite(n)) return 0;
		return Math.max(0, Math.min(255, Math.round(n)));
	}
	/**
	* Convert a byte to 2-digit hex string
	*/
	function toHexByte$1(n) {
		return clampByte$1(n).toString(16).padStart(2, "0");
	}
	/**
	* Convert rgb(r, g, b) or rgba(r, g, b, a) string to #RRGGBB hex
	*/
	function rgbToHex(rgb) {
		const match = rgb.match(/rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)/i);
		if (!match) return null;
		const r = Number(match[1]);
		const g = Number(match[2]);
		const b = Number(match[3]);
		if (!Number.isFinite(r) || !Number.isFinite(g) || !Number.isFinite(b)) return null;
		return `#${toHexByte$1(r)}${toHexByte$1(g)}${toHexByte$1(b)}`;
	}
	/**
	* Normalize a hex color string to #RRGGBB format
	*/
	function normalizeHex(raw) {
		const v = raw.trim().toLowerCase();
		if (!v.startsWith("#")) return null;
		if (/^#[0-9a-f]{6}$/.test(v)) return v;
		if (/^#[0-9a-f]{3}$/.test(v)) {
			const r = v[1];
			const g = v[2];
			const b = v[3];
			return `#${r}${r}${g}${g}${b}${b}`;
		}
		if (/^#[0-9a-f]{8}$/.test(v)) return v.slice(0, 7);
		if (/^#[0-9a-f]{4}$/.test(v)) {
			const r = v[1];
			const g = v[2];
			const b = v[3];
			return `#${r}${r}${g}${g}${b}${b}`;
		}
		return null;
	}
	/**
	* Get active element from shadow DOM context
	*/
	function getActiveElement(root) {
		try {
			const rootNode = root.getRootNode();
			if (rootNode instanceof ShadowRoot) return rootNode.activeElement;
		} catch (_unused) {}
		return document.activeElement;
	}
	/**
	* Create a color field component with optional token support.
	*/
	function createColorField(options) {
		const { container, ariaLabel, onInput, onCommit, onCancel, tokensService, getTokenTarget, tokenPickerMaxVisible } = options;
		const disposer = new Disposer();
		let currentValue = "";
		let currentPlaceholder = "";
		let lastResolvedHex = DEFAULT_COLOR_HEX;
		let isTokenMode = false;
		let isDisabled = false;
		let tokenPill = null;
		let tokenBtn = null;
		let tokenPicker = null;
		const root = document.createElement("div");
		root.className = "we-color-field";
		root.style.position = "relative";
		const swatchBtn = document.createElement("button");
		swatchBtn.type = "button";
		swatchBtn.className = "we-color-swatch";
		swatchBtn.dataset.tooltip = "Pick color";
		swatchBtn.setAttribute("aria-label", `Pick ${ariaLabel}`);
		const nativeInput = document.createElement("input");
		nativeInput.type = "color";
		nativeInput.className = "we-color-native-input";
		nativeInput.value = lastResolvedHex;
		nativeInput.tabIndex = -1;
		const textInput = document.createElement("input");
		textInput.type = "text";
		textInput.className = "we-input we-color-text";
		textInput.autocomplete = "off";
		textInput.spellcheck = false;
		textInput.setAttribute("aria-label", ariaLabel);
		const probe = document.createElement("span");
		probe.style.cssText = "position:fixed;left:-9999px;top:0;width:1px;height:1px;pointer-events:none;opacity:0";
		probe.setAttribute("aria-hidden", "true");
		swatchBtn.append(nativeInput);
		if (tokensService) {
			tokenBtn = document.createElement("button");
			tokenBtn.type = "button";
			tokenBtn.className = "we-token-btn";
			tokenBtn.setAttribute("aria-label", "Select design token");
			tokenBtn.dataset.tooltip = "Select design token";
			tokenBtn.innerHTML = TOKEN_BTN_ICON_SVG;
		}
		root.append(swatchBtn, textInput);
		if (tokenBtn) root.append(tokenBtn);
		root.append(probe);
		container.append(root);
		disposer.add(() => root.remove());
		if (tokensService) {
			tokenPill = createTokenPill({
				container: root,
				ariaLabel: `${ariaLabel} token`,
				tokenName: "",
				disabled: false,
				onClick: () => toggleTokenPicker(),
				onClear: () => detachToken()
			});
			tokenPill.root.hidden = true;
			disposer.add(() => tokenPill === null || tokenPill === void 0 ? void 0 : tokenPill.dispose());
		}
		if (tokensService) {
			tokenPicker = createTokenPicker({
				container: root,
				tokensService,
				tokenKind: "color",
				maxVisible: tokenPickerMaxVisible,
				onSelect: handleTokenSelect
			});
			disposer.add(() => tokenPicker === null || tokenPicker === void 0 ? void 0 : tokenPicker.dispose());
			disposer.listen(document, "click", (e) => {
				if (!(tokenPicker === null || tokenPicker === void 0 ? void 0 : tokenPicker.isVisible())) return;
				const target = e.target;
				if (!root.contains(target)) tokenPicker.hide();
			});
		}
		/**
		* Get the display value for color resolution.
		* When value contains var(), use placeholder (computed value) for resolution.
		*/
		function getDisplayValue() {
			const value = currentValue.trim();
			const placeholder = currentPlaceholder.trim();
			if (value && /\bvar\s*\(/i.test(value) && placeholder) return placeholder;
			return value || placeholder;
		}
		/**
		* Resolve a color string to swatch display and hex for native picker
		*/
		function resolveDisplayColor(raw) {
			const trimmed = raw.trim();
			if (!trimmed) return {
				swatch: null,
				hex: null
			};
			const hex = normalizeHex(trimmed);
			if (hex) return {
				swatch: hex,
				hex
			};
			try {
				probe.style.backgroundColor = "";
				probe.style.backgroundColor = trimmed;
				if (!probe.style.backgroundColor) return {
					swatch: null,
					hex: null
				};
				const computed = getComputedStyle(probe).backgroundColor;
				const computedHex = rgbToHex(computed);
				return {
					swatch: computed || null,
					hex: computedHex
				};
			} catch (_unused2) {
				return {
					swatch: null,
					hex: null
				};
			}
		}
		/**
		* Update the swatch button color
		*/
		function updateSwatch() {
			const resolved = resolveDisplayColor(getDisplayValue());
			if (resolved.swatch) swatchBtn.style.backgroundColor = resolved.swatch;
			else swatchBtn.style.backgroundColor = "";
			if (resolved.hex) {
				lastResolvedHex = resolved.hex;
				nativeInput.value = resolved.hex;
			}
		}
		/**
		* Open the native color picker
		*/
		function openPicker() {
			if (nativeInput.disabled) return;
			const resolved = resolveDisplayColor(getDisplayValue());
			if (resolved.hex) lastResolvedHex = resolved.hex;
			nativeInput.value = lastResolvedHex;
			const showPicker = nativeInput.showPicker;
			if (typeof showPicker === "function") try {
				showPicker.call(nativeInput);
				return;
			} catch (_unused3) {}
			try {
				nativeInput.click();
			} catch (_unused4) {}
		}
		/**
		* Parse token name from current value using tokensService.parseCssVar
		*/
		function parseTokenName() {
			if (!tokensService) return null;
			const ref = tokensService.parseCssVar(currentValue.trim());
			return ref ? ref.name : null;
		}
		/**
		* Switch between token pill mode and text input mode
		*/
		function setTokenMode(next, tokenName) {
			if (!tokensService || !tokenPill) return;
			if (next === isTokenMode) {
				if (next && tokenName) tokenPill.setTokenName(tokenName);
				return;
			}
			isTokenMode = next;
			if (next) {
				var _ref;
				const name = (_ref = tokenName !== null && tokenName !== void 0 ? tokenName : parseTokenName()) !== null && _ref !== void 0 ? _ref : "";
				tokenPill.setTokenName(name);
				tokenPill.setLeadingElement(swatchBtn);
				tokenPill.root.hidden = false;
				textInput.hidden = true;
				if (tokenBtn) tokenBtn.hidden = true;
			} else {
				tokenPill.root.hidden = true;
				tokenPill.setLeadingElement(null);
				textInput.hidden = false;
				if (tokenBtn) tokenBtn.hidden = false;
				if (swatchBtn.parentElement !== root) root.insertBefore(swatchBtn, textInput);
				else if (swatchBtn.nextSibling !== textInput) root.insertBefore(swatchBtn, textInput);
			}
		}
		/**
		* Sync token UI based on current value
		*/
		function syncTokenUi() {
			if (!tokensService || !tokenPill) return;
			const name = parseTokenName();
			setTokenMode(Boolean(name), name !== null && name !== void 0 ? name : void 0);
		}
		/**
		* Toggle token picker visibility
		*/
		function toggleTokenPicker() {
			var _getTokenTarget;
			if (!tokenPicker || !tokensService) return;
			if (isDisabled) return;
			tokenPicker.setTarget((_getTokenTarget = getTokenTarget === null || getTokenTarget === void 0 ? void 0 : getTokenTarget()) !== null && _getTokenTarget !== void 0 ? _getTokenTarget : null);
			tokenPicker.toggle();
		}
		/**
		* Handle token selection from picker
		*/
		function handleTokenSelect(tokenName, cssValue) {
			currentPlaceholder = "";
			textInput.placeholder = "";
			currentValue = cssValue;
			textInput.value = currentValue;
			updateSwatch();
			onInput === null || onInput === void 0 || onInput(currentValue.trim());
			onCommit === null || onCommit === void 0 || onCommit();
			setTokenMode(true, tokenName);
		}
		/**
		* Detach token (clear to literal color)
		*/
		function detachToken() {
			if (!tokensService || !tokenPill) return;
			if (isDisabled) return;
			tokenPicker === null || tokenPicker === void 0 || tokenPicker.hide();
			const literal = lastResolvedHex || DEFAULT_COLOR_HEX;
			currentPlaceholder = "";
			textInput.placeholder = "";
			currentValue = literal;
			textInput.value = currentValue;
			updateSwatch();
			onInput === null || onInput === void 0 || onInput(currentValue);
			onCommit === null || onCommit === void 0 || onCommit();
			setTokenMode(false);
		}
		disposer.listen(swatchBtn, "keydown", (e) => {
			if (e.key === "Enter" || e.key === " ") {
				e.preventDefault();
				openPicker();
			}
		});
		disposer.listen(textInput, "input", () => {
			currentValue = textInput.value;
			updateSwatch();
			onInput === null || onInput === void 0 || onInput(currentValue.trim());
		});
		disposer.listen(textInput, "blur", () => {
			onCommit === null || onCommit === void 0 || onCommit();
			syncTokenUi();
		});
		disposer.listen(textInput, "keydown", (e) => {
			if (e.key === "Enter") {
				e.preventDefault();
				onCommit === null || onCommit === void 0 || onCommit();
				textInput.blur();
			} else if (e.key === "Escape") {
				e.preventDefault();
				onCancel === null || onCancel === void 0 || onCancel();
			}
		});
		disposer.listen(nativeInput, "input", () => {
			currentValue = nativeInput.value;
			textInput.value = currentValue;
			updateSwatch();
			onInput === null || onInput === void 0 || onInput(currentValue);
		});
		disposer.listen(nativeInput, "change", () => {
			onCommit === null || onCommit === void 0 || onCommit();
			syncTokenUi();
		});
		if (tokenBtn) disposer.listen(tokenBtn, "click", (e) => {
			e.preventDefault();
			e.stopPropagation();
			toggleTokenPicker();
		});
		updateSwatch();
		syncTokenUi();
		return {
			setValue(value) {
				currentValue = String(value !== null && value !== void 0 ? value : "");
				textInput.value = currentValue;
				updateSwatch();
				syncTokenUi();
			},
			setPlaceholder(value) {
				currentPlaceholder = String(value !== null && value !== void 0 ? value : "");
				textInput.placeholder = currentPlaceholder;
				updateSwatch();
			},
			setDisabled(disabled) {
				isDisabled = Boolean(disabled);
				swatchBtn.disabled = isDisabled;
				textInput.disabled = isDisabled;
				nativeInput.disabled = isDisabled;
				if (tokenBtn) tokenBtn.disabled = isDisabled;
				tokenPill === null || tokenPill === void 0 || tokenPill.setDisabled(isDisabled);
				if (isDisabled) tokenPicker === null || tokenPicker === void 0 || tokenPicker.hide();
			},
			isFocused() {
				const active = getActiveElement(root);
				return active instanceof HTMLElement ? root.contains(active) : false;
			},
			dispose() {
				disposer.dispose();
			}
		};
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.126.0/helpers/objectSpread2.js
	function ownKeys(e, r) {
		var t = Object.keys(e);
		if (Object.getOwnPropertySymbols) {
			var o = Object.getOwnPropertySymbols(e);
			r && (o = o.filter(function(r) {
				return Object.getOwnPropertyDescriptor(e, r).enumerable;
			})), t.push.apply(t, o);
		}
		return t;
	}
	function _objectSpread2(e) {
		for (var r = 1; r < arguments.length; r++) {
			var t = null != arguments[r] ? arguments[r] : {};
			r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
				_defineProperty(e, r, t[r]);
			}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
				Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
			});
		}
		return e;
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/gradient-control.ts
	/**
	* Gradient Control
	*
	* Edits inline `background-image` gradients:
	* - linear-gradient(<angle>deg, <stop1>, <stop2>, ...)
	* - radial-gradient([<shape>] [at <x>% <y>%], <stop1>, <stop2>, ...)
	*
	* Supports:
	* - Multiple color stops (2+)
	* - Numeric angles (deg) and percent positions
	*
	* Current UI Limitation:
	* - UI currently edits only the first 2 stops (parser supports N stops)
	*/
	var GRADIENT_TYPES = [
		{
			value: "none",
			label: "None"
		},
		{
			value: "linear",
			label: "Linear"
		},
		{
			value: "radial",
			label: "Radial"
		}
	];
	var RADIAL_SHAPES = [{
		value: "ellipse",
		label: "Ellipse"
	}, {
		value: "circle",
		label: "Circle"
	}];
	var DEFAULT_LINEAR_ANGLE = 180;
	var DEFAULT_POSITION = 50;
	var DEFAULT_STOP_1 = {
		color: "#000000",
		position: 0
	};
	var DEFAULT_STOP_2 = {
		color: "#ffffff",
		position: 100
	};
	var stopIdCounter = 0;
	/**
	* Generate a unique stop ID using crypto.randomUUID when available,
	* falling back to a counter-based ID.
	*/
	function createStopId() {
		try {
			if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
		} catch (_unused) {}
		stopIdCounter += 1;
		return `stop_${stopIdCounter}_${Date.now()}`;
	}
	/** Create default stop models with unique IDs */
	function createDefaultStopModels() {
		return [{
			id: createStopId(),
			color: DEFAULT_STOP_1.color,
			position: DEFAULT_STOP_1.position
		}, {
			id: createStopId(),
			color: DEFAULT_STOP_2.color,
			position: DEFAULT_STOP_2.position
		}];
	}
	/** Convert GradientStop[] to StopModel[] (assigns new IDs) */
	function toStopModels(stops) {
		return stops.map((s) => ({
			id: createStopId(),
			color: s.color,
			position: s.position,
			placeholderColor: s.placeholderColor
		}));
	}
	/**
	* Reconcile new stops with existing models to preserve stable IDs.
	* Uses index-based matching when stop count is the same, otherwise creates new models.
	*/
	function reconcileStopModels(prevModels, newStops) {
		if (prevModels.length === newStops.length) return newStops.map((stop, i) => {
			var _prevModels$i$id, _prevModels$i;
			return {
				id: (_prevModels$i$id = (_prevModels$i = prevModels[i]) === null || _prevModels$i === void 0 ? void 0 : _prevModels$i.id) !== null && _prevModels$i$id !== void 0 ? _prevModels$i$id : createStopId(),
				color: stop.color,
				position: stop.position,
				placeholderColor: stop.placeholderColor
			};
		});
		return toStopModels(newStops);
	}
	/** Get the preview color for a stop (resolved color if contains var(), otherwise raw color) */
	function getStopPreviewColor(stop) {
		if (needsColorPlaceholder(stop.color)) {
			var _stop$placeholderColo;
			const c = (_stop$placeholderColo = stop.placeholderColor) === null || _stop$placeholderColo === void 0 ? void 0 : _stop$placeholderColo.trim();
			return c ? c : "transparent";
		}
		return stop.color;
	}
	/** Clamp a value to byte range [0, 255] */
	function clampByte(value) {
		if (!Number.isFinite(value)) return 0;
		return Math.max(0, Math.min(255, Math.round(value)));
	}
	/** Convert a byte value to 2-digit hex string */
	function toHexByte(value) {
		return clampByte(value).toString(16).padStart(2, "0");
	}
	/** Convert RGBA to CSS color string (hex or rgba) */
	function rgbaToCss(color) {
		const a = clampNumber(color.a, 0, 1);
		if (a >= 1) return `#${toHexByte(color.r)}${toHexByte(color.g)}${toHexByte(color.b)}`;
		const alpha = Math.round(a * 1e3) / 1e3;
		return `rgba(${clampByte(color.r)}, ${clampByte(color.g)}, ${clampByte(color.b)}, ${alpha})`;
	}
	/** Parse hex color (#RGB, #RGBA, #RRGGBB, #RRGGBBAA) to RGBA */
	function parseHexColorToRgba(raw) {
		const v = raw.trim().toLowerCase();
		if (!v.startsWith("#")) return null;
		if (/^#[0-9a-f]{3}$/.test(v)) return {
			r: Number.parseInt(v[1] + v[1], 16),
			g: Number.parseInt(v[2] + v[2], 16),
			b: Number.parseInt(v[3] + v[3], 16),
			a: 1
		};
		if (/^#[0-9a-f]{4}$/.test(v)) return {
			r: Number.parseInt(v[1] + v[1], 16),
			g: Number.parseInt(v[2] + v[2], 16),
			b: Number.parseInt(v[3] + v[3], 16),
			a: Number.parseInt(v[4] + v[4], 16) / 255
		};
		if (/^#[0-9a-f]{6}$/.test(v)) return {
			r: Number.parseInt(v.slice(1, 3), 16),
			g: Number.parseInt(v.slice(3, 5), 16),
			b: Number.parseInt(v.slice(5, 7), 16),
			a: 1
		};
		if (/^#[0-9a-f]{8}$/.test(v)) return {
			r: Number.parseInt(v.slice(1, 3), 16),
			g: Number.parseInt(v.slice(3, 5), 16),
			b: Number.parseInt(v.slice(5, 7), 16),
			a: Number.parseInt(v.slice(7, 9), 16) / 255
		};
		return null;
	}
	/** Parse RGB channel value (number or percentage) */
	function parseRgbChannel(token) {
		const t = token.trim();
		if (!t) return null;
		if (t.endsWith("%")) {
			const n = Number(t.slice(0, -1));
			if (!Number.isFinite(n)) return null;
			return clampByte(n / 100 * 255);
		}
		const n = Number(t);
		if (!Number.isFinite(n)) return null;
		return clampByte(n);
	}
	/** Parse alpha channel value (number or percentage) */
	function parseAlphaChannel(token) {
		const t = token.trim();
		if (!t) return null;
		if (t.endsWith("%")) {
			const n = Number(t.slice(0, -1));
			if (!Number.isFinite(n)) return null;
			return clampNumber(n / 100, 0, 1);
		}
		const n = Number(t);
		if (!Number.isFinite(n)) return null;
		return clampNumber(n, 0, 1);
	}
	/** Parse rgb()/rgba() color to RGBA (supports legacy and modern syntax) */
	function parseRgbColorToRgba(raw) {
		const trimmed = raw.trim();
		if (!/^rgba?\(/i.test(trimmed)) return null;
		const openIndex = trimmed.indexOf("(");
		const closeIndex = trimmed.lastIndexOf(")");
		if (openIndex < 0 || closeIndex < openIndex) return null;
		const inner = trimmed.slice(openIndex + 1, closeIndex).trim();
		if (!inner) return null;
		let channelsPart = inner;
		let alphaPart = null;
		const slashIndex = inner.indexOf("/");
		if (slashIndex !== -1) {
			channelsPart = inner.slice(0, slashIndex).trim();
			alphaPart = inner.slice(slashIndex + 1).trim();
		}
		const channelTokens = channelsPart.includes(",") ? channelsPart.split(",").map((t) => t.trim()).filter(Boolean) : channelsPart.split(/\s+/).map((t) => t.trim()).filter(Boolean);
		if (channelTokens.length < 3) return null;
		const r = parseRgbChannel(channelTokens[0]);
		const g = parseRgbChannel(channelTokens[1]);
		const b = parseRgbChannel(channelTokens[2]);
		if (r === null || g === null || b === null) return null;
		let a = 1;
		if (!alphaPart && channelTokens.length >= 4) alphaPart = channelTokens[3];
		if (alphaPart) {
			const parsedA = parseAlphaChannel(alphaPart);
			if (parsedA !== null) a = parsedA;
		}
		return {
			r,
			g,
			b,
			a
		};
	}
	/** Linear interpolation between two numbers */
	function lerpNumber(a, b, t) {
		return a + (b - a) * t;
	}
	/** Interpolate between two RGBA colors */
	function interpolateRgba(a, b, t) {
		const clampedT = clampNumber(t, 0, 1);
		return {
			r: lerpNumber(a.r, b.r, clampedT),
			g: lerpNumber(a.g, b.g, clampedT),
			b: lerpNumber(a.b, b.b, clampedT),
			a: lerpNumber(a.a, b.a, clampedT)
		};
	}
	function isFieldFocused$4(el) {
		try {
			const rootNode = el.getRootNode();
			if (rootNode instanceof ShadowRoot) return rootNode.activeElement === el;
			return document.activeElement === el;
		} catch (_unused2) {
			return false;
		}
	}
	function readInlineValue$5(element, property) {
		try {
			var _style$getPropertyVal, _style$getPropertyVal2;
			const style = element.style;
			return (_style$getPropertyVal = style === null || style === void 0 || (_style$getPropertyVal2 = style.getPropertyValue) === null || _style$getPropertyVal2 === void 0 || (_style$getPropertyVal2 = _style$getPropertyVal2.call(style, property)) === null || _style$getPropertyVal2 === void 0 ? void 0 : _style$getPropertyVal2.trim()) !== null && _style$getPropertyVal !== void 0 ? _style$getPropertyVal : "";
		} catch (_unused3) {
			return "";
		}
	}
	function readComputedValue$4(element, property) {
		try {
			return window.getComputedStyle(element).getPropertyValue(property).trim();
		} catch (_unused4) {
			return "";
		}
	}
	function isNoneValue(value) {
		const trimmed = value.trim();
		return !trimmed || trimmed.toLowerCase() === "none";
	}
	function clampNumber(value, min, max) {
		if (!Number.isFinite(value)) return min;
		return Math.max(min, Math.min(max, value));
	}
	function parseNumber$1(raw) {
		const trimmed = raw.trim();
		if (!trimmed) return null;
		const n = Number(trimmed);
		return Number.isFinite(n) ? n : null;
	}
	function parseAngleToken(raw) {
		const trimmed = raw.trim();
		if (!trimmed) return null;
		const match = trimmed.match(/^(-?(?:\d+\.?\d*|\.\d+))\s*deg$/i);
		if (!match) return null;
		const n = Number(match[1]);
		return Number.isFinite(n) ? n : null;
	}
	function parsePercentToken(raw) {
		const trimmed = raw.trim();
		if (!trimmed) return null;
		const match = trimmed.match(/^(-?(?:\d+\.?\d*|\.\d+))\s*%$/);
		if (!match) return null;
		const n = Number(match[1]);
		return Number.isFinite(n) ? n : null;
	}
	/**
	* Parse X position keyword (left/center/right or %)
	*/
	function parsePositionX(raw) {
		const trimmed = raw.trim().toLowerCase();
		if (!trimmed) return null;
		const pct = parsePercentToken(trimmed);
		if (pct !== null) return pct;
		if (trimmed === "center") return 50;
		if (trimmed === "left") return 0;
		if (trimmed === "right") return 100;
		return null;
	}
	/**
	* Parse Y position keyword (top/center/bottom or %)
	*/
	function parsePositionY(raw) {
		const trimmed = raw.trim().toLowerCase();
		if (!trimmed) return null;
		const pct = parsePercentToken(trimmed);
		if (pct !== null) return pct;
		if (trimmed === "center") return 50;
		if (trimmed === "top") return 0;
		if (trimmed === "bottom") return 100;
		return null;
	}
	/**
	* Check if a token is an X-axis keyword
	*/
	function isXKeyword(raw) {
		const lower = raw.trim().toLowerCase();
		return lower === "left" || lower === "right";
	}
	/**
	* Check if a token is a Y-axis keyword
	*/
	function isYKeyword(raw) {
		const lower = raw.trim().toLowerCase();
		return lower === "top" || lower === "bottom";
	}
	function clampAngle(value) {
		return clampNumber(value, 0, 360);
	}
	function clampPercent(value) {
		return clampNumber(value, 0, 100);
	}
	/**
	* Split a CSS value by a separator, respecting parentheses and quotes
	*/
	function splitTopLevel$1(value, separator) {
		const results = [];
		let depth = 0;
		let quote = null;
		let escape = false;
		let start = 0;
		for (let i = 0; i < value.length; i++) {
			const ch = value[i];
			if (escape) {
				escape = false;
				continue;
			}
			if (ch === "\\") {
				escape = true;
				continue;
			}
			if (quote) {
				if (ch === quote) quote = null;
				continue;
			}
			if (ch === "\"" || ch === "'") {
				quote = ch;
				continue;
			}
			if (ch === "(") {
				depth++;
				continue;
			}
			if (ch === ")") {
				depth = Math.max(0, depth - 1);
				continue;
			}
			if (depth === 0 && ch === separator) {
				results.push(value.slice(start, i));
				start = i + 1;
			}
		}
		results.push(value.slice(start));
		return results;
	}
	/**
	* Tokenize a CSS value by whitespace, respecting parentheses and quotes
	*/
	function tokenizeTopLevel$1(value) {
		const tokens = [];
		let depth = 0;
		let quote = null;
		let escape = false;
		let buffer = "";
		const flush = () => {
			const t = buffer.trim();
			if (t) tokens.push(t);
			buffer = "";
		};
		for (let i = 0; i < value.length; i++) {
			const ch = value[i];
			if (escape) {
				buffer += ch;
				escape = false;
				continue;
			}
			if (ch === "\\") {
				buffer += ch;
				escape = true;
				continue;
			}
			if (quote) {
				buffer += ch;
				if (ch === quote) quote = null;
				continue;
			}
			if (ch === "\"" || ch === "'") {
				buffer += ch;
				quote = ch;
				continue;
			}
			if (ch === "(") {
				depth++;
				buffer += ch;
				continue;
			}
			if (ch === ")") {
				depth = Math.max(0, depth - 1);
				buffer += ch;
				continue;
			}
			if (depth === 0 && /\s/.test(ch)) {
				flush();
				continue;
			}
			buffer += ch;
		}
		flush();
		return tokens;
	}
	function parseColorStop(raw) {
		var _tokens$;
		const trimmed = raw.trim();
		if (!trimmed) return null;
		const tokens = tokenizeTopLevel$1(trimmed);
		if (tokens.length === 0) return null;
		const color = (_tokens$ = tokens[0]) !== null && _tokens$ !== void 0 ? _tokens$ : "";
		if (!color) return null;
		let position = null;
		for (let i = 1; i < tokens.length; i++) {
			var _tokens$i;
			const p = parsePercentToken((_tokens$i = tokens[i]) !== null && _tokens$i !== void 0 ? _tokens$i : "");
			if (p !== null) {
				position = p;
				break;
			}
		}
		return {
			color,
			position
		};
	}
	/**
	* Normalize stop positions following CSS gradient specification:
	* - First stop defaults to 0%, last stop defaults to 100%
	* - Enforces monotonically non-decreasing positions (CSS spec)
	* - Missing positions are distributed evenly between defined positions
	* - All positions are clamped to 0..100
	*
	* @param stops - Parsed stops with optional positions
	* @returns Normalized stops with all positions defined
	*/
	function normalizeStopPositions(stops) {
		var _positions$;
		if (stops.length === 0) return [];
		if (stops.length === 1) {
			var _stops$0$position;
			return [{
				color: stops[0].color.trim() || DEFAULT_STOP_1.color,
				position: clampPercent((_stops$0$position = stops[0].position) !== null && _stops$0$position !== void 0 ? _stops$0$position : 0)
			}];
		}
		const colors = stops.map((s) => s.color.trim() || DEFAULT_STOP_1.color);
		const positions = stops.map((s) => s.position === null ? null : clampPercent(s.position));
		if (positions[0] === null) positions[0] = 0;
		const lastIndex = positions.length - 1;
		if (positions[lastIndex] === null) positions[lastIndex] = 100;
		let maxSoFar = (_positions$ = positions[0]) !== null && _positions$ !== void 0 ? _positions$ : 0;
		for (let i = 1; i < positions.length; i++) {
			const pos = positions[i];
			if (pos !== null) if (pos < maxSoFar) positions[i] = maxSoFar;
			else maxSoFar = pos;
		}
		let runStart = null;
		for (let i = 0; i < positions.length; i++) if (positions[i] === null) {
			if (runStart === null) runStart = i;
		} else if (runStart !== null) {
			var _positions, _positions$i;
			const prevPos = (_positions = positions[runStart - 1]) !== null && _positions !== void 0 ? _positions : 0;
			const nextPos = (_positions$i = positions[i]) !== null && _positions$i !== void 0 ? _positions$i : 100;
			const runLength = i - runStart + 1;
			for (let j = runStart; j < i; j++) {
				const t = (j - runStart + 1) / runLength;
				positions[j] = prevPos + (nextPos - prevPos) * t;
			}
			runStart = null;
		}
		return stops.map((_, i) => {
			var _positions$i2;
			return {
				color: colors[i],
				position: clampPercent((_positions$i2 = positions[i]) !== null && _positions$i2 !== void 0 ? _positions$i2 : 0)
			};
		});
	}
	function parseGradientFunctionCall(value) {
		const trimmed = value.trim();
		const lower = trimmed.toLowerCase();
		let kind = null;
		let fnName = "";
		if (lower.startsWith("linear-gradient")) {
			kind = "linear";
			fnName = "linear-gradient";
		} else if (lower.startsWith("radial-gradient")) {
			kind = "radial";
			fnName = "radial-gradient";
		} else return null;
		let i = fnName.length;
		while (i < trimmed.length && /\s/.test(trimmed[i])) i++;
		if (trimmed[i] !== "(") return null;
		const openIndex = i;
		let depth = 0;
		let quote = null;
		let escape = false;
		for (let j = openIndex; j < trimmed.length; j++) {
			const ch = trimmed[j];
			if (escape) {
				escape = false;
				continue;
			}
			if (ch === "\\") {
				escape = true;
				continue;
			}
			if (quote) {
				if (ch === quote) quote = null;
				continue;
			}
			if (ch === "\"" || ch === "'") {
				quote = ch;
				continue;
			}
			if (ch === "(") {
				depth++;
				continue;
			}
			if (ch === ")") {
				depth--;
				if (depth === 0) {
					if (trimmed.slice(j + 1).trim()) return null;
					const args = trimmed.slice(openIndex + 1, j);
					return {
						kind,
						args
					};
				}
			}
		}
		return null;
	}
	function parseLinearGradient(args) {
		var _parts$;
		const parts = splitTopLevel$1(args, ",").map((s) => s.trim()).filter(Boolean);
		if (parts.length < 2) return null;
		const firstPart = (_parts$ = parts[0]) !== null && _parts$ !== void 0 ? _parts$ : "";
		if (firstPart.toLowerCase().startsWith("to ")) return null;
		const maybeAngle = parseAngleToken(firstPart);
		let angle = DEFAULT_LINEAR_ANGLE;
		let stopStartIndex = 0;
		if (maybeAngle !== null) {
			if (parts.length < 3) return null;
			angle = maybeAngle;
			stopStartIndex = 1;
		}
		const stopParts = parts.slice(stopStartIndex);
		const parsedStops = [];
		for (const raw of stopParts) {
			const stop = parseColorStop(raw);
			if (!stop) return null;
			parsedStops.push(stop);
		}
		if (parsedStops.length < 2) return null;
		return {
			type: "linear",
			angle: clampAngle(angle),
			stops: normalizeStopPositions(parsedStops)
		};
	}
	/** Size keywords we don't support - return null to show as "none" */
	var UNSUPPORTED_RADIAL_SIZE_KEYWORDS = new Set([
		"closest-side",
		"farthest-side",
		"closest-corner",
		"farthest-corner"
	]);
	function parseRadialGradient(args) {
		var _parts$2;
		const parts = splitTopLevel$1(args, ",").map((s) => s.trim()).filter(Boolean);
		if (parts.length < 2) return null;
		let shape = "ellipse";
		let position = null;
		let stopStartIndex = 0;
		const tokens = tokenizeTopLevel$1((_parts$2 = parts[0]) !== null && _parts$2 !== void 0 ? _parts$2 : "");
		const lowerTokens = tokens.map((t) => t.toLowerCase());
		for (const token of lowerTokens) if (UNSUPPORTED_RADIAL_SIZE_KEYWORDS.has(token)) return null;
		const atIndex = lowerTokens.indexOf("at");
		const hasAt = atIndex >= 0;
		const hasCircle = lowerTokens.includes("circle");
		const hasEllipse = lowerTokens.includes("ellipse");
		if (hasCircle || hasEllipse || hasAt) {
			stopStartIndex = 1;
			if (hasCircle) shape = "circle";
			else if (hasEllipse) shape = "ellipse";
			if (hasAt) {
				var _tokens, _tokens2, _x, _y;
				const token1 = (_tokens = tokens[atIndex + 1]) !== null && _tokens !== void 0 ? _tokens : "";
				const token2 = (_tokens2 = tokens[atIndex + 2]) !== null && _tokens2 !== void 0 ? _tokens2 : "";
				let x = null;
				let y = null;
				if (isYKeyword(token1)) {
					y = parsePositionY(token1);
					x = token2 ? parsePositionX(token2) : null;
				} else if (isXKeyword(token1)) {
					x = parsePositionX(token1);
					y = token2 ? parsePositionY(token2) : null;
				} else {
					x = parsePositionX(token1);
					y = token2 ? parsePositionY(token2) : null;
				}
				position = {
					x: clampPercent((_x = x) !== null && _x !== void 0 ? _x : DEFAULT_POSITION),
					y: clampPercent((_y = y) !== null && _y !== void 0 ? _y : DEFAULT_POSITION)
				};
			}
		}
		const stopParts = parts.slice(stopStartIndex);
		const parsedStops = [];
		for (const raw of stopParts) {
			const stop = parseColorStop(raw);
			if (!stop) return null;
			parsedStops.push(stop);
		}
		if (parsedStops.length < 2) return null;
		return {
			type: "radial",
			shape,
			position,
			stops: normalizeStopPositions(parsedStops)
		};
	}
	function parseGradient(value) {
		const fn = parseGradientFunctionCall(value);
		if (!fn) return null;
		return fn.kind === "linear" ? parseLinearGradient(fn.args) : parseRadialGradient(fn.args);
	}
	function needsColorPlaceholder(value) {
		return /\bvar\s*\(/i.test(value);
	}
	/**
	* Build placeholder color mapping from inline stops to computed stops.
	* Uses nearest-neighbor matching by stop position (0..100).
	* This handles cases where normalization may produce slightly different positions.
	*
	* @param inlineStops - Stops parsed from inline CSS (may contain var())
	* @param computedStops - Stops parsed from computed CSS (resolved colors)
	* @returns Array of placeholder colors aligned to inlineStops indices
	*/
	function buildPlaceholderMapping(inlineStops, computedStops) {
		if (inlineStops.length === 0 || computedStops.length === 0) return [];
		return inlineStops.map((inlineStop) => {
			let nearestStop = computedStops[0];
			let minDistance = Math.abs(nearestStop.position - inlineStop.position);
			for (let i = 1; i < computedStops.length; i++) {
				const candidate = computedStops[i];
				const distance = Math.abs(candidate.position - inlineStop.position);
				if (distance < minDistance) {
					nearestStop = candidate;
					minDistance = distance;
				}
			}
			return nearestStop.color;
		});
	}
	function createGradientControl(options) {
		var _currentStops$0$id, _currentStops$;
		const { container, transactionManager, tokensService, property: cssProperty = "background-image", allowNone = true } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		let currentType = allowNone ? "none" : "linear";
		let currentStops = createDefaultStopModels();
		let selectedStopId = (_currentStops$0$id = (_currentStops$ = currentStops[0]) === null || _currentStops$ === void 0 ? void 0 : _currentStops$.id) !== null && _currentStops$0$id !== void 0 ? _currentStops$0$id : null;
		let thumbDrag = null;
		let thumbKeyboard = null;
		let backgroundHandle = null;
		const root = document.createElement("div");
		root.className = "we-field-group";
		function createInputRow(labelText, ariaLabel) {
			const row = document.createElement("div");
			row.className = "we-field";
			const label = document.createElement("span");
			label.className = "we-field-label";
			label.textContent = labelText;
			const input = document.createElement("input");
			input.type = "text";
			input.className = "we-input";
			input.autocomplete = "off";
			input.spellcheck = false;
			input.inputMode = "decimal";
			input.setAttribute("aria-label", ariaLabel);
			row.append(label, input);
			return {
				row,
				input
			};
		}
		function createSelectRow(labelText, ariaLabel, values) {
			const row = document.createElement("div");
			row.className = "we-field";
			const label = document.createElement("span");
			label.className = "we-field-label";
			label.textContent = labelText;
			const select = document.createElement("select");
			select.className = "we-select";
			select.setAttribute("aria-label", ariaLabel);
			for (const v of values) {
				const opt = document.createElement("option");
				opt.value = v.value;
				opt.textContent = v.label;
				select.append(opt);
			}
			row.append(label, select);
			return {
				row,
				select
			};
		}
		const { row: typeRow, select: typeSelect } = createSelectRow("Type", "Gradient Type", allowNone ? GRADIENT_TYPES : GRADIENT_TYPES.filter((t) => t.value !== "none"));
		const gradientBarRow = document.createElement("div");
		gradientBarRow.className = "we-gradient-bar-row";
		const gradientBar = document.createElement("div");
		gradientBar.className = "we-gradient-bar";
		gradientBar.setAttribute("aria-label", "Gradient preview");
		const gradientThumbs = document.createElement("div");
		gradientThumbs.className = "we-gradient-bar-thumbs";
		gradientBar.append(gradientThumbs);
		gradientBarRow.append(gradientBar);
		const { row: angleRow, input: angleInput } = createInputRow("Angle", "Gradient Angle (deg)");
		angleInput.placeholder = String(DEFAULT_LINEAR_ANGLE);
		const { row: shapeRow, select: shapeSelect } = createSelectRow("Shape", "Radial Gradient Shape", RADIAL_SHAPES);
		const { row: posXRow, input: posXInput } = createInputRow("Position X", "Radial Position X (%)");
		const { row: posYRow, input: posYInput } = createInputRow("Position Y", "Radial Position Y (%)");
		const stopsHeaderRow = document.createElement("div");
		stopsHeaderRow.className = "we-gradient-stops-header";
		const stopsHeaderLabel = document.createElement("span");
		stopsHeaderLabel.className = "we-gradient-stops-title";
		stopsHeaderLabel.textContent = "Stops";
		const stopsAddBtn = document.createElement("button");
		stopsAddBtn.type = "button";
		stopsAddBtn.className = "we-icon-btn we-gradient-stops-add";
		stopsAddBtn.setAttribute("aria-label", "Add stop");
		stopsAddBtn.disabled = false;
		stopsAddBtn.textContent = "+";
		stopsHeaderRow.append(stopsHeaderLabel, stopsAddBtn);
		const stopsList = document.createElement("div");
		stopsList.className = "we-gradient-stops-list";
		stopsList.setAttribute("role", "list");
		root.append(typeRow, gradientBarRow, angleRow, shapeRow, posXRow, posYRow, stopsHeaderRow, stopsList);
		container.append(root);
		disposer.add(() => root.remove());
		wireNumberStepping(disposer, angleInput, {
			mode: "number",
			min: 0,
			max: 360,
			step: 1,
			shiftStep: 15,
			altStep: .1
		});
		wireNumberStepping(disposer, posXInput, {
			mode: "number",
			min: 0,
			max: 100,
			step: 1,
			shiftStep: 10,
			altStep: .1
		});
		wireNumberStepping(disposer, posYInput, {
			mode: "number",
			min: 0,
			max: 100,
			step: 1,
			shiftStep: 10,
			altStep: .1
		});
		const selectedStopPosHost = document.createElement("div");
		const selectedStopPosInput = document.createElement("input");
		selectedStopPosInput.type = "text";
		selectedStopPosInput.className = "we-gradient-stop-pos-input";
		selectedStopPosInput.autocomplete = "off";
		selectedStopPosInput.spellcheck = false;
		selectedStopPosInput.inputMode = "decimal";
		selectedStopPosInput.placeholder = "0";
		selectedStopPosInput.setAttribute("aria-label", "Selected Stop Position (%)");
		selectedStopPosHost.append(selectedStopPosInput);
		wireNumberStepping(disposer, selectedStopPosInput, {
			mode: "number",
			min: 0,
			max: 100,
			step: 1,
			shiftStep: 10
		});
		/**
		* Commit the position edit: sort stops and finalize the transaction.
		* Called on blur or Enter key.
		*/
		function commitSelectedStopPosition() {
			sortCurrentStopsByPosition();
			if (backgroundHandle) {
				previewGradient();
				commitTransaction();
			}
			syncAllFields();
		}
		/**
		* Cancel the position edit and rollback to the original value.
		* Called on Escape key.
		*/
		function cancelSelectedStopPosition() {
			rollbackTransaction();
			syncAllFields(true);
		}
		disposer.listen(selectedStopPosInput, "input", () => {
			const id = selectedStopId;
			if (!id) return;
			const parsed = parseNumber$1(selectedStopPosInput.value);
			if (parsed === null) return;
			setStopPositionById(id, parsed);
			previewGradient();
		});
		disposer.listen(selectedStopPosInput, "blur", commitSelectedStopPosition);
		disposer.listen(selectedStopPosInput, "keydown", (event) => {
			if (event.key === "Enter") {
				event.preventDefault();
				commitSelectedStopPosition();
				selectedStopPosInput.blur();
			} else if (event.key === "Escape") {
				event.preventDefault();
				cancelSelectedStopPosition();
			}
		});
		const selectedStopColorHost = document.createElement("div");
		const selectedStopColorField = createColorField({
			container: selectedStopColorHost,
			ariaLabel: "Selected Stop Color",
			tokensService,
			getTokenTarget: () => currentTarget,
			onInput: (value) => {
				var _currentStops$index$p;
				const id = selectedStopId;
				if (!id) return;
				const index = currentStops.findIndex((s) => s.id === id);
				if (index < 0) return;
				currentStops[index].color = value;
				selectedStopColorField.setPlaceholder(needsColorPlaceholder(value) ? (_currentStops$index$p = currentStops[index].placeholderColor) !== null && _currentStops$index$p !== void 0 ? _currentStops$index$p : "" : "");
				previewGradient();
			},
			onCommit: () => {
				commitTransaction();
				syncAllFields();
			},
			onCancel: () => {
				rollbackTransaction();
				syncAllFields(true);
			}
		});
		disposer.add(() => selectedStopColorField.dispose());
		function beginTransaction() {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			if (backgroundHandle) return backgroundHandle;
			backgroundHandle = transactionManager.beginStyle(target, cssProperty);
			return backgroundHandle;
		}
		function commitTransaction() {
			const handle = backgroundHandle;
			backgroundHandle = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackTransaction() {
			const handle = backgroundHandle;
			backgroundHandle = null;
			if (handle) handle.rollback();
		}
		/**
		* Update a stop's position by its ID.
		* Used during drag to update the model in real-time.
		*/
		function setStopPositionById(stopId, position) {
			const index = currentStops.findIndex((s) => s.id === stopId);
			if (index < 0) return;
			const clamped = clampPercent(position);
			currentStops[index].position = clamped;
		}
		/**
		* Restore all stop positions from a snapshot map.
		* Used when canceling a drag operation (Escape key).
		*/
		function restoreStopPositions(snapshot) {
			for (const stop of currentStops) {
				const savedPos = snapshot.get(stop.id);
				if (savedPos !== void 0) stop.position = savedPos;
			}
		}
		/**
		* End the current thumb drag session and clean up.
		* Commits or rolls back the transaction based on the outcome.
		*
		* @param commit - If true, commit changes; if false, rollback to initial state
		*/
		function endThumbDrag(commit) {
			const session = thumbDrag;
			if (!session) return;
			thumbDrag = null;
			gradientBar.classList.remove("we-gradient-bar--dragging");
			session.thumbElement.classList.remove("we-gradient-thumb--dragging");
			try {
				session.thumbElement.releasePointerCapture(session.pointerId);
			} catch (_unused5) {}
			if (commit) {
				sortCurrentStopsByPosition();
				previewGradient();
				commitTransaction();
				syncAllFields();
			} else {
				restoreStopPositions(session.initialPositions);
				rollbackTransaction();
				syncAllFields(true);
			}
		}
		/**
		* Calculate the position percentage from a pointer event relative to the gradient bar.
		* Returns a value clamped to 0-100.
		*/
		function calculatePositionFromPointer(clientX) {
			const rect = gradientBar.getBoundingClientRect();
			if (rect.width <= 0) return 0;
			return clampPercent((clientX - rect.left) / rect.width * 100);
		}
		/**
		* Start a keyboard stepping session for a thumb.
		* Similar to drag session but triggered by arrow keys.
		*/
		function startThumbKeyboardSession(stopId, thumbElement) {
			if (thumbDrag) return;
			if (currentType === "none") return;
			if (typeSelect.disabled) return;
			if ((thumbKeyboard === null || thumbKeyboard === void 0 ? void 0 : thumbKeyboard.stopId) === stopId) return;
			if (thumbKeyboard) endThumbKeyboard(true);
			const initialPositions = /* @__PURE__ */ new Map();
			for (const stop of currentStops) initialPositions.set(stop.id, stop.position);
			thumbKeyboard = {
				stopId,
				initialPositions,
				thumbElement
			};
			beginTransaction();
		}
		/**
		* End the keyboard stepping session.
		* @param commit - If true, commit changes; if false, rollback to initial state
		*/
		function endThumbKeyboard(commit) {
			const session = thumbKeyboard;
			if (!session) return;
			thumbKeyboard = null;
			if (commit) {
				sortCurrentStopsByPosition();
				previewGradient();
				commitTransaction();
				syncAllFields();
			} else {
				restoreStopPositions(session.initialPositions);
				rollbackTransaction();
				syncAllFields(true);
			}
		}
		/**
		* Handle focus on a thumb - select the corresponding stop.
		*/
		function handleThumbFocus(event) {
			if (thumbDrag) return;
			if (currentType === "none") return;
			if (typeSelect.disabled) return;
			const stopId = event.currentTarget.dataset.stopId;
			if (!stopId) return;
			if (selectedStopId !== stopId) {
				selectedStopId = stopId;
				updateGradientBar({ preserveThumbs: true });
			}
		}
		/**
		* Handle blur on a thumb - commit any active keyboard session.
		*/
		function handleThumbBlur(event) {
			const session = thumbKeyboard;
			if (!session) return;
			if (event.currentTarget !== session.thumbElement) return;
			endThumbKeyboard(true);
		}
		/**
		* Handle keydown on a thumb - arrow keys for stepping, Escape for cancel.
		*/
		function handleThumbKeyDown(event) {
			if (event.metaKey || event.ctrlKey) return;
			if (thumbDrag) return;
			if (currentType === "none") return;
			if (typeSelect.disabled) return;
			const thumb = event.currentTarget;
			const stopId = thumb.dataset.stopId;
			if (!stopId) return;
			if (event.key === "Escape") {
				const session = thumbKeyboard;
				if (!session || session.stopId !== stopId) return;
				event.preventDefault();
				event.stopPropagation();
				endThumbKeyboard(false);
				return;
			}
			if (!(event.key === "ArrowLeft" || event.key === "ArrowRight" || event.key === "ArrowUp" || event.key === "ArrowDown")) return;
			event.preventDefault();
			event.stopPropagation();
			const delta = (event.key === "ArrowLeft" || event.key === "ArrowDown" ? -1 : 1) * (event.shiftKey ? 10 : 1);
			selectedStopId = stopId;
			startThumbKeyboardSession(stopId, thumb);
			const idx = currentStops.findIndex((s) => s.id === stopId);
			if (idx < 0) return;
			setStopPositionById(stopId, currentStops[idx].position + delta);
			previewGradient();
		}
		/**
		* Sync slider ARIA attributes on a thumb element.
		* Provides accessible name and value for screen readers.
		*/
		function syncThumbSliderAria(thumb, position) {
			const clamped = clampPercent(position);
			const rounded = Math.round(clamped * 100) / 100;
			const value = Object.is(rounded, -0) ? 0 : rounded;
			thumb.setAttribute("role", "slider");
			thumb.setAttribute("aria-label", "Gradient stop position");
			thumb.setAttribute("aria-valuemin", "0");
			thumb.setAttribute("aria-valuemax", "100");
			thumb.setAttribute("aria-valuenow", String(value));
			thumb.setAttribute("aria-valuetext", `${value}%`);
			thumb.setAttribute("aria-orientation", "horizontal");
		}
		const stopColorProbe = document.createElement("div");
		stopColorProbe.style.cssText = "position:fixed;left:-9999px;top:0;width:1px;height:1px;pointer-events:none;opacity:0";
		root.append(stopColorProbe);
		disposer.add(() => stopColorProbe.remove());
		/**
		* Resolve any CSS color string to RGBA using browser color parsing.
		* Handles hex, rgb(), rgba(), named colors, currentColor, etc.
		*/
		function resolveCssColorToRgba(raw) {
			const trimmed = raw.trim();
			if (!trimmed) return null;
			if (trimmed.toLowerCase() === "transparent") return {
				r: 0,
				g: 0,
				b: 0,
				a: 0
			};
			const fromHex = parseHexColorToRgba(trimmed);
			if (fromHex) return fromHex;
			const fromRgb = parseRgbColorToRgba(trimmed);
			if (fromRgb) return fromRgb;
			try {
				stopColorProbe.style.color = "";
				stopColorProbe.style.color = trimmed;
				if (!stopColorProbe.style.color) return null;
				const computed = getComputedStyle(stopColorProbe).color;
				return parseRgbColorToRgba(computed);
			} catch (_unused6) {
				return null;
			}
		}
		/**
		* Keep stop order monotonic by position for correct CSS output.
		* CSS gradients do not reorder stops; out-of-order positions get clamped.
		* Tie-breaks by original insertion order (array index) for stability.
		*/
		function sortCurrentStopsByPosition() {
			if (currentStops.length <= 1) return;
			const indexed = currentStops.map((stop, index) => ({
				stop,
				index
			}));
			indexed.sort((a, b) => a.stop.position - b.stop.position || a.index - b.index);
			currentStops = indexed.map((entry) => entry.stop);
		}
		/**
		* Interpolate a new stop's color based on its position.
		* Finds the left and right bounding stops and linearly interpolates.
		*/
		function interpolateNewStopColor(position) {
			const clamped = clampPercent(position);
			const models = currentStops.length >= 2 ? currentStops : createDefaultStopModels();
			if (models.length === 0) return DEFAULT_STOP_1.color;
			const sorted = models.slice().sort((a, b) => a.position - b.position);
			let left = sorted[0];
			let right = sorted[sorted.length - 1];
			for (const stop of sorted) {
				if (stop.position <= clamped) left = stop;
				if (stop.position >= clamped) {
					right = stop;
					break;
				}
			}
			const leftRgba = resolveCssColorToRgba(getStopPreviewColor(left));
			const rightRgba = resolveCssColorToRgba(getStopPreviewColor(right));
			if (!leftRgba && !rightRgba) return left.color.trim() || DEFAULT_STOP_1.color;
			if (!leftRgba) return rgbaToCss(rightRgba);
			if (!rightRgba) return rgbaToCss(leftRgba);
			const span = right.position - left.position;
			if (!Number.isFinite(span) || span <= 0) return rgbaToCss(leftRgba);
			return rgbaToCss(interpolateRgba(leftRgba, rightRgba, clampNumber((clamped - left.position) / span, 0, 1)));
		}
		/**
		* Get a suggested position for adding a new stop.
		* Returns the midpoint between the selected stop and its next neighbor.
		*/
		function getSuggestedAddStopPosition() {
			const selectedId = selectedStopId;
			if (!selectedId) return DEFAULT_POSITION;
			const sorted = (currentStops.length >= 2 ? currentStops : createDefaultStopModels()).slice().sort((a, b) => a.position - b.position);
			const index = sorted.findIndex((s) => s.id === selectedId);
			if (index < 0) return DEFAULT_POSITION;
			const current = sorted[index];
			const next = sorted[index + 1];
			const prev = sorted[index - 1];
			if (next) return clampPercent((current.position + next.position) / 2);
			if (prev) return clampPercent((prev.position + current.position) / 2);
			return DEFAULT_POSITION;
		}
		/**
		* Find the stop ID closest to a given position.
		* Used to select a neighbor after deletion.
		* Tie-breaks toward the right (higher position).
		*/
		function pickClosestStopId(position) {
			if (currentStops.length === 0) return null;
			let best = currentStops[0];
			let bestDistance = Math.abs(best.position - position);
			for (let i = 1; i < currentStops.length; i++) {
				const candidate = currentStops[i];
				const distance = Math.abs(candidate.position - position);
				if (distance < bestDistance) {
					best = candidate;
					bestDistance = distance;
					continue;
				}
				if (distance === bestDistance) {
					const candidateOnRight = candidate.position >= position;
					const bestOnRight = best.position >= position;
					if (candidateOnRight && !bestOnRight) best = candidate;
				}
			}
			return best.id;
		}
		/**
		* Add a new stop at the specified position with interpolated color.
		* Auto-selects the new stop after adding.
		*/
		function addStopAtPosition(position, opts = {}) {
			if (currentType === "none") return;
			if (typeSelect.disabled) return;
			const clamped = clampPercent(position);
			const newStop = {
				id: createStopId(),
				position: clamped,
				color: interpolateNewStopColor(clamped)
			};
			currentStops.push(newStop);
			selectedStopId = newStop.id;
			sortCurrentStopsByPosition();
			previewGradient();
			commitTransaction();
			if (opts.focusColor) queueMicrotask(() => {
				const input = selectedStopColorHost.querySelector("input.we-color-text");
				input === null || input === void 0 || input.focus();
			});
		}
		/**
		* Remove a stop by its ID.
		* Enforces minimum 2 stops constraint.
		* Auto-selects the closest neighbor after deletion.
		*/
		function removeStopById(stopId) {
			if (currentType === "none") return;
			if (typeSelect.disabled) return;
			if (currentStops.length <= 2) return;
			const index = currentStops.findIndex((s) => s.id === stopId);
			if (index < 0) return;
			const removed = currentStops[index];
			currentStops.splice(index, 1);
			if (selectedStopId === stopId) {
				selectedStopId = pickClosestStopId(removed.position);
				if (!selectedStopId) {
					var _currentStops$0$id2, _currentStops$2;
					selectedStopId = (_currentStops$0$id2 = (_currentStops$2 = currentStops[0]) === null || _currentStops$2 === void 0 ? void 0 : _currentStops$2.id) !== null && _currentStops$0$id2 !== void 0 ? _currentStops$0$id2 : null;
				}
			}
			sortCurrentStopsByPosition();
			previewGradient();
			commitTransaction();
		}
		/**
		* Check if an event target is a text input-like element.
		* Used to avoid capturing Delete/Backspace when user is editing text.
		*/
		function isTextInputLike(target) {
			return target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLElement && target.isContentEditable;
		}
		/**
		* Update the gradient preview bar background and thumb elements.
		* Uses buildPreviewBarCss() to render a horizontal (90deg) gradient.
		* Reads from current UI state (inputs) to ensure real-time sync during editing.
		*
		* @param options.refreshStopsList - Set to false to skip stops list refresh (avoid re-mounting color field during editing)
		* @param options.preserveThumbs - Set to true to only update thumb positions without recreating elements (used during drag)
		*/
		function updateGradientBar(options = {}) {
			var _options$refreshStops, _options$preserveThum;
			const refreshStopsList = (_options$refreshStops = options.refreshStopsList) !== null && _options$refreshStops !== void 0 ? _options$refreshStops : true;
			const preserveThumbs = (_options$preserveThum = options.preserveThumbs) !== null && _options$preserveThum !== void 0 ? _options$preserveThum : false;
			if (currentType === "none") {
				gradientBar.style.backgroundImage = "none";
				gradientThumbs.textContent = "";
				if (refreshStopsList) updateStopsList([], [], []);
				return;
			}
			const stops = collectCurrentStops();
			if (stops.length === 0) {
				gradientBar.style.backgroundImage = "none";
				gradientThumbs.textContent = "";
				if (refreshStopsList) updateStopsList([], [], []);
				return;
			}
			const previewStops = stops.map((stop, i) => {
				var _model$placeholderCol;
				const model = currentStops[i];
				return {
					color: needsColorPlaceholder(stop.color) ? (model === null || model === void 0 || (_model$placeholderCol = model.placeholderColor) === null || _model$placeholderCol === void 0 ? void 0 : _model$placeholderCol.trim()) || "transparent" : stop.color,
					position: stop.position
				};
			});
			gradientBar.style.backgroundImage = buildPreviewBarCss(previewStops);
			const models = currentStops.length >= 2 ? currentStops : createDefaultStopModels();
			if (!selectedStopId || !models.some((s) => s.id === selectedStopId)) {
				var _models$0$id, _models$;
				selectedStopId = (_models$0$id = (_models$ = models[0]) === null || _models$ === void 0 ? void 0 : _models$.id) !== null && _models$0$id !== void 0 ? _models$0$id : null;
			}
			if (preserveThumbs) {
				const existingThumbs = gradientThumbs.querySelectorAll(".we-gradient-thumb");
				for (const thumb of existingThumbs) {
					const stopId = thumb.dataset.stopId;
					if (!stopId) continue;
					const modelIndex = models.findIndex((m) => m.id === stopId);
					if (modelIndex < 0) continue;
					const stop = stops[modelIndex];
					const preview = previewStops[modelIndex];
					if (!stop || !preview) continue;
					thumb.style.left = `${clampPercent(stop.position)}%`;
					thumb.style.backgroundColor = preview.color;
					syncThumbSliderAria(thumb, stop.position);
					const isActive = stopId === selectedStopId;
					thumb.classList.toggle("we-gradient-thumb--active", isActive);
				}
			} else {
				gradientThumbs.textContent = "";
				for (let i = 0; i < stops.length; i++) {
					const model = models[i];
					const stop = stops[i];
					const preview = previewStops[i];
					if (!model || !stop || !preview) continue;
					const thumb = document.createElement("button");
					thumb.type = "button";
					thumb.className = model.id === selectedStopId ? "we-gradient-thumb we-gradient-thumb--active" : "we-gradient-thumb";
					thumb.dataset.stopId = model.id;
					thumb.style.left = `${clampPercent(stop.position)}%`;
					thumb.style.backgroundColor = preview.color;
					syncThumbSliderAria(thumb, stop.position);
					thumb.addEventListener("pointerdown", handleThumbPointerDown);
					thumb.addEventListener("keydown", handleThumbKeyDown);
					thumb.addEventListener("focus", handleThumbFocus);
					thumb.addEventListener("blur", handleThumbBlur);
					gradientThumbs.append(thumb);
				}
			}
			if (refreshStopsList && !preserveThumbs) updateStopsList(models, stops, previewStops);
		}
		/**
		* Handle pointerdown on a thumb to start drag.
		* Sets up pointer capture and initializes the drag session.
		*/
		function handleThumbPointerDown(event) {
			if (thumbDrag) return;
			if (currentType === "none") return;
			if (typeSelect.disabled) return;
			if (event.button !== 0) return;
			if (!event.isPrimary) return;
			const thumb = event.currentTarget;
			const stopId = thumb.dataset.stopId;
			if (!stopId) return;
			if (thumbKeyboard) thumbKeyboard = null;
			event.preventDefault();
			event.stopPropagation();
			selectedStopId = stopId;
			const initialPositions = /* @__PURE__ */ new Map();
			for (const stop of currentStops) initialPositions.set(stop.id, stop.position);
			thumbDrag = {
				stopId,
				pointerId: event.pointerId,
				initialPositions,
				thumbElement: thumb
			};
			gradientBar.classList.add("we-gradient-bar--dragging");
			thumb.classList.add("we-gradient-thumb--dragging");
			try {
				thumb.setPointerCapture(event.pointerId);
			} catch (_unused7) {}
			beginTransaction();
			updateGradientBar({
				preserveThumbs: true,
				refreshStopsList: false
			});
		}
		/**
		* Handle pointermove during drag to update stop position.
		* Called on window (capture phase) to ensure we capture all movement.
		*/
		function handleThumbPointerMove(event) {
			const session = thumbDrag;
			if (!session) return;
			if (event.pointerId !== session.pointerId) return;
			const newPosition = calculatePositionFromPointer(event.clientX);
			setStopPositionById(session.stopId, newPosition);
			previewGradient();
		}
		/**
		* Handle pointerup to end drag and commit changes.
		*/
		function handleThumbPointerUp(event) {
			const session = thumbDrag;
			if (!session) return;
			if (event.pointerId !== session.pointerId) return;
			endThumbDrag(true);
		}
		/**
		* Handle pointercancel (e.g., touch interrupted) to cancel drag.
		*/
		function handleThumbPointerCancel(event) {
			const session = thumbDrag;
			if (!session) return;
			if (event.pointerId !== session.pointerId) return;
			endThumbDrag(false);
		}
		/**
		* Handle keydown during drag to support Escape cancellation.
		*/
		function handleDragKeyDown(event) {
			if (!thumbDrag) return;
			if (event.key === "Escape") {
				event.preventDefault();
				event.stopImmediatePropagation();
				event.stopPropagation();
				endThumbDrag(false);
			}
		}
		const DRAG_LISTENER_OPTIONS = {
			capture: true,
			passive: false
		};
		disposer.listen(window, "pointermove", handleThumbPointerMove, DRAG_LISTENER_OPTIONS);
		disposer.listen(window, "pointerup", handleThumbPointerUp, DRAG_LISTENER_OPTIONS);
		disposer.listen(window, "pointercancel", handleThumbPointerCancel, DRAG_LISTENER_OPTIONS);
		disposer.listen(window, "keydown", handleDragKeyDown, DRAG_LISTENER_OPTIONS);
		/**
		* Render stops list and sync selection with selectedStopId.
		* Clicking a row selects the stop and refreshes thumbs via updateGradientBar().
		*/
		function updateStopsList(models, stops, previewStops) {
			stopsList.textContent = "";
			if (currentType === "none") return;
			if (models.length === 0 || stops.length === 0) return;
			/**
			* Format position value for display (e.g., "50%")
			*/
			const formatPercentValue = (value) => {
				const clamped = clampPercent(value);
				const rounded = Math.round(clamped * 100) / 100;
				return Object.is(rounded, -0) ? 0 : rounded;
			};
			const formatPercentLabel = (value) => `${formatPercentValue(value)}%`;
			const rows = stops.map((stop, index) => ({
				index,
				stop,
				model: models[index],
				preview: previewStops[index]
			})).filter((r) => Boolean(r.model && r.preview)).sort((a, b) => a.stop.position - b.stop.position || a.index - b.index);
			for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
				const r = rows[rowIndex];
				const model = r.model;
				const stop = r.stop;
				const preview = r.preview;
				const isActive = model.id === selectedStopId;
				const row = document.createElement("div");
				row.className = isActive ? "we-gradient-stop-row we-gradient-stop-row--active" : "we-gradient-stop-row";
				row.dataset.stopId = model.id;
				row.setAttribute("role", "button");
				row.tabIndex = 0;
				row.setAttribute("aria-label", `Select stop at ${formatPercentLabel(stop.position)}`);
				const pos = document.createElement("div");
				pos.className = "we-gradient-stop-pos";
				const posStatic = document.createElement("span");
				posStatic.className = "we-gradient-stop-pos-static";
				posStatic.textContent = formatPercentLabel(stop.position);
				const posEditor = document.createElement("div");
				posEditor.className = "we-gradient-stop-pos-editor";
				if (isActive) {
					posEditor.append(selectedStopPosHost);
					if (!isPositionInputFocused()) selectedStopPosInput.value = String(formatPercentValue(stop.position));
				}
				pos.append(posStatic, posEditor);
				const color = document.createElement("div");
				color.className = "we-gradient-stop-color";
				const colorStatic = document.createElement("button");
				colorStatic.type = "button";
				colorStatic.className = "we-gradient-stop-color-static";
				colorStatic.tabIndex = -1;
				colorStatic.setAttribute("aria-label", "Select stop");
				const swatch = document.createElement("span");
				swatch.className = "we-gradient-stop-swatch";
				swatch.style.backgroundColor = preview.color;
				const text = document.createElement("span");
				text.className = "we-gradient-stop-color-text";
				text.textContent = stop.color.trim() || DEFAULT_STOP_1.color;
				colorStatic.append(swatch, text);
				const colorEditor = document.createElement("div");
				colorEditor.className = "we-gradient-stop-color-editor";
				if (isActive) {
					colorEditor.append(selectedStopColorHost);
					if (!selectedStopColorField.isFocused()) {
						var _model$placeholderCol2;
						selectedStopColorField.setValue(stop.color);
						selectedStopColorField.setPlaceholder(needsColorPlaceholder(stop.color) ? (_model$placeholderCol2 = model.placeholderColor) !== null && _model$placeholderCol2 !== void 0 ? _model$placeholderCol2 : "" : "");
					}
				}
				color.append(colorStatic, colorEditor);
				const removeBtn = document.createElement("button");
				removeBtn.type = "button";
				removeBtn.className = "we-icon-btn we-gradient-stop-remove";
				removeBtn.setAttribute("aria-label", "Remove stop");
				removeBtn.disabled = !(!typeSelect.disabled && models.length > 2);
				removeBtn.textContent = "–";
				removeBtn.addEventListener("click", (event) => {
					event.preventDefault();
					event.stopPropagation();
					removeStopById(model.id);
				});
				const focusSelectedPosInput = () => {
					queueMicrotask(() => {
						selectedStopPosInput.focus();
						selectedStopPosInput.select();
					});
				};
				const focusSelectedColorField = () => {
					queueMicrotask(() => {
						const input = selectedStopColorHost.querySelector("input.we-color-text");
						input === null || input === void 0 || input.focus();
					});
				};
				const selectThisRow = (opts) => {
					selectedStopId = model.id;
					updateGradientBar();
					if (opts === null || opts === void 0 ? void 0 : opts.focusColor) focusSelectedColorField();
					if (opts === null || opts === void 0 ? void 0 : opts.focusPosition) focusSelectedPosInput();
				};
				row.addEventListener("click", (event) => {
					if (model.id === selectedStopId) return;
					event.preventDefault();
					selectThisRow();
				});
				row.addEventListener("keydown", (event) => {
					if (isTextInputLike(event.target)) return;
					if (event.key === "ArrowUp" || event.key === "ArrowDown") {
						var _rows$nextIndex;
						event.preventDefault();
						event.stopPropagation();
						const nextIndex = event.key === "ArrowUp" ? Math.max(0, rowIndex - 1) : Math.min(rows.length - 1, rowIndex + 1);
						if (nextIndex === rowIndex) return;
						const nextModel = (_rows$nextIndex = rows[nextIndex]) === null || _rows$nextIndex === void 0 ? void 0 : _rows$nextIndex.model;
						if (!nextModel) return;
						selectedStopId = nextModel.id;
						updateGradientBar();
						queueMicrotask(() => {
							const nextRow = stopsList.querySelector(`.we-gradient-stop-row[data-stop-id="${nextModel.id}"]`);
							nextRow === null || nextRow === void 0 || nextRow.focus();
						});
						return;
					}
					if (model.id !== selectedStopId && (event.key === "Enter" || event.key === " ")) {
						event.preventDefault();
						selectThisRow();
					}
				});
				posStatic.addEventListener("click", (event) => {
					event.preventDefault();
					event.stopPropagation();
					if (model.id === selectedStopId) {
						focusSelectedPosInput();
						return;
					}
					selectThisRow({ focusPosition: true });
				});
				colorStatic.addEventListener("click", (event) => {
					event.preventDefault();
					event.stopPropagation();
					if (model.id === selectedStopId) {
						focusSelectedColorField();
						return;
					}
					selectThisRow({ focusColor: true });
				});
				row.append(pos, color, removeBtn);
				stopsList.append(row);
			}
		}
		function updateRowVisibility() {
			gradientBarRow.hidden = currentType === "none";
			angleRow.hidden = currentType !== "linear";
			shapeRow.hidden = currentType !== "radial";
			posXRow.hidden = currentType !== "radial";
			posYRow.hidden = currentType !== "radial";
			stopsHeaderRow.hidden = currentType === "none";
			stopsList.hidden = currentType === "none";
			stopsAddBtn.disabled = typeSelect.disabled || currentType === "none";
		}
		function setAllDisabled(disabled) {
			typeSelect.disabled = disabled;
			angleInput.disabled = disabled;
			shapeSelect.disabled = disabled;
			posXInput.disabled = disabled;
			posYInput.disabled = disabled;
			stopsAddBtn.disabled = disabled;
			selectedStopPosInput.disabled = disabled || currentType === "none";
			selectedStopColorField.setDisabled(disabled || currentType === "none");
		}
		function resetDefaults(options = {}) {
			var _currentStops$0$id3, _currentStops$3;
			angleInput.value = String(DEFAULT_LINEAR_ANGLE);
			shapeSelect.value = "ellipse";
			posXInput.value = "";
			posYInput.value = "";
			currentStops = createDefaultStopModels();
			selectedStopId = (_currentStops$0$id3 = (_currentStops$3 = currentStops[0]) === null || _currentStops$3 === void 0 ? void 0 : _currentStops$3.id) !== null && _currentStops$0$id3 !== void 0 ? _currentStops$0$id3 : null;
			if (!options.skipPreview) updateGradientBar();
		}
		/**
		* Check if the position input is currently focused.
		* Used to prevent list re-rendering while editing.
		*/
		function isPositionInputFocused() {
			return isFieldFocused$4(selectedStopPosInput);
		}
		function isEditing() {
			return backgroundHandle !== null || isFieldFocused$4(typeSelect) || isFieldFocused$4(angleInput) || isFieldFocused$4(shapeSelect) || isFieldFocused$4(posXInput) || isFieldFocused$4(posYInput) || isPositionInputFocused() || selectedStopColorField.isFocused();
		}
		/**
		* Format stops array as CSS color-stop list
		*/
		function formatStopList(stops) {
			return stops.map((s) => {
				return `${s.color.trim() || DEFAULT_STOP_1.color} ${clampPercent(s.position)}%`;
			}).join(", ");
		}
		/**
		* Build CSS gradient string for writing back to element (background-image).
		* Uses current UI input values for angle (linear) or shape/position (radial).
		*
		* @param stops - The gradient stops to include
		* @returns CSS gradient string (e.g., "linear-gradient(45deg, #fff 0%, #000 100%)")
		*/
		function buildElementGradientCss(stops) {
			var _parseNumber2, _parseNumber3;
			if (currentType === "none" || stops.length === 0) return "none";
			const stopsText = formatStopList(stops);
			if (currentType === "linear") {
				var _parseNumber;
				return `linear-gradient(${clampAngle((_parseNumber = parseNumber$1(angleInput.value)) !== null && _parseNumber !== void 0 ? _parseNumber : DEFAULT_LINEAR_ANGLE)}deg, ${stopsText})`;
			}
			const shape = shapeSelect.value || "ellipse";
			const rawX = posXInput.value.trim();
			const rawY = posYInput.value.trim();
			if (!Boolean(rawX || rawY)) return `radial-gradient(${shape}, ${stopsText})`;
			return `radial-gradient(${shape} at ${clampPercent((_parseNumber2 = parseNumber$1(rawX)) !== null && _parseNumber2 !== void 0 ? _parseNumber2 : DEFAULT_POSITION)}% ${clampPercent((_parseNumber3 = parseNumber$1(rawY)) !== null && _parseNumber3 !== void 0 ? _parseNumber3 : DEFAULT_POSITION)}%, ${stopsText})`;
		}
		/**
		* Build CSS for the preview bar UI.
		* Always outputs a horizontal 90deg linear-gradient regardless of actual gradient type.
		* This provides a consistent left-to-right preview of stop positions and colors.
		*
		* @param stops - The gradient stops to preview
		* @returns CSS linear-gradient string with 90deg angle
		*/
		function buildPreviewBarCss(stops) {
			if (stops.length === 0) return "linear-gradient(90deg, transparent, transparent)";
			return `linear-gradient(90deg, ${formatStopList(stops)})`;
		}
		/**
		* Collect current stops from UI state, merging UI values for edited stops
		* with preserved values for additional stops.
		* Returns GradientStop[] for CSS generation (strips id field).
		*/
		function collectCurrentStops() {
			return (currentStops.length >= 2 ? currentStops : createDefaultStopModels()).map((s) => ({
				color: s.color.trim() || DEFAULT_STOP_1.color,
				position: clampPercent(s.position)
			}));
		}
		/**
		* Build the current gradient value for writing to element
		*/
		function buildGradientValue() {
			if (currentType === "none") return "none";
			return buildElementGradientCss(collectCurrentStops());
		}
		function previewGradient() {
			if (disposer.isDisposed) return;
			const isDragging = thumbDrag !== null;
			const isKeyboardStepping = thumbKeyboard !== null;
			const isEditingStopFields = selectedStopColorField.isFocused() || isPositionInputFocused();
			updateGradientBar({
				preserveThumbs: isDragging || isKeyboardStepping,
				refreshStopsList: isDragging || isKeyboardStepping ? false : !isEditingStopFields
			});
			const target = currentTarget;
			if (!target || !target.isConnected) return;
			const handle = beginTransaction();
			if (!handle) return;
			handle.set(buildGradientValue());
		}
		function syncAllFields(force = false) {
			const target = currentTarget;
			if (!target || !target.isConnected) {
				setAllDisabled(true);
				const defaultType = allowNone ? "none" : "linear";
				currentType = defaultType;
				typeSelect.value = defaultType;
				resetDefaults();
				updateRowVisibility();
				updateGradientBar();
				return;
			}
			setAllDisabled(false);
			if (isEditing() && !force) return;
			const inlineValue = readInlineValue$5(target, cssProperty);
			const computedValue = !inlineValue || /\bvar\s*\(/i.test(inlineValue) ? readComputedValue$4(target, cssProperty) : "";
			const inlineParsed = !isNoneValue(inlineValue) ? parseGradient(inlineValue) : null;
			const computedParsed = !isNoneValue(computedValue) ? parseGradient(computedValue) : null;
			let parsed = null;
			let source = "none";
			if (inlineValue.trim()) if (isNoneValue(inlineValue)) {
				parsed = null;
				source = "none";
			} else if (inlineParsed) {
				parsed = inlineParsed;
				source = "inline";
			} else {
				parsed = null;
				source = "none";
			}
			else if (isNoneValue(computedValue)) {
				parsed = null;
				source = "none";
			} else if (computedParsed) {
				parsed = computedParsed;
				source = "computed";
			} else {
				parsed = null;
				source = "none";
			}
			resetDefaults({ skipPreview: true });
			if (!parsed) {
				const defaultType = allowNone ? "none" : "linear";
				currentType = defaultType;
				typeSelect.value = defaultType;
				updateRowVisibility();
				updateGradientBar();
				return;
			}
			const rawStops = parsed.stops.length >= 2 ? parsed.stops.slice() : [_objectSpread2({}, DEFAULT_STOP_1), _objectSpread2({}, DEFAULT_STOP_2)];
			if (source === "inline" && needsColorPlaceholder(inlineValue) && computedParsed) {
				const placeholderColors = buildPlaceholderMapping(rawStops, computedParsed.stops);
				for (let i = 0; i < rawStops.length; i++) {
					var _placeholderColors$i;
					rawStops[i].placeholderColor = (_placeholderColors$i = placeholderColors[i]) !== null && _placeholderColors$i !== void 0 ? _placeholderColors$i : "";
				}
			}
			currentStops = reconcileStopModels(currentStops, rawStops);
			if (!selectedStopId || !currentStops.some((s) => s.id === selectedStopId)) {
				var _currentStops$0$id4, _currentStops$4;
				selectedStopId = (_currentStops$0$id4 = (_currentStops$4 = currentStops[0]) === null || _currentStops$4 === void 0 ? void 0 : _currentStops$4.id) !== null && _currentStops$0$id4 !== void 0 ? _currentStops$0$id4 : null;
			}
			if (parsed.type === "linear") {
				currentType = "linear";
				typeSelect.value = "linear";
				angleInput.value = String(parsed.angle);
			} else {
				currentType = "radial";
				typeSelect.value = "radial";
				shapeSelect.value = parsed.shape;
				if (parsed.position) {
					posXInput.value = String(parsed.position.x);
					posYInput.value = String(parsed.position.y);
				} else {
					posXInput.value = "";
					posYInput.value = "";
				}
			}
			updateRowVisibility();
			updateGradientBar();
		}
		function wireTextInput(input) {
			disposer.listen(input, "input", previewGradient);
			disposer.listen(input, "blur", () => {
				commitTransaction();
				syncAllFields();
			});
			disposer.listen(input, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction();
					syncAllFields();
					input.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction();
					syncAllFields(true);
				}
			});
		}
		function wireSelect(select, onPreview) {
			const preview = () => {
				onPreview === null || onPreview === void 0 || onPreview();
				previewGradient();
			};
			disposer.listen(select, "input", preview);
			disposer.listen(select, "change", preview);
			disposer.listen(select, "blur", () => {
				commitTransaction();
				syncAllFields();
			});
			disposer.listen(select, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction();
					syncAllFields();
					select.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction();
					syncAllFields(true);
				}
			});
		}
		wireSelect(typeSelect, () => {
			currentType = typeSelect.value;
			updateRowVisibility();
		});
		wireSelect(shapeSelect);
		wireTextInput(angleInput);
		wireTextInput(posXInput);
		wireTextInput(posYInput);
		disposer.listen(stopsAddBtn, "click", (event) => {
			event.preventDefault();
			if (stopsAddBtn.disabled) return;
			addStopAtPosition(getSuggestedAddStopPosition(), { focusColor: true });
		});
		disposer.listen(gradientBar, "dblclick", (event) => {
			if (thumbDrag) return;
			if (currentType === "none" || typeSelect.disabled) return;
			if (event.composedPath().some((el) => el instanceof HTMLElement && el.classList.contains("we-gradient-thumb"))) return;
			event.preventDefault();
			addStopAtPosition(calculatePositionFromPointer(event.clientX), { focusColor: true });
		});
		disposer.listen(root, "keydown", (event) => {
			if (event.key !== "Delete" && event.key !== "Backspace") return;
			if (thumbDrag) return;
			if (currentType === "none" || typeSelect.disabled) return;
			const id = selectedStopId;
			if (!id) return;
			if (isTextInputLike(event.target)) return;
			const path = event.composedPath();
			if (!path.includes(stopsList) && !path.includes(gradientBar)) return;
			event.preventDefault();
			event.stopPropagation();
			removeStopById(id);
		});
		function setTarget(element) {
			if (disposer.isDisposed) return;
			if (element !== currentTarget) commitTransaction();
			currentTarget = element;
			syncAllFields(true);
		}
		function refresh() {
			if (disposer.isDisposed) return;
			syncAllFields();
		}
		function dispose() {
			commitTransaction();
			currentTarget = null;
			disposer.dispose();
		}
		typeSelect.value = currentType;
		resetDefaults();
		updateRowVisibility();
		syncAllFields(true);
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/typography-control.ts
	/**
	* Typography Control (Phase 3.7)
	*
	* Edits inline typography styles:
	* - font-family (select + custom input)
	* - font-size (input)
	* - font-weight (select)
	* - line-height (input)
	* - letter-spacing (input)
	* - text-align (icon button group)
	* - vertical-align (icon button group)
	* - color (input with optional token picker)
	*
	* Phase 5.4: Added optional DesignTokensService integration for color field.
	*/
	var SVG_NS$2 = "http://www.w3.org/2000/svg";
	var FONT_WEIGHT_VALUES = [
		"100",
		"200",
		"300",
		"400",
		"500",
		"600",
		"700",
		"800",
		"900"
	];
	var TEXT_ALIGN_VALUES = [
		"left",
		"center",
		"right",
		"justify"
	];
	var VERTICAL_ALIGN_VALUES = [
		"baseline",
		"middle",
		"top",
		"bottom"
	];
	/** Text color type: solid uses 'color' property, gradient uses background-clip: text */
	var TEXT_COLOR_TYPE_VALUES = ["solid", "gradient"];
	var FONT_FAMILY_PRESET_VALUES = [
		"inherit",
		"system-ui",
		"sans-serif",
		"serif",
		"monospace"
	];
	var FONT_FAMILY_CUSTOM_VALUE = "custom";
	function createBaseIconSvg() {
		const svg = document.createElementNS(SVG_NS$2, "svg");
		svg.setAttribute("viewBox", "0 0 15 15");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		svg.setAttribute("focusable", "false");
		return svg;
	}
	function createTextAlignIcon(value) {
		const svg = createBaseIconSvg();
		const container = document.createElementNS(SVG_NS$2, "rect");
		container.setAttribute("x", "2");
		container.setAttribute("y", "2");
		container.setAttribute("width", "11");
		container.setAttribute("height", "11");
		container.setAttribute("rx", "1.5");
		container.setAttribute("stroke", "currentColor");
		container.setAttribute("stroke-width", "1");
		container.setAttribute("stroke-dasharray", "2 1");
		container.setAttribute("fill", "none");
		container.setAttribute("opacity", "0.5");
		const lineConfigs = {
			left: [
				[3.5, 8],
				[3.5, 5],
				[3.5, 6.5]
			],
			center: [
				[3.5, 8],
				[5, 5],
				[4.25, 6.5]
			],
			right: [
				[3.5, 8],
				[6.5, 5],
				[5.5, 6.5]
			],
			justify: [
				[3.5, 8],
				[3.5, 8],
				[3.5, 8]
			]
		};
		const yPositions = [
			4.5,
			7.5,
			10.5
		];
		lineConfigs[value].forEach(([x, width], index) => {
			const line = document.createElementNS(SVG_NS$2, "rect");
			line.setAttribute("x", String(x));
			line.setAttribute("y", String(yPositions[index] - .5));
			line.setAttribute("width", String(width));
			line.setAttribute("height", "1");
			line.setAttribute("rx", "0.5");
			line.setAttribute("fill", "currentColor");
			svg.append(line);
		});
		svg.prepend(container);
		return svg;
	}
	function createVerticalAlignIcon(value) {
		const svg = createBaseIconSvg();
		const container = document.createElementNS(SVG_NS$2, "rect");
		container.setAttribute("x", "2");
		container.setAttribute("y", "2");
		container.setAttribute("width", "11");
		container.setAttribute("height", "11");
		container.setAttribute("rx", "1.5");
		container.setAttribute("stroke", "currentColor");
		container.setAttribute("stroke-width", "1");
		container.setAttribute("stroke-dasharray", "2 1");
		container.setAttribute("fill", "none");
		container.setAttribute("opacity", "0.5");
		const blockY = {
			top: 3.5,
			middle: 5.5,
			bottom: 7.5,
			baseline: 6.5
		};
		const block1 = document.createElementNS(SVG_NS$2, "rect");
		block1.setAttribute("x", "4");
		block1.setAttribute("y", String(blockY[value]));
		block1.setAttribute("width", "3");
		block1.setAttribute("height", "4");
		block1.setAttribute("rx", "0.5");
		block1.setAttribute("fill", "currentColor");
		const block2 = document.createElementNS(SVG_NS$2, "rect");
		block2.setAttribute("x", "8");
		block2.setAttribute("y", String(blockY[value]));
		block2.setAttribute("width", "3");
		block2.setAttribute("height", "4");
		block2.setAttribute("rx", "0.5");
		block2.setAttribute("fill", "currentColor");
		svg.append(container, block1, block2);
		if (value === "baseline") {
			const baselinePath = document.createElementNS(SVG_NS$2, "path");
			baselinePath.setAttribute("d", "M3 10H12");
			baselinePath.setAttribute("stroke", "currentColor");
			baselinePath.setAttribute("stroke-width", "1");
			baselinePath.setAttribute("stroke-dasharray", "1.5 1");
			svg.append(baselinePath);
		}
		return svg;
	}
	function isTextAlignValue(value) {
		return TEXT_ALIGN_VALUES.includes(value);
	}
	function isVerticalAlignValue(value) {
		return VERTICAL_ALIGN_VALUES.includes(value);
	}
	function isFieldFocused$3(el) {
		try {
			const rootNode = el.getRootNode();
			if (rootNode instanceof ShadowRoot) return rootNode.activeElement === el;
			return document.activeElement === el;
		} catch (_unused) {
			return false;
		}
	}
	function readInlineValue$4(element, property) {
		try {
			var _style$getPropertyVal, _style$getPropertyVal2;
			const style = element.style;
			return (_style$getPropertyVal = style === null || style === void 0 || (_style$getPropertyVal2 = style.getPropertyValue) === null || _style$getPropertyVal2 === void 0 || (_style$getPropertyVal2 = _style$getPropertyVal2.call(style, property)) === null || _style$getPropertyVal2 === void 0 ? void 0 : _style$getPropertyVal2.trim()) !== null && _style$getPropertyVal !== void 0 ? _style$getPropertyVal : "";
		} catch (_unused2) {
			return "";
		}
	}
	function readComputedValue$3(element, property) {
		try {
			return window.getComputedStyle(element).getPropertyValue(property).trim();
		} catch (_unused3) {
			return "";
		}
	}
	/**
	* Check if a value is a gradient background-image.
	*/
	function isGradientBackgroundValue(raw) {
		return /\b(?:linear|radial|conic)-gradient\s*\(/i.test(raw.trim());
	}
	/**
	* Check if text-fill-color is transparent (for gradient text detection).
	*/
	function isTransparentTextFillColor(raw) {
		const v = raw.trim().toLowerCase();
		if (!v) return false;
		if (v === "transparent") return true;
		if (/^rgba\([^)]*,\s*0\s*\)$/.test(v)) return true;
		return false;
	}
	/**
	* Infer text color type from element's computed styles.
	* Returns 'gradient' if background-clip: text pattern is detected.
	*/
	function inferTextColorType(target) {
		const bgImage = readInlineValue$4(target, "background-image") || readComputedValue$3(target, "background-image");
		const bgClip = readInlineValue$4(target, "-webkit-background-clip") || readComputedValue$3(target, "-webkit-background-clip");
		const textFill = readInlineValue$4(target, "-webkit-text-fill-color") || readComputedValue$3(target, "-webkit-text-fill-color");
		const hasGradientBg = bgImage && bgImage.toLowerCase() !== "none" && isGradientBackgroundValue(bgImage);
		const hasClipText = bgClip.toLowerCase().includes("text");
		const hasTransparentFill = isTransparentTextFillColor(textFill);
		return hasGradientBg && hasClipText && hasTransparentFill ? "gradient" : "solid";
	}
	function createTypographyControl(options) {
		const { container, transactionManager, tokensService } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		let currentTextColorType = "solid";
		const root = document.createElement("div");
		root.className = "we-field-group";
		const fontFamilyRow = document.createElement("div");
		fontFamilyRow.className = "we-field";
		const fontFamilyLabel = document.createElement("span");
		fontFamilyLabel.className = "we-field-label";
		fontFamilyLabel.textContent = "Font";
		const fontFamilyControls = document.createElement("div");
		fontFamilyControls.className = "we-field-content";
		fontFamilyControls.style.display = "flex";
		fontFamilyControls.style.flexDirection = "column";
		fontFamilyControls.style.gap = "4px";
		const fontFamilySelect = document.createElement("select");
		fontFamilySelect.className = "we-select";
		fontFamilySelect.setAttribute("aria-label", "Font Family");
		for (const v of FONT_FAMILY_PRESET_VALUES) {
			const opt = document.createElement("option");
			opt.value = v;
			opt.textContent = v;
			fontFamilySelect.append(opt);
		}
		const customFontOpt = document.createElement("option");
		customFontOpt.value = FONT_FAMILY_CUSTOM_VALUE;
		customFontOpt.textContent = "Custom…";
		fontFamilySelect.append(customFontOpt);
		const fontFamilyCustomContainer = createInputContainer({
			ariaLabel: "Custom Font Family",
			prefix: null,
			suffix: null,
			placeholder: "e.g. Inter, system-ui"
		});
		fontFamilyCustomContainer.root.style.display = "none";
		fontFamilyCustomContainer.input.disabled = true;
		fontFamilyControls.append(fontFamilySelect, fontFamilyCustomContainer.root);
		fontFamilyRow.append(fontFamilyLabel, fontFamilyControls);
		const fontSizeRow = document.createElement("div");
		fontSizeRow.className = "we-field";
		const fontSizeLabel = document.createElement("span");
		fontSizeLabel.className = "we-field-label";
		fontSizeLabel.textContent = "Size";
		const fontSizeContainer = createInputContainer({
			ariaLabel: "Font Size",
			inputMode: "decimal",
			prefix: null,
			suffix: "px"
		});
		fontSizeRow.append(fontSizeLabel, fontSizeContainer.root);
		const fontWeightRow = document.createElement("div");
		fontWeightRow.className = "we-field";
		const fontWeightLabel = document.createElement("span");
		fontWeightLabel.className = "we-field-label";
		fontWeightLabel.textContent = "Weight";
		const fontWeightSelect = document.createElement("select");
		fontWeightSelect.className = "we-select";
		fontWeightSelect.setAttribute("aria-label", "Font Weight");
		for (const v of FONT_WEIGHT_VALUES) {
			const opt = document.createElement("option");
			opt.value = v;
			opt.textContent = v;
			fontWeightSelect.append(opt);
		}
		fontWeightRow.append(fontWeightLabel, fontWeightSelect);
		const lineHeightRow = document.createElement("div");
		lineHeightRow.className = "we-field";
		const lineHeightLabel = document.createElement("span");
		lineHeightLabel.className = "we-field-label";
		lineHeightLabel.textContent = "Line Height";
		const lineHeightContainer = createInputContainer({
			ariaLabel: "Line Height",
			inputMode: "decimal",
			prefix: null,
			suffix: null
		});
		lineHeightRow.append(lineHeightLabel, lineHeightContainer.root);
		const letterSpacingRow = document.createElement("div");
		letterSpacingRow.className = "we-field";
		const letterSpacingLabel = document.createElement("span");
		letterSpacingLabel.className = "we-field-label";
		letterSpacingLabel.textContent = "Spacing";
		const letterSpacingContainer = createInputContainer({
			ariaLabel: "Letter Spacing",
			inputMode: "decimal",
			prefix: null,
			suffix: "px"
		});
		letterSpacingRow.append(letterSpacingLabel, letterSpacingContainer.root);
		wireNumberStepping(disposer, fontSizeContainer.input, { mode: "css-length" });
		wireNumberStepping(disposer, lineHeightContainer.input, {
			mode: "css-length",
			step: .1,
			shiftStep: 1,
			altStep: .01
		});
		wireNumberStepping(disposer, letterSpacingContainer.input, {
			mode: "css-length",
			step: .1,
			shiftStep: 1,
			altStep: .01
		});
		const textAlignRow = document.createElement("div");
		textAlignRow.className = "we-field";
		const textAlignLabel = document.createElement("span");
		textAlignLabel.className = "we-field-label";
		textAlignLabel.textContent = "Text Align";
		const textAlignMount = document.createElement("div");
		textAlignMount.className = "we-field-content";
		textAlignRow.append(textAlignLabel, textAlignMount);
		const verticalAlignRow = document.createElement("div");
		verticalAlignRow.className = "we-field";
		const verticalAlignLabel = document.createElement("span");
		verticalAlignLabel.className = "we-field-label";
		verticalAlignLabel.textContent = "Vertical Align";
		const verticalAlignMount = document.createElement("div");
		verticalAlignMount.className = "we-field-content";
		verticalAlignRow.append(verticalAlignLabel, verticalAlignMount);
		const textColorTypeRow = document.createElement("div");
		textColorTypeRow.className = "we-field";
		const textColorTypeLabel = document.createElement("span");
		textColorTypeLabel.className = "we-field-label";
		textColorTypeLabel.textContent = "Type";
		const textColorTypeSelect = document.createElement("select");
		textColorTypeSelect.className = "we-select";
		textColorTypeSelect.setAttribute("aria-label", "Text Color Type");
		for (const v of TEXT_COLOR_TYPE_VALUES) {
			const opt = document.createElement("option");
			opt.value = v;
			opt.textContent = v.charAt(0).toUpperCase() + v.slice(1);
			textColorTypeSelect.append(opt);
		}
		textColorTypeRow.append(textColorTypeLabel, textColorTypeSelect);
		const colorRow = document.createElement("div");
		colorRow.className = "we-field";
		const colorLabel = document.createElement("span");
		colorLabel.className = "we-field-label";
		colorLabel.textContent = "Color";
		const colorFieldContainer = document.createElement("div");
		colorFieldContainer.style.minWidth = "0";
		colorRow.append(colorLabel, colorFieldContainer);
		const textGradientMount = document.createElement("div");
		const sizeAndWeightRow = document.createElement("div");
		sizeAndWeightRow.className = "we-field-row";
		fontSizeRow.style.flex = "1";
		fontSizeRow.style.minWidth = "0";
		fontWeightRow.style.flex = "1";
		fontWeightRow.style.minWidth = "0";
		sizeAndWeightRow.append(fontSizeRow, fontWeightRow);
		const lineHeightAndSpacingRow = document.createElement("div");
		lineHeightAndSpacingRow.className = "we-field-row";
		lineHeightRow.style.flex = "1";
		lineHeightRow.style.minWidth = "0";
		letterSpacingRow.style.flex = "1";
		letterSpacingRow.style.minWidth = "0";
		lineHeightAndSpacingRow.append(lineHeightRow, letterSpacingRow);
		root.append(fontFamilyRow, sizeAndWeightRow, lineHeightAndSpacingRow, textAlignRow, verticalAlignRow, textColorTypeRow, colorRow, textGradientMount);
		container.append(root);
		disposer.add(() => root.remove());
		const textAlignGroup = createIconButtonGroup({
			container: textAlignMount,
			ariaLabel: "Text Align",
			columns: 4,
			items: TEXT_ALIGN_VALUES.map((v) => ({
				value: v,
				ariaLabel: `text-align: ${v}`,
				title: v.charAt(0).toUpperCase() + v.slice(1),
				icon: createTextAlignIcon(v)
			})),
			onChange: (value) => {
				const handle = beginTransaction("text-align");
				if (handle) handle.set(value);
				commitTransaction("text-align");
				syncAllFields();
			}
		});
		disposer.add(() => textAlignGroup.dispose());
		const verticalAlignGroup = createIconButtonGroup({
			container: verticalAlignMount,
			ariaLabel: "Vertical Align",
			columns: 4,
			items: VERTICAL_ALIGN_VALUES.map((v) => ({
				value: v,
				ariaLabel: `vertical-align: ${v}`,
				title: v.charAt(0).toUpperCase() + v.slice(1),
				icon: createVerticalAlignIcon(v)
			})),
			onChange: (value) => {
				const handle = beginTransaction("vertical-align");
				if (handle) handle.set(value);
				commitTransaction("vertical-align");
				syncAllFields();
			}
		});
		disposer.add(() => verticalAlignGroup.dispose());
		const textColorField = createColorField({
			container: colorFieldContainer,
			ariaLabel: "Text Color",
			tokensService,
			getTokenTarget: () => currentTarget,
			onInput: (value) => {
				const handle = beginTransaction("color");
				if (handle) handle.set(value);
			},
			onCommit: () => {
				commitTransaction("color");
				syncAllFields();
			},
			onCancel: () => {
				rollbackTransaction("color");
				syncField("color", true);
			}
		});
		disposer.add(() => textColorField.dispose());
		const textGradientControl = createGradientControl({
			container: textGradientMount,
			transactionManager,
			tokensService,
			property: "background-image",
			allowNone: false
		});
		disposer.add(() => textGradientControl.dispose());
		const fields = {
			"font-family": {
				kind: "font-family",
				property: "font-family",
				select: fontFamilySelect,
				custom: fontFamilyCustomContainer,
				controlsContainer: fontFamilyControls,
				handle: null
			},
			"font-size": {
				kind: "standard",
				property: "font-size",
				element: fontSizeContainer.input,
				container: fontSizeContainer,
				handle: null
			},
			"font-weight": {
				kind: "standard",
				property: "font-weight",
				element: fontWeightSelect,
				handle: null
			},
			"line-height": {
				kind: "standard",
				property: "line-height",
				element: lineHeightContainer.input,
				container: lineHeightContainer,
				handle: null
			},
			"letter-spacing": {
				kind: "standard",
				property: "letter-spacing",
				element: letterSpacingContainer.input,
				container: letterSpacingContainer,
				handle: null
			},
			"text-align": {
				kind: "text-align",
				property: "text-align",
				group: textAlignGroup,
				handle: null
			},
			"vertical-align": {
				kind: "vertical-align",
				property: "vertical-align",
				group: verticalAlignGroup,
				handle: null
			},
			color: {
				kind: "color",
				property: "color",
				field: textColorField,
				handle: null
			}
		};
		const PROPS = [
			"font-family",
			"font-size",
			"font-weight",
			"line-height",
			"letter-spacing",
			"text-align",
			"vertical-align",
			"color"
		];
		function beginTransaction(property) {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields[property];
			if (field.handle) return field.handle;
			const handle = transactionManager.beginStyle(target, property);
			field.handle = handle;
			return handle;
		}
		function commitTransaction(property) {
			const field = fields[property];
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackTransaction(property) {
			const field = fields[property];
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.rollback();
		}
		function commitAllTransactions() {
			for (const p of PROPS) commitTransaction(p);
		}
		/**
		* Update visibility of color-related rows based on currentTextColorType.
		*/
		function updateTextColorTypeVisibility() {
			colorRow.hidden = currentTextColorType !== "solid";
			textGradientMount.hidden = currentTextColorType !== "gradient";
		}
		/**
		* Set text color type and apply necessary CSS changes.
		* Uses multiStyle transaction to atomically set background-clip text properties.
		*/
		function setTextColorType(type) {
			const target = currentTarget;
			currentTextColorType = type;
			textColorTypeSelect.value = type;
			updateTextColorTypeVisibility();
			if (!target || !target.isConnected) return;
			commitTransaction("color");
			const handle = transactionManager.beginMultiStyle(target, [
				"background-image",
				"-webkit-background-clip",
				"-webkit-text-fill-color"
			]);
			if (!handle) return;
			if (type === "solid") handle.set({
				"background-image": "",
				"-webkit-background-clip": "",
				"-webkit-text-fill-color": ""
			});
			else {
				const inlineBg = readInlineValue$4(target, "background-image");
				const computedBg = readComputedValue$3(target, "background-image");
				const currentBg = inlineBg || computedBg;
				const gradientValue = currentBg && isGradientBackgroundValue(currentBg) ? currentBg : "linear-gradient(90deg, #000000, #ffffff)";
				handle.set({
					"background-image": gradientValue,
					"-webkit-background-clip": "text",
					"-webkit-text-fill-color": "transparent"
				});
			}
			handle.commit({ merge: true });
		}
		disposer.listen(textColorTypeSelect, "change", () => {
			const type = textColorTypeSelect.value;
			setTextColorType(type);
			textGradientControl.refresh();
			syncAllFields();
		});
		function syncField(property, force = false) {
			const field = fields[property];
			const target = currentTarget;
			if (field.kind === "font-family") {
				const presetValues = FONT_FAMILY_PRESET_VALUES;
				if (!target || !target.isConnected) {
					var _presetValues$;
					field.select.disabled = true;
					field.select.value = (_presetValues$ = presetValues[0]) !== null && _presetValues$ !== void 0 ? _presetValues$ : "inherit";
					field.custom.input.disabled = true;
					field.custom.input.value = "";
					field.custom.root.style.display = "none";
					return;
				}
				field.select.disabled = false;
				if ((field.handle !== null || isFieldFocused$3(field.select) || isFieldFocused$3(field.custom.input)) && !force) return;
				const displayValue = readInlineValue$4(target, property) || readComputedValue$3(target, property);
				const normalized = displayValue.trim().toLowerCase();
				if (presetValues.includes(normalized)) {
					field.select.value = normalized;
					field.custom.root.style.display = "none";
					field.custom.input.disabled = true;
				} else {
					field.select.value = FONT_FAMILY_CUSTOM_VALUE;
					field.custom.root.style.display = "";
					field.custom.input.disabled = false;
					field.custom.input.value = displayValue;
				}
				return;
			}
			if (field.kind === "text-align") {
				const group = field.group;
				if (!target || !target.isConnected) {
					group.setDisabled(true);
					group.setValue(null);
					return;
				}
				group.setDisabled(false);
				if (field.handle !== null && !force) return;
				const inlineValue = readInlineValue$4(target, property);
				const computedValue = readComputedValue$3(target, property);
				const raw = (inlineValue || computedValue).trim();
				group.setValue(isTextAlignValue(raw) ? raw : "left");
				return;
			}
			if (field.kind === "vertical-align") {
				const group = field.group;
				if (!target || !target.isConnected) {
					group.setDisabled(true);
					group.setValue(null);
					return;
				}
				group.setDisabled(false);
				if (field.handle !== null && !force) return;
				const inlineValue = readInlineValue$4(target, property);
				const computedValue = readComputedValue$3(target, property);
				const raw = (inlineValue || computedValue).trim();
				group.setValue(isVerticalAlignValue(raw) ? raw : "baseline");
				return;
			}
			if (field.kind === "color") {
				const colorField = field.field;
				if (!target || !target.isConnected) {
					colorField.setDisabled(true);
					colorField.setValue("");
					colorField.setPlaceholder("");
					return;
				}
				colorField.setDisabled(false);
				if ((field.handle !== null || colorField.isFocused()) && !force) return;
				const inlineValue = readInlineValue$4(target, property);
				const computedValue = readComputedValue$3(target, property);
				if (inlineValue) {
					colorField.setValue(inlineValue);
					colorField.setPlaceholder(/\bvar\s*\(/i.test(inlineValue) ? computedValue : "");
				} else {
					colorField.setValue(computedValue);
					colorField.setPlaceholder("");
				}
				return;
			}
			const el = field.element;
			if (!target || !target.isConnected) {
				el.disabled = true;
				if (el instanceof HTMLInputElement) {
					el.value = "";
					el.placeholder = "";
					if (field.container) {
						if (property === "font-size" || property === "letter-spacing") field.container.setSuffix("px");
						else if (property === "line-height") field.container.setSuffix(null);
					}
				}
				return;
			}
			el.disabled = false;
			const isEditing = field.handle !== null || isFieldFocused$3(el);
			if (el instanceof HTMLInputElement) {
				if (isEditing && !force) return;
				const displayValue = readInlineValue$4(target, property) || readComputedValue$3(target, property);
				if (field.container) if (property === "font-size" || property === "letter-spacing") {
					const formatted = formatLengthForDisplay(displayValue);
					el.value = formatted.value;
					field.container.setSuffix(formatted.suffix);
				} else if (property === "line-height") if (hasExplicitUnit(displayValue)) {
					const formatted = formatLengthForDisplay(displayValue);
					el.value = formatted.value;
					field.container.setSuffix(formatted.suffix);
				} else {
					el.value = displayValue;
					field.container.setSuffix(null);
				}
				else el.value = displayValue;
				else el.value = displayValue;
				el.placeholder = "";
			} else {
				var _el$options$0$value, _el$options$;
				const inline = readInlineValue$4(target, property);
				const computed = readComputedValue$3(target, property);
				if (isEditing && !force) return;
				const val = inline || computed;
				el.value = Array.from(el.options).some((o) => o.value === val) ? val : (_el$options$0$value = (_el$options$ = el.options[0]) === null || _el$options$ === void 0 ? void 0 : _el$options$.value) !== null && _el$options$0$value !== void 0 ? _el$options$0$value : "";
			}
		}
		function syncAllFields() {
			for (const p of PROPS) syncField(p);
			textColorTypeSelect.disabled = !Boolean(currentTarget && currentTarget.isConnected);
			updateTextColorTypeVisibility();
		}
		function wireSelect(property) {
			const field = fields[property];
			if (field.kind !== "standard") return;
			const select = field.element;
			const preview = () => {
				const handle = beginTransaction(property);
				if (handle) handle.set(select.value);
			};
			disposer.listen(select, "input", preview);
			disposer.listen(select, "change", preview);
			disposer.listen(select, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(select, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					select.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		function wireInput(property, normalize = (v) => v.trim()) {
			const field = fields[property];
			if (field.kind !== "standard") return;
			const input = field.element;
			disposer.listen(input, "input", () => {
				var _field$container$getS, _field$container;
				const handle = beginTransaction(property);
				if (!handle) return;
				const suffix = (_field$container$getS = (_field$container = field.container) === null || _field$container === void 0 ? void 0 : _field$container.getSuffixText()) !== null && _field$container$getS !== void 0 ? _field$container$getS : null;
				handle.set(normalize(input.value, suffix));
			});
			disposer.listen(input, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(input, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					input.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		function wireFontFamily() {
			const field = fields["font-family"];
			if (field.kind !== "font-family") return;
			const { select, custom, controlsContainer } = field;
			const updateCustomVisibility = () => {
				const isCustom = select.value === FONT_FAMILY_CUSTOM_VALUE;
				custom.root.style.display = isCustom ? "" : "none";
				custom.input.disabled = !isCustom;
				if (isCustom) custom.input.focus();
			};
			const previewSelect = () => {
				updateCustomVisibility();
				if (select.value === FONT_FAMILY_CUSTOM_VALUE) return;
				const handle = beginTransaction("font-family");
				if (handle) handle.set(select.value);
			};
			disposer.listen(select, "input", previewSelect);
			disposer.listen(select, "change", previewSelect);
			disposer.listen(custom.input, "input", () => {
				const handle = beginTransaction("font-family");
				if (handle) handle.set(custom.input.value.trim());
			});
			disposer.listen(controlsContainer, "focusout", (e) => {
				const next = e.relatedTarget;
				if (next instanceof Node && controlsContainer.contains(next)) return;
				commitTransaction("font-family");
				syncAllFields();
			});
			disposer.listen(select, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction("font-family");
					syncAllFields();
					select.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction("font-family");
					syncField("font-family", true);
				}
			});
			disposer.listen(custom.input, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction("font-family");
					syncAllFields();
					custom.input.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction("font-family");
					syncField("font-family", true);
				}
			});
		}
		wireFontFamily();
		wireInput("font-size", combineLengthValue);
		wireSelect("font-weight");
		wireInput("line-height", (v, suffix) => {
			const trimmed = v.trim();
			if (!trimmed) return "";
			if (/[a-zA-Z%]/.test(trimmed)) return trimmed;
			return suffix ? `${trimmed}${suffix}` : trimmed;
		});
		wireInput("letter-spacing", combineLengthValue);
		function setTarget(element) {
			if (disposer.isDisposed) return;
			if (element !== currentTarget) commitAllTransactions();
			currentTarget = element;
			if (element && element.isConnected) currentTextColorType = inferTextColorType(element);
			else currentTextColorType = "solid";
			textColorTypeSelect.value = currentTextColorType;
			updateTextColorTypeVisibility();
			textGradientControl.setTarget(element);
			syncAllFields();
		}
		function refresh() {
			if (disposer.isDisposed) return;
			const target = currentTarget;
			if (target && target.isConnected) {
				const inferredType = inferTextColorType(target);
				if (inferredType !== currentTextColorType) {
					currentTextColorType = inferredType;
					textColorTypeSelect.value = inferredType;
				}
			}
			textGradientControl.refresh();
			syncAllFields();
		}
		function dispose() {
			commitAllTransactions();
			currentTarget = null;
			disposer.dispose();
		}
		syncAllFields();
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/components/slider-input.ts
	/**
	* Slider Input Component
	*
	* A reusable "slider + input" control for numeric values:
	* - Left: native range slider for visual manipulation
	* - Right: InputContainer-backed numeric input for precise values
	*
	* Features:
	* - Bidirectional synchronization between slider and input
	* - Supports disabled state
	* - Accessible with ARIA labels
	*
	* Styling is defined in shadow-host.ts:
	* - `.we-slider-input`
	* - `.we-slider-input__slider`
	* - `.we-slider-input__number`
	*/
	/**
	* Create a slider input component with synchronized slider and input
	*/
	function createSliderInput(options) {
		const { sliderAriaLabel, inputAriaLabel, min, max, step, inputMode = "decimal", inputWidthPx = 72 } = options;
		const root = document.createElement("div");
		root.className = "we-slider-input";
		const slider = document.createElement("input");
		slider.type = "range";
		slider.className = "we-slider-input__slider";
		slider.min = String(min);
		slider.max = String(max);
		slider.step = String(step);
		slider.value = String(min);
		slider.setAttribute("aria-label", sliderAriaLabel);
		/**
		* Update the slider's progress color based on current value.
		* Uses CSS custom property --progress for the gradient.
		*/
		function updateSliderProgress() {
			const value = parseFloat(slider.value);
			const minVal = parseFloat(slider.min);
			const maxVal = parseFloat(slider.max);
			const percent = (value - minVal) / (maxVal - minVal) * 100;
			slider.style.setProperty("--progress", `${percent}%`);
		}
		updateSliderProgress();
		slider.addEventListener("input", updateSliderProgress);
		const inputContainer = createInputContainer({
			ariaLabel: inputAriaLabel,
			inputMode,
			prefix: null,
			suffix: null,
			rootClassName: "we-slider-input__number"
		});
		inputContainer.root.style.width = `${inputWidthPx}px`;
		inputContainer.root.style.flex = "0 0 auto";
		root.append(slider, inputContainer.root);
		function setDisabled(disabled) {
			slider.disabled = disabled;
			inputContainer.input.disabled = disabled;
		}
		function setSliderDisabled(disabled) {
			slider.disabled = disabled;
		}
		function setValue(value) {
			const stringValue = String(value);
			slider.value = stringValue;
			inputContainer.input.value = stringValue;
			updateSliderProgress();
		}
		function setSliderValue(value) {
			slider.value = String(value);
			updateSliderProgress();
		}
		return {
			root,
			slider,
			input: inputContainer.input,
			inputContainer,
			setDisabled,
			setSliderDisabled,
			setValue,
			setSliderValue
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/appearance-control.ts
	/**
	* Appearance Control
	*
	* Edits general appearance styles:
	* - overflow (select)
	* - box-sizing (select)
	* - opacity (input)
	*
	* Note: Border and Background controls have been split into separate controls
	* (border-control.ts and background-control.ts) for better organization.
	*/
	var OVERFLOW_VALUES = [
		"visible",
		"hidden",
		"scroll",
		"auto"
	];
	var BOX_SIZING_VALUES = ["content-box", "border-box"];
	function isFieldFocused$2(el) {
		try {
			const rootNode = el.getRootNode();
			if (rootNode instanceof ShadowRoot) return rootNode.activeElement === el;
			return document.activeElement === el;
		} catch (_unused) {
			return false;
		}
	}
	function normalizeOpacity(raw) {
		return raw.trim();
	}
	/** Regex to match valid numeric values for opacity (including decimal) */
	var OPACITY_NUMBER_REGEX = /^-?(?:(?:\d+\.\d+)|(?:\d+\.)|(?:\d+)|(?:\.\d+))$/;
	/**
	* Clamp opacity value to valid range [0, 1]
	*/
	function clampOpacity(value) {
		if (!Number.isFinite(value)) return 1;
		const clamped = Math.min(1, Math.max(0, value));
		return Object.is(clamped, -0) ? 0 : clamped;
	}
	/**
	* Parse a string to a numeric opacity value
	* Returns null if the string is not a valid number
	*/
	function parseOpacityNumber(raw) {
		const trimmed = raw.trim();
		if (!trimmed) return null;
		if (!OPACITY_NUMBER_REGEX.test(trimmed)) return null;
		const normalized = trimmed.endsWith(".") ? trimmed.slice(0, -1) : trimmed;
		const value = Number(normalized);
		if (!Number.isFinite(value)) return null;
		return value;
	}
	function readInlineValue$3(element, property) {
		try {
			var _style$getPropertyVal, _style$getPropertyVal2;
			const style = element.style;
			return (_style$getPropertyVal = style === null || style === void 0 || (_style$getPropertyVal2 = style.getPropertyValue) === null || _style$getPropertyVal2 === void 0 || (_style$getPropertyVal2 = _style$getPropertyVal2.call(style, property)) === null || _style$getPropertyVal2 === void 0 ? void 0 : _style$getPropertyVal2.trim()) !== null && _style$getPropertyVal !== void 0 ? _style$getPropertyVal : "";
		} catch (_unused2) {
			return "";
		}
	}
	function readComputedValue$2(element, property) {
		try {
			return window.getComputedStyle(element).getPropertyValue(property).trim();
		} catch (_unused3) {
			return "";
		}
	}
	function createAppearanceControl(options) {
		const { container, transactionManager } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		const root = document.createElement("div");
		root.className = "we-field-group";
		function createSelectRow(labelText, ariaLabel, values) {
			const row = document.createElement("div");
			row.className = "we-field";
			const label = document.createElement("span");
			label.className = "we-field-label";
			label.textContent = labelText;
			const select = document.createElement("select");
			select.className = "we-select";
			select.setAttribute("aria-label", ariaLabel);
			for (const v of values) {
				const opt = document.createElement("option");
				opt.value = v;
				opt.textContent = v;
				select.appendChild(opt);
			}
			row.append(label, select);
			return {
				row,
				select
			};
		}
		const { row: overflowRow, select: overflowSelect } = createSelectRow("Overflow", "Overflow", OVERFLOW_VALUES);
		const { row: boxSizingRow, select: boxSizingSelect } = createSelectRow("Box Sizing", "Box Sizing", BOX_SIZING_VALUES);
		const opacityRow = document.createElement("div");
		opacityRow.className = "we-field";
		const opacityLabel = document.createElement("span");
		opacityLabel.className = "we-field-label";
		opacityLabel.textContent = "Opacity";
		const opacityMount = document.createElement("div");
		opacityMount.className = "we-field-content";
		opacityRow.append(opacityLabel, opacityMount);
		const opacityControl = createSliderInput({
			sliderAriaLabel: "Opacity slider",
			inputAriaLabel: "Opacity value",
			min: 0,
			max: 1,
			step: .01,
			inputMode: "decimal",
			inputWidthPx: 72
		});
		opacityMount.append(opacityControl.root);
		wireNumberStepping(disposer, opacityControl.input, {
			mode: "number",
			min: 0,
			max: 1,
			step: .01,
			shiftStep: .1,
			altStep: .001
		});
		root.append(overflowRow, boxSizingRow, opacityRow);
		container.appendChild(root);
		disposer.add(() => root.remove());
		const fields = {
			overflow: {
				kind: "select",
				property: "overflow",
				element: overflowSelect,
				handle: null
			},
			"box-sizing": {
				kind: "select",
				property: "box-sizing",
				element: boxSizingSelect,
				handle: null
			},
			opacity: {
				kind: "opacity",
				property: "opacity",
				control: opacityControl,
				handle: null
			}
		};
		const PROPS = [
			"overflow",
			"box-sizing",
			"opacity"
		];
		function beginTransaction(property) {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields[property];
			if (field.handle) return field.handle;
			const handle = transactionManager.beginStyle(target, property);
			field.handle = handle;
			return handle;
		}
		function commitTransaction(property) {
			const field = fields[property];
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackTransaction(property) {
			const field = fields[property];
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.rollback();
		}
		function commitAllTransactions() {
			for (const p of PROPS) commitTransaction(p);
		}
		function syncField(property, force = false) {
			const field = fields[property];
			const target = currentTarget;
			if (field.kind === "opacity") {
				var _ref;
				const { slider, input } = field.control;
				if (!target || !target.isConnected) {
					field.control.setDisabled(true);
					slider.value = "0";
					input.value = "";
					input.placeholder = "";
					return;
				}
				field.control.setDisabled(false);
				if ((field.handle !== null || isFieldFocused$2(slider) || isFieldFocused$2(input)) && !force) return;
				const inlineValue = readInlineValue$3(target, property);
				const computedValue = readComputedValue$2(target, property);
				const displayValue = inlineValue || computedValue;
				input.value = displayValue;
				input.placeholder = "";
				const inlineNumeric = parseOpacityNumber(displayValue);
				const computedNumeric = parseOpacityNumber(computedValue);
				if (inlineValue && inlineNumeric === null) {
					field.control.setSliderDisabled(true);
					if (computedNumeric !== null) field.control.setSliderValue(clampOpacity(computedNumeric));
					return;
				}
				const numeric = (_ref = inlineNumeric !== null && inlineNumeric !== void 0 ? inlineNumeric : computedNumeric) !== null && _ref !== void 0 ? _ref : 1;
				field.control.setSliderDisabled(false);
				field.control.setSliderValue(clampOpacity(numeric));
			} else {
				var _select$options$0$val, _select$options$;
				const select = field.element;
				if (!target || !target.isConnected) {
					select.disabled = true;
					return;
				}
				select.disabled = false;
				if ((field.handle !== null || isFieldFocused$2(select)) && !force) return;
				const inline = readInlineValue$3(target, property);
				const computed = readComputedValue$2(target, property);
				const val = inline || computed;
				select.value = Array.from(select.options).some((o) => o.value === val) ? val : (_select$options$0$val = (_select$options$ = select.options[0]) === null || _select$options$ === void 0 ? void 0 : _select$options$.value) !== null && _select$options$0$val !== void 0 ? _select$options$0$val : "";
			}
		}
		function syncAllFields() {
			for (const p of PROPS) syncField(p);
		}
		function wireOpacity() {
			const field = fields.opacity;
			if (field.kind !== "opacity") return;
			const { slider, input } = field.control;
			/**
			* Commit opacity value with optional clamping for numeric values.
			* Non-numeric values (like CSS variables) are preserved as-is.
			*/
			const commit = () => {
				const raw = normalizeOpacity(input.value);
				const numeric = parseOpacityNumber(raw);
				if (numeric !== null) {
					const clamped = clampOpacity(numeric);
					const clampedStr = String(clamped);
					if (raw !== clampedStr) {
						input.value = clampedStr;
						const handle = field.handle;
						if (handle) handle.set(clampedStr);
					}
				}
				commitTransaction("opacity");
				syncAllFields();
			};
			disposer.listen(slider, "input", () => {
				if (slider.disabled) return;
				input.value = slider.value;
				const handle = beginTransaction("opacity");
				if (handle) handle.set(normalizeOpacity(slider.value));
			});
			disposer.listen(slider, "change", commit);
			disposer.listen(slider, "blur", commit);
			disposer.listen(slider, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction("opacity");
					syncAllFields();
					slider.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction("opacity");
					syncField("opacity", true);
				}
			});
			disposer.listen(input, "input", () => {
				const raw = normalizeOpacity(input.value);
				const handle = beginTransaction("opacity");
				if (handle) handle.set(raw);
				const numeric = parseOpacityNumber(raw);
				if (numeric === null) {
					field.control.setSliderDisabled(raw.length > 0);
					return;
				}
				field.control.setSliderDisabled(false);
				field.control.setSliderValue(clampOpacity(numeric));
			});
			disposer.listen(input, "blur", commit);
			disposer.listen(input, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction("opacity");
					syncAllFields();
					input.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction("opacity");
					syncField("opacity", true);
				}
			});
		}
		function wireSelect(property) {
			const field = fields[property];
			if (field.kind !== "select") return;
			const select = field.element;
			const preview = () => {
				const handle = beginTransaction(property);
				if (handle) handle.set(select.value);
			};
			disposer.listen(select, "input", preview);
			disposer.listen(select, "change", preview);
			disposer.listen(select, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(select, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					select.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		wireSelect("overflow");
		wireSelect("box-sizing");
		wireOpacity();
		function setTarget(element) {
			if (disposer.isDisposed) return;
			if (element !== currentTarget) commitAllTransactions();
			currentTarget = element;
			syncAllFields();
		}
		function refresh() {
			if (disposer.isDisposed) return;
			syncAllFields();
		}
		function dispose() {
			commitAllTransactions();
			currentTarget = null;
			disposer.dispose();
		}
		syncAllFields();
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/border-control.ts
	/**
	* Border Control
	*
	* Edits inline border styles:
	* - edge selector (all/top/right/bottom/left)
	* - border-width (input)
	* - border-style (select: solid/dashed/dotted/none)
	* - border-color (color picker)
	* - border-radius (unified + per-corner editing)
	*/
	var SVG_NS$1 = "http://www.w3.org/2000/svg";
	var BORDER_STYLE_VALUES = [
		"solid",
		"dashed",
		"dotted",
		"none"
	];
	/** Color type for border: solid uses border-color, gradient uses border-image-source */
	var BORDER_COLOR_TYPE_VALUES = ["solid", "gradient"];
	var BORDER_EDGE_VALUES = [
		"all",
		"top",
		"right",
		"bottom",
		"left"
	];
	var BORDER_RADIUS_CORNERS = [
		"top-left",
		"top-right",
		"bottom-right",
		"bottom-left"
	];
	var BORDER_RADIUS_CORNER_PROPERTIES = {
		"top-left": "border-top-left-radius",
		"top-right": "border-top-right-radius",
		"bottom-right": "border-bottom-right-radius",
		"bottom-left": "border-bottom-left-radius"
	};
	var BORDER_RADIUS_TRANSACTION_PROPERTIES = [
		"border-radius",
		"border-top-left-radius",
		"border-top-right-radius",
		"border-bottom-right-radius",
		"border-bottom-left-radius"
	];
	function isFieldFocused$1(el) {
		try {
			const rootNode = el.getRootNode();
			if (rootNode instanceof ShadowRoot) return rootNode.activeElement === el;
			return document.activeElement === el;
		} catch (_unused) {
			return false;
		}
	}
	function readInlineValue$2(element, property) {
		try {
			var _style$getPropertyVal, _style$getPropertyVal2;
			const style = element.style;
			return (_style$getPropertyVal = style === null || style === void 0 || (_style$getPropertyVal2 = style.getPropertyValue) === null || _style$getPropertyVal2 === void 0 || (_style$getPropertyVal2 = _style$getPropertyVal2.call(style, property)) === null || _style$getPropertyVal2 === void 0 ? void 0 : _style$getPropertyVal2.trim()) !== null && _style$getPropertyVal !== void 0 ? _style$getPropertyVal : "";
		} catch (_unused2) {
			return "";
		}
	}
	function readComputedValue$1(element, property) {
		try {
			return window.getComputedStyle(element).getPropertyValue(property).trim();
		} catch (_unused3) {
			return "";
		}
	}
	/**
	* Infer border color type from border-image-source value.
	* Returns 'gradient' if a gradient is detected, 'solid' otherwise.
	*/
	function inferBorderColorType(borderImageSource) {
		const trimmed = borderImageSource.trim().toLowerCase();
		if (!trimmed || trimmed === "none") return "solid";
		if (/\b(?:linear|radial|conic)-gradient\s*\(/i.test(trimmed)) return "gradient";
		return "solid";
	}
	function createBorderEdgeIcon(edge) {
		const svg = document.createElementNS(SVG_NS$1, "svg");
		svg.setAttribute("viewBox", "0 0 15 15");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		svg.setAttribute("focusable", "false");
		const outline = document.createElementNS(SVG_NS$1, "rect");
		outline.setAttribute("x", "3.5");
		outline.setAttribute("y", "3.5");
		outline.setAttribute("width", "8");
		outline.setAttribute("height", "8");
		outline.setAttribute("stroke", "currentColor");
		outline.setAttribute("stroke-width", "1");
		outline.setAttribute("opacity", "0.4");
		svg.appendChild(outline);
		const highlight = document.createElementNS(SVG_NS$1, "path");
		highlight.setAttribute("stroke", "currentColor");
		highlight.setAttribute("stroke-width", "2");
		highlight.setAttribute("stroke-linecap", "round");
		switch (edge) {
			case "all":
				highlight.setAttribute("d", "M3.5 3.5h8v8h-8z");
				break;
			case "top":
				highlight.setAttribute("d", "M3.5 3.5h8");
				break;
			case "right":
				highlight.setAttribute("d", "M11.5 3.5v8");
				break;
			case "bottom":
				highlight.setAttribute("d", "M3.5 11.5h8");
				break;
			case "left":
				highlight.setAttribute("d", "M3.5 3.5v8");
				break;
		}
		svg.appendChild(highlight);
		return svg;
	}
	function createEditCornersIcon() {
		const svg = document.createElementNS(SVG_NS$1, "svg");
		svg.setAttribute("viewBox", "0 0 15 15");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		svg.setAttribute("focusable", "false");
		const path = document.createElementNS(SVG_NS$1, "path");
		path.setAttribute("stroke", "currentColor");
		path.setAttribute("stroke-width", "1.5");
		path.setAttribute("stroke-linecap", "round");
		path.setAttribute("stroke-linejoin", "round");
		path.setAttribute("d", "M4 6V4H6 M9 4H11V6 M11 9V11H9 M6 11H4V9");
		svg.appendChild(path);
		return svg;
	}
	function createCornerIcon(corner) {
		const svg = document.createElementNS(SVG_NS$1, "svg");
		svg.setAttribute("viewBox", "0 0 15 15");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		svg.setAttribute("focusable", "false");
		const path = document.createElementNS(SVG_NS$1, "path");
		path.setAttribute("stroke", "currentColor");
		path.setAttribute("stroke-width", "1.5");
		path.setAttribute("stroke-linecap", "round");
		path.setAttribute("stroke-linejoin", "round");
		switch (corner) {
			case "top-left":
				path.setAttribute("d", "M11 4H6Q4 4 4 6V11");
				break;
			case "top-right":
				path.setAttribute("d", "M4 4H9Q11 4 11 6V11");
				break;
			case "bottom-right":
				path.setAttribute("d", "M11 4V9Q11 11 9 11H4");
				break;
			case "bottom-left":
				path.setAttribute("d", "M4 4V9Q4 11 6 11H11");
				break;
		}
		svg.appendChild(path);
		return svg;
	}
	function createBorderControl(options) {
		const { container, transactionManager, tokensService } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		let currentBorderEdge = "all";
		let currentColorType = "solid";
		const root = document.createElement("div");
		root.className = "we-field-group";
		function createSelectRow(labelText, ariaLabel, values) {
			const row = document.createElement("div");
			row.className = "we-field";
			const label = document.createElement("span");
			label.className = "we-field-label";
			label.textContent = labelText;
			const select = document.createElement("select");
			select.className = "we-select";
			select.setAttribute("aria-label", ariaLabel);
			for (const v of values) {
				const opt = document.createElement("option");
				opt.value = v;
				opt.textContent = v;
				select.appendChild(opt);
			}
			row.append(label, select);
			return {
				row,
				select
			};
		}
		function createColorRow(labelText) {
			const row = document.createElement("div");
			row.className = "we-field";
			const label = document.createElement("span");
			label.className = "we-field-label";
			label.textContent = labelText;
			const colorFieldContainer = document.createElement("div");
			colorFieldContainer.style.flex = "1";
			colorFieldContainer.style.minWidth = "0";
			row.append(label, colorFieldContainer);
			return {
				row,
				colorFieldContainer
			};
		}
		const borderEdgeRow = document.createElement("div");
		borderEdgeRow.className = "we-field";
		const borderEdgeLabel = document.createElement("span");
		borderEdgeLabel.className = "we-field-label";
		borderEdgeLabel.textContent = "Edge";
		const borderEdgeMount = document.createElement("div");
		borderEdgeMount.style.flex = "1";
		borderEdgeRow.append(borderEdgeLabel, borderEdgeMount);
		const borderWidthRow = document.createElement("div");
		borderWidthRow.className = "we-field";
		const borderWidthLabel = document.createElement("span");
		borderWidthLabel.className = "we-field-label";
		borderWidthLabel.textContent = "Width";
		const borderWidthContainer = createInputContainer({
			ariaLabel: "Border Width",
			inputMode: "decimal",
			prefix: null,
			suffix: "px"
		});
		borderWidthRow.append(borderWidthLabel, borderWidthContainer.root);
		const borderWidthInput = borderWidthContainer.input;
		const { row: borderStyleRow, select: borderStyleSelect } = createSelectRow("Style", "Border Style", BORDER_STYLE_VALUES);
		const { row: colorTypeRow, select: colorTypeSelect } = createSelectRow("Type", "Border Color Type", BORDER_COLOR_TYPE_VALUES);
		const { row: borderColorRow, colorFieldContainer: borderColorContainer } = createColorRow("Color");
		const borderGradientMount = document.createElement("div");
		const borderRadiusRow = document.createElement("div");
		borderRadiusRow.className = "we-field";
		const borderRadiusLabel = document.createElement("span");
		borderRadiusLabel.className = "we-field-label";
		borderRadiusLabel.textContent = "Radius";
		const borderRadiusControl = document.createElement("div");
		borderRadiusControl.className = "we-radius-control";
		const borderRadiusUnifiedRow = document.createElement("div");
		borderRadiusUnifiedRow.className = "we-field-row";
		const borderRadiusUnified = createInputContainer({
			ariaLabel: "Border Radius",
			inputMode: "decimal",
			prefix: null,
			suffix: "px"
		});
		borderRadiusUnified.root.style.flex = "1";
		const borderRadiusToggleButton = document.createElement("button");
		borderRadiusToggleButton.type = "button";
		borderRadiusToggleButton.className = "we-toggle-btn";
		borderRadiusToggleButton.setAttribute("aria-label", "Edit corners");
		borderRadiusToggleButton.setAttribute("aria-pressed", "false");
		borderRadiusToggleButton.dataset.tooltip = "Edit corners";
		borderRadiusToggleButton.append(createEditCornersIcon());
		borderRadiusUnifiedRow.append(borderRadiusUnified.root, borderRadiusToggleButton);
		const borderRadiusCornersGrid = document.createElement("div");
		borderRadiusCornersGrid.className = "we-radius-corners-grid";
		borderRadiusCornersGrid.hidden = true;
		const borderRadiusCorners = {
			"top-left": createInputContainer({
				ariaLabel: "Top-left radius",
				inputMode: "decimal",
				prefix: createCornerIcon("top-left"),
				suffix: "px"
			}),
			"top-right": createInputContainer({
				ariaLabel: "Top-right radius",
				inputMode: "decimal",
				prefix: createCornerIcon("top-right"),
				suffix: "px"
			}),
			"bottom-left": createInputContainer({
				ariaLabel: "Bottom-left radius",
				inputMode: "decimal",
				prefix: createCornerIcon("bottom-left"),
				suffix: "px"
			}),
			"bottom-right": createInputContainer({
				ariaLabel: "Bottom-right radius",
				inputMode: "decimal",
				prefix: createCornerIcon("bottom-right"),
				suffix: "px"
			})
		};
		borderRadiusCornersGrid.append(borderRadiusCorners["top-left"].root, borderRadiusCorners["top-right"].root, borderRadiusCorners["bottom-left"].root, borderRadiusCorners["bottom-right"].root);
		borderRadiusControl.append(borderRadiusUnifiedRow);
		borderRadiusRow.append(borderRadiusLabel, borderRadiusControl);
		const borderRadiusField = {
			kind: "border-radius",
			property: "border-radius",
			root: borderRadiusRow,
			unified: borderRadiusUnified,
			toggleButton: borderRadiusToggleButton,
			cornersGrid: borderRadiusCornersGrid,
			corners: borderRadiusCorners,
			handle: null,
			expanded: false,
			mode: null,
			cornersMaterialized: false
		};
		const widthAndRadiusRow = document.createElement("div");
		widthAndRadiusRow.className = "we-field-row";
		borderWidthRow.style.flex = "1";
		borderWidthRow.style.minWidth = "0";
		borderRadiusRow.style.flex = "1";
		borderRadiusRow.style.minWidth = "0";
		widthAndRadiusRow.append(borderWidthRow, borderRadiusRow);
		wireNumberStepping(disposer, borderWidthInput, { mode: "css-length" });
		wireNumberStepping(disposer, borderRadiusUnified.input, { mode: "css-length" });
		for (const corner of BORDER_RADIUS_CORNERS) wireNumberStepping(disposer, borderRadiusCorners[corner].input, { mode: "css-length" });
		root.append(borderEdgeRow, widthAndRadiusRow, borderRadiusCornersGrid, borderStyleRow, colorTypeRow, borderColorRow, borderGradientMount);
		container.appendChild(root);
		disposer.add(() => root.remove());
		const borderEdgeGroup = createIconButtonGroup({
			container: borderEdgeMount,
			ariaLabel: "Border edge",
			columns: 5,
			value: currentBorderEdge,
			items: BORDER_EDGE_VALUES.map((edge) => ({
				value: edge,
				ariaLabel: edge,
				title: edge.charAt(0).toUpperCase() + edge.slice(1),
				icon: createBorderEdgeIcon(edge)
			})),
			onChange: (edge) => {
				if (edge === currentBorderEdge) return;
				commitTransaction("border-width");
				commitTransaction("border-style");
				commitTransaction("border-color");
				currentBorderEdge = edge;
				syncAllFields();
			}
		});
		disposer.add(() => borderEdgeGroup.dispose());
		const borderColorField = createColorField({
			container: borderColorContainer,
			ariaLabel: "Border Color",
			tokensService,
			getTokenTarget: () => currentTarget,
			onInput: (value) => {
				const handle = beginTransaction("border-color");
				if (handle) handle.set(value);
			},
			onCommit: () => {
				commitTransaction("border-color");
				syncAllFields();
			},
			onCancel: () => {
				rollbackTransaction("border-color");
				syncField("border-color", true);
			}
		});
		disposer.add(() => borderColorField.dispose());
		const borderGradientControl = createGradientControl({
			container: borderGradientMount,
			transactionManager,
			tokensService,
			property: "border-image-source",
			allowNone: true
		});
		disposer.add(() => borderGradientControl.dispose());
		const fields = {
			"border-width": {
				kind: "text",
				property: "border-width",
				element: borderWidthInput,
				handle: null
			},
			"border-style": {
				kind: "select",
				property: "border-style",
				element: borderStyleSelect,
				handle: null
			},
			"border-color": {
				kind: "color",
				property: "border-color",
				field: borderColorField,
				handle: null
			},
			"border-radius": borderRadiusField
		};
		const PROPS = [
			"border-width",
			"border-style",
			"border-color",
			"border-radius"
		];
		function resolveBorderProperty(kind) {
			if (currentBorderEdge === "all") return `border-${kind}`;
			return `border-${currentBorderEdge}-${kind}`;
		}
		function resolveCssProperty(property) {
			if (property === "border-width") return resolveBorderProperty("width");
			if (property === "border-style") return resolveBorderProperty("style");
			if (property === "border-color") return resolveBorderProperty("color");
			return property;
		}
		function beginTransaction(property) {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields[property];
			if (field.kind === "border-radius") return null;
			if (field.handle) return field.handle;
			const cssProperty = resolveCssProperty(property);
			const handle = transactionManager.beginStyle(target, cssProperty);
			field.handle = handle;
			return handle;
		}
		function commitTransaction(property) {
			const field = fields[property];
			if (field.kind === "border-radius") return;
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackTransaction(property) {
			const field = fields[property];
			if (field.kind === "border-radius") return;
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.rollback();
		}
		function beginBorderRadiusTransaction() {
			if (disposer.isDisposed) return null;
			const field = fields["border-radius"];
			if (field.kind !== "border-radius") return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			if (field.handle) return field.handle;
			const handle = transactionManager.beginMultiStyle(target, [...BORDER_RADIUS_TRANSACTION_PROPERTIES]);
			field.handle = handle;
			field.mode = null;
			field.cornersMaterialized = false;
			return handle;
		}
		function commitBorderRadiusTransaction() {
			const field = fields["border-radius"];
			if (field.kind !== "border-radius") return;
			const handle = field.handle;
			field.handle = null;
			field.mode = null;
			field.cornersMaterialized = false;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackBorderRadiusTransaction() {
			const field = fields["border-radius"];
			if (field.kind !== "border-radius") return;
			const handle = field.handle;
			field.handle = null;
			field.mode = null;
			field.cornersMaterialized = false;
			if (handle) handle.rollback();
		}
		function commitAllTransactions() {
			for (const p of PROPS) commitTransaction(p);
			commitBorderRadiusTransaction();
		}
		/**
		* Update visibility of color-related rows based on currentColorType.
		*/
		function updateColorTypeVisibility() {
			borderColorRow.hidden = currentColorType !== "solid";
			borderGradientMount.hidden = currentColorType !== "gradient";
		}
		/**
		* Update edge selector disabled state based on color type.
		* Gradient mode requires 'all' edges (border-image doesn't support per-edge).
		*/
		function updateEdgeSelectorState() {
			const hasTarget = Boolean(currentTarget && currentTarget.isConnected);
			if (currentColorType === "gradient") {
				if (currentBorderEdge !== "all") {
					commitTransaction("border-width");
					commitTransaction("border-style");
					commitTransaction("border-color");
					currentBorderEdge = "all";
				}
				borderEdgeGroup.setValue("all");
			}
			borderEdgeGroup.setDisabled(!hasTarget || currentColorType === "gradient");
		}
		/**
		* Set border color type and apply necessary CSS changes.
		* Uses multiStyle transaction to atomically set border-image properties.
		*/
		function setColorType(type) {
			const target = currentTarget;
			currentColorType = type;
			colorTypeSelect.value = type;
			updateColorTypeVisibility();
			updateEdgeSelectorState();
			if (!target || !target.isConnected) return;
			const handle = transactionManager.beginMultiStyle(target, ["border-image-source", "border-image-slice"]);
			if (!handle) return;
			if (type === "solid") handle.set({
				"border-image-source": "none",
				"border-image-slice": ""
			});
			else {
				const inlineSource = readInlineValue$2(target, "border-image-source");
				const computedSource = readComputedValue$1(target, "border-image-source");
				const currentSource = inlineSource || computedSource;
				const gradientValue = currentSource && currentSource.trim() && currentSource.trim().toLowerCase() !== "none" && /\b(?:linear|radial|conic)-gradient\s*\(/i.test(currentSource) ? currentSource : "linear-gradient(90deg, #000000, #ffffff)";
				handle.set({
					"border-image-source": gradientValue,
					"border-image-slice": "1"
				});
			}
			handle.commit({ merge: true });
		}
		disposer.listen(colorTypeSelect, "change", () => {
			const type = colorTypeSelect.value;
			setColorType(type);
			borderGradientControl.refresh();
			syncAllFields();
		});
		function syncField(property, force = false) {
			const field = fields[property];
			const target = currentTarget;
			const cssProperty = resolveCssProperty(property);
			if (field.kind === "border-radius") {
				const hasTarget = Boolean(target && target.isConnected);
				field.unified.input.disabled = !hasTarget;
				field.toggleButton.disabled = !hasTarget;
				for (const corner of BORDER_RADIUS_CORNERS) field.corners[corner].input.disabled = !hasTarget;
				if (!hasTarget || !target) {
					field.unified.input.value = "";
					field.unified.input.placeholder = "";
					field.unified.setSuffix("px");
					for (const corner of BORDER_RADIUS_CORNERS) {
						field.corners[corner].input.value = "";
						field.corners[corner].input.placeholder = "";
						field.corners[corner].setSuffix("px");
					}
					return;
				}
				const isCornerFocused = BORDER_RADIUS_CORNERS.some((c) => isFieldFocused$1(field.corners[c].input));
				if ((field.handle !== null || isFieldFocused$1(field.unified.input) || isCornerFocused) && !force) return;
				const inlineUnified = readInlineValue$2(target, "border-radius");
				if (inlineUnified) {
					const formatted = formatLengthForDisplay(inlineUnified);
					field.unified.input.value = formatted.value;
					field.unified.setSuffix(formatted.suffix);
				} else {
					const tl = readComputedValue$1(target, BORDER_RADIUS_CORNER_PROPERTIES["top-left"]);
					const tr = readComputedValue$1(target, BORDER_RADIUS_CORNER_PROPERTIES["top-right"]);
					const br = readComputedValue$1(target, BORDER_RADIUS_CORNER_PROPERTIES["bottom-right"]);
					const bl = readComputedValue$1(target, BORDER_RADIUS_CORNER_PROPERTIES["bottom-left"]);
					const formatted = formatLengthForDisplay(tl === tr && tl === br && tl === bl ? tl : readComputedValue$1(target, "border-radius"));
					field.unified.input.value = formatted.value;
					field.unified.setSuffix(formatted.suffix);
				}
				field.unified.input.placeholder = "";
				for (const corner of BORDER_RADIUS_CORNERS) {
					const propName = BORDER_RADIUS_CORNER_PROPERTIES[corner];
					const inlineValue = readInlineValue$2(target, propName);
					const computedValue = readComputedValue$1(target, propName);
					const formatted = formatLengthForDisplay(inlineValue || computedValue);
					field.corners[corner].input.value = formatted.value;
					field.corners[corner].input.placeholder = "";
					field.corners[corner].setSuffix(formatted.suffix);
				}
				return;
			}
			if (field.kind === "text") {
				const input = field.element;
				if (!target || !target.isConnected) {
					input.disabled = true;
					input.value = "";
					input.placeholder = "";
					if (property === "border-width") borderWidthContainer.setSuffix("px");
					return;
				}
				input.disabled = false;
				if ((field.handle !== null || isFieldFocused$1(input)) && !force) return;
				const inlineValue = readInlineValue$2(target, cssProperty);
				const computedValue = readComputedValue$1(target, cssProperty);
				if (property === "border-width") {
					const formatted = formatLengthForDisplay(inlineValue || computedValue);
					input.value = formatted.value;
					borderWidthContainer.setSuffix(formatted.suffix);
				} else input.value = inlineValue || computedValue;
				input.placeholder = "";
			} else if (field.kind === "select") {
				var _select$options$0$val, _select$options$;
				const select = field.element;
				if (!target || !target.isConnected) {
					select.disabled = true;
					return;
				}
				select.disabled = false;
				if ((field.handle !== null || isFieldFocused$1(select)) && !force) return;
				const inline = readInlineValue$2(target, cssProperty);
				const computed = readComputedValue$1(target, cssProperty);
				const val = inline || computed;
				select.value = Array.from(select.options).some((o) => o.value === val) ? val : (_select$options$0$val = (_select$options$ = select.options[0]) === null || _select$options$ === void 0 ? void 0 : _select$options$.value) !== null && _select$options$0$val !== void 0 ? _select$options$0$val : "";
			} else {
				const colorField = field.field;
				if (!target || !target.isConnected) {
					colorField.setDisabled(true);
					colorField.setValue("");
					colorField.setPlaceholder("");
					return;
				}
				colorField.setDisabled(false);
				if ((field.handle !== null || colorField.isFocused()) && !force) return;
				const inlineValue = readInlineValue$2(target, cssProperty);
				const computedValue = readComputedValue$1(target, cssProperty);
				if (inlineValue) {
					colorField.setValue(inlineValue);
					colorField.setPlaceholder(/\bvar\s*\(/i.test(inlineValue) ? computedValue : "");
				} else {
					colorField.setValue(computedValue);
					colorField.setPlaceholder("");
				}
			}
		}
		function syncAllFields() {
			for (const p of PROPS) syncField(p);
			colorTypeSelect.disabled = !Boolean(currentTarget && currentTarget.isConnected);
			updateColorTypeVisibility();
			updateEdgeSelectorState();
		}
		function wireTextInput(property) {
			const field = fields[property];
			if (field.kind !== "text") return;
			const input = field.element;
			const getNextValue = property === "border-width" ? () => combineLengthValue(input.value, borderWidthContainer.getSuffixText()) : () => input.value.trim();
			disposer.listen(input, "input", () => {
				const handle = beginTransaction(property);
				if (handle) handle.set(getNextValue());
			});
			disposer.listen(input, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(input, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					input.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		function wireSelect(property) {
			const field = fields[property];
			if (field.kind !== "select") return;
			const select = field.element;
			const preview = () => {
				const handle = beginTransaction(property);
				if (handle) handle.set(select.value);
			};
			disposer.listen(select, "input", preview);
			disposer.listen(select, "change", preview);
			disposer.listen(select, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(select, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					select.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		function wireBorderRadiusControl() {
			const field = fields["border-radius"];
			if (field.kind !== "border-radius") return;
			const setExpanded = (expanded) => {
				field.expanded = expanded;
				field.cornersGrid.hidden = !expanded;
				field.toggleButton.setAttribute("aria-pressed", expanded ? "true" : "false");
			};
			setExpanded(false);
			disposer.listen(field.toggleButton, "click", () => {
				setExpanded(!field.expanded);
			});
			const previewUnified = () => {
				const handle = beginBorderRadiusTransaction();
				if (!handle) return;
				field.mode = "unified";
				field.cornersMaterialized = false;
				const v = combineLengthValue(field.unified.input.value, field.unified.getSuffixText());
				handle.set({
					"border-top-left-radius": "",
					"border-top-right-radius": "",
					"border-bottom-right-radius": "",
					"border-bottom-left-radius": "",
					"border-radius": ""
				});
				handle.set({ "border-radius": v });
			};
			const previewCorner = (corner) => {
				const target = currentTarget;
				if (!target || !target.isConnected) return;
				const handle = beginBorderRadiusTransaction();
				if (!handle) return;
				const cornerProp = BORDER_RADIUS_CORNER_PROPERTIES[corner];
				const container = field.corners[corner];
				const next = combineLengthValue(container.input.value, container.getSuffixText());
				if (field.mode !== "corners" || !field.cornersMaterialized) {
					const initialValues = {
						"border-radius": "",
						"border-top-left-radius": readInlineValue$2(target, "border-top-left-radius") || readComputedValue$1(target, "border-top-left-radius"),
						"border-top-right-radius": readInlineValue$2(target, "border-top-right-radius") || readComputedValue$1(target, "border-top-right-radius"),
						"border-bottom-right-radius": readInlineValue$2(target, "border-bottom-right-radius") || readComputedValue$1(target, "border-bottom-right-radius"),
						"border-bottom-left-radius": readInlineValue$2(target, "border-bottom-left-radius") || readComputedValue$1(target, "border-bottom-left-radius")
					};
					initialValues[cornerProp] = next;
					handle.set(initialValues);
					field.mode = "corners";
					field.cornersMaterialized = true;
					return;
				}
				handle.set({
					"border-radius": "",
					[cornerProp]: next
				});
			};
			disposer.listen(field.unified.input, "input", previewUnified);
			for (const corner of BORDER_RADIUS_CORNERS) disposer.listen(field.corners[corner].input, "input", () => previewCorner(corner));
			disposer.listen(field.root, "focusout", (e) => {
				const next = e.relatedTarget;
				if (next instanceof Node && field.root.contains(next)) return;
				commitBorderRadiusTransaction();
				syncAllFields();
			});
			const wireKeydown = (input) => {
				disposer.listen(input, "keydown", (e) => {
					if (e.key === "Enter") {
						e.preventDefault();
						commitBorderRadiusTransaction();
						syncAllFields();
						input.blur();
					} else if (e.key === "Escape") {
						e.preventDefault();
						rollbackBorderRadiusTransaction();
						syncField("border-radius", true);
					}
				});
			};
			wireKeydown(field.unified.input);
			for (const corner of BORDER_RADIUS_CORNERS) wireKeydown(field.corners[corner].input);
		}
		wireTextInput("border-width");
		wireSelect("border-style");
		wireBorderRadiusControl();
		function setTarget(element) {
			if (disposer.isDisposed) return;
			if (element !== currentTarget) commitAllTransactions();
			currentTarget = element;
			if (element && element.isConnected) currentColorType = inferBorderColorType(readInlineValue$2(element, "border-image-source") || readComputedValue$1(element, "border-image-source"));
			else currentColorType = "solid";
			colorTypeSelect.value = currentColorType;
			if (currentColorType === "gradient") {
				currentBorderEdge = "all";
				borderEdgeGroup.setValue("all");
			}
			borderGradientControl.setTarget(element);
			syncAllFields();
		}
		function refresh() {
			if (disposer.isDisposed) return;
			const target = currentTarget;
			if (target && target.isConnected) {
				const inferredType = inferBorderColorType(readInlineValue$2(target, "border-image-source") || readComputedValue$1(target, "border-image-source"));
				if (inferredType !== currentColorType) {
					currentColorType = inferredType;
					colorTypeSelect.value = inferredType;
					if (inferredType === "gradient") {
						currentBorderEdge = "all";
						borderEdgeGroup.setValue("all");
					}
				}
			}
			borderGradientControl.refresh();
			syncAllFields();
		}
		function dispose() {
			commitAllTransactions();
			currentTarget = null;
			disposer.dispose();
		}
		syncAllFields();
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/background-control.ts
	/**
	* Background Control
	*
	* Edits inline background styles:
	* - type selector (solid/gradient/image)
	* - solid: background-color picker
	* - gradient: gradient editor (reuses gradient-control.ts)
	* - image: background-image URL input
	*/
	var BACKGROUND_TYPE_VALUES = [
		"solid",
		"gradient",
		"image"
	];
	function isFieldFocused(el) {
		try {
			const rootNode = el.getRootNode();
			if (rootNode instanceof ShadowRoot) return rootNode.activeElement === el;
			return document.activeElement === el;
		} catch (_unused) {
			return false;
		}
	}
	function readInlineValue$1(element, property) {
		try {
			var _style$getPropertyVal, _style$getPropertyVal2;
			const style = element.style;
			return (_style$getPropertyVal = style === null || style === void 0 || (_style$getPropertyVal2 = style.getPropertyValue) === null || _style$getPropertyVal2 === void 0 || (_style$getPropertyVal2 = _style$getPropertyVal2.call(style, property)) === null || _style$getPropertyVal2 === void 0 ? void 0 : _style$getPropertyVal2.trim()) !== null && _style$getPropertyVal !== void 0 ? _style$getPropertyVal : "";
		} catch (_unused2) {
			return "";
		}
	}
	function readComputedValue(element, property) {
		try {
			return window.getComputedStyle(element).getPropertyValue(property).trim();
		} catch (_unused3) {
			return "";
		}
	}
	function inferBackgroundType(bgImage) {
		const trimmed = bgImage.trim().toLowerCase();
		if (!trimmed || trimmed === "none") return "solid";
		if (/\b(?:linear|radial|conic)-gradient\s*\(/i.test(trimmed)) return "gradient";
		if (/\burl\s*\(/i.test(trimmed)) return "image";
		return "solid";
	}
	function extractUrlFromBackgroundImage(raw) {
		var _match$2$trim, _match$;
		const match = raw.trim().match(/\burl\(\s*(['"]?)(.*?)\1\s*\)/i);
		return (_match$2$trim = match === null || match === void 0 || (_match$ = match[2]) === null || _match$ === void 0 ? void 0 : _match$.trim()) !== null && _match$2$trim !== void 0 ? _match$2$trim : "";
	}
	function normalizeBackgroundImageUrl(raw) {
		const trimmed = raw.trim();
		if (!trimmed) return "";
		if (/^none$/i.test(trimmed)) return "none";
		if (/^url\s*\(/i.test(trimmed)) return trimmed;
		return `url("${trimmed.replace(/\\/g, "\\\\").replace(/"/g, "\\\"")}")`;
	}
	function createBackgroundControl(options) {
		const { container, transactionManager, tokensService } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		let currentBackgroundType = "solid";
		const root = document.createElement("div");
		root.className = "we-field-group";
		function createInputRow(labelText, ariaLabel) {
			const row = document.createElement("div");
			row.className = "we-field";
			const label = document.createElement("span");
			label.className = "we-field-label";
			label.textContent = labelText;
			const input = document.createElement("input");
			input.type = "text";
			input.className = "we-input";
			input.autocomplete = "off";
			input.setAttribute("aria-label", ariaLabel);
			row.append(label, input);
			return {
				row,
				input
			};
		}
		function createColorRow(labelText) {
			const row = document.createElement("div");
			row.className = "we-field";
			const label = document.createElement("span");
			label.className = "we-field-label";
			label.textContent = labelText;
			const colorFieldContainer = document.createElement("div");
			colorFieldContainer.style.flex = "1";
			colorFieldContainer.style.minWidth = "0";
			row.append(label, colorFieldContainer);
			return {
				row,
				colorFieldContainer
			};
		}
		const bgTypeRow = document.createElement("div");
		bgTypeRow.className = "we-field";
		const bgTypeLabel = document.createElement("span");
		bgTypeLabel.className = "we-field-label";
		bgTypeLabel.textContent = "Type";
		const bgTypeSelect = document.createElement("select");
		bgTypeSelect.className = "we-select";
		bgTypeSelect.setAttribute("aria-label", "Background Type");
		for (const v of BACKGROUND_TYPE_VALUES) {
			const opt = document.createElement("option");
			opt.value = v;
			opt.textContent = v.charAt(0).toUpperCase() + v.slice(1);
			bgTypeSelect.appendChild(opt);
		}
		bgTypeRow.append(bgTypeLabel, bgTypeSelect);
		const { row: bgColorRow, colorFieldContainer: bgColorContainer } = createColorRow("Color");
		const bgGradientMount = document.createElement("div");
		const { row: bgImageRow, input: bgImageInput } = createInputRow("URL", "Background Image URL");
		bgImageInput.placeholder = "https://...";
		bgImageInput.spellcheck = false;
		root.append(bgTypeRow, bgColorRow, bgGradientMount, bgImageRow);
		container.appendChild(root);
		disposer.add(() => root.remove());
		const gradientControl = createGradientControl({
			container: bgGradientMount,
			transactionManager,
			tokensService
		});
		disposer.add(() => gradientControl.dispose());
		const bgColorField = createColorField({
			container: bgColorContainer,
			ariaLabel: "Background Color",
			tokensService,
			getTokenTarget: () => currentTarget,
			onInput: (value) => {
				const handle = beginTransaction("background-color");
				if (handle) handle.set(value);
			},
			onCommit: () => {
				commitTransaction("background-color");
				syncAllFields();
			},
			onCancel: () => {
				rollbackTransaction("background-color");
				syncField("background-color", true);
			}
		});
		disposer.add(() => bgColorField.dispose());
		const fields = {
			"background-color": {
				kind: "color",
				property: "background-color",
				field: bgColorField,
				handle: null
			},
			"background-image": {
				kind: "text",
				property: "background-image",
				element: bgImageInput,
				handle: null
			}
		};
		const PROPS = ["background-color", "background-image"];
		function beginTransaction(property) {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			const field = fields[property];
			if (field.handle) return field.handle;
			const handle = transactionManager.beginStyle(target, property);
			field.handle = handle;
			return handle;
		}
		function commitTransaction(property) {
			const field = fields[property];
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackTransaction(property) {
			const field = fields[property];
			const handle = field.handle;
			field.handle = null;
			if (handle) handle.rollback();
		}
		function commitAllTransactions() {
			for (const p of PROPS) commitTransaction(p);
		}
		function updateBackgroundVisibility() {
			bgColorRow.hidden = currentBackgroundType !== "solid";
			bgGradientMount.hidden = currentBackgroundType !== "gradient";
			bgImageRow.hidden = currentBackgroundType !== "image";
		}
		function setBackgroundType(type) {
			const target = currentTarget;
			currentBackgroundType = type;
			bgTypeSelect.value = type;
			updateBackgroundVisibility();
			if (!target || !target.isConnected) return;
			if (type === "solid") {
				commitTransaction("background-image");
				const handle = transactionManager.beginStyle(target, "background-image");
				if (handle) {
					handle.set("none");
					handle.commit({ merge: true });
				}
			}
		}
		disposer.listen(bgTypeSelect, "change", () => {
			const type = bgTypeSelect.value;
			setBackgroundType(type);
			gradientControl.refresh();
			syncAllFields();
		});
		function syncField(property, force = false) {
			const field = fields[property];
			const target = currentTarget;
			if (field.kind === "text") {
				const input = field.element;
				if (!target || !target.isConnected) {
					input.disabled = true;
					input.value = "";
					input.placeholder = "";
					return;
				}
				input.disabled = false;
				if ((field.handle !== null || isFieldFocused(input)) && !force) return;
				const inlineValue = readInlineValue$1(target, property);
				const computedValue = readComputedValue(target, property);
				const displayValue = inlineValue || computedValue;
				if (property === "background-image") input.value = extractUrlFromBackgroundImage(displayValue);
				else input.value = displayValue;
				input.placeholder = "";
			} else {
				const colorField = field.field;
				if (!target || !target.isConnected) {
					colorField.setDisabled(true);
					colorField.setValue("");
					colorField.setPlaceholder("");
					return;
				}
				colorField.setDisabled(false);
				if ((field.handle !== null || colorField.isFocused()) && !force) return;
				const inlineValue = readInlineValue$1(target, property);
				const computedValue = readComputedValue(target, property);
				if (inlineValue) {
					colorField.setValue(inlineValue);
					colorField.setPlaceholder(/\bvar\s*\(/i.test(inlineValue) ? computedValue : "");
				} else {
					colorField.setValue(computedValue);
					colorField.setPlaceholder("");
				}
			}
		}
		function syncAllFields() {
			for (const p of PROPS) syncField(p);
			bgTypeSelect.disabled = !Boolean(currentTarget && currentTarget.isConnected);
			updateBackgroundVisibility();
		}
		function wireTextInput(property) {
			const field = fields[property];
			if (field.kind !== "text") return;
			const input = field.element;
			const normalize = property === "background-image" ? normalizeBackgroundImageUrl : (v) => v.trim();
			disposer.listen(input, "input", () => {
				const handle = beginTransaction(property);
				if (handle) handle.set(normalize(input.value));
			});
			disposer.listen(input, "blur", () => {
				commitTransaction(property);
				syncAllFields();
			});
			disposer.listen(input, "keydown", (e) => {
				if (e.key === "Enter") {
					e.preventDefault();
					commitTransaction(property);
					syncAllFields();
					input.blur();
				} else if (e.key === "Escape") {
					e.preventDefault();
					rollbackTransaction(property);
					syncField(property, true);
				}
			});
		}
		wireTextInput("background-image");
		function setTarget(element) {
			if (disposer.isDisposed) return;
			if (element !== currentTarget) commitAllTransactions();
			currentTarget = element;
			if (element && element.isConnected) {
				currentBackgroundType = inferBackgroundType(readInlineValue$1(element, "background-image") || readComputedValue(element, "background-image"));
				bgTypeSelect.value = currentBackgroundType;
			} else {
				currentBackgroundType = "solid";
				bgTypeSelect.value = "solid";
			}
			gradientControl.setTarget(element);
			updateBackgroundVisibility();
			syncAllFields();
		}
		function refresh() {
			if (disposer.isDisposed) return;
			gradientControl.refresh();
			syncAllFields();
		}
		function dispose() {
			commitAllTransactions();
			currentTarget = null;
			disposer.dispose();
		}
		updateBackgroundVisibility();
		syncAllFields();
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/controls/effects-control.ts
	/**
	* Effects Control
	*
	* Current scope:
	* - Inline `box-shadow` list editor (Drop Shadow / Inner Shadow)
	*
	* Features:
	* - Add/remove multiple shadow effects
	* - Toggle visibility (hide/show) per shadow
	* - Adjust panel for detailed editing (type, offset, blur, spread, color)
	*
	* Notes:
	* - Rendering reads inline styles only (no computed fallback)
	* - Hidden shadows are kept in memory for the current editor session
	*/
	/**
	* Regex to match CSS length tokens (e.g., "10px", "-5.5em", "0")
	* Note: Does not match calc()/var() - those are treated as "other" tokens
	*/
	var LENGTH_TOKEN_REGEX = /^-?(?:\d+\.?\d*|\.\d+)(?:[a-zA-Z%]+)?$/;
	/** Check if a token looks like a CSS function call (e.g., calc(), var()) */
	function isCssFunctionToken(token) {
		return /^[a-zA-Z_-]+\s*\(/.test(token);
	}
	/**
	* Normalize a length value to include "px" unit if missing
	*/
	function normalizeLength(raw) {
		const trimmed = raw.trim();
		if (!trimmed || trimmed.toLowerCase() === "none") return "";
		if (/^-?(?:\d+|\d*\.\d+)$/.test(trimmed)) return `${trimmed}px`;
		if (/^-?\d+\.$/.test(trimmed)) return `${trimmed.slice(0, -1)}px`;
		return trimmed;
	}
	/**
	* Read inline style value from element
	*/
	function readInlineValue(element, property) {
		try {
			var _style$getPropertyVal, _style$getPropertyVal2;
			const style = element.style;
			return (_style$getPropertyVal = style === null || style === void 0 || (_style$getPropertyVal2 = style.getPropertyValue) === null || _style$getPropertyVal2 === void 0 || (_style$getPropertyVal2 = _style$getPropertyVal2.call(style, property)) === null || _style$getPropertyVal2 === void 0 ? void 0 : _style$getPropertyVal2.trim()) !== null && _style$getPropertyVal !== void 0 ? _style$getPropertyVal : "";
		} catch (_unused2) {
			return "";
		}
	}
	/**
	* Split a CSS value by a separator, respecting parentheses and quotes
	*/
	function splitTopLevel(value, separator) {
		const results = [];
		let depth = 0;
		let quote = null;
		let escape = false;
		let start = 0;
		for (let i = 0; i < value.length; i++) {
			const ch = value[i];
			if (escape) {
				escape = false;
				continue;
			}
			if (ch === "\\") {
				escape = true;
				continue;
			}
			if (quote) {
				if (ch === quote) quote = null;
				continue;
			}
			if (ch === "\"" || ch === "'") {
				quote = ch;
				continue;
			}
			if (ch === "(") {
				depth++;
				continue;
			}
			if (ch === ")") {
				depth = Math.max(0, depth - 1);
				continue;
			}
			if (depth === 0 && ch === separator) {
				results.push(value.slice(start, i));
				start = i + 1;
			}
		}
		results.push(value.slice(start));
		return results;
	}
	/**
	* Tokenize a CSS value by whitespace, respecting parentheses and quotes
	*/
	function tokenizeTopLevel(value) {
		const tokens = [];
		let depth = 0;
		let quote = null;
		let escape = false;
		let buffer = "";
		const flush = () => {
			const t = buffer.trim();
			if (t) tokens.push(t);
			buffer = "";
		};
		for (let i = 0; i < value.length; i++) {
			const ch = value[i];
			if (escape) {
				buffer += ch;
				escape = false;
				continue;
			}
			if (ch === "\\") {
				buffer += ch;
				escape = true;
				continue;
			}
			if (quote) {
				buffer += ch;
				if (ch === quote) quote = null;
				continue;
			}
			if (ch === "\"" || ch === "'") {
				buffer += ch;
				quote = ch;
				continue;
			}
			if (ch === "(") {
				depth++;
				buffer += ch;
				continue;
			}
			if (ch === ")") {
				depth = Math.max(0, depth - 1);
				buffer += ch;
				continue;
			}
			if (depth === 0 && /\s/.test(ch)) {
				flush();
				continue;
			}
			buffer += ch;
		}
		flush();
		return tokens;
	}
	/**
	* Parse a single box-shadow value into components
	*/
	function parseBoxShadow(raw) {
		var _splitTopLevel$0$trim, _splitTopLevel$, _lengthTokens$, _lengthTokens$2, _lengthTokens$3, _lengthTokens$4;
		const trimmed = raw.trim();
		if (!trimmed || trimmed.toLowerCase() === "none") return null;
		const first = (_splitTopLevel$0$trim = (_splitTopLevel$ = splitTopLevel(trimmed, ",")[0]) === null || _splitTopLevel$ === void 0 ? void 0 : _splitTopLevel$.trim()) !== null && _splitTopLevel$0$trim !== void 0 ? _splitTopLevel$0$trim : "";
		if (!first || first.toLowerCase() === "none") return null;
		const tokens = tokenizeTopLevel(first);
		if (tokens.length === 0) return null;
		let inset = false;
		const lengthTokens = [];
		const otherTokens = [];
		for (const token of tokens) {
			if (/^inset$/i.test(token)) {
				inset = true;
				continue;
			}
			if (LENGTH_TOKEN_REGEX.test(token)) lengthTokens.push(token);
			else if (isCssFunctionToken(token) && lengthTokens.length < 4) lengthTokens.push(token);
			else otherTokens.push(token);
		}
		if (lengthTokens.length < 2) return null;
		return {
			inset,
			offsetX: (_lengthTokens$ = lengthTokens[0]) !== null && _lengthTokens$ !== void 0 ? _lengthTokens$ : "",
			offsetY: (_lengthTokens$2 = lengthTokens[1]) !== null && _lengthTokens$2 !== void 0 ? _lengthTokens$2 : "",
			blurRadius: (_lengthTokens$3 = lengthTokens[2]) !== null && _lengthTokens$3 !== void 0 ? _lengthTokens$3 : "",
			spreadRadius: (_lengthTokens$4 = lengthTokens[3]) !== null && _lengthTokens$4 !== void 0 ? _lengthTokens$4 : "",
			color: otherTokens.join(" ").trim()
		};
	}
	/**
	* Format box-shadow components into CSS value
	*/
	function formatBoxShadow(input) {
		const offsetX = normalizeLength(input.offsetX);
		const offsetY = normalizeLength(input.offsetY);
		const blurRadius = normalizeLength(input.blurRadius);
		const spreadRadius = normalizeLength(input.spreadRadius);
		const color = input.color.trim();
		if (!offsetX && !offsetY && !blurRadius && !spreadRadius && !color) return "";
		const parts = [];
		if (input.inset) parts.push("inset");
		parts.push(offsetX || "0px", offsetY || "0px");
		if (blurRadius || spreadRadius) parts.push(blurRadius || "0px");
		if (spreadRadius) parts.push(spreadRadius);
		if (color) parts.push(color);
		return parts.join(" ");
	}
	/**
	* Find a CSS function call (e.g., blur(...)) in a filter value
	* Handles word boundaries to avoid matching "myblur" when looking for "blur"
	*/
	function findCssFunction(value, fnName) {
		const src = value;
		const lower = src.toLowerCase();
		const needle = fnName.toLowerCase();
		let searchIndex = 0;
		while (searchIndex < src.length) {
			const found = lower.indexOf(needle, searchIndex);
			if (found < 0) return null;
			if (found > 0) {
				const prevChar = src[found - 1];
				if (/[a-zA-Z0-9_-]/.test(prevChar)) {
					searchIndex = found + needle.length;
					continue;
				}
			}
			let i = found + needle.length;
			while (i < src.length && /\s/.test(src[i])) i++;
			if (src[i] !== "(") {
				searchIndex = found + needle.length;
				continue;
			}
			const openIndex = i;
			let depth = 0;
			let quote = null;
			let escape = false;
			for (let j = openIndex; j < src.length; j++) {
				const ch = src[j];
				if (escape) {
					escape = false;
					continue;
				}
				if (ch === "\\") {
					escape = true;
					continue;
				}
				if (quote) {
					if (ch === quote) quote = null;
					continue;
				}
				if (ch === "\"" || ch === "'") {
					quote = ch;
					continue;
				}
				if (ch === "(") {
					depth++;
					continue;
				}
				if (ch === ")") {
					depth--;
					if (depth === 0) return {
						start: found,
						end: j + 1,
						args: src.slice(openIndex + 1, j)
					};
					continue;
				}
			}
			return null;
		}
		return null;
	}
	/**
	* Extract blur radius from filter/backdrop-filter value
	*/
	function parseBlurRadius(value) {
		const trimmed = value.trim();
		if (!trimmed || trimmed.toLowerCase() === "none") return "";
		const match = findCssFunction(trimmed, "blur");
		return match ? match.args.trim() : "";
	}
	/**
	* Update blur() function in filter value, preserving other functions
	*/
	function upsertBlurFunction(existing, radius) {
		const base = existing.trim().toLowerCase() === "none" ? "" : existing.trim();
		const match = base ? findCssFunction(base, "blur") : null;
		const normalizedRadius = normalizeLength(radius);
		if (!normalizedRadius) {
			if (!match) return base;
			const left = base.slice(0, match.start).trimEnd();
			const right = base.slice(match.end).trimStart();
			if (left && right) return `${left} ${right}`.trim();
			return (left || right).trim();
		}
		const replacement = `blur(${normalizedRadius})`;
		if (!match) {
			if (!base) return replacement;
			return `${base} ${replacement}`.trim();
		}
		const left = base.slice(0, match.start).trimEnd();
		const right = base.slice(match.end).trimStart();
		const parts = [];
		if (left) parts.push(left);
		parts.push(replacement);
		if (right) parts.push(right);
		return parts.join(" ");
	}
	var SVG_NS = "http://www.w3.org/2000/svg";
	var BOX_SHADOW_PROPERTY = "box-shadow";
	var EFFECT_TYPE_OPTIONS = [
		{
			value: "drop-shadow",
			label: "Drop Shadow",
			category: "shadow"
		},
		{
			value: "inner-shadow",
			label: "Inner Shadow",
			category: "shadow"
		},
		{
			value: "layer-blur",
			label: "Layer Blur",
			category: "blur"
		},
		{
			value: "backdrop-blur",
			label: "Backdrop Blur",
			category: "blur"
		}
	];
	var shadowItemIdCounter = 0;
	function createShadowItemId() {
		try {
			if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
		} catch (_unused4) {}
		shadowItemIdCounter += 1;
		return `shadow_${shadowItemIdCounter}_${Date.now()}`;
	}
	function isShadowEffect(item) {
		return item.type === "drop-shadow" || item.type === "inner-shadow";
	}
	function isBlurEffect(item) {
		return item.type === "layer-blur" || item.type === "backdrop-blur";
	}
	function createDefaultShadowEffect() {
		return {
			id: createShadowItemId(),
			enabled: true,
			type: "drop-shadow",
			kind: "parsed",
			inset: false,
			offsetX: "0px",
			offsetY: "4px",
			blurRadius: "12px",
			spreadRadius: "0px",
			color: "rgba(0, 0, 0, 0.15)"
		};
	}
	function createDefaultBlurEffect(type) {
		return {
			id: createShadowItemId(),
			enabled: true,
			type,
			kind: "parsed",
			radius: "8px"
		};
	}
	function getEffectItemLabel(item) {
		const option = EFFECT_TYPE_OPTIONS.find((o) => o.value === item.type);
		if (option) return option.label;
		if (item.kind === "raw") return "Custom Effect";
		return "Unknown Effect";
	}
	function effectItemKey(item) {
		if (item.kind === "raw") return `raw:${item.property}:${item.rawText.trim()}`;
		if (isShadowEffect(item)) {
			const css = formatBoxShadow({
				inset: item.inset,
				offsetX: item.offsetX,
				offsetY: item.offsetY,
				blurRadius: item.blurRadius,
				spreadRadius: item.spreadRadius,
				color: item.color
			});
			return `shadow:${item.type}:${css.toLowerCase()}`;
		}
		return `blur:${item.type}:${item.radius}`;
	}
	function parseBoxShadowToEffects(raw) {
		const trimmed = raw.trim();
		if (!trimmed || trimmed.toLowerCase() === "none") return [];
		const segments = splitTopLevel(trimmed, ",").map((s) => s.trim()).filter(Boolean);
		const out = [];
		for (const seg of segments) {
			const parsed = parseBoxShadow(seg);
			if (parsed) out.push({
				id: createShadowItemId(),
				enabled: true,
				type: parsed.inset ? "inner-shadow" : "drop-shadow",
				kind: "parsed",
				inset: parsed.inset,
				offsetX: parsed.offsetX,
				offsetY: parsed.offsetY,
				blurRadius: parsed.blurRadius,
				spreadRadius: parsed.spreadRadius,
				color: parsed.color
			});
			else out.push({
				id: createShadowItemId(),
				enabled: true,
				type: "raw",
				kind: "raw",
				property: "box-shadow",
				rawText: seg
			});
		}
		return out;
	}
	function parseFilterBlurToEffect(raw, type) {
		const radius = parseBlurRadius(raw);
		if (!radius) return null;
		return {
			id: createShadowItemId(),
			enabled: true,
			type,
			kind: "parsed",
			radius
		};
	}
	function formatEffectsToBoxShadow(items) {
		return items.filter((item) => item.enabled && (isShadowEffect(item) || item.kind === "raw" && item.property === "box-shadow")).map((item) => {
			if (item.kind === "raw") return item.rawText.trim();
			if (isShadowEffect(item)) return formatBoxShadow({
				inset: item.inset,
				offsetX: item.offsetX,
				offsetY: item.offsetY,
				blurRadius: item.blurRadius,
				spreadRadius: item.spreadRadius,
				color: item.color
			});
			return "";
		}).map((s) => s.trim()).filter(Boolean).join(", ");
	}
	function getBlurEffectByType(items, type) {
		const item = items.find((i) => i.type === type && i.enabled);
		return item && isBlurEffect(item) ? item : null;
	}
	function reconcileEffectItems(prevItems, nextEnabledItems) {
		const usedIds = /* @__PURE__ */ new Set();
		const pool = /* @__PURE__ */ new Map();
		for (const item of prevItems) {
			var _pool$get;
			const key = effectItemKey(item);
			const queue = (_pool$get = pool.get(key)) !== null && _pool$get !== void 0 ? _pool$get : [];
			queue.push(item);
			pool.set(key, queue);
		}
		const reconciledEnabled = nextEnabledItems.map((item) => {
			const key = effectItemKey(item);
			const queue = pool.get(key);
			const match = queue === null || queue === void 0 ? void 0 : queue.shift();
			if (match) {
				usedIds.add(match.id);
				return _objectSpread2(_objectSpread2({}, item), {}, {
					id: match.id,
					enabled: true
				});
			}
			return item;
		});
		const remainingHidden = prevItems.filter((item) => !item.enabled && !usedIds.has(item.id));
		return [...reconciledEnabled, ...remainingHidden];
	}
	function createSvgIcon(pathD, viewBox = "0 0 24 24") {
		const svg = document.createElementNS(SVG_NS, "svg");
		svg.setAttribute("viewBox", viewBox);
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		const path = document.createElementNS(SVG_NS, "path");
		path.setAttribute("d", pathD);
		path.setAttribute("stroke", "currentColor");
		path.setAttribute("stroke-width", "2");
		path.setAttribute("stroke-linecap", "round");
		path.setAttribute("stroke-linejoin", "round");
		svg.append(path);
		return svg;
	}
	function createPlusIcon() {
		return createSvgIcon("M12 5v14M5 12h14");
	}
	function createTrashIcon() {
		return createSvgIcon("M9 6h6M10 6l.5-1.5h3L14 6M7 6l1 14h8l1-14");
	}
	function createAdjustIcon() {
		const svg = document.createElementNS(SVG_NS, "svg");
		svg.setAttribute("viewBox", "0 0 20 20");
		svg.setAttribute("fill", "none");
		svg.setAttribute("aria-hidden", "true");
		const lines = document.createElementNS(SVG_NS, "path");
		lines.setAttribute("d", "M4 5H16 M4 10H16 M4 15H16");
		lines.setAttribute("stroke", "currentColor");
		lines.setAttribute("stroke-width", "2");
		lines.setAttribute("stroke-linecap", "round");
		lines.setAttribute("stroke-linejoin", "round");
		svg.append(lines);
		for (const [cx, cy] of [
			[7, 5],
			[13, 10],
			[9, 15]
		]) {
			const circle = document.createElementNS(SVG_NS, "circle");
			circle.setAttribute("cx", String(cx));
			circle.setAttribute("cy", String(cy));
			circle.setAttribute("r", "1.6");
			circle.setAttribute("fill", "none");
			circle.setAttribute("stroke", "currentColor");
			circle.setAttribute("stroke-width", "2");
			svg.append(circle);
		}
		return svg;
	}
	function createEyeIcon(enabled) {
		if (enabled) {
			const svg = document.createElementNS(SVG_NS, "svg");
			svg.setAttribute("viewBox", "0 0 24 24");
			svg.setAttribute("fill", "none");
			svg.setAttribute("aria-hidden", "true");
			const outline = document.createElementNS(SVG_NS, "path");
			outline.setAttribute("d", "M2.5 12s3.5-7 9.5-7 9.5 7 9.5 7-3.5 7-9.5 7-9.5-7-9.5-7z");
			outline.setAttribute("stroke", "currentColor");
			outline.setAttribute("stroke-width", "2");
			outline.setAttribute("stroke-linecap", "round");
			outline.setAttribute("stroke-linejoin", "round");
			const iris = document.createElementNS(SVG_NS, "circle");
			iris.setAttribute("cx", "12");
			iris.setAttribute("cy", "12");
			iris.setAttribute("r", "3");
			iris.setAttribute("stroke", "currentColor");
			iris.setAttribute("stroke-width", "2");
			svg.append(outline, iris);
			return svg;
		}
		return createSvgIcon("M3 3l18 18M10.6 10.6A3 3 0 0012 15a3 3 0 002.4-4.4M9.5 5.8A10.7 10.7 0 0112 5c6 0 9.5 7 9.5 7a17.4 17.4 0 01-3.1 4.1M6.2 6.2A17.8 17.8 0 002.5 12s3.5 7 9.5 7c1 0 1.9-.2 2.8-.5");
	}
	function createIconButton(ariaLabel) {
		const btn = document.createElement("button");
		btn.type = "button";
		btn.className = "we-effects-icon-btn";
		btn.setAttribute("aria-label", ariaLabel);
		return btn;
	}
	function getViewTypeForItem(item) {
		if (item.kind === "raw") return "raw";
		if (isShadowEffect(item)) return "shadow";
		if (isBlurEffect(item)) return "blur";
		return "raw";
	}
	function createEffectsControl(options) {
		const { container, transactionManager, tokensService, headerActionsContainer } = options;
		const disposer = new Disposer();
		const perTargetItems = /* @__PURE__ */ new WeakMap();
		let currentTarget = null;
		let currentItems = [];
		let itemsById = /* @__PURE__ */ new Map();
		let openItemId = null;
		let activeHandle = null;
		let activeProperty = null;
		const root = document.createElement("div");
		root.className = "we-field-group we-effects";
		container.append(root);
		disposer.add(() => root.remove());
		const addBtn = document.createElement("button");
		addBtn.type = "button";
		addBtn.className = "we-effects-icon-btn";
		addBtn.setAttribute("aria-label", "Add effect");
		addBtn.append(createPlusIcon());
		if (headerActionsContainer) {
			headerActionsContainer.insertBefore(addBtn, headerActionsContainer.firstChild);
			disposer.add(() => addBtn.remove());
		} else {
			const toolbar = document.createElement("div");
			toolbar.className = "we-effects-toolbar";
			toolbar.append(addBtn);
			root.append(toolbar);
		}
		const list = document.createElement("div");
		list.className = "we-effects-list";
		root.append(list);
		const views = /* @__PURE__ */ new Map();
		function setCurrentItems(next) {
			currentItems = next;
			itemsById = new Map(next.map((i) => [i.id, i]));
			const target = currentTarget;
			if (target) perTargetItems.set(target, next);
		}
		function getItem(id) {
			var _itemsById$get;
			return (_itemsById$get = itemsById.get(id)) !== null && _itemsById$get !== void 0 ? _itemsById$get : null;
		}
		function beginTransaction(property) {
			if (disposer.isDisposed) return null;
			const target = currentTarget;
			if (!target || !target.isConnected) return null;
			if (activeHandle && activeProperty === property) return activeHandle;
			if (activeHandle) activeHandle.commit({ merge: true });
			activeHandle = transactionManager.beginStyle(target, property);
			activeProperty = property;
			return activeHandle;
		}
		function commitTransaction() {
			const handle = activeHandle;
			activeHandle = null;
			activeProperty = null;
			if (handle) handle.commit({ merge: true });
		}
		function rollbackTransaction() {
			const handle = activeHandle;
			activeHandle = null;
			activeProperty = null;
			if (handle) handle.rollback();
		}
		function isEditing() {
			return activeHandle !== null || openItemId !== null;
		}
		function previewCurrentItems() {
			const target = currentTarget;
			if (!target || !target.isConnected) return;
			const shadowHandle = beginTransaction(BOX_SHADOW_PROPERTY);
			if (shadowHandle) shadowHandle.set(formatEffectsToBoxShadow(currentItems));
			const layerBlur = getBlurEffectByType(currentItems, "layer-blur");
			if (layerBlur) {
				const filterHandle = beginTransaction("filter");
				if (filterHandle) {
					const existing = readInlineValue(target, "filter");
					filterHandle.set(upsertBlurFunction(existing, layerBlur.radius));
				}
			}
			const backdropBlur = getBlurEffectByType(currentItems, "backdrop-blur");
			if (backdropBlur) {
				const backdropHandle = beginTransaction("backdrop-filter");
				if (backdropHandle) {
					const existing = readInlineValue(target, "backdrop-filter");
					backdropHandle.set(upsertBlurFunction(existing, backdropBlur.radius));
				}
			}
		}
		function applyCurrentItemsDiscrete() {
			var _layerBlur$radius, _backdropBlur$radius;
			const target = currentTarget;
			if (!target || !target.isConnected) return;
			commitTransaction();
			transactionManager.applyStyle(target, BOX_SHADOW_PROPERTY, formatEffectsToBoxShadow(currentItems), { merge: false });
			const layerBlur = getBlurEffectByType(currentItems, "layer-blur");
			const existingFilter = readInlineValue(target, "filter");
			transactionManager.applyStyle(target, "filter", upsertBlurFunction(existingFilter, (_layerBlur$radius = layerBlur === null || layerBlur === void 0 ? void 0 : layerBlur.radius) !== null && _layerBlur$radius !== void 0 ? _layerBlur$radius : ""), { merge: false });
			const backdropBlur = getBlurEffectByType(currentItems, "backdrop-blur");
			const existingBackdrop = readInlineValue(target, "backdrop-filter");
			transactionManager.applyStyle(target, "backdrop-filter", upsertBlurFunction(existingBackdrop, (_backdropBlur$radius = backdropBlur === null || backdropBlur === void 0 ? void 0 : backdropBlur.radius) !== null && _backdropBlur$radius !== void 0 ? _backdropBlur$radius : ""), { merge: false });
		}
		function closePopover(opts) {
			var _opts$commit, _opts$rollback;
			const commit = (_opts$commit = opts === null || opts === void 0 ? void 0 : opts.commit) !== null && _opts$commit !== void 0 ? _opts$commit : false;
			const rollback = (_opts$rollback = opts === null || opts === void 0 ? void 0 : opts.rollback) !== null && _opts$rollback !== void 0 ? _opts$rollback : false;
			if (rollback) rollbackTransaction();
			else if (commit) commitTransaction();
			const wasOpen = openItemId !== null;
			openItemId = null;
			for (const view of views.values()) view.setOpen(false);
			if (wasOpen && !rollback) syncFromTarget(true);
		}
		function setPopoverOpen(id) {
			if (id === openItemId) {
				closePopover({ commit: true });
				return;
			}
			closePopover({ commit: true });
			if (!id) return;
			const view = views.get(id);
			if (!view) return;
			openItemId = id;
			for (const [vid, v] of views) v.setOpen(vid === id);
			view.focusFirst();
		}
		function setLengthInput(containerRef, raw) {
			const formatted = formatLengthForDisplay(raw);
			containerRef.input.value = formatted.value;
			containerRef.setSuffix(formatted.suffix);
		}
		/**
		* Convert an effect item to a new type, preserving compatible fields.
		*/
		function createEffectItemWithType(prev, nextType) {
			var _ref, _shadowPrev$blurRadiu, _shadowPrev$offsetX, _shadowPrev$offsetY, _shadowPrev$spreadRad, _shadowPrev$color;
			if (prev.kind === "raw") return null;
			if (nextType === "layer-blur" || nextType === "backdrop-blur") {
				const base = createDefaultBlurEffect(nextType);
				const mappedRadius = isBlurEffect(prev) ? prev.radius : isShadowEffect(prev) ? prev.blurRadius : base.radius;
				return _objectSpread2(_objectSpread2({}, base), {}, {
					id: prev.id,
					enabled: prev.enabled,
					radius: mappedRadius || base.radius
				});
			}
			const base = createDefaultShadowEffect();
			const shadowPrev = isShadowEffect(prev) ? prev : null;
			const blurPrev = isBlurEffect(prev) ? prev : null;
			const mappedBlurRadius = (_ref = (_shadowPrev$blurRadiu = shadowPrev === null || shadowPrev === void 0 ? void 0 : shadowPrev.blurRadius) !== null && _shadowPrev$blurRadiu !== void 0 ? _shadowPrev$blurRadiu : blurPrev === null || blurPrev === void 0 ? void 0 : blurPrev.radius) !== null && _ref !== void 0 ? _ref : base.blurRadius;
			return _objectSpread2(_objectSpread2({}, base), {}, {
				id: prev.id,
				enabled: prev.enabled,
				type: nextType,
				inset: nextType === "inner-shadow",
				offsetX: (_shadowPrev$offsetX = shadowPrev === null || shadowPrev === void 0 ? void 0 : shadowPrev.offsetX) !== null && _shadowPrev$offsetX !== void 0 ? _shadowPrev$offsetX : base.offsetX,
				offsetY: (_shadowPrev$offsetY = shadowPrev === null || shadowPrev === void 0 ? void 0 : shadowPrev.offsetY) !== null && _shadowPrev$offsetY !== void 0 ? _shadowPrev$offsetY : base.offsetY,
				blurRadius: mappedBlurRadius || base.blurRadius,
				spreadRadius: (_shadowPrev$spreadRad = shadowPrev === null || shadowPrev === void 0 ? void 0 : shadowPrev.spreadRadius) !== null && _shadowPrev$spreadRad !== void 0 ? _shadowPrev$spreadRad : base.spreadRadius,
				color: (_shadowPrev$color = shadowPrev === null || shadowPrev === void 0 ? void 0 : shadowPrev.color) !== null && _shadowPrev$color !== void 0 ? _shadowPrev$color : base.color
			});
		}
		/**
		* Update an effect item's type, potentially converting between shadow/blur.
		*/
		function updateEffectItemType(id, nextType) {
			const prev = getItem(id);
			if (!prev || prev.kind === "raw") return;
			if (prev.type === nextType) return;
			const nextItem = createEffectItemWithType(prev, nextType);
			if (!nextItem) return;
			let nextItems = currentItems.map((it) => it.id === id ? nextItem : it);
			if (nextItem.type === "layer-blur" || nextItem.type === "backdrop-blur") nextItems = nextItems.filter((it) => it.id === id || it.type !== nextItem.type);
			setCurrentItems(nextItems);
			renderList();
			applyCurrentItemsDiscrete();
			if (openItemId === id) {
				var _views$get;
				(_views$get = views.get(id)) === null || _views$get === void 0 || _views$get.focusFirst();
			}
		}
		function createItemView(item) {
			const itemDisposer = new Disposer();
			const wrap = document.createElement("div");
			wrap.className = "we-effects-item-wrap";
			const row = document.createElement("div");
			row.className = "we-effects-item";
			row.dataset.enabled = item.enabled ? "true" : "false";
			row.dataset.open = "false";
			const adjustBtn = createIconButton("Adjust effect");
			adjustBtn.append(createAdjustIcon());
			const nameBtn = document.createElement("button");
			nameBtn.type = "button";
			nameBtn.className = "we-effects-name";
			const eyeBtn = createIconButton("Toggle visibility");
			const deleteBtn = createIconButton("Remove effect");
			deleteBtn.append(createTrashIcon());
			row.append(adjustBtn, nameBtn, eyeBtn, deleteBtn);
			const popover = document.createElement("div");
			popover.className = "we-effects-popover";
			popover.hidden = true;
			wrap.append(row, popover);
			itemDisposer.listen(adjustBtn, "click", (e) => {
				e.preventDefault();
				e.stopPropagation();
				setPopoverOpen(item.id);
			});
			itemDisposer.listen(nameBtn, "click", (e) => {
				e.preventDefault();
				e.stopPropagation();
				setPopoverOpen(item.id);
			});
			itemDisposer.listen(eyeBtn, "click", (e) => {
				e.preventDefault();
				e.stopPropagation();
				const it = getItem(item.id);
				if (!it) return;
				it.enabled = !it.enabled;
				row.dataset.enabled = it.enabled ? "true" : "false";
				eyeBtn.replaceChildren(createEyeIcon(it.enabled));
				applyCurrentItemsDiscrete();
			});
			itemDisposer.listen(deleteBtn, "click", (e) => {
				var _views$get2;
				e.preventDefault();
				e.stopPropagation();
				if (openItemId === item.id) closePopover({ commit: true });
				setCurrentItems(currentItems.filter((i) => i.id !== item.id));
				(_views$get2 = views.get(item.id)) === null || _views$get2 === void 0 || _views$get2.dispose();
				views.delete(item.id);
				renderList();
				applyCurrentItemsDiscrete();
			});
			if (item.kind === "raw") {
				const content = document.createElement("div");
				content.className = "we-effects-popover-content";
				const field = document.createElement("div");
				field.className = "we-field";
				const label = document.createElement("span");
				label.className = "we-field-label";
				label.textContent = "Value";
				const input = document.createElement("input");
				input.type = "text";
				input.className = "we-input";
				input.autocomplete = "off";
				input.spellcheck = false;
				input.setAttribute("aria-label", "Shadow value");
				field.append(label, input);
				content.append(field);
				popover.append(content);
				itemDisposer.listen(input, "input", () => {
					const it = getItem(item.id);
					if (!it || it.kind !== "raw") return;
					it.rawText = input.value;
					previewCurrentItems();
				});
				itemDisposer.listen(input, "blur", () => {
					commitTransaction();
				});
				itemDisposer.listen(input, "keydown", (e) => {
					if (e.key === "Enter") {
						e.preventDefault();
						commitTransaction();
						input.blur();
					} else if (e.key === "Escape") {
						e.preventDefault();
						closePopover({ rollback: true });
						syncFromTarget(true);
					}
				});
				return {
					id: item.id,
					viewType: "raw",
					root: wrap,
					row,
					adjustBtn,
					nameBtn,
					eyeBtn,
					deleteBtn,
					popover,
					rawInput: input,
					disposer: itemDisposer,
					setOpen(open) {
						row.dataset.open = open ? "true" : "false";
						popover.hidden = !open;
					},
					focusFirst() {
						input.focus();
						input.select();
					},
					sync(next) {
						row.dataset.enabled = next.enabled ? "true" : "false";
						nameBtn.textContent = getEffectItemLabel(next);
						eyeBtn.replaceChildren(createEyeIcon(next.enabled));
						if (next.kind === "raw") input.value = next.rawText;
					},
					dispose() {
						itemDisposer.dispose();
						wrap.remove();
					}
				};
			}
			if (isBlurEffect(item)) {
				const content = document.createElement("div");
				content.className = "we-effects-popover-content";
				const typeField = document.createElement("div");
				typeField.className = "we-field";
				const typeLabel = document.createElement("span");
				typeLabel.className = "we-field-label";
				typeLabel.textContent = "Type";
				const typeSelect = document.createElement("select");
				typeSelect.className = "we-select";
				typeSelect.setAttribute("aria-label", "Effect type");
				for (const v of EFFECT_TYPE_OPTIONS) {
					const opt = document.createElement("option");
					opt.value = v.value;
					opt.textContent = v.label;
					typeSelect.append(opt);
				}
				typeField.append(typeLabel, typeSelect);
				const radiusField = document.createElement("div");
				radiusField.className = "we-field";
				const radiusLabel = document.createElement("span");
				radiusLabel.className = "we-field-label";
				radiusLabel.textContent = "Blur";
				const radiusInput = createInputContainer({
					ariaLabel: "Blur radius",
					inputMode: "decimal",
					suffix: "px"
				});
				radiusField.append(radiusLabel, radiusInput.root);
				content.append(typeField, radiusField);
				popover.append(content);
				wireNumberStepping(itemDisposer, radiusInput.input, {
					mode: "css-length",
					min: 0,
					step: 1,
					shiftStep: 10,
					altStep: .1
				});
				itemDisposer.listen(radiusInput.input, "input", () => {
					const it = getItem(item.id);
					if (!it || !isBlurEffect(it)) return;
					it.radius = combineLengthValue(radiusInput.input.value, radiusInput.getSuffixText());
					previewCurrentItems();
				});
				itemDisposer.listen(radiusInput.input, "blur", () => {
					commitTransaction();
					syncFromTarget(true);
				});
				itemDisposer.listen(radiusInput.input, "keydown", (e) => {
					if (e.key === "Enter") {
						e.preventDefault();
						commitTransaction();
						syncFromTarget(true);
						radiusInput.input.blur();
					} else if (e.key === "Escape") {
						e.preventDefault();
						closePopover({ rollback: true });
						syncFromTarget(true);
					}
				});
				const onTypeChange = () => {
					updateEffectItemType(item.id, typeSelect.value);
				};
				itemDisposer.listen(typeSelect, "input", onTypeChange);
				itemDisposer.listen(typeSelect, "change", onTypeChange);
				return {
					id: item.id,
					viewType: "blur",
					root: wrap,
					row,
					adjustBtn,
					nameBtn,
					eyeBtn,
					deleteBtn,
					popover,
					disposer: itemDisposer,
					typeSelect,
					radiusInput,
					setOpen(open) {
						row.dataset.open = open ? "true" : "false";
						popover.hidden = !open;
					},
					focusFirst() {
						radiusInput.input.focus();
						radiusInput.input.select();
					},
					sync(next) {
						row.dataset.enabled = next.enabled ? "true" : "false";
						nameBtn.textContent = getEffectItemLabel(next);
						eyeBtn.replaceChildren(createEyeIcon(next.enabled));
						if (!isBlurEffect(next)) return;
						typeSelect.value = next.type;
						setLengthInput(radiusInput, next.radius);
					},
					dispose() {
						itemDisposer.dispose();
						wrap.remove();
					}
				};
			}
			const content = document.createElement("div");
			content.className = "we-effects-popover-content";
			const typeField = document.createElement("div");
			typeField.className = "we-field";
			const typeLabel = document.createElement("span");
			typeLabel.className = "we-field-label";
			typeLabel.textContent = "Type";
			const typeSelect = document.createElement("select");
			typeSelect.className = "we-select";
			typeSelect.setAttribute("aria-label", "Effect type");
			for (const v of EFFECT_TYPE_OPTIONS) {
				const opt = document.createElement("option");
				opt.value = v.value;
				opt.textContent = v.label;
				typeSelect.append(opt);
			}
			typeField.append(typeLabel, typeSelect);
			const xyRow = document.createElement("div");
			xyRow.className = "we-field-row";
			const x = createInputContainer({
				ariaLabel: "Shadow offset X",
				inputMode: "decimal",
				prefix: "X",
				suffix: "px"
			});
			const y = createInputContainer({
				ariaLabel: "Shadow offset Y",
				inputMode: "decimal",
				prefix: "Y",
				suffix: "px"
			});
			xyRow.append(x.root, y.root);
			const blurRow = document.createElement("div");
			blurRow.className = "we-field-row";
			const blur = createInputContainer({
				ariaLabel: "Shadow blur radius",
				inputMode: "decimal",
				prefix: "B",
				suffix: "px"
			});
			const spread = createInputContainer({
				ariaLabel: "Shadow spread radius",
				inputMode: "decimal",
				prefix: "S",
				suffix: "px"
			});
			blurRow.append(blur.root, spread.root);
			const colorFieldRow = document.createElement("div");
			colorFieldRow.className = "we-field";
			const colorLabel = document.createElement("span");
			colorLabel.className = "we-field-label";
			colorLabel.textContent = "Color";
			const colorMount = document.createElement("div");
			colorMount.style.minWidth = "0";
			colorFieldRow.append(colorLabel, colorMount);
			content.append(typeField, xyRow, blurRow, colorFieldRow);
			popover.append(content);
			wireNumberStepping(itemDisposer, x.input, { mode: "css-length" });
			wireNumberStepping(itemDisposer, y.input, { mode: "css-length" });
			wireNumberStepping(itemDisposer, blur.input, {
				mode: "css-length",
				min: 0,
				step: 1,
				shiftStep: 10,
				altStep: .1
			});
			wireNumberStepping(itemDisposer, spread.input, {
				mode: "css-length",
				step: 1,
				shiftStep: 10,
				altStep: .1
			});
			const colorField = createColorField({
				container: colorMount,
				ariaLabel: "Shadow color",
				tokensService,
				getTokenTarget: () => currentTarget,
				onInput: (value) => {
					const it = getItem(item.id);
					if (!it || !isShadowEffect(it)) return;
					it.color = value;
					previewCurrentItems();
				},
				onCommit: () => {
					commitTransaction();
				},
				onCancel: () => {
					rollbackTransaction();
					syncFromTarget(true);
				}
			});
			itemDisposer.add(() => colorField.dispose());
			const wireShadowLengthField = (containerRef, key) => {
				itemDisposer.listen(containerRef.input, "input", () => {
					const it = getItem(item.id);
					if (!it || !isShadowEffect(it)) return;
					it[key] = combineLengthValue(containerRef.input.value, containerRef.getSuffixText());
					previewCurrentItems();
				});
				itemDisposer.listen(containerRef.input, "blur", () => {
					commitTransaction();
					syncFromTarget(true);
				});
				itemDisposer.listen(containerRef.input, "keydown", (e) => {
					if (e.key === "Enter") {
						e.preventDefault();
						commitTransaction();
						syncFromTarget(true);
						containerRef.input.blur();
					} else if (e.key === "Escape") {
						e.preventDefault();
						rollbackTransaction();
						syncFromTarget(true);
					}
				});
			};
			wireShadowLengthField(x, "offsetX");
			wireShadowLengthField(y, "offsetY");
			wireShadowLengthField(blur, "blurRadius");
			wireShadowLengthField(spread, "spreadRadius");
			const onTypeChange = () => {
				updateEffectItemType(item.id, typeSelect.value);
			};
			itemDisposer.listen(typeSelect, "input", onTypeChange);
			itemDisposer.listen(typeSelect, "change", onTypeChange);
			return {
				id: item.id,
				viewType: "shadow",
				root: wrap,
				row,
				adjustBtn,
				nameBtn,
				eyeBtn,
				deleteBtn,
				popover,
				disposer: itemDisposer,
				typeSelect,
				offsetX: x,
				offsetY: y,
				blur,
				spread,
				colorField,
				setOpen(open) {
					row.dataset.open = open ? "true" : "false";
					popover.hidden = !open;
				},
				focusFirst() {
					typeSelect.focus();
				},
				sync(next) {
					row.dataset.enabled = next.enabled ? "true" : "false";
					nameBtn.textContent = getEffectItemLabel(next);
					eyeBtn.replaceChildren(createEyeIcon(next.enabled));
					if (!isShadowEffect(next)) return;
					typeSelect.value = next.type;
					setLengthInput(x, next.offsetX);
					setLengthInput(y, next.offsetY);
					setLengthInput(blur, next.blurRadius);
					setLengthInput(spread, next.spreadRadius);
					colorField.setValue(next.color);
				},
				dispose() {
					itemDisposer.dispose();
					wrap.remove();
				}
			};
		}
		function renderList() {
			const ids = new Set(currentItems.map((i) => i.id));
			for (const [id, view] of Array.from(views.entries())) if (!ids.has(id)) {
				if (openItemId === id) openItemId = null;
				view.dispose();
				views.delete(id);
			}
			for (const item of currentItems) {
				const existing = views.get(item.id);
				const expectedViewType = getViewTypeForItem(item);
				if (!existing || existing.viewType !== expectedViewType) {
					existing === null || existing === void 0 || existing.dispose();
					views.set(item.id, createItemView(item));
				}
				const view = views.get(item.id);
				view.sync(item);
				view.setOpen(openItemId === item.id);
				list.append(view.root);
			}
		}
		function syncFromTarget(force = false) {
			var _perTargetItems$get;
			const target = currentTarget;
			if (!target || !target.isConnected) {
				addBtn.disabled = true;
				setCurrentItems([]);
				closePopover({ commit: true });
				renderList();
				return;
			}
			addBtn.disabled = false;
			if (!force && isEditing()) return;
			const shadowEffects = parseBoxShadowToEffects(readInlineValue(target, BOX_SHADOW_PROPERTY));
			const layerBlur = parseFilterBlurToEffect(readInlineValue(target, "filter"), "layer-blur");
			const backdropBlur = parseFilterBlurToEffect(readInlineValue(target, "backdrop-filter"), "backdrop-blur");
			const nextEnabled = [
				...shadowEffects,
				...layerBlur ? [layerBlur] : [],
				...backdropBlur ? [backdropBlur] : []
			];
			setCurrentItems(reconcileEffectItems((_perTargetItems$get = perTargetItems.get(target)) !== null && _perTargetItems$get !== void 0 ? _perTargetItems$get : [], nextEnabled));
			renderList();
		}
		disposer.listen(addBtn, "click", (e) => {
			e.preventDefault();
			e.stopPropagation();
			const target = currentTarget;
			if (!target || !target.isConnected) return;
			closePopover({ commit: true });
			const newEffect = createDefaultShadowEffect();
			setCurrentItems([...currentItems, newEffect]);
			renderList();
			applyCurrentItemsDiscrete();
			setPopoverOpen(newEffect.id);
		});
		const handleClickOutside = (e) => {
			const openId = openItemId;
			if (!openId) return;
			const view = views.get(openId);
			if (!view) return;
			const path = typeof e.composedPath === "function" ? e.composedPath() : [];
			if (path.length > 0 ? path.includes(view.root) : (() => {
				const node = e.target;
				return !!(node && view.root.contains(node));
			})()) return;
			closePopover({ commit: true });
		};
		const doc = root.ownerDocument;
		doc.addEventListener("click", handleClickOutside, true);
		disposer.add(() => doc.removeEventListener("click", handleClickOutside, true));
		const handleEscape = (e) => {
			if (e.key !== "Escape") return;
			if (!openItemId) return;
			e.preventDefault();
			e.stopPropagation();
			closePopover({ rollback: true });
			syncFromTarget(true);
		};
		root.addEventListener("keydown", handleEscape, true);
		disposer.add(() => root.removeEventListener("keydown", handleEscape, true));
		function setTarget(element) {
			if (disposer.isDisposed) return;
			if (element !== currentTarget) {
				commitTransaction();
				closePopover({ commit: true });
			}
			currentTarget = element;
			if (element && element.isConnected) {
				var _perTargetItems$get2;
				setCurrentItems((_perTargetItems$get2 = perTargetItems.get(element)) !== null && _perTargetItems$get2 !== void 0 ? _perTargetItems$get2 : []);
			} else setCurrentItems([]);
			syncFromTarget(true);
		}
		function refresh() {
			if (disposer.isDisposed) return;
			syncFromTarget(false);
		}
		function dispose() {
			commitTransaction();
			currentTarget = null;
			for (const view of views.values()) view.dispose();
			views.clear();
			disposer.dispose();
		}
		syncFromTarget(true);
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/components-tree.ts
	/**
	* Components Tree (Phase 3.2)
	*
	* Displays DOM hierarchy for the selected element.
	* Shows:
	* - Ancestor path from document.body to selected element
	* - Direct children of selected element
	* - Highlights selected element in tree
	* - Click to select any visible element
	*
	* MVP Design:
	* - Simple tree structure
	* - No virtual scrolling (limit to reasonable depth)
	* - Compact display with tag#id.class format
	*/
	var MAX_ANCESTORS = 10;
	var MAX_CHILDREN = 20;
	var MAX_CLASSES = 2;
	var MAX_TEXT_LENGTH = 20;
	/**
	* Format element for display: tag#id.class1.class2
	*/
	function formatElementLabel$1(element) {
		var _htmlEl$id, _element$classList;
		const tag = element.tagName.toLowerCase();
		const htmlEl = element;
		let label = tag;
		const id = (_htmlEl$id = htmlEl.id) === null || _htmlEl$id === void 0 ? void 0 : _htmlEl$id.trim();
		if (id) label += `#${id}`;
		const classes = Array.from((_element$classList = element.classList) !== null && _element$classList !== void 0 ? _element$classList : []).slice(0, MAX_CLASSES).filter(Boolean);
		if (classes.length > 0) label += `.${classes.join(".")}`;
		if (!element.children.length) {
			var _element$textContent$, _element$textContent;
			const text = (_element$textContent$ = (_element$textContent = element.textContent) === null || _element$textContent === void 0 ? void 0 : _element$textContent.trim()) !== null && _element$textContent$ !== void 0 ? _element$textContent$ : "";
			if (text.length > 0 && text.length <= MAX_TEXT_LENGTH) label += ` "${text}"`;
			else if (text.length > MAX_TEXT_LENGTH) label += ` "${text.slice(0, MAX_TEXT_LENGTH - 3)}..."`;
		}
		return label;
	}
	/**
	* Get ancestor chain from body to element
	*/
	function getAncestorChain(element) {
		const ancestors = [];
		let current = element.parentElement;
		while (current && ancestors.length < MAX_ANCESTORS) {
			if (current === document.body || current === document.documentElement) {
				ancestors.unshift(current);
				break;
			}
			if (current.shadowRoot) break;
			ancestors.unshift(current);
			current = current.parentElement;
		}
		return ancestors;
	}
	/**
	* Get direct children
	*/
	function getDirectChildren(element) {
		return Array.from(element.children).slice(0, MAX_CHILDREN);
	}
	/**
	* Build tree nodes for display
	*/
	function buildTreeNodes(target) {
		if (!target || !target.isConnected) return [];
		const nodes = [];
		const ancestors = getAncestorChain(target);
		for (let i = 0; i < ancestors.length; i++) nodes.push({
			element: ancestors[i],
			label: formatElementLabel$1(ancestors[i]),
			depth: i,
			isSelected: false,
			isAncestor: true,
			isChild: false
		});
		const selectedDepth = ancestors.length;
		nodes.push({
			element: target,
			label: formatElementLabel$1(target),
			depth: selectedDepth,
			isSelected: true,
			isAncestor: false,
			isChild: false
		});
		const children = getDirectChildren(target);
		for (const child of children) nodes.push({
			element: child,
			label: formatElementLabel$1(child),
			depth: selectedDepth + 1,
			isSelected: false,
			isAncestor: false,
			isChild: true
		});
		return nodes;
	}
	function createComponentsTree(options) {
		const { container, onSelect } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		const root = document.createElement("div");
		root.className = "we-tree";
		const emptyState = document.createElement("div");
		emptyState.className = "we-tree-empty";
		emptyState.textContent = "Select an element to view its DOM hierarchy.";
		const treeList = document.createElement("div");
		treeList.className = "we-tree-list";
		treeList.setAttribute("role", "tree");
		root.append(emptyState, treeList);
		container.append(root);
		disposer.add(() => root.remove());
		function render() {
			const nodes = buildTreeNodes(currentTarget);
			const hasTarget = nodes.length > 0;
			emptyState.hidden = hasTarget;
			treeList.hidden = !hasTarget;
			if (!hasTarget) {
				treeList.innerHTML = "";
				return;
			}
			treeList.innerHTML = "";
			for (const node of nodes) {
				const item = document.createElement("div");
				item.className = "we-tree-item";
				item.setAttribute("role", "treeitem");
				item.style.paddingLeft = `${8 + node.depth * 16}px`;
				if (node.isSelected) {
					item.classList.add("we-tree-item--selected");
					item.setAttribute("aria-selected", "true");
				}
				if (node.isAncestor) item.classList.add("we-tree-item--ancestor");
				if (node.isChild) item.classList.add("we-tree-item--child");
				if (node.depth > 0) {
					const indent = document.createElement("span");
					indent.className = "we-tree-indent";
					indent.textContent = node.isChild ? "└" : "├";
					item.append(indent);
				}
				const icon = document.createElement("span");
				icon.className = "we-tree-icon";
				icon.textContent = "◇";
				item.append(icon);
				const label = document.createElement("span");
				label.className = "we-tree-label";
				label.textContent = node.label;
				item.append(label);
				disposer.listen(item, "click", (e) => {
					e.preventDefault();
					e.stopPropagation();
					if (node.element.isConnected && onSelect) onSelect(node.element);
				});
				disposer.listen(item, "mouseenter", () => {
					if (node.element.isConnected) node.element.classList.add("we-tree-hover-highlight");
				});
				disposer.listen(item, "mouseleave", () => {
					node.element.classList.remove("we-tree-hover-highlight");
				});
				treeList.append(item);
			}
		}
		function setTarget(element) {
			if (disposer.isDisposed) return;
			currentTarget = element;
			render();
		}
		function refresh() {
			if (disposer.isDisposed) return;
			render();
		}
		function dispose() {
			currentTarget = null;
			disposer.dispose();
		}
		render();
		return {
			setTarget,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/class-editor.ts
	/**
	* Class Editor (Phase 4.7)
	*
	* DevTools-like class chips editor for the CSS panel.
	* Displays element's class list as interactive chips with add/remove capability.
	*
	* Features:
	* - Chips display for each class token
	* - Input field for adding new classes
	* - Backspace to remove last chip when input is empty
	* - Enter/Space to commit input
	* - Paste support for multiple classes
	* - Optional autocomplete suggestions
	*
	* This component is UI-only: it does not mutate the DOM element directly.
	* Instead, it emits the next class list via `onClassChange` callback.
	*/
	var MAX_SUGGESTIONS = 8;
	/**
	* Normalize class list: deduplicate, trim, remove empty tokens
	*/
	function normalizeClassList$2(input) {
		const out = [];
		const seen = /* @__PURE__ */ new Set();
		for (const raw of input !== null && input !== void 0 ? input : []) {
			const token = String(raw !== null && raw !== void 0 ? raw : "").trim();
			if (!token) continue;
			if (seen.has(token)) continue;
			seen.add(token);
			out.push(token);
		}
		return out;
	}
	/**
	* Check if two string arrays are equal (order-sensitive)
	*/
	function isSameStringList$1(a, b) {
		if (a.length !== b.length) return false;
		for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
		return true;
	}
	/**
	* Split input string into class tokens
	*/
	function splitTokens(raw) {
		return String(raw !== null && raw !== void 0 ? raw : "").split(/\s+/).map((t) => t.trim()).filter(Boolean);
	}
	/**
	* Read class list from element (compatible with SVG elements)
	*/
	function readElementClasses$1(element) {
		try {
			const list = element.classList;
			if (list && typeof list[Symbol.iterator] === "function") return Array.from(list).filter(Boolean);
		} catch (_unused) {}
		try {
			var _element$getAttribute;
			return ((_element$getAttribute = element.getAttribute("class")) !== null && _element$getAttribute !== void 0 ? _element$getAttribute : "").split(/\s+/).map((t) => t.trim()).filter(Boolean);
		} catch (_unused2) {
			return [];
		}
	}
	/**
	* Create a Class Editor component
	*/
	function createClassEditor(options) {
		const { container, onClassChange, getSuggestions } = options;
		const disposer = new Disposer();
		let currentTarget = null;
		let currentClasses = [];
		let isComposing = false;
		const root = document.createElement("div");
		root.className = "we-class-editor";
		root.setAttribute("role", "group");
		root.setAttribute("aria-label", "Class editor");
		const chipsContainer = document.createElement("div");
		chipsContainer.className = "we-class-chips";
		const input = document.createElement("input");
		input.type = "text";
		input.className = "we-input we-class-input";
		input.autocomplete = "off";
		input.spellcheck = false;
		input.placeholder = "Add class";
		input.setAttribute("aria-label", "Add class");
		const suggestionsContainer = document.createElement("div");
		suggestionsContainer.className = "we-class-suggestions";
		suggestionsContainer.hidden = true;
		root.append(chipsContainer, input, suggestionsContainer);
		container.append(root);
		disposer.add(() => root.remove());
		/**
		* Render class chips
		*/
		function renderChips() {
			chipsContainer.innerHTML = "";
			for (const cls of currentClasses) {
				const chip = document.createElement("span");
				chip.className = "we-class-chip";
				const text = document.createElement("span");
				text.className = "we-class-chip-text";
				text.textContent = cls;
				const removeBtn = document.createElement("button");
				removeBtn.type = "button";
				removeBtn.className = "we-class-chip-remove";
				removeBtn.textContent = "×";
				removeBtn.dataset.action = "remove";
				removeBtn.dataset.value = cls;
				removeBtn.setAttribute("aria-label", `Remove class ${cls}`);
				chip.append(text, removeBtn);
				chipsContainer.append(chip);
			}
		}
		/**
		* Hide suggestions dropdown
		*/
		function hideSuggestions() {
			suggestionsContainer.hidden = true;
			suggestionsContainer.innerHTML = "";
		}
		/**
		* Render suggestions dropdown based on current input prefix
		*/
		function renderSuggestions() {
			var _getSuggestions;
			if (input.disabled) {
				hideSuggestions();
				return;
			}
			const prefix = input.value.trim();
			if (!prefix) {
				hideSuggestions();
				return;
			}
			const allSuggestions = (_getSuggestions = getSuggestions === null || getSuggestions === void 0 ? void 0 : getSuggestions()) !== null && _getSuggestions !== void 0 ? _getSuggestions : [];
			if (!Array.isArray(allSuggestions) || allSuggestions.length === 0) {
				hideSuggestions();
				return;
			}
			const existingSet = new Set(currentClasses);
			const seenSet = /* @__PURE__ */ new Set();
			const filtered = [];
			for (const raw of allSuggestions) {
				const s = String(raw !== null && raw !== void 0 ? raw : "").trim();
				if (!s) continue;
				if (existingSet.has(s)) continue;
				if (!s.startsWith(prefix)) continue;
				if (seenSet.has(s)) continue;
				seenSet.add(s);
				filtered.push(s);
				if (filtered.length >= MAX_SUGGESTIONS) break;
			}
			if (filtered.length === 0) {
				hideSuggestions();
				return;
			}
			suggestionsContainer.hidden = false;
			suggestionsContainer.innerHTML = "";
			for (const suggestion of filtered) {
				const btn = document.createElement("button");
				btn.type = "button";
				btn.className = "we-class-suggestion";
				btn.textContent = suggestion;
				btn.dataset.action = "suggestion";
				btn.dataset.value = suggestion;
				suggestionsContainer.append(btn);
			}
		}
		/**
		* Internal setter for class list (updates UI only)
		*/
		function setClassesInternal(classes) {
			currentClasses = normalizeClassList$2(classes);
			renderChips();
			renderSuggestions();
		}
		/**
		* Commit a new class list
		*/
		function commitClassList(next) {
			if (!currentTarget || !currentTarget.isConnected) return;
			const normalized = normalizeClassList$2(next);
			if (isSameStringList$1(normalized, currentClasses)) {
				renderSuggestions();
				return;
			}
			currentClasses = normalized;
			renderChips();
			renderSuggestions();
			onClassChange(currentClasses.slice());
		}
		/**
		* Add one or more class tokens
		*/
		function addTokens(tokens) {
			if (!tokens.length) return;
			const next = currentClasses.slice();
			const seenSet = new Set(next);
			for (const raw of tokens) {
				const t = String(raw !== null && raw !== void 0 ? raw : "").trim();
				if (!t) continue;
				if (seenSet.has(t)) continue;
				seenSet.add(t);
				next.push(t);
			}
			commitClassList(next);
		}
		/**
		* Remove a specific class token
		*/
		function removeToken(token) {
			const t = String(token !== null && token !== void 0 ? token : "").trim();
			if (!t) return;
			commitClassList(currentClasses.filter((c) => c !== t));
		}
		/**
		* Remove the last class token
		*/
		function removeLastToken() {
			if (currentClasses.length === 0) return;
			commitClassList(currentClasses.slice(0, -1));
		}
		/**
		* Commit tokens from input field and clear it
		*/
		function commitInputTokens() {
			const tokens = splitTokens(input.value);
			if (tokens.length === 0) return;
			addTokens(tokens);
			input.value = "";
			renderSuggestions();
		}
		disposer.listen(suggestionsContainer, "mousedown", (e) => {
			e.preventDefault();
		});
		disposer.listen(chipsContainer, "click", (e) => {
			var _target$closest, _btn$dataset;
			const target = e.target;
			const btn = target === null || target === void 0 || (_target$closest = target.closest) === null || _target$closest === void 0 ? void 0 : _target$closest.call(target, "button[data-action=\"remove\"]");
			const value = btn === null || btn === void 0 || (_btn$dataset = btn.dataset) === null || _btn$dataset === void 0 ? void 0 : _btn$dataset.value;
			if (!btn || !value) return;
			e.preventDefault();
			removeToken(value);
		});
		disposer.listen(suggestionsContainer, "click", (e) => {
			var _target$closest2, _btn$dataset2;
			const target = e.target;
			const btn = target === null || target === void 0 || (_target$closest2 = target.closest) === null || _target$closest2 === void 0 ? void 0 : _target$closest2.call(target, "button[data-action=\"suggestion\"]");
			const value = btn === null || btn === void 0 || (_btn$dataset2 = btn.dataset) === null || _btn$dataset2 === void 0 ? void 0 : _btn$dataset2.value;
			if (!btn || !value) return;
			e.preventDefault();
			addTokens([value]);
			input.value = "";
			renderSuggestions();
			input.focus();
		});
		disposer.listen(input, "compositionstart", () => {
			isComposing = true;
		});
		disposer.listen(input, "compositionend", () => {
			isComposing = false;
			renderSuggestions();
		});
		disposer.listen(input, "input", () => {
			renderSuggestions();
		});
		disposer.listen(input, "blur", () => {
			hideSuggestions();
		});
		disposer.listen(input, "paste", () => {
			window.setTimeout(() => {
				if (disposer.isDisposed) return;
				if (splitTokens(input.value).length > 1) commitInputTokens();
				else renderSuggestions();
			}, 0);
		});
		disposer.listen(input, "keydown", (e) => {
			if (input.disabled) return;
			if (e.key === "Enter") {
				if (isComposing) return;
				e.preventDefault();
				commitInputTokens();
				return;
			}
			if (e.key === " ") {
				if (isComposing) return;
				if (input.value.trim()) {
					e.preventDefault();
					commitInputTokens();
				}
				return;
			}
			if (e.key === "Backspace") {
				if (!input.value && currentClasses.length > 0) {
					e.preventDefault();
					removeLastToken();
				}
				return;
			}
			if (e.key === "Escape") {
				if (!suggestionsContainer.hidden) {
					e.preventDefault();
					hideSuggestions();
				} else if (input.value) {
					e.preventDefault();
					input.value = "";
					renderSuggestions();
				}
			}
		});
		function setTarget(element) {
			if (disposer.isDisposed) return;
			currentTarget = element && element.isConnected ? element : null;
			input.value = "";
			hideSuggestions();
			input.disabled = !currentTarget;
			if (!currentTarget) {
				setClassesInternal([]);
				return;
			}
			setClassesInternal(readElementClasses$1(currentTarget));
		}
		function setClasses(classes) {
			if (disposer.isDisposed) return;
			setClassesInternal(classes);
		}
		function refresh() {
			if (disposer.isDisposed) return;
			const target = currentTarget;
			if (!target || !target.isConnected) {
				setTarget(null);
				return;
			}
			setClassesInternal(readElementClasses$1(target));
		}
		function dispose() {
			currentTarget = null;
			currentClasses = [];
			disposer.dispose();
		}
		setTarget(null);
		return {
			setTarget,
			setClasses,
			refresh,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/css-defaults.ts
	function normalizeTagName$1(tagName) {
		return String(tagName !== null && tagName !== void 0 ? tagName : "").trim().toLowerCase();
	}
	function normalizePropertyName$2(property) {
		return String(property !== null && property !== void 0 ? property : "").trim();
	}
	function createCssDefaultsProvider() {
		let disposed = false;
		let probeRoot = null;
		const probeByTag = /* @__PURE__ */ new Map();
		const cacheByTag = /* @__PURE__ */ new Map();
		function ensureProbeRoot() {
			var _probeRoot$host, _document$documentEle;
			if (disposed) return null;
			if (typeof document === "undefined") return null;
			if (probeRoot === null || probeRoot === void 0 || (_probeRoot$host = probeRoot.host) === null || _probeRoot$host === void 0 ? void 0 : _probeRoot$host.isConnected) return probeRoot;
			const mountPoint = (_document$documentEle = document.documentElement) !== null && _document$documentEle !== void 0 ? _document$documentEle : document.body;
			if (!mountPoint) return null;
			const host = document.createElement("div");
			host.setAttribute("aria-hidden", "true");
			host.style.cssText = "all: initial;display: block;position: fixed;left: -100000px;top: 0;width: 100px;height: 100px;overflow: hidden;pointer-events: none;contain: layout style paint;z-index: -1;visibility: hidden;";
			const shadow = host.attachShadow({ mode: "open" });
			const container = document.createElement("div");
			container.style.cssText = "all: initial; display: block;";
			shadow.append(container);
			mountPoint.append(host);
			probeRoot = {
				host,
				shadow,
				container
			};
			return probeRoot;
		}
		function ensureProbeElement(tagName) {
			const tag = normalizeTagName$1(tagName);
			if (!tag) return null;
			const existing = probeByTag.get(tag);
			if (existing === null || existing === void 0 ? void 0 : existing.isConnected) return existing;
			const root = ensureProbeRoot();
			if (!root) return null;
			let probe;
			try {
				probe = document.createElement(tag);
			} catch (_unused) {
				probe = document.createElement("div");
			}
			root.container.append(probe);
			probeByTag.set(tag, probe);
			return probe;
		}
		function ensureBaselineValues(tagName, properties) {
			var _cacheByTag$get;
			const tag = normalizeTagName$1(tagName);
			if (!tag) return;
			const list = (properties !== null && properties !== void 0 ? properties : []).map((p) => normalizePropertyName$2(p)).filter(Boolean);
			if (list.length === 0) return;
			const perTag = (_cacheByTag$get = cacheByTag.get(tag)) !== null && _cacheByTag$get !== void 0 ? _cacheByTag$get : /* @__PURE__ */ new Map();
			if (!cacheByTag.has(tag)) cacheByTag.set(tag, perTag);
			const missing = [];
			for (const prop of list) if (!perTag.has(prop)) missing.push(prop);
			if (missing.length === 0) return;
			const probe = ensureProbeElement(tag);
			if (!probe) return;
			let computed = null;
			try {
				computed = window.getComputedStyle(probe);
			} catch (_unused2) {
				computed = null;
			}
			if (!computed) {
				for (const prop of missing) perTag.set(prop, "");
				return;
			}
			for (const prop of missing) {
				let value = "";
				try {
					var _computed$getProperty;
					value = String((_computed$getProperty = computed.getPropertyValue(prop)) !== null && _computed$getProperty !== void 0 ? _computed$getProperty : "").trim();
				} catch (_unused3) {
					value = "";
				}
				perTag.set(prop, value);
			}
		}
		function getBaselineValue(tagName, property) {
			var _cacheByTag$get$get, _cacheByTag$get2;
			const tag = normalizeTagName$1(tagName);
			const prop = normalizePropertyName$2(property);
			if (!tag || !prop) return "";
			ensureBaselineValues(tag, [prop]);
			return (_cacheByTag$get$get = (_cacheByTag$get2 = cacheByTag.get(tag)) === null || _cacheByTag$get2 === void 0 ? void 0 : _cacheByTag$get2.get(prop)) !== null && _cacheByTag$get$get !== void 0 ? _cacheByTag$get$get : "";
		}
		function dispose() {
			disposed = true;
			try {
				var _probeRoot$host2;
				probeRoot === null || probeRoot === void 0 || (_probeRoot$host2 = probeRoot.host) === null || _probeRoot$host2 === void 0 || _probeRoot$host2.remove();
			} catch (_unused4) {}
			probeRoot = null;
			probeByTag.clear();
			cacheByTag.clear();
		}
		return {
			ensureBaselineValues,
			getBaselineValue,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/cssom-styles-collector.ts
	var _globalThis$CSSRule, _globalThis$CSSRule2;
	var ZERO_SPEC = [
		0,
		0,
		0,
		0
	];
	function compareSpecificity(a, b) {
		for (let i = 0; i < 4; i++) if (a[i] !== b[i]) return a[i] > b[i] ? 1 : -1;
		return 0;
	}
	function splitSelectorList(input) {
		const out = [];
		let start = 0;
		let depthParen = 0;
		let depthBrack = 0;
		let quote = null;
		for (let i = 0; i < input.length; i++) {
			const ch = input[i];
			if (quote) {
				if (ch === "\\") {
					i += 1;
					continue;
				}
				if (ch === quote) quote = null;
				continue;
			}
			if (ch === "\"" || ch === "'") {
				quote = ch;
				continue;
			}
			if (ch === "\\") {
				i += 1;
				continue;
			}
			if (ch === "[") depthBrack += 1;
			else if (ch === "]" && depthBrack > 0) depthBrack -= 1;
			else if (ch === "(") depthParen += 1;
			else if (ch === ")" && depthParen > 0) depthParen -= 1;
			if (ch === "," && depthParen === 0 && depthBrack === 0) {
				const part = input.slice(start, i).trim();
				if (part) out.push(part);
				start = i + 1;
			}
		}
		const tail = input.slice(start).trim();
		if (tail) out.push(tail);
		return out;
	}
	function maxSpecificity(list) {
		let best = ZERO_SPEC;
		for (const s of list) if (compareSpecificity(s, best) > 0) best = s;
		return best;
	}
	function computeSelectorSpecificity(selector) {
		let ids = 0;
		let classes = 0;
		let types = 0;
		let expectType = true;
		for (let i = 0; i < selector.length; i++) {
			const ch = selector[i];
			if (ch === "\\") {
				i += 1;
				continue;
			}
			if (ch === "[") {
				classes += 1;
				i = consumeBracket(selector, i);
				expectType = false;
				continue;
			}
			if (isCombinatorOrWhitespace(selector, i)) {
				i = consumeWhitespaceAndCombinators(selector, i);
				expectType = true;
				continue;
			}
			if (ch === "#") {
				ids += 1;
				i = consumeIdent(selector, i + 1) - 1;
				expectType = false;
				continue;
			}
			if (ch === ".") {
				classes += 1;
				i = consumeIdent(selector, i + 1) - 1;
				expectType = false;
				continue;
			}
			if (ch === ":") {
				if (selector[i + 1] === ":") {
					types += 1;
					const nameStart = i + 2;
					const nameEnd = consumeIdent(selector, nameStart);
					const name = selector.slice(nameStart, nameEnd).toLowerCase();
					i = nameEnd - 1;
					if (selector[i + 1] === "(" && name === "slotted") {
						const { content, endIndex } = consumeParenFunction(selector, i + 1);
						const maxArg = maxSpecificity(splitSelectorList(content).map(computeSelectorSpecificity));
						ids += maxArg[1];
						classes += maxArg[2];
						types += maxArg[3];
						i = endIndex;
					}
					expectType = false;
					continue;
				}
				const nameStart = i + 1;
				const nameEnd = consumeIdent(selector, nameStart);
				const name = selector.slice(nameStart, nameEnd).toLowerCase();
				if (LEGACY_PSEUDO_ELEMENTS.has(name)) {
					types += 1;
					i = nameEnd - 1;
					expectType = false;
					continue;
				}
				if (selector[nameEnd] === "(") {
					const { content, endIndex } = consumeParenFunction(selector, nameEnd);
					i = endIndex;
					if (name === "where") {
						expectType = false;
						continue;
					}
					if (name === "is" || name === "not" || name === "has") {
						const maxArg = maxSpecificity(splitSelectorList(content).map(computeSelectorSpecificity));
						ids += maxArg[1];
						classes += maxArg[2];
						types += maxArg[3];
						expectType = false;
						continue;
					}
					if (name === "nth-child" || name === "nth-last-child") {
						classes += 1;
						const ofSelectors = extractNthOfSelectorList(content);
						if (ofSelectors) {
							const maxArg = maxSpecificity(splitSelectorList(ofSelectors).map(computeSelectorSpecificity));
							ids += maxArg[1];
							classes += maxArg[2];
							types += maxArg[3];
						}
						expectType = false;
						continue;
					}
					classes += 1;
					expectType = false;
					continue;
				}
				classes += 1;
				i = nameEnd - 1;
				expectType = false;
				continue;
			}
			if (expectType) {
				if (ch === "*") {
					expectType = false;
					continue;
				}
				if (isIdentStart(ch)) {
					types += 1;
					i = consumeIdent(selector, i + 1) - 1;
					expectType = false;
					continue;
				}
			}
		}
		return [
			0,
			ids,
			classes,
			types
		];
	}
	/**
	* For a selector list, returns the matched selector with max specificity among matches.
	*/
	function computeMatchedRuleSpecificity(element, selectorText) {
		const selectors = splitSelectorList(selectorText);
		let bestSel = null;
		let bestSpec = ZERO_SPEC;
		for (const sel of selectors) try {
			if (!element.matches(sel)) continue;
			const spec = computeSelectorSpecificity(sel);
			if (!bestSel || compareSpecificity(spec, bestSpec) > 0) {
				bestSel = sel;
				bestSpec = spec;
			}
		} catch (_unused) {}
		return bestSel ? {
			matchedSelector: bestSel,
			specificity: bestSpec
		} : null;
	}
	var LEGACY_PSEUDO_ELEMENTS = new Set([
		"before",
		"after",
		"first-line",
		"first-letter",
		"selection",
		"backdrop",
		"placeholder"
	]);
	function isIdentStart(ch) {
		return /[a-zA-Z_]/.test(ch) || ch.charCodeAt(0) >= 128;
	}
	function consumeIdent(s, start) {
		let i = start;
		for (; i < s.length; i++) {
			const ch = s[i];
			if (ch === "\\") {
				i += 1;
				continue;
			}
			if (/[a-zA-Z0-9_-]/.test(ch) || ch.charCodeAt(0) >= 128) continue;
			break;
		}
		return i;
	}
	function consumeBracket(s, openIndex) {
		let depth = 1;
		let quote = null;
		for (let i = openIndex + 1; i < s.length; i++) {
			const ch = s[i];
			if (quote) {
				if (ch === "\\") {
					i += 1;
					continue;
				}
				if (ch === quote) quote = null;
				continue;
			}
			if (ch === "\"" || ch === "'") {
				quote = ch;
				continue;
			}
			if (ch === "\\") {
				i += 1;
				continue;
			}
			if (ch === "[") depth += 1;
			else if (ch === "]") {
				depth -= 1;
				if (depth === 0) return i;
			}
		}
		return s.length - 1;
	}
	function consumeParenFunction(s, openParenIndex) {
		let depth = 1;
		let quote = null;
		for (let i = openParenIndex + 1; i < s.length; i++) {
			const ch = s[i];
			if (quote) {
				if (ch === "\\") {
					i += 1;
					continue;
				}
				if (ch === quote) quote = null;
				continue;
			}
			if (ch === "\"" || ch === "'") {
				quote = ch;
				continue;
			}
			if (ch === "\\") {
				i += 1;
				continue;
			}
			if (ch === "[") i = consumeBracket(s, i);
			else if (ch === "(") depth += 1;
			else if (ch === ")") {
				depth -= 1;
				if (depth === 0) return {
					content: s.slice(openParenIndex + 1, i),
					endIndex: i
				};
			}
		}
		return {
			content: s.slice(openParenIndex + 1),
			endIndex: s.length - 1
		};
	}
	function isCombinatorOrWhitespace(s, i) {
		const ch = s[i];
		return /\s/.test(ch) || ch === ">" || ch === "+" || ch === "~" || ch === "|";
	}
	function consumeWhitespaceAndCombinators(s, i) {
		let j = i;
		while (j < s.length && /\s/.test(s[j])) j++;
		if (s[j] === "|" && s[j + 1] === "|") return j + 1;
		if (s[j] === ">" || s[j] === "+" || s[j] === "~" || s[j] === "|") return j;
		return j - 1;
	}
	function extractNthOfSelectorList(content) {
		let depthParen = 0;
		let depthBrack = 0;
		let quote = null;
		for (let i = 0; i < content.length; i++) {
			const ch = content[i];
			if (quote) {
				if (ch === "\\") {
					i += 1;
					continue;
				}
				if (ch === quote) quote = null;
				continue;
			}
			if (ch === "\"" || ch === "'") {
				quote = ch;
				continue;
			}
			if (ch === "\\") {
				i += 1;
				continue;
			}
			if (ch === "[") depthBrack += 1;
			else if (ch === "]" && depthBrack > 0) depthBrack -= 1;
			else if (ch === "(") depthParen += 1;
			else if (ch === ")" && depthParen > 0) depthParen -= 1;
			if (depthParen === 0 && depthBrack === 0) {
				if (isOfTokenAt(content, i)) return content.slice(i + 2).trimStart();
			}
		}
		return null;
	}
	function isOfTokenAt(s, i) {
		if (s[i] !== "o" || s[i + 1] !== "f") return false;
		const prev = s[i - 1];
		const next = s[i + 2];
		const prevOk = prev === void 0 || /\s/.test(prev);
		const nextOk = next === void 0 || /\s/.test(next);
		return prevOk && nextOk;
	}
	var INHERITED_PROPERTIES = new Set([
		"color",
		"color-scheme",
		"caret-color",
		"accent-color",
		"font",
		"font-family",
		"font-feature-settings",
		"font-kerning",
		"font-language-override",
		"font-optical-sizing",
		"font-palette",
		"font-size",
		"font-size-adjust",
		"font-stretch",
		"font-style",
		"font-synthesis",
		"font-synthesis-small-caps",
		"font-synthesis-style",
		"font-synthesis-weight",
		"font-variant",
		"font-variant-alternates",
		"font-variant-caps",
		"font-variant-east-asian",
		"font-variant-emoji",
		"font-variant-ligatures",
		"font-variant-numeric",
		"font-variant-position",
		"font-variation-settings",
		"font-weight",
		"letter-spacing",
		"line-height",
		"text-rendering",
		"text-size-adjust",
		"text-transform",
		"text-indent",
		"text-align",
		"text-align-last",
		"text-justify",
		"text-shadow",
		"text-emphasis-color",
		"text-emphasis-position",
		"text-emphasis-style",
		"text-underline-position",
		"tab-size",
		"white-space",
		"word-break",
		"overflow-wrap",
		"word-spacing",
		"hyphens",
		"line-break",
		"direction",
		"unicode-bidi",
		"writing-mode",
		"text-orientation",
		"text-combine-upright",
		"list-style",
		"list-style-image",
		"list-style-position",
		"list-style-type",
		"border-collapse",
		"border-spacing",
		"caption-side",
		"empty-cells",
		"cursor",
		"visibility",
		"pointer-events",
		"user-select",
		"quotes",
		"orphans",
		"widows",
		"fill",
		"fill-opacity",
		"fill-rule",
		"stroke",
		"stroke-width",
		"stroke-linecap",
		"stroke-linejoin",
		"stroke-miterlimit",
		"stroke-dasharray",
		"stroke-dashoffset",
		"stroke-opacity",
		"paint-order",
		"shape-rendering",
		"image-rendering",
		"color-interpolation",
		"color-interpolation-filters",
		"color-rendering",
		"dominant-baseline",
		"alignment-baseline",
		"baseline-shift",
		"text-anchor",
		"stop-color",
		"stop-opacity",
		"flood-color",
		"flood-opacity",
		"lighting-color",
		"marker",
		"marker-start",
		"marker-mid",
		"marker-end"
	]);
	function isInheritableProperty(property) {
		const p = String(property || "").trim();
		if (!p) return false;
		if (p.startsWith("--")) return true;
		return INHERITED_PROPERTIES.has(p.toLowerCase());
	}
	var SHORTHAND_TO_LONGHANDS = {
		margin: [
			"margin-top",
			"margin-right",
			"margin-bottom",
			"margin-left"
		],
		padding: [
			"padding-top",
			"padding-right",
			"padding-bottom",
			"padding-left"
		],
		inset: [
			"top",
			"right",
			"bottom",
			"left"
		],
		border: [
			"border-top-width",
			"border-right-width",
			"border-bottom-width",
			"border-left-width",
			"border-top-style",
			"border-right-style",
			"border-bottom-style",
			"border-left-style",
			"border-top-color",
			"border-right-color",
			"border-bottom-color",
			"border-left-color"
		],
		"border-width": [
			"border-top-width",
			"border-right-width",
			"border-bottom-width",
			"border-left-width"
		],
		"border-style": [
			"border-top-style",
			"border-right-style",
			"border-bottom-style",
			"border-left-style"
		],
		"border-color": [
			"border-top-color",
			"border-right-color",
			"border-bottom-color",
			"border-left-color"
		],
		"border-top": [
			"border-top-width",
			"border-top-style",
			"border-top-color"
		],
		"border-right": [
			"border-right-width",
			"border-right-style",
			"border-right-color"
		],
		"border-bottom": [
			"border-bottom-width",
			"border-bottom-style",
			"border-bottom-color"
		],
		"border-left": [
			"border-left-width",
			"border-left-style",
			"border-left-color"
		],
		"border-radius": [
			"border-top-left-radius",
			"border-top-right-radius",
			"border-bottom-right-radius",
			"border-bottom-left-radius"
		],
		outline: [
			"outline-color",
			"outline-style",
			"outline-width"
		],
		background: [
			"background-attachment",
			"background-clip",
			"background-color",
			"background-image",
			"background-origin",
			"background-position",
			"background-repeat",
			"background-size"
		],
		font: [
			"font-style",
			"font-variant",
			"font-weight",
			"font-stretch",
			"font-size",
			"line-height",
			"font-family"
		],
		flex: [
			"flex-grow",
			"flex-shrink",
			"flex-basis"
		],
		"flex-flow": ["flex-direction", "flex-wrap"],
		"place-content": ["align-content", "justify-content"],
		"place-items": ["align-items", "justify-items"],
		"place-self": ["align-self", "justify-self"],
		gap: ["row-gap", "column-gap"],
		"grid-gap": ["row-gap", "column-gap"],
		overflow: ["overflow-x", "overflow-y"],
		"grid-area": [
			"grid-row-start",
			"grid-column-start",
			"grid-row-end",
			"grid-column-end"
		],
		"grid-row": ["grid-row-start", "grid-row-end"],
		"grid-column": ["grid-column-start", "grid-column-end"],
		"grid-template": [
			"grid-template-rows",
			"grid-template-columns",
			"grid-template-areas"
		],
		"text-emphasis": ["text-emphasis-style", "text-emphasis-color"],
		"text-decoration": [
			"text-decoration-line",
			"text-decoration-style",
			"text-decoration-color",
			"text-decoration-thickness"
		],
		transition: [
			"transition-property",
			"transition-duration",
			"transition-timing-function",
			"transition-delay"
		],
		animation: [
			"animation-name",
			"animation-duration",
			"animation-timing-function",
			"animation-delay",
			"animation-iteration-count",
			"animation-direction",
			"animation-fill-mode",
			"animation-play-state"
		],
		columns: ["column-width", "column-count"],
		"column-rule": [
			"column-rule-width",
			"column-rule-style",
			"column-rule-color"
		],
		"list-style": [
			"list-style-position",
			"list-style-image",
			"list-style-type"
		]
	};
	function expandToLonghands(property) {
		var _SHORTHAND_TO_LONGHAN;
		const raw = String(property || "").trim();
		if (!raw) return [];
		if (raw.startsWith("--")) return [raw];
		const p = raw.toLowerCase();
		return (_SHORTHAND_TO_LONGHAN = SHORTHAND_TO_LONGHANDS[p]) !== null && _SHORTHAND_TO_LONGHAN !== void 0 ? _SHORTHAND_TO_LONGHAN : [p];
	}
	function normalizePropertyName$1(property) {
		const raw = String(property || "").trim();
		if (!raw) return "";
		if (raw.startsWith("--")) return raw;
		return raw.toLowerCase();
	}
	function compareSourceOrder(a, b) {
		if (a[0] !== b[0]) return a[0] > b[0] ? 1 : -1;
		if (a[1] !== b[1]) return a[1] > b[1] ? 1 : -1;
		if (a[2] !== b[2]) return a[2] > b[2] ? 1 : -1;
		return 0;
	}
	function compareCascade(a, b) {
		if (a.important !== b.important) return a.important ? 1 : -1;
		const spec = compareSpecificity(a.specificity, b.specificity);
		if (spec !== 0) return spec;
		return compareSourceOrder(a.sourceOrder, b.sourceOrder);
	}
	function computeOverrides(candidates) {
		const winners = /* @__PURE__ */ new Map();
		for (const cand of candidates) for (const longhand of cand.affects) {
			const cur = winners.get(longhand);
			if (!cur || compareCascade(cand, cur) > 0) winners.set(longhand, cand);
		}
		const declStatus = /* @__PURE__ */ new Map();
		for (const cand of candidates) declStatus.set(cand.id, "overridden");
		for (const [, winner] of winners) declStatus.set(winner.id, "active");
		return {
			winners,
			declStatus
		};
	}
	var CONTAINER_RULE = (_globalThis$CSSRule = globalThis.CSSRule) === null || _globalThis$CSSRule === void 0 ? void 0 : _globalThis$CSSRule.CONTAINER_RULE;
	var SCOPE_RULE = (_globalThis$CSSRule2 = globalThis.CSSRule) === null || _globalThis$CSSRule2 === void 0 ? void 0 : _globalThis$CSSRule2.SCOPE_RULE;
	function isSheetApplicable(sheet) {
		if (sheet.disabled) return false;
		try {
			var _sheet$media$mediaTex, _sheet$media;
			const mediaText = (_sheet$media$mediaTex = (_sheet$media = sheet.media) === null || _sheet$media === void 0 || (_sheet$media = _sheet$media.mediaText) === null || _sheet$media === void 0 ? void 0 : _sheet$media.trim()) !== null && _sheet$media$mediaTex !== void 0 ? _sheet$media$mediaTex : "";
			if (!mediaText || mediaText.toLowerCase() === "all") return true;
			return window.matchMedia(mediaText).matches;
		} catch (_unused2) {
			return true;
		}
	}
	function describeStyleSheet(sheet, fallbackIndex) {
		const href = typeof sheet.href === "string" ? sheet.href : void 0;
		if (href) {
			var _href$split$pop$split, _href$split$pop;
			return {
				url: href,
				label: (_href$split$pop$split = (_href$split$pop = href.split("/").pop()) === null || _href$split$pop === void 0 ? void 0 : _href$split$pop.split("?")[0]) !== null && _href$split$pop$split !== void 0 ? _href$split$pop$split : href
			};
		}
		const ownerNode = sheet.ownerNode;
		if (ownerNode && ownerNode.nodeType === Node.ELEMENT_NODE) {
			const el = ownerNode;
			if (el.tagName === "STYLE") return { label: `<style #${fallbackIndex}>` };
			if (el.tagName === "LINK") return { label: `<link #${fallbackIndex}>` };
		}
		return { label: `<constructed #${fallbackIndex}>` };
	}
	function safeReadCssRules(sheet) {
		try {
			return sheet.cssRules;
		} catch (_unused3) {
			return null;
		}
	}
	function evalMediaRule(rule, warnings) {
		try {
			var _rule$media$mediaText, _rule$media;
			const mediaText = (_rule$media$mediaText = (_rule$media = rule.media) === null || _rule$media === void 0 || (_rule$media = _rule$media.mediaText) === null || _rule$media === void 0 ? void 0 : _rule$media.trim()) !== null && _rule$media$mediaText !== void 0 ? _rule$media$mediaText : "";
			if (!mediaText || mediaText.toLowerCase() === "all") return true;
			return window.matchMedia(mediaText).matches;
		} catch (e) {
			warnings.push(`Failed to evaluate @media rule: ${String(e)}`);
			return false;
		}
	}
	function evalSupportsRule(rule, warnings) {
		try {
			var _rule$conditionText$t, _rule$conditionText, _CSS;
			const cond = (_rule$conditionText$t = (_rule$conditionText = rule.conditionText) === null || _rule$conditionText === void 0 ? void 0 : _rule$conditionText.trim()) !== null && _rule$conditionText$t !== void 0 ? _rule$conditionText$t : "";
			if (!cond) return true;
			if (typeof ((_CSS = CSS) === null || _CSS === void 0 ? void 0 : _CSS.supports) !== "function") return true;
			return CSS.supports(cond);
		} catch (e) {
			warnings.push(`Failed to evaluate @supports rule: ${String(e)}`);
			return false;
		}
	}
	function createRuleIndexForRoot(root, rootId) {
		const warnings = [];
		const flatRules = [];
		let rulesScanned = 0;
		const docOrShadow = root;
		const styleSheets = [];
		try {
			var _docOrShadow$styleShe;
			for (const s of Array.from((_docOrShadow$styleShe = docOrShadow.styleSheets) !== null && _docOrShadow$styleShe !== void 0 ? _docOrShadow$styleShe : [])) if (s && s instanceof CSSStyleSheet) styleSheets.push(s);
		} catch (_unused4) {}
		try {
			var _docOrShadow$adoptedS;
			const adopted = Array.from((_docOrShadow$adoptedS = docOrShadow.adoptedStyleSheets) !== null && _docOrShadow$adoptedS !== void 0 ? _docOrShadow$adoptedS : []);
			for (const s of adopted) if (s && s instanceof CSSStyleSheet) styleSheets.push(s);
		} catch (_unused5) {}
		let order = 0;
		function walkRuleList(list, ctx) {
			for (const rule of Array.from(list)) {
				rulesScanned += 1;
				if (CONTAINER_RULE && rule.type === CONTAINER_RULE) {
					warnings.push("Skipped @container rules (not evaluated in CSSOM collector)");
					continue;
				}
				if (SCOPE_RULE && rule.type === SCOPE_RULE) {
					warnings.push("Skipped @scope rules (not evaluated in CSSOM collector)");
					continue;
				}
				if (rule.type === CSSRule.IMPORT_RULE) {
					const importRule = rule;
					try {
						var _importRule$media$med, _importRule$media;
						const mediaText = (_importRule$media$med = (_importRule$media = importRule.media) === null || _importRule$media === void 0 || (_importRule$media = _importRule$media.mediaText) === null || _importRule$media === void 0 ? void 0 : _importRule$media.trim()) !== null && _importRule$media$med !== void 0 ? _importRule$media$med : "";
						if (mediaText && mediaText.toLowerCase() !== "all" && !window.matchMedia(mediaText).matches) continue;
					} catch (_unused6) {}
					const imported = importRule.styleSheet;
					if (imported) {
						if (ctx.stack.has(imported)) {
							var _src$url;
							const src = describeStyleSheet(imported, ctx.sheetIndex);
							warnings.push(`Detected @import cycle, skipping: ${(_src$url = src.url) !== null && _src$url !== void 0 ? _src$url : src.label}`);
							continue;
						}
						ctx.stack.add(imported);
						try {
							if (!isSheetApplicable(imported)) continue;
							const cssRules = safeReadCssRules(imported);
							const src = describeStyleSheet(imported, ctx.sheetIndex);
							if (!cssRules) {
								var _src$url2;
								warnings.push(`Skipped @import stylesheet (cannot access cssRules, likely cross-origin): ${(_src$url2 = src.url) !== null && _src$url2 !== void 0 ? _src$url2 : src.label}`);
								continue;
							}
							walkRuleList(cssRules, {
								sheetIndex: ctx.sheetIndex,
								sourceForRules: src,
								topSheet: imported,
								stack: ctx.stack
							});
						} finally {
							ctx.stack.delete(imported);
						}
					}
					continue;
				}
				if (rule.type === CSSRule.MEDIA_RULE) {
					if (evalMediaRule(rule, warnings)) walkRuleList(rule.cssRules, ctx);
					continue;
				}
				if (rule.type === CSSRule.SUPPORTS_RULE) {
					if (evalSupportsRule(rule, warnings)) walkRuleList(rule.cssRules, ctx);
					continue;
				}
				if (rule.type === CSSRule.STYLE_RULE) {
					var _styleRule$selectorTe;
					const styleRule = rule;
					flatRules.push({
						sheetIndex: ctx.sheetIndex,
						order: order++,
						selectorText: (_styleRule$selectorTe = styleRule.selectorText) !== null && _styleRule$selectorTe !== void 0 ? _styleRule$selectorTe : "",
						style: styleRule.style,
						source: ctx.sourceForRules
					});
					continue;
				}
				const anyRule = rule;
				if (anyRule.cssRules && typeof anyRule.cssRules.length === "number") try {
					walkRuleList(anyRule.cssRules, ctx);
				} catch (_unused7) {}
			}
		}
		for (let sheetIndex = 0; sheetIndex < styleSheets.length; sheetIndex++) {
			const sheet = styleSheets[sheetIndex];
			if (!isSheetApplicable(sheet)) continue;
			const sheetSource = describeStyleSheet(sheet, sheetIndex);
			const cssRules = safeReadCssRules(sheet);
			if (!cssRules) {
				var _sheetSource$url;
				warnings.push(`Skipped stylesheet (cannot access cssRules, likely cross-origin): ${(_sheetSource$url = sheetSource.url) !== null && _sheetSource$url !== void 0 ? _sheetSource$url : sheetSource.label}`);
				continue;
			}
			const recursionStack = /* @__PURE__ */ new Set();
			recursionStack.add(sheet);
			walkRuleList(cssRules, {
				sheetIndex,
				sourceForRules: sheetSource,
				topSheet: sheet,
				stack: recursionStack
			});
		}
		return {
			root,
			rootId,
			flatRules,
			warnings,
			stats: {
				styleSheets: styleSheets.length,
				rulesScanned
			}
		};
	}
	function readStyleDecls(style) {
		var _style$length;
		const out = [];
		const len = Number((_style$length = style === null || style === void 0 ? void 0 : style.length) !== null && _style$length !== void 0 ? _style$length : 0);
		for (let i = 0; i < len; i++) {
			let prop = "";
			try {
				prop = style.item(i);
			} catch (_unused8) {
				prop = "";
			}
			prop = normalizePropertyName$1(prop);
			if (!prop) continue;
			let value = "";
			let important = false;
			try {
				var _style$getPropertyVal, _style$getPropertyPri;
				value = (_style$getPropertyVal = style.getPropertyValue(prop)) !== null && _style$getPropertyVal !== void 0 ? _style$getPropertyVal : "";
				important = String((_style$getPropertyPri = style.getPropertyPriority(prop)) !== null && _style$getPropertyPri !== void 0 ? _style$getPropertyPri : "") === "important";
			} catch (_unused9) {
				value = "";
				important = false;
			}
			out.push({
				property: prop,
				value: String(value).trim(),
				important,
				declIndex: i
			});
		}
		return out;
	}
	function canReadInlineStyle(element) {
		const anyEl = element;
		return !!anyEl.style && typeof anyEl.style.getPropertyValue === "function" && typeof anyEl.style.getPropertyPriority === "function";
	}
	function formatElementLabel(element, maxClasses = 2) {
		var _element$id, _element$classList;
		const tag = element.tagName.toLowerCase();
		const id = (_element$id = element.id) === null || _element$id === void 0 ? void 0 : _element$id.trim();
		if (id) return `${tag}#${id}`;
		const classes = Array.from((_element$classList = element.classList) !== null && _element$classList !== void 0 ? _element$classList : []).slice(0, maxClasses).filter(Boolean);
		if (classes.length) return `${tag}.${classes.join(".")}`;
		return tag;
	}
	function getElementRoot(element) {
		try {
			var _element$getRootNode, _element$ownerDocumen;
			const root = (_element$getRootNode = element.getRootNode) === null || _element$getRootNode === void 0 ? void 0 : _element$getRootNode.call(element);
			return root instanceof ShadowRoot ? root : (_element$ownerDocumen = element.ownerDocument) !== null && _element$ownerDocumen !== void 0 ? _element$ownerDocumen : document;
		} catch (_unused10) {
			var _element$ownerDocumen2;
			return (_element$ownerDocumen2 = element.ownerDocument) !== null && _element$ownerDocumen2 !== void 0 ? _element$ownerDocumen2 : document;
		}
	}
	function getParentElementOrHost$1(element) {
		if (element.parentElement) return element.parentElement;
		try {
			var _element$getRootNode2;
			const root = (_element$getRootNode2 = element.getRootNode) === null || _element$getRootNode2 === void 0 ? void 0 : _element$getRootNode2.call(element);
			if (root instanceof ShadowRoot) return root.host;
		} catch (_unused11) {}
		return null;
	}
	function collectForElement(element, index, elementId, options) {
		const warnings = [];
		const matchedRules = [];
		const candidates = [];
		const rootType = index.root instanceof ShadowRoot ? "shadow" : "document";
		let inlineRule = null;
		if (options.includeInline && canReadInlineStyle(element)) {
			const declsRaw = readStyleDecls(element.style);
			const decls = [];
			for (const d of declsRaw) {
				const affects = expandToLonghands(d.property);
				if (!options.declFilter({
					property: d.property,
					affects
				})) continue;
				const declId = `inline:${elementId}:${d.declIndex}`;
				decls.push({
					id: declId,
					name: d.property,
					value: d.value,
					important: d.important,
					affects,
					status: "overridden"
				});
				candidates.push({
					id: declId,
					important: d.important,
					specificity: [
						1,
						0,
						0,
						0
					],
					sourceOrder: [
						Number.MAX_SAFE_INTEGER,
						Number.MAX_SAFE_INTEGER,
						d.declIndex
					],
					property: d.property,
					value: d.value,
					affects,
					ownerRuleId: `inline:${elementId}`,
					ownerElementId: elementId
				});
			}
			inlineRule = {
				id: `inline:${elementId}`,
				origin: "inline",
				selector: "element.style",
				matchedSelector: "element.style",
				specificity: [
					1,
					0,
					0,
					0
				],
				source: { label: "element.style" },
				order: Number.MAX_SAFE_INTEGER,
				decls
			};
		}
		for (const flat of index.flatRules) {
			const match = computeMatchedRuleSpecificity(element, flat.selectorText);
			if (!match) continue;
			const declsRaw = readStyleDecls(flat.style);
			const decls = [];
			const ruleId = `rule:${index.rootId}:${flat.sheetIndex}:${flat.order}`;
			for (const d of declsRaw) {
				const affects = expandToLonghands(d.property);
				if (!options.declFilter({
					property: d.property,
					affects
				})) continue;
				const declId = `${ruleId}:${d.declIndex}`;
				decls.push({
					id: declId,
					name: d.property,
					value: d.value,
					important: d.important,
					affects,
					status: "overridden"
				});
				candidates.push({
					id: declId,
					important: d.important,
					specificity: match.specificity,
					sourceOrder: [
						flat.sheetIndex,
						flat.order,
						d.declIndex
					],
					property: d.property,
					value: d.value,
					affects,
					ownerRuleId: ruleId,
					ownerElementId: elementId
				});
			}
			if (decls.length === 0) continue;
			matchedRules.push({
				id: ruleId,
				origin: "rule",
				selector: flat.selectorText,
				matchedSelector: match.matchedSelector,
				specificity: match.specificity,
				source: flat.source,
				order: flat.order,
				decls
			});
		}
		matchedRules.sort((a, b) => {
			var _a$specificity, _b$specificity;
			const sa = (_a$specificity = a.specificity) !== null && _a$specificity !== void 0 ? _a$specificity : ZERO_SPEC;
			const spec = compareSpecificity((_b$specificity = b.specificity) !== null && _b$specificity !== void 0 ? _b$specificity : ZERO_SPEC, sa);
			if (spec !== 0) return spec;
			return b.order - a.order;
		});
		return {
			element,
			elementId,
			root: index.root,
			rootType,
			inlineRule,
			matchedRules,
			candidates,
			warnings,
			stats: { matchedRules: matchedRules.length }
		};
	}
	/**
	* Collect full snapshot: inline + matched + inherited chain (ancestor traversal).
	*/
	function collectCssPanelSnapshot(element, options = {}) {
		const warnings = [];
		const maxDepth = Number.isFinite(options.maxInheritanceDepth) ? Math.max(0, options.maxInheritanceDepth) : 10;
		const elementIds = /* @__PURE__ */ new WeakMap();
		let nextElementId = 1;
		const rootIds = /* @__PURE__ */ new WeakMap();
		let nextRootId = 1;
		const indexCache = /* @__PURE__ */ new WeakMap();
		const indexList = [];
		function getElementId(el) {
			const existing = elementIds.get(el);
			if (existing) return existing;
			const id = nextElementId++;
			elementIds.set(el, id);
			return id;
		}
		function getIndex(root) {
			var _rootIds$get;
			const cached = indexCache.get(root);
			if (cached) return cached;
			const idx = createRuleIndexForRoot(root, (_rootIds$get = rootIds.get(root)) !== null && _rootIds$get !== void 0 ? _rootIds$get : (() => {
				const v = nextRootId++;
				rootIds.set(root, v);
				return v;
			})());
			indexCache.set(root, idx);
			indexList.push(idx);
			return idx;
		}
		if (!element || !element.isConnected) return {
			target: {
				label: formatElementLabel(element),
				root: "document"
			},
			warnings: ["Target element is not connected; snapshot may be incomplete."],
			stats: {
				roots: 0,
				styleSheets: 0,
				rulesScanned: 0,
				matchedRules: 0
			},
			sections: []
		};
		const targetRoot = getElementRoot(element);
		const targetIndex = getIndex(targetRoot);
		warnings.push(...targetIndex.warnings);
		const targetCollected = collectForElement(element, targetIndex, getElementId(element), {
			includeInline: true,
			declFilter: () => true
		});
		const targetOverrides = computeOverrides(targetCollected.candidates);
		const targetDeclStatus = targetOverrides.declStatus;
		if (targetCollected.inlineRule) for (const d of targetCollected.inlineRule.decls) {
			var _targetDeclStatus$get;
			d.status = (_targetDeclStatus$get = targetDeclStatus.get(d.id)) !== null && _targetDeclStatus$get !== void 0 ? _targetDeclStatus$get : "overridden";
		}
		for (const rule of targetCollected.matchedRules) {
			var _targetDeclStatus$get2;
			for (const d of rule.decls) d.status = (_targetDeclStatus$get2 = targetDeclStatus.get(d.id)) !== null && _targetDeclStatus$get2 !== void 0 ? _targetDeclStatus$get2 : "overridden";
		}
		const ancestors = [];
		let cur = getParentElementOrHost$1(element);
		while (cur && ancestors.length < maxDepth) {
			ancestors.push(cur);
			cur = getParentElementOrHost$1(cur);
		}
		const inheritableLonghands = /* @__PURE__ */ new Set();
		for (const cand of targetCollected.candidates) for (const lh of cand.affects) if (isInheritableProperty(lh)) inheritableLonghands.add(lh);
		const ancestorData = [];
		for (const a of ancestors) {
			const aIndex = getIndex(getElementRoot(a));
			warnings.push(...aIndex.warnings);
			const aCollected = collectForElement(a, aIndex, getElementId(a), {
				includeInline: true,
				declFilter: ({ affects }) => affects.some(isInheritableProperty)
			});
			const filteredCandidates = [];
			for (const cand of aCollected.candidates) {
				const affects = cand.affects.filter(isInheritableProperty);
				if (affects.length === 0) continue;
				const next = _objectSpread2(_objectSpread2({}, cand), {}, { affects });
				filteredCandidates.push(next);
				for (const lh of affects) inheritableLonghands.add(lh);
			}
			const aOverrides = computeOverrides(filteredCandidates);
			if (aCollected.inlineRule) {
				aCollected.inlineRule.decls = aCollected.inlineRule.decls.map((d) => _objectSpread2(_objectSpread2({}, d), {}, { affects: d.affects.filter(isInheritableProperty) })).filter((d) => d.affects.length > 0);
				if (aCollected.inlineRule.decls.length === 0) aCollected.inlineRule = null;
			}
			aCollected.matchedRules = aCollected.matchedRules.map((r) => _objectSpread2(_objectSpread2({}, r), {}, { decls: r.decls.map((d) => _objectSpread2(_objectSpread2({}, d), {}, { affects: d.affects.filter(isInheritableProperty) })).filter((d) => d.affects.length > 0) })).filter((r) => r.decls.length > 0);
			if (!aCollected.inlineRule && aCollected.matchedRules.length === 0) continue;
			ancestorData.push({
				ancestor: a,
				label: formatElementLabel(a),
				collected: _objectSpread2(_objectSpread2({}, aCollected), {}, { candidates: filteredCandidates }),
				overrides: aOverrides
			});
		}
		const finalInheritedDeclIds = /* @__PURE__ */ new Set();
		for (const longhand of inheritableLonghands) {
			if (targetOverrides.winners.has(longhand)) continue;
			for (const a of ancestorData) {
				const win = a.overrides.winners.get(longhand);
				if (win) {
					finalInheritedDeclIds.add(win.id);
					break;
				}
			}
		}
		for (const a of ancestorData) {
			if (a.collected.inlineRule) for (const d of a.collected.inlineRule.decls) d.status = finalInheritedDeclIds.has(d.id) ? "active" : "overridden";
			for (const r of a.collected.matchedRules) for (const d of r.decls) d.status = finalInheritedDeclIds.has(d.id) ? "active" : "overridden";
		}
		const sections = [];
		sections.push({
			kind: "inline",
			title: "element.style",
			rules: targetCollected.inlineRule ? [targetCollected.inlineRule] : []
		});
		sections.push({
			kind: "matched",
			title: "Matched CSS Rules",
			rules: targetCollected.matchedRules
		});
		for (const a of ancestorData) {
			const rules = [];
			if (a.collected.inlineRule) rules.push(a.collected.inlineRule);
			rules.push(...a.collected.matchedRules);
			sections.push({
				kind: "inherited",
				title: `Inherited from ${a.label}`,
				inheritedFrom: { label: a.label },
				rules
			});
		}
		let totalStyleSheets = 0;
		let totalRulesScanned = 0;
		const rootsSeen = /* @__PURE__ */ new Set();
		for (const idx of indexList) {
			rootsSeen.add(idx.rootId);
			totalStyleSheets += idx.stats.styleSheets;
			totalRulesScanned += idx.stats.rulesScanned;
		}
		const dedupWarnings = Array.from(new Set([...warnings, ...targetCollected.warnings]));
		return {
			target: {
				label: formatElementLabel(element),
				root: targetRoot instanceof ShadowRoot ? "shadow" : "document"
			},
			warnings: dedupWarnings,
			stats: {
				roots: rootsSeen.size,
				styleSheets: totalStyleSheets,
				rulesScanned: totalRulesScanned,
				matchedRules: targetCollected.stats.matchedRules
			},
			sections
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/css-panel.ts
	/**
	* CSS Panel (Phase 4.6 + 4.7)
	*
	* Displays CSS rules and their sources for the selected element.
	* Similar to Chrome DevTools Styles panel.
	*
	* Features:
	* - Shows inline styles, matched CSS rules, and inherited styles
	* - Displays selector, specificity, and source file
	* - Shows which declarations are active vs overridden (strikethrough)
	* - Collapsible sections for inherited rules
	* - Supports Shadow DOM stylesheets
	* - Class editing with chips UI (Phase 4.7)
	*/
	/**
	* Format specificity as a human-readable string: (i, a, b, c)
	*/
	function formatSpecificity(spec) {
		if (!spec) return "";
		return `(${spec[0]}, ${spec[1]}, ${spec[2]}, ${spec[3]})`;
	}
	/**
	* Read class list from element (compatible with SVG elements)
	*/
	function readElementClasses(element) {
		try {
			const list = element.classList;
			if (list && typeof list[Symbol.iterator] === "function") return Array.from(list).filter(Boolean);
		} catch (_unused) {}
		try {
			var _element$getAttribute;
			return ((_element$getAttribute = element.getAttribute("class")) !== null && _element$getAttribute !== void 0 ? _element$getAttribute : "").split(/\s+/).map((t) => t.trim()).filter(Boolean);
		} catch (_unused2) {
			return [];
		}
	}
	/**
	* Apply class list to element (compatible with SVG elements)
	*/
	function applyClassListToElement$1(element, classes) {
		const seen = /* @__PURE__ */ new Set();
		const normalized = [];
		for (const raw of classes !== null && classes !== void 0 ? classes : []) {
			const token = String(raw !== null && raw !== void 0 ? raw : "").trim();
			if (!token) continue;
			if (seen.has(token)) continue;
			seen.add(token);
			normalized.push(token);
		}
		const value = normalized.join(" ").trim();
		try {
			if (value) element.setAttribute("class", value);
			else element.removeAttribute("class");
		} catch (_unused3) {}
	}
	/**
	* Unescape CSS identifier (handles hex escapes and simple backslash escapes)
	*
	* Examples:
	* - 'sm\\:bg-red-500' -> 'sm:bg-red-500'
	* - '\\31 23' -> '123'
	*/
	function unescapeCssIdentifier(input) {
		const s = String(input !== null && input !== void 0 ? input : "");
		let out = "";
		for (let i = 0; i < s.length; i++) {
			var _s$j;
			const ch = s[i];
			if (ch !== "\\") {
				out += ch;
				continue;
			}
			if (i >= s.length - 1) break;
			let j = i + 1;
			let hex = "";
			while (j < s.length && hex.length < 6 && /[0-9a-fA-F]/.test(s[j])) {
				hex += s[j];
				j += 1;
			}
			if (hex.length > 0) {
				const codePoint = Number.parseInt(hex, 16);
				if (Number.isFinite(codePoint) && codePoint >= 0 && codePoint <= 1114111) {
					out += String.fromCodePoint(codePoint);
					if (j < s.length && /\s/.test(s[j])) j += 1;
					i = j - 1;
					continue;
				}
			}
			out += (_s$j = s[j]) !== null && _s$j !== void 0 ? _s$j : "";
			i = j;
		}
		return out;
	}
	/**
	* Consume a CSS class identifier starting at `start` position
	* Returns the end position (exclusive)
	*/
	function consumeClassIdent(selector, start) {
		for (let i = start; i < selector.length; i++) {
			const ch = selector[i];
			if (ch === "\\") {
				const next = i + 1;
				if (next >= selector.length) return selector.length;
				if (/[0-9a-fA-F]/.test(selector[next])) {
					let j = next;
					let hexCount = 0;
					while (j < selector.length && hexCount < 6 && /[0-9a-fA-F]/.test(selector[j])) {
						j += 1;
						hexCount += 1;
					}
					if (j < selector.length && /\s/.test(selector[j])) j += 1;
					i = j - 1;
				} else i = next;
				continue;
			}
			if (/\s/.test(ch) || ch === "." || ch === "#" || ch === ":" || ch === "[" || ch === "]" || ch === "(" || ch === ")" || ch === "," || ch === ">" || ch === "+" || ch === "~" || ch === "|") return i;
		}
		return selector.length;
	}
	/**
	* Extract class names from a CSS selector string
	* Handles CSS escapes (e.g., Tailwind's `sm\:bg-red-500`)
	*/
	function extractClassNamesFromSelector(selector) {
		const out = [];
		const s = String(selector !== null && selector !== void 0 ? selector : "");
		let bracketDepth = 0;
		let quote = null;
		for (let i = 0; i < s.length; i++) {
			const ch = s[i];
			if (quote) {
				if (ch === "\\") {
					i += 1;
					continue;
				}
				if (ch === quote) quote = null;
				continue;
			}
			if (ch === "\"" || ch === "'") {
				quote = ch;
				continue;
			}
			if (ch === "[") {
				bracketDepth += 1;
				continue;
			}
			if (ch === "]") {
				bracketDepth = Math.max(0, bracketDepth - 1);
				continue;
			}
			if (bracketDepth > 0) continue;
			if (ch !== ".") continue;
			const start = i + 1;
			if (start >= s.length) continue;
			const end = consumeClassIdent(s, start);
			const cls = unescapeCssIdentifier(s.slice(start, end)).trim();
			if (cls) out.push(cls);
			i = end - 1;
		}
		return out;
	}
	/**
	* Collect class suggestions from CSS snapshot
	* Extracts class names from matched selectors
	*/
	function collectClassSuggestions(snapshot) {
		const out = [];
		const seen = /* @__PURE__ */ new Set();
		for (const section of snapshot.sections) for (const rule of section.rules) {
			var _rule$matchedSelector;
			const selector = (_rule$matchedSelector = rule.matchedSelector) !== null && _rule$matchedSelector !== void 0 ? _rule$matchedSelector : rule.selector;
			for (const cls of extractClassNamesFromSelector(selector)) {
				if (!cls) continue;
				if (seen.has(cls)) continue;
				seen.add(cls);
				out.push(cls);
				if (out.length >= 400) return out;
			}
		}
		return out;
	}
	/**
	* Check if a declaration is a design token (CSS custom property)
	*/
	function isDesignToken(declName) {
		return declName.trim().startsWith("--");
	}
	/**
	* Global/universal selectors to filter out (only show element-specific styles)
	*/
	var GLOBAL_SELECTORS = new Set([
		"*",
		"html",
		"body",
		":root",
		":where(*)",
		":is(*)"
	]);
	/**
	* Check if a selector is a global/universal selector that should be filtered
	*/
	function isGlobalSelector(selector) {
		const normalized = selector.trim().toLowerCase();
		if (GLOBAL_SELECTORS.has(normalized)) return true;
		return normalized.split(/\s*,\s*/).every((part) => {
			return part.split(/\s+/).filter(Boolean).every((t) => GLOBAL_SELECTORS.has(t) || t === ">" || t === "+" || t === "~");
		});
	}
	/**
	* Get the longhand properties affected by a declaration
	*/
	function getDeclAffectedProperties(decl) {
		if (Array.isArray(decl.affects)) {
			const affects = decl.affects;
			if (affects && affects.length > 0) return affects;
		}
		return [decl.name];
	}
	/**
	* Collect all properties that need baseline values for comparison
	*/
	function collectBaselineProperties(snapshot) {
		const out = /* @__PURE__ */ new Set();
		for (const section of snapshot.sections) for (const rule of section.rules) for (const decl of rule.decls) {
			if (decl.status !== "active") continue;
			if (isDesignToken(decl.name)) continue;
			for (const prop of getDeclAffectedProperties(decl)) {
				const name = String(prop !== null && prop !== void 0 ? prop : "").trim();
				if (name) out.add(name);
			}
		}
		return Array.from(out);
	}
	/**
	* Check if an active declaration's computed value matches browser default
	*/
	function isDefaultValueDecl(decl, ctx) {
		if (decl.status !== "active") return false;
		if (!ctx.computedStyle) return false;
		const props = getDeclAffectedProperties(decl);
		let hasComparable = false;
		for (const propRaw of props) {
			const prop = String(propRaw !== null && propRaw !== void 0 ? propRaw : "").trim();
			if (!prop) continue;
			let computed = "";
			try {
				var _ctx$computedStyle$ge;
				computed = String((_ctx$computedStyle$ge = ctx.computedStyle.getPropertyValue(prop)) !== null && _ctx$computedStyle$ge !== void 0 ? _ctx$computedStyle$ge : "").trim();
			} catch (_unused4) {
				computed = "";
			}
			const baseline = ctx.defaults.getBaselineValue(ctx.tagName, prop);
			if (computed || baseline) hasComparable = true;
			if (computed !== baseline) return false;
		}
		return hasComparable;
	}
	/**
	* Check if a declaration should be rendered (after all filters)
	*/
	function shouldRenderDecl(decl, ctx) {
		if (isDesignToken(decl.name)) return false;
		if (isDefaultValueDecl(decl, ctx)) return false;
		return true;
	}
	/**
	* Check if global selector filtering should apply for this element
	* Don't filter global selectors when the selected element is html/body itself
	*/
	function shouldFilterGlobalSelector(selector, tagName) {
		if (!isGlobalSelector(selector)) return false;
		const tag = tagName.toLowerCase();
		if (tag === "html" || tag === "body") return false;
		return true;
	}
	/**
	* Create a rule block element
	* Returns null if all declarations are filtered out (design tokens) or selector is global
	*/
	function createRuleBlock(rule, disposer, ctx) {
		var _rule$matchedSelector2, _rule$matchedSelector3;
		const matchedSelector = (_rule$matchedSelector2 = rule.matchedSelector) !== null && _rule$matchedSelector2 !== void 0 ? _rule$matchedSelector2 : rule.selector;
		if (rule.origin === "rule" && shouldFilterGlobalSelector(matchedSelector, ctx.tagName)) return null;
		const visibleDecls = rule.decls.filter((decl) => shouldRenderDecl(decl, ctx));
		if (visibleDecls.length === 0) return null;
		const block = document.createElement("div");
		block.className = "we-css-rule";
		block.dataset.ruleId = rule.id;
		block.dataset.origin = rule.origin;
		const header = document.createElement("div");
		header.className = "we-css-rule-header";
		const selector = document.createElement("span");
		selector.className = "we-css-rule-selector";
		selector.textContent = (_rule$matchedSelector3 = rule.matchedSelector) !== null && _rule$matchedSelector3 !== void 0 ? _rule$matchedSelector3 : rule.selector;
		selector.title = rule.selector;
		header.append(selector);
		if (rule.source) {
			const source = document.createElement("span");
			source.className = "we-css-rule-source";
			source.textContent = rule.source.label;
			if (rule.source.url) source.title = rule.source.url;
			header.append(source);
		}
		if (rule.origin === "rule" && rule.specificity) {
			const specBadge = document.createElement("span");
			specBadge.className = "we-css-rule-spec";
			specBadge.textContent = formatSpecificity(rule.specificity);
			specBadge.title = "Specificity (inline, id, class, type)";
			header.append(specBadge);
		}
		block.append(header);
		const declsContainer = document.createElement("div");
		declsContainer.className = "we-css-decls";
		for (const decl of visibleDecls) {
			const declEl = createDeclaration(decl);
			declsContainer.append(declEl);
		}
		block.append(declsContainer);
		return block;
	}
	/**
	* Create a declaration element
	*/
	function createDeclaration(decl) {
		const el = document.createElement("div");
		el.className = "we-css-decl";
		el.dataset.status = decl.status;
		const name = document.createElement("span");
		name.className = "we-css-decl-name";
		name.textContent = decl.name;
		const colon = document.createElement("span");
		colon.className = "we-css-decl-colon";
		colon.textContent = ": ";
		const valueContainer = document.createElement("span");
		valueContainer.className = "we-css-decl-value-container";
		const value = document.createElement("span");
		value.className = "we-css-decl-value";
		value.textContent = decl.value;
		valueContainer.append(value);
		if (decl.important) {
			const imp = document.createElement("span");
			imp.className = "we-css-decl-important";
			imp.textContent = "!important";
			valueContainer.append(imp);
		}
		const semi = document.createElement("span");
		semi.className = "we-css-decl-semi";
		semi.textContent = ";";
		el.append(name, colon, valueContainer, semi);
		return el;
	}
	/**
	* Check if a rule has any renderable declarations (after filtering)
	*/
	function hasRenderableRule(rule, ctx) {
		var _rule$matchedSelector4;
		const matchedSelector = (_rule$matchedSelector4 = rule.matchedSelector) !== null && _rule$matchedSelector4 !== void 0 ? _rule$matchedSelector4 : rule.selector;
		if (rule.origin === "rule" && shouldFilterGlobalSelector(matchedSelector, ctx.tagName)) return false;
		return rule.decls.some((decl) => shouldRenderDecl(decl, ctx));
	}
	/**
	* Check if a section has any renderable rules (after filtering)
	*/
	function hasRenderableDecls(section, ctx) {
		return section.rules.some((rule) => hasRenderableRule(rule, ctx));
	}
	/**
	* Create a section element (inline, matched, or inherited)
	* Returns null if all rules are filtered out
	*/
	function createSection(section, disposer, ctx) {
		if (!hasRenderableDecls(section, ctx)) return null;
		const el = document.createElement("div");
		el.className = "we-css-section";
		el.dataset.kind = section.kind;
		if (section.kind === "inherited") {
			const header = document.createElement("div");
			header.className = "we-css-section-header";
			const title = document.createElement("span");
			title.className = "we-css-section-title";
			title.textContent = section.title;
			header.append(title);
			el.append(header);
		}
		const rulesContainer = document.createElement("div");
		rulesContainer.className = "we-css-section-rules";
		for (const rule of section.rules) {
			const ruleEl = createRuleBlock(rule, disposer, ctx);
			if (ruleEl) rulesContainer.append(ruleEl);
		}
		if (rulesContainer.childElementCount === 0) return null;
		el.append(rulesContainer);
		return el;
	}
	/**
	* Create a CSS Panel component
	*/
	function createCssPanel(options) {
		const { container, transactionManager, onClassChange } = options;
		const disposer = new Disposer();
		const defaultsProvider = createCssDefaultsProvider();
		disposer.add(() => defaultsProvider.dispose());
		let currentTarget = null;
		let snapshot = null;
		let classSuggestions = [];
		let classEditor = null;
		let isVisible = false;
		let needsRefresh = false;
		const root = document.createElement("div");
		root.className = "we-css-panel";
		const classEditorMount = document.createElement("div");
		classEditorMount.className = "we-css-class-editor-mount";
		const infoBar = document.createElement("div");
		infoBar.className = "we-css-info";
		infoBar.hidden = true;
		const emptyState = document.createElement("div");
		emptyState.className = "we-css-empty";
		emptyState.textContent = "No styles";
		const warningsContainer = document.createElement("div");
		warningsContainer.className = "we-css-warnings";
		warningsContainer.hidden = true;
		const sectionsContainer = document.createElement("div");
		sectionsContainer.className = "we-css-sections";
		classEditor = createClassEditor({
			container: classEditorMount,
			onClassChange: (nextClasses) => {
				const target = currentTarget;
				if (!target || !target.isConnected) return;
				const beforeClasses = readElementClasses(target);
				if (transactionManager) transactionManager.recordClass(target, beforeClasses, nextClasses);
				else applyClassListToElement$1(target, nextClasses);
				classEditor === null || classEditor === void 0 || classEditor.setClasses(readElementClasses(target));
				onClassChange === null || onClassChange === void 0 || onClassChange();
				collectAndRender();
			},
			getSuggestions: () => classSuggestions
		});
		root.append(classEditorMount, infoBar, warningsContainer, emptyState, sectionsContainer);
		container.append(root);
		disposer.add(() => root.remove());
		function renderSnapshot() {
			sectionsContainer.innerHTML = "";
			warningsContainer.innerHTML = "";
			if (!snapshot) {
				emptyState.hidden = false;
				emptyState.textContent = "Select an element to view styles";
				infoBar.hidden = true;
				warningsContainer.hidden = true;
				return;
			}
			const tagName = currentTarget ? currentTarget.tagName.toLowerCase() : "";
			let computedStyle = null;
			try {
				if (currentTarget === null || currentTarget === void 0 ? void 0 : currentTarget.isConnected) computedStyle = window.getComputedStyle(currentTarget);
			} catch (_unused5) {
				computedStyle = null;
			}
			const filterCtx = {
				defaults: defaultsProvider,
				tagName,
				computedStyle
			};
			if (computedStyle && tagName) defaultsProvider.ensureBaselineValues(tagName, collectBaselineProperties(snapshot));
			if (!snapshot.sections.some((section) => hasRenderableDecls(section, filterCtx))) {
				emptyState.hidden = false;
				emptyState.textContent = "No CSS rules matched";
				infoBar.hidden = true;
			} else {
				emptyState.hidden = true;
				const { stats } = snapshot;
				infoBar.textContent = `${stats.matchedRules} rules matched (${stats.styleSheets} stylesheets, ${stats.rulesScanned} rules scanned)`;
				infoBar.hidden = false;
			}
			if (snapshot.warnings.length > 0) {
				warningsContainer.hidden = false;
				for (const warning of snapshot.warnings.slice(0, 5)) {
					const warningEl = document.createElement("div");
					warningEl.className = "we-css-warning";
					warningEl.textContent = warning;
					warningsContainer.append(warningEl);
				}
				if (snapshot.warnings.length > 5) {
					const more = document.createElement("div");
					more.className = "we-css-warning-more";
					more.textContent = `...and ${snapshot.warnings.length - 5} more warnings`;
					warningsContainer.append(more);
				}
			} else warningsContainer.hidden = true;
			for (const section of snapshot.sections) {
				const sectionEl = createSection(section, disposer, filterCtx);
				if (sectionEl) sectionsContainer.append(sectionEl);
			}
		}
		function collectAndRender() {
			if (!isVisible) {
				needsRefresh = true;
				return;
			}
			if (!currentTarget || !currentTarget.isConnected) {
				snapshot = null;
				classSuggestions = [];
				classEditor === null || classEditor === void 0 || classEditor.setTarget(null);
				renderSnapshot();
				return;
			}
			snapshot = collectCssPanelSnapshot(currentTarget, { maxInheritanceDepth: 0 });
			classSuggestions = snapshot ? collectClassSuggestions(snapshot) : [];
			renderSnapshot();
			needsRefresh = false;
		}
		function setTarget(element) {
			if (disposer.isDisposed) return;
			currentTarget = element;
			classEditor === null || classEditor === void 0 || classEditor.setTarget(element);
			collectAndRender();
		}
		function refresh() {
			if (disposer.isDisposed) return;
			classEditor === null || classEditor === void 0 || classEditor.refresh();
			collectAndRender();
		}
		function setVisible(visible) {
			if (disposer.isDisposed) return;
			isVisible = visible;
			if (visible && needsRefresh) collectAndRender();
		}
		function dispose() {
			currentTarget = null;
			snapshot = null;
			classEditor === null || classEditor === void 0 || classEditor.dispose();
			classEditor = null;
			classSuggestions = [];
			isVisible = false;
			needsRefresh = false;
			disposer.dispose();
		}
		renderSnapshot();
		return {
			setTarget,
			refresh,
			setVisible,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/debug-source.ts
	/** Maximum depth to walk up the DOM tree for debug source */
	var MAX_DOM_DEPTH = 15;
	/** Maximum depth to walk up React fiber tree */
	var MAX_FIBER_DEPTH = 40;
	/**
	* Safely access object as record
	*/
	function asRecord(value) {
		if (value && typeof value === "object") return value;
		return null;
	}
	/**
	* Read optional string value
	*/
	function readString$1(value) {
		if (typeof value === "string") return value.trim() || void 0;
	}
	/**
	* Read optional number value
	*/
	function readNumber(value) {
		if (typeof value === "number" && Number.isFinite(value)) return value;
		const parsed = Number.parseInt(String(value), 10);
		return Number.isFinite(parsed) ? parsed : void 0;
	}
	/**
	* Read component name from function/object
	*/
	function readComponentName(value) {
		if (!value) return void 0;
		if (typeof value === "function") {
			var _readString;
			const fn = value;
			return (_readString = readString$1(fn.displayName)) !== null && _readString !== void 0 ? _readString : readString$1(fn.name);
		}
		const rec = asRecord(value);
		if (rec) {
			var _readString2;
			return (_readString2 = readString$1(rec.displayName)) !== null && _readString2 !== void 0 ? _readString2 : readString$1(rec.name);
		}
	}
	/**
	* Extract debug source from React Fiber
	*/
	function extractReactDebugSource(fiber) {
		let current = fiber;
		for (let i = 0; i < MAX_FIBER_DEPTH && current; i++) {
			const rec = asRecord(current);
			if (!rec) break;
			const src = asRecord(rec._debugSource);
			const file = readString$1(src === null || src === void 0 ? void 0 : src.fileName);
			if (file) {
				var _readComponentName;
				const componentName = (_readComponentName = readComponentName(rec.elementType)) !== null && _readComponentName !== void 0 ? _readComponentName : readComponentName(rec.type);
				return {
					file,
					line: readNumber(src === null || src === void 0 ? void 0 : src.lineNumber),
					column: readNumber(src === null || src === void 0 ? void 0 : src.columnNumber),
					componentName
				};
			}
			const owner = asRecord(rec._debugOwner);
			const ownerSrc = asRecord(owner === null || owner === void 0 ? void 0 : owner._debugSource);
			const ownerFile = readString$1(ownerSrc === null || ownerSrc === void 0 ? void 0 : ownerSrc.fileName);
			if (ownerFile) {
				var _readComponentName2;
				const componentName = (_readComponentName2 = readComponentName(owner === null || owner === void 0 ? void 0 : owner.elementType)) !== null && _readComponentName2 !== void 0 ? _readComponentName2 : readComponentName(owner === null || owner === void 0 ? void 0 : owner.type);
				return {
					file: ownerFile,
					line: readNumber(ownerSrc === null || ownerSrc === void 0 ? void 0 : ownerSrc.lineNumber),
					column: readNumber(ownerSrc === null || ownerSrc === void 0 ? void 0 : ownerSrc.columnNumber),
					componentName
				};
			}
			current = rec.return;
		}
		return null;
	}
	/**
	* Find React debug source from element
	*/
	function findReactDebugSource(element) {
		try {
			let node = element;
			for (let depth = 0; depth < MAX_DOM_DEPTH && node; depth++) {
				const rec = node;
				for (const key of Object.keys(rec)) if (key.startsWith("__reactFiber$") || key.startsWith("__reactInternalInstance$")) {
					const source = extractReactDebugSource(rec[key]);
					if (source) return source;
				}
				node = node.parentElement;
			}
		} catch (_unused) {}
		return null;
	}
	/**
	* Parse Vue inspector location attribute value.
	* Format: "src/components/Foo.vue:23:7" or "C:\path\file.vue:10:5" (Windows)
	*
	* Uses trailing regex to safely handle Windows paths with drive letters.
	*/
	function parseVInspector(value) {
		if (typeof value !== "string") return null;
		const raw = value.trim();
		if (!raw) return null;
		const match = raw.match(/:(\d+)(?::(\d+))?$/);
		if (!match) return { file: raw };
		const file = raw.slice(0, match.index).trim();
		if (!file) return null;
		const line = Number.parseInt(match[1], 10);
		const columnRaw = match[2] ? Number.parseInt(match[2], 10) : void 0;
		return {
			file,
			line: Number.isFinite(line) && line > 0 ? line : void 0,
			column: columnRaw !== void 0 && Number.isFinite(columnRaw) && columnRaw > 0 ? columnRaw : void 0
		};
	}
	/**
	* Walk up DOM tree to find data-v-inspector attribute.
	* This attribute is injected by @vitejs/plugin-vue-inspector.
	*/
	function findInspectorLocation(element) {
		try {
			let node = element;
			for (let depth = 0; depth < MAX_DOM_DEPTH && node; depth++) {
				if (typeof node.getAttribute === "function") {
					const attr = node.getAttribute("data-v-inspector");
					if (attr) {
						const parsed = parseVInspector(attr);
						if (parsed === null || parsed === void 0 ? void 0 : parsed.file) return parsed;
					}
				}
				node = node.parentElement;
			}
		} catch (_unused2) {}
		return null;
	}
	/**
	* Find Vue debug source from element.
	* Priority: data-v-inspector (has line/column) > type.__file (file only)
	*/
	function findVueDebugSource(element) {
		try {
			const inspector = findInspectorLocation(element);
			if (inspector === null || inspector === void 0 ? void 0 : inspector.file) {
				let componentName;
				let node = element;
				for (let depth = 0; depth < MAX_DOM_DEPTH && node; depth++) {
					const inst = asRecord(node.__vueParentComponent);
					const typeRec = asRecord(inst === null || inst === void 0 ? void 0 : inst.type);
					componentName = readString$1(typeRec === null || typeRec === void 0 ? void 0 : typeRec.name);
					if (componentName) break;
					node = node.parentElement;
				}
				return _objectSpread2(_objectSpread2({}, inspector), {}, { componentName });
			}
			let node = element;
			for (let depth = 0; depth < MAX_DOM_DEPTH && node; depth++) {
				const inst = asRecord(node.__vueParentComponent);
				const typeRec = asRecord(inst === null || inst === void 0 ? void 0 : inst.type);
				const file = readString$1(typeRec === null || typeRec === void 0 ? void 0 : typeRec.__file);
				if (file) return {
					file,
					componentName: readString$1(typeRec === null || typeRec === void 0 ? void 0 : typeRec.name)
				};
				node = node.parentElement;
			}
		} catch (_unused3) {}
		return null;
	}
	/**
	* Find debug source from element (tries React first, then Vue).
	* Returns null if no debug info is available.
	*
	* @param element - DOM element to extract debug source from
	* @returns Debug source with file path and optional line/column/component name
	*/
	function findDebugSource(element) {
		const react = findReactDebugSource(element);
		if (react) return react;
		const vue = findVueDebugSource(element);
		if (vue) return vue;
		return null;
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/locator.ts
	/** Maximum candidate selectors to generate */
	var DEFAULT_MAX_CANDIDATES = 5;
	/** Maximum text length for fingerprint */
	var FINGERPRINT_TEXT_MAX_LENGTH = 32;
	/** Maximum classes to include in fingerprint */
	var FINGERPRINT_MAX_CLASSES = 8;
	/** Priority ordered data attributes for unique identification */
	var UNIQUE_DATA_ATTRS = [
		"data-testid",
		"data-test-id",
		"data-test",
		"data-qa",
		"data-cy",
		"name",
		"title",
		"alt",
		"aria-label"
	];
	/** Maximum class combinations to try for uniqueness */
	var MAX_CLASS_COMBO_DEPTH = 3;
	/** Data attributes eligible for ancestor anchors (Phase 2.9) */
	var ANCHOR_DATA_ATTRS = [
		"data-testid",
		"data-test-id",
		"data-test",
		"data-qa",
		"data-cy"
	];
	/** Maximum number of class names to consider for selector generation */
	var MAX_SELECTOR_CLASS_COUNT = 24;
	/** Maximum ancestor depth to search for an anchor selector */
	var MAX_ANCHOR_DEPTH = 20;
	/**
	* Escape a string for use in CSS selector.
	* Uses native CSS.escape if available, otherwise a spec-compliant polyfill.
	*/
	function cssEscape(value) {
		if (typeof CSS !== "undefined" && typeof CSS.escape === "function") return CSS.escape(value);
		const str = String(value);
		const len = str.length;
		if (len === 0) return "";
		let result = "";
		const firstCodeUnit = str.charCodeAt(0);
		for (let i = 0; i < len; i++) {
			const codeUnit = str.charCodeAt(i);
			if (codeUnit === 0) {
				result += "�";
				continue;
			}
			if (codeUnit >= 1 && codeUnit <= 31 || codeUnit === 127 || i === 0 && codeUnit >= 48 && codeUnit <= 57 || i === 1 && codeUnit >= 48 && codeUnit <= 57 && firstCodeUnit === 45) {
				result += `\\${codeUnit.toString(16)} `;
				continue;
			}
			if (i === 0 && len === 1 && codeUnit === 45) {
				result += `\\${str.charAt(i)}`;
				continue;
			}
			if (codeUnit >= 48 && codeUnit <= 57 || codeUnit >= 65 && codeUnit <= 90 || codeUnit >= 97 && codeUnit <= 122 || codeUnit === 45 || codeUnit === 95) result += str.charAt(i);
			else result += `\\${str.charAt(i)}`;
		}
		return result;
	}
	/**
	* Get the query root for an element (Document or ShadowRoot)
	*/
	function getQueryRoot(element) {
		var _element$getRootNode;
		const root = (_element$getRootNode = element.getRootNode) === null || _element$getRootNode === void 0 ? void 0 : _element$getRootNode.call(element);
		return root instanceof ShadowRoot ? root : document;
	}
	/**
	* Safely execute querySelector, returning null on invalid selectors
	*/
	function safeQuerySelector(root, selector) {
		try {
			return root.querySelector(selector);
		} catch (_unused) {
			return null;
		}
	}
	/**
	* Check if a selector matches exactly one element in the root
	*/
	function isUnique(root, selector) {
		try {
			return root.querySelectorAll(selector).length === 1;
		} catch (_unused2) {
			return false;
		}
	}
	/**
	* Try to build a unique ID-based selector
	*/
	function tryIdSelector(element, root) {
		var _element$id;
		const id = (_element$id = element.id) === null || _element$id === void 0 ? void 0 : _element$id.trim();
		if (!id) return null;
		const selector = `#${cssEscape(id)}`;
		return isUnique(root, selector) ? selector : null;
	}
	/**
	* Collect unique data-attribute selector candidates (ordered by priority).
	* Phase 2.9: Returns multiple candidates instead of just the first.
	*/
	function collectDataAttrSelectors(element, root, max) {
		const out = [];
		if (max <= 0) return out;
		const tag = element.tagName.toLowerCase();
		for (const attr of UNIQUE_DATA_ATTRS) {
			var _element$getAttribute;
			if (out.length >= max) break;
			const value = (_element$getAttribute = element.getAttribute(attr)) === null || _element$getAttribute === void 0 ? void 0 : _element$getAttribute.trim();
			if (!value) continue;
			const attrOnly = `[${attr}="${cssEscape(value)}"]`;
			if (isUnique(root, attrOnly)) {
				out.push(attrOnly);
				continue;
			}
			const withTag = `${tag}${attrOnly}`;
			if (isUnique(root, withTag)) out.push(withTag);
		}
		return out;
	}
	/**
	* Collect unique class-based selector candidates.
	* Phase 2.9: Produces multiple variants (single class, tag+class, combinations) with early stop.
	*/
	function collectClassSelectors(element, root, max) {
		const out = [];
		if (max <= 0) return out;
		const tag = element.tagName.toLowerCase();
		const classes = Array.from(element.classList).filter((c) => c && /^[a-zA-Z_][a-zA-Z0-9_-]*$/.test(c)).slice(0, MAX_SELECTOR_CLASS_COUNT);
		if (classes.length === 0) return out;
		const uniqueSingle = /* @__PURE__ */ new Map();
		for (const cls of classes) {
			if (out.length >= max) return out;
			const sel = `.${cssEscape(cls)}`;
			const unique = isUnique(root, sel);
			uniqueSingle.set(cls, unique);
			if (unique) out.push(sel);
		}
		for (const cls of classes) {
			if (out.length >= max) return out;
			if (uniqueSingle.get(cls) === true) continue;
			const sel = `${tag}.${cssEscape(cls)}`;
			if (isUnique(root, sel)) out.push(sel);
		}
		const limit = Math.min(classes.length, MAX_CLASS_COMBO_DEPTH);
		for (let i = 0; i < limit; i++) for (let j = i + 1; j < limit; j++) {
			if (out.length >= max) return out;
			const a = classes[i];
			const b = classes[j];
			const pair = `.${cssEscape(a)}.${cssEscape(b)}`;
			if (isUnique(root, pair)) {
				out.push(pair);
				continue;
			}
			const withTag = `${tag}${pair}`;
			if (isUnique(root, withTag)) out.push(withTag);
		}
		if (limit >= 3 && out.length < max) {
			const triple = `.${cssEscape(classes[0])}.${cssEscape(classes[1])}.${cssEscape(classes[2])}`;
			if (isUnique(root, triple)) out.push(triple);
			else {
				const withTag = `${tag}${triple}`;
				if (out.length < max && isUnique(root, withTag)) out.push(withTag);
			}
		}
		return out;
	}
	/**
	* Build a structural path selector using nth-of-type
	*/
	function buildPathSelector(element, root) {
		const segments = [];
		let current = element;
		const isDocument = root instanceof Document;
		while (current && current.nodeType === Node.ELEMENT_NODE) {
			const tag = current.tagName.toLowerCase();
			if (isDocument && tag === "body") break;
			let selector = tag;
			const parent = current.parentElement;
			const parentNode = current.parentNode;
			let siblings;
			if (parent) siblings = Array.from(parent.children);
			else if (parentNode instanceof ShadowRoot || parentNode instanceof Document) siblings = Array.from(parentNode.children);
			else siblings = [];
			const sameTagSiblings = siblings.filter((s) => s.tagName === current.tagName);
			if (sameTagSiblings.length > 1) {
				const index = sameTagSiblings.indexOf(current) + 1;
				selector += `:nth-of-type(${index})`;
			}
			segments.unshift(selector);
			current = parent;
			if (!parent && parentNode === root) break;
		}
		const path = segments.join(" > ");
		return isDocument ? `body > ${path}` : path || "*";
	}
	/**
	* Build a relative path selector from an ancestor to a target within the same root.
	*/
	function buildRelativePathSelector(ancestor, target, root) {
		const segments = [];
		let current = target;
		for (let depth = 0; current && current !== ancestor && depth < MAX_ANCHOR_DEPTH; depth++) {
			let selector = current.tagName.toLowerCase();
			const parent = current.parentElement;
			const parentNode = current.parentNode;
			let siblings;
			if (parent) siblings = Array.from(parent.children);
			else if (parentNode instanceof ShadowRoot || parentNode instanceof Document) siblings = Array.from(parentNode.children);
			else siblings = [];
			const sameTagSiblings = siblings.filter((s) => s.tagName === current.tagName);
			if (sameTagSiblings.length > 1) {
				const index = sameTagSiblings.indexOf(current) + 1;
				selector += `:nth-of-type(${index})`;
			}
			segments.unshift(selector);
			if (!parent) {
				if (parentNode === root) break;
				break;
			}
			current = parent;
		}
		if (current !== ancestor) return null;
		return segments.join(" > ") || null;
	}
	/**
	* Try to build a unique anchor selector for an ancestor (id or stable data-* only).
	*/
	function tryAnchorSelector(element, root) {
		const idSel = tryIdSelector(element, root);
		if (idSel) return idSel;
		const tag = element.tagName.toLowerCase();
		for (const attr of ANCHOR_DATA_ATTRS) {
			var _element$getAttribute2;
			const value = (_element$getAttribute2 = element.getAttribute(attr)) === null || _element$getAttribute2 === void 0 ? void 0 : _element$getAttribute2.trim();
			if (!value) continue;
			const attrOnly = `[${attr}="${cssEscape(value)}"]`;
			if (isUnique(root, attrOnly)) return attrOnly;
			const withTag = `${tag}${attrOnly}`;
			if (isUnique(root, withTag)) return withTag;
		}
		return null;
	}
	/**
	* Build an "anchor + relative path" selector candidate.
	* Finds a unique ancestor (id or stable data-*) and appends a relative path from there.
	* This improves matching when the target itself doesn't have unique attributes.
	*/
	function buildAnchorRelPathSelector(element, root) {
		let current = element.parentElement;
		for (let depth = 0; current && depth < MAX_ANCHOR_DEPTH; depth++) {
			const tag = current.tagName.toUpperCase();
			if (tag === "HTML" || tag === "BODY") break;
			const anchor = tryAnchorSelector(current, root);
			if (anchor) {
				const rel = buildRelativePathSelector(current, element, root);
				if (!rel) {
					current = current.parentElement;
					continue;
				}
				const composed = `${anchor} ${rel}`;
				if (!isUnique(root, composed)) {
					current = current.parentElement;
					continue;
				}
				if (safeQuerySelector(root, composed) === element) return composed;
			}
			current = current.parentElement;
		}
		return null;
	}
	/**
	* Get selector chain for shadow host ancestors (from outer to inner)
	*/
	function getShadowHostChain(element) {
		const chain = [];
		let current = element;
		while (true) {
			var _current$getRootNode;
			const root = (_current$getRootNode = current.getRootNode) === null || _current$getRootNode === void 0 ? void 0 : _current$getRootNode.call(current);
			if (!(root instanceof ShadowRoot)) break;
			const host = root.host;
			if (!(host instanceof Element)) break;
			const hostSelector = generateCssSelector(host, { root: getQueryRoot(host) });
			if (!hostSelector) break;
			chain.unshift(hostSelector);
			current = host;
		}
		return chain.length > 0 ? chain : void 0;
	}
	/**
	* Normalize text content for fingerprinting
	*/
	function normalizeText$3(text, maxLength) {
		return text.replace(/\s+/g, " ").trim().slice(0, maxLength);
	}
	/**
	* Compute a structural fingerprint for fuzzy element matching
	*/
	function computeFingerprint(element) {
		var _element$tagName$toLo, _element$tagName, _element$id2, _element$textContent;
		const parts = [];
		const tag = (_element$tagName$toLo = (_element$tagName = element.tagName) === null || _element$tagName === void 0 ? void 0 : _element$tagName.toLowerCase()) !== null && _element$tagName$toLo !== void 0 ? _element$tagName$toLo : "unknown";
		parts.push(tag);
		const id = (_element$id2 = element.id) === null || _element$id2 === void 0 ? void 0 : _element$id2.trim();
		if (id) parts.push(`id=${id}`);
		const classes = Array.from(element.classList).slice(0, FINGERPRINT_MAX_CLASSES);
		if (classes.length > 0) parts.push(`class=${classes.join(".")}`);
		const text = normalizeText$3((_element$textContent = element.textContent) !== null && _element$textContent !== void 0 ? _element$textContent : "", FINGERPRINT_TEXT_MAX_LENGTH);
		if (text) parts.push(`text=${text}`);
		return parts.join("|");
	}
	/**
	* Compute the DOM tree path as child indices from root
	*/
	function computeDomPath(element) {
		const path = [];
		let current = element;
		while (current) {
			const parent = current.parentElement;
			if (parent) {
				const index = Array.from(parent.children).indexOf(current);
				if (index >= 0) path.unshift(index);
				current = parent;
				continue;
			}
			const parentNode = current.parentNode;
			if (parentNode instanceof ShadowRoot || parentNode instanceof Document) {
				const index = Array.from(parentNode.children).indexOf(current);
				if (index >= 0) path.unshift(index);
			}
			break;
		}
		return path;
	}
	/**
	* Generate multiple CSS selector candidates for an element.
	* Phase 2.9 enhanced: Collects multiple candidates from each strategy.
	*
	* Candidates are ordered by preference: ID > data-attrs > classes > path > anchor+relPath
	*/
	function generateSelectorCandidates(element, options = {}) {
		var _options$root, _options$maxCandidate;
		const root = (_options$root = options.root) !== null && _options$root !== void 0 ? _options$root : getQueryRoot(element);
		const maxCandidates = Math.max(1, (_options$maxCandidate = options.maxCandidates) !== null && _options$maxCandidate !== void 0 ? _options$maxCandidate : DEFAULT_MAX_CANDIDATES);
		const candidates = [];
		const push = (selector, limit = maxCandidates) => {
			if (!selector) return;
			if (candidates.length >= limit) return;
			const s = selector.trim();
			if (!s || candidates.includes(s)) return;
			candidates.push(s);
		};
		const anchorCandidate = maxCandidates >= DEFAULT_MAX_CANDIDATES ? buildAnchorRelPathSelector(element, root) : null;
		const headLimit = Math.max(1, maxCandidates - (1 + (anchorCandidate ? 1 : 0)));
		push(tryIdSelector(element, root), headLimit);
		for (const sel of collectDataAttrSelectors(element, root, headLimit - candidates.length)) push(sel, headLimit);
		for (const sel of collectClassSelectors(element, root, headLimit - candidates.length)) push(sel, headLimit);
		push(buildPathSelector(element, root));
		push(anchorCandidate);
		return candidates.slice(0, maxCandidates);
	}
	/**
	* Generate a single best CSS selector for an element
	*/
	function generateCssSelector(element, options = {}) {
		var _generateSelectorCand;
		return (_generateSelectorCand = generateSelectorCandidates(element, options)[0]) !== null && _generateSelectorCand !== void 0 ? _generateSelectorCand : "";
	}
	/**
	* Create a complete ElementLocator for an element.
	* The locator contains multiple strategies for re-identification.
	*/
	function createElementLocator(element) {
		var _findDebugSource;
		const root = getQueryRoot(element);
		const debugSource = (_findDebugSource = findDebugSource(element)) !== null && _findDebugSource !== void 0 ? _findDebugSource : void 0;
		return {
			selectors: generateSelectorCandidates(element, {
				root,
				maxCandidates: DEFAULT_MAX_CANDIDATES
			}),
			fingerprint: computeFingerprint(element),
			path: computeDomPath(element),
			shadowHostChain: getShadowHostChain(element),
			debugSource
		};
	}
	/**
	* Safely check if a selector matches exactly one element
	*/
	function isSelectorUnique(root, selector) {
		try {
			return root.querySelectorAll(selector).length === 1;
		} catch (_unused3) {
			return false;
		}
	}
	/**
	* Verify element matches the stored fingerprint
	*/
	function verifyFingerprint(element, fingerprint) {
		const currentFingerprint = computeFingerprint(element);
		const storedParts = fingerprint.split("|");
		const currentParts = currentFingerprint.split("|");
		if (storedParts[0] !== currentParts[0]) return false;
		const storedId = storedParts.find((p) => p.startsWith("id="));
		const currentId = currentParts.find((p) => p.startsWith("id="));
		if (storedId && storedId !== currentId) return false;
		return true;
	}
	/**
	* Resolve an ElementLocator to a DOM element.
	* Traverses Shadow DOM boundaries and tries multiple selector candidates.
	* Includes uniqueness verification to avoid misidentification.
	*/
	function locateElement(locator, rootDocument = document) {
		var _locator$frameChain, _locator$shadowHostCh;
		let doc = rootDocument;
		if ((_locator$frameChain = locator.frameChain) === null || _locator$frameChain === void 0 ? void 0 : _locator$frameChain.length) for (const frameSelector of locator.frameChain) {
			const frame = safeQuerySelector(doc, frameSelector);
			if (!(frame instanceof HTMLIFrameElement)) return null;
			const contentDoc = frame.contentDocument;
			if (!contentDoc) return null;
			doc = contentDoc;
		}
		let queryRoot = doc;
		if ((_locator$shadowHostCh = locator.shadowHostChain) === null || _locator$shadowHostCh === void 0 ? void 0 : _locator$shadowHostCh.length) for (const hostSelector of locator.shadowHostChain) {
			if (!isSelectorUnique(queryRoot, hostSelector)) return null;
			const host = safeQuerySelector(queryRoot, hostSelector);
			if (!host) return null;
			const shadowRoot = host.shadowRoot;
			if (!shadowRoot) return null;
			queryRoot = shadowRoot;
		}
		for (const selector of locator.selectors) {
			if (!isSelectorUnique(queryRoot, selector)) continue;
			const element = safeQuerySelector(queryRoot, selector);
			if (!element) continue;
			if (locator.fingerprint && !verifyFingerprint(element, locator.fingerprint)) continue;
			return element;
		}
		return null;
	}
	/**
	* Generate a unique key for an ElementLocator (for comparison/caching)
	*/
	function locatorKey(locator) {
		var _locator$shadowHostCh2, _locator$shadowHostCh3, _locator$frameChain$j, _locator$frameChain2;
		const selectors = locator.selectors.join("|");
		const shadow = (_locator$shadowHostCh2 = (_locator$shadowHostCh3 = locator.shadowHostChain) === null || _locator$shadowHostCh3 === void 0 ? void 0 : _locator$shadowHostCh3.join(">")) !== null && _locator$shadowHostCh2 !== void 0 ? _locator$shadowHostCh2 : "";
		return `frame:${(_locator$frameChain$j = (_locator$frameChain2 = locator.frameChain) === null || _locator$frameChain2 === void 0 ? void 0 : _locator$frameChain2.join(">")) !== null && _locator$frameChain$j !== void 0 ? _locator$frameChain$j : ""}|shadow:${shadow}|sel:${selectors}`;
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/props-panel.ts
	var WRITE_DEBOUNCE_MS = 250;
	var DANGEROUS_PROP_KEYS = new Set([
		"__proto__",
		"constructor",
		"prototype",
		"__defineGetter__",
		"__defineSetter__",
		"__lookupGetter__",
		"__lookupSetter__"
	]);
	function isDangerousPropKey(key) {
		return DANGEROUS_PROP_KEYS.has(String(key !== null && key !== void 0 ? key : "").trim());
	}
	function formatFramework(framework, version) {
		if (framework === "react") {
			const trimmedVersion = version === null || version === void 0 ? void 0 : version.trim();
			return trimmedVersion ? `React ${trimmedVersion}` : "React";
		}
		if (framework === "vue") {
			const trimmedVersion = version === null || version === void 0 ? void 0 : version.trim();
			return trimmedVersion ? `Vue ${trimmedVersion}` : "Vue";
		}
		return "Unknown";
	}
	function formatHookStatus(hookStatus) {
		return hookStatus ? String(hookStatus) : "";
	}
	/**
	* Format debug source for display.
	* Returns empty string if source is invalid/missing.
	*/
	function formatDebugSource(source) {
		if (!source || typeof source !== "object") return "";
		const rec = source;
		const file = typeof rec.file === "string" ? rec.file.trim() : "";
		if (!file) return "";
		const lineRaw = Number(rec.line);
		const columnRaw = Number(rec.column);
		const line = Number.isFinite(lineRaw) && lineRaw > 0 ? lineRaw : void 0;
		const column = Number.isFinite(columnRaw) && columnRaw > 0 ? columnRaw : void 0;
		if (!line) return file;
		return column ? `${file}:${line}:${column}` : `${file}:${line}`;
	}
	function formatSerializedValue(value) {
		switch (value.kind) {
			case "null": return "null";
			case "undefined": return "undefined";
			case "boolean": return value.value ? "true" : "false";
			case "number":
				if (value.special) return value.special;
				if (typeof value.value === "number") return String(value.value);
				return "NaN";
			case "string": return value.truncated ? `"${value.value}…"` : JSON.stringify(value.value);
			case "bigint": return `${value.value}n`;
			case "symbol": return `Symbol(${value.description})`;
			case "function":
				var _value$name;
				return `ƒ ${(_value$name = value.name) !== null && _value$name !== void 0 ? _value$name : "(anonymous)"}`;
			case "react_element": return value.display;
			case "dom_element":
				var _value$tagName;
				return `<${String((_value$tagName = value.tagName) !== null && _value$tagName !== void 0 ? _value$tagName : "").toLowerCase() || "element"}${value.id ? `#${value.id}` : ""}${value.className ? `.${String(value.className).split(/\s+/).filter(Boolean).slice(0, 2).join(".")}` : ""}>`;
			case "date": return value.value;
			case "regexp": return `/${value.source}/${value.flags}`;
			case "error": return `${value.name}: ${value.message}`;
			case "circular": return `[Circular #${value.refId}]`;
			case "max_depth": return value.preview;
			case "array": return `Array(${value.length})`;
			case "object":
				var _value$name2;
				return `${(_value$name2 = value.name) !== null && _value$name2 !== void 0 ? _value$name2 : "Object"} {…}`;
			case "map": return `Map(${value.size})`;
			case "set": return `Set(${value.size})`;
			case "unknown": return value.preview;
			default:
				var _value$kind;
				return String((_value$kind = value.kind) !== null && _value$kind !== void 0 ? _value$kind : "unknown");
		}
	}
	function canRenderEditableNumber(value) {
		if (value.special) return false;
		if (typeof value.value !== "number") return false;
		return Number.isFinite(value.value);
	}
	function parseNumberInput(raw) {
		const trimmed = raw.trim();
		if (!trimmed) return { ok: false };
		if (/^-?\d+\.$/.test(trimmed)) {
			const n = Number(trimmed.slice(0, -1));
			return Number.isFinite(n) ? {
				ok: true,
				value: n
			} : { ok: false };
		}
		if (/^-?(?:\d+|\d*\.\d+)$/.test(trimmed)) {
			const n = Number(trimmed);
			return Number.isFinite(n) ? {
				ok: true,
				value: n
			} : { ok: false };
		}
		return { ok: false };
	}
	function mergeResponseData(prev, next) {
		var _next$capabilities, _next$props, _prev$meta, _next$meta;
		if (!next) return prev;
		if (!prev) return next;
		return _objectSpread2(_objectSpread2(_objectSpread2({}, prev), next), {}, {
			capabilities: (_next$capabilities = next.capabilities) !== null && _next$capabilities !== void 0 ? _next$capabilities : prev.capabilities,
			props: (_next$props = next.props) !== null && _next$props !== void 0 ? _next$props : prev.props,
			meta: _objectSpread2(_objectSpread2({}, (_prev$meta = prev.meta) !== null && _prev$meta !== void 0 ? _prev$meta : {}), (_next$meta = next.meta) !== null && _next$meta !== void 0 ? _next$meta : {})
		});
	}
	function buildStatusLine(loading, data, error) {
		if (loading) return "Loading…";
		if (!data) return error ? `Error • ${error}` : "Waiting for selection…";
		const parts = [];
		const caps = data.capabilities;
		if (caps) {
			parts.push(`read: ${caps.canRead ? "yes" : "no"}`);
			parts.push(`write: ${caps.canWrite ? "yes" : "no"}`);
		} else {
			parts.push("read: unknown");
			parts.push("write: unknown");
		}
		const hook = formatHookStatus(data.hookStatus);
		if (hook) parts.push(`hook: ${hook}`);
		if (data.needsRefresh) parts.push("needs refresh");
		if (error) parts.push("error");
		return parts.join(" • ");
	}
	function getCanWrite(data) {
		var _data$capabilities;
		return Boolean(data === null || data === void 0 || (_data$capabilities = data.capabilities) === null || _data$capabilities === void 0 ? void 0 : _data$capabilities.canWrite) && !(data === null || data === void 0 ? void 0 : data.needsRefresh);
	}
	function getCanRead(data) {
		var _data$capabilities2;
		return Boolean(data === null || data === void 0 || (_data$capabilities2 = data.capabilities) === null || _data$capabilities2 === void 0 ? void 0 : _data$capabilities2.canRead);
	}
	function findPropEntry(data, key) {
		var _props$entries$find;
		const props = data === null || data === void 0 ? void 0 : data.props;
		if (!props || !Array.isArray(props.entries)) return null;
		return (_props$entries$find = props.entries.find((e) => e.key === key)) !== null && _props$entries$find !== void 0 ? _props$entries$find : null;
	}
	function setInputFromEntry(entry, input) {
		input.classList.remove("we-props-input--invalid");
		if (entry.value.kind === "string") {
			var _entry$value$value;
			input.value = (_entry$value$value = entry.value.value) !== null && _entry$value$value !== void 0 ? _entry$value$value : "";
			return;
		}
		if (entry.value.kind === "number") {
			if (typeof entry.value.value === "number" && Number.isFinite(entry.value.value)) input.value = String(entry.value.value);
			else if (entry.value.special) input.value = entry.value.special;
			else input.value = "";
			return;
		}
		if (entry.value.kind === "boolean") input.checked = Boolean(entry.value.value);
	}
	function updateLocalPrimitiveSnapshot(data, key, value) {
		var _data$props;
		if (!(data === null || data === void 0 || (_data$props = data.props) === null || _data$props === void 0 ? void 0 : _data$props.entries)) return;
		const entry = data.props.entries.find((e) => e.key === key);
		if (!entry) return;
		if (typeof value === "string") {
			entry.value = {
				kind: "string",
				value
			};
			entry.editable = true;
			return;
		}
		if (typeof value === "number") {
			entry.value = {
				kind: "number",
				value
			};
			entry.editable = true;
			return;
		}
		entry.value = {
			kind: "boolean",
			value
		};
		entry.editable = true;
	}
	function createPropsPanel(options) {
		const { container, propsBridge } = options;
		const disposer = new Disposer();
		const tooltip = document.createElement("div");
		tooltip.className = "we-tooltip";
		tooltip.hidden = true;
		const rootNode = container.getRootNode();
		if (rootNode instanceof ShadowRoot) rootNode.appendChild(tooltip);
		else document.body.appendChild(tooltip);
		disposer.add(() => tooltip.remove());
		function showTooltip(el) {
			const text = el.getAttribute("data-tip");
			if (!text) {
				tooltip.hidden = true;
				return;
			}
			const rect = el.getBoundingClientRect();
			tooltip.textContent = text;
			tooltip.style.left = `${rect.left + rect.width / 2}px`;
			tooltip.style.top = `${rect.bottom + 4}px`;
			tooltip.hidden = false;
		}
		function hideTooltip() {
			tooltip.hidden = true;
		}
		let currentTarget = null;
		let currentLocator = null;
		let isVisible = false;
		let needsFetchOnVisible = false;
		let loading = false;
		let sessionId = 0;
		let lastData = null;
		let lastError = null;
		const pendingWrites = /* @__PURE__ */ new Map();
		const root = document.createElement("div");
		root.className = "we-props-panel";
		const meta = document.createElement("div");
		meta.className = "we-props-meta";
		const metaTitleRow = document.createElement("div");
		metaTitleRow.className = "we-props-meta-title";
		const titleLeft = document.createElement("div");
		titleLeft.className = "we-props-title-left";
		const componentEl = document.createElement("div");
		componentEl.className = "we-props-component";
		componentEl.textContent = "Props";
		const frameworkEl = document.createElement("span");
		frameworkEl.className = "we-props-badge";
		frameworkEl.textContent = "Unknown";
		titleLeft.append(componentEl, frameworkEl);
		const titleActions = document.createElement("div");
		titleActions.className = "we-props-title-actions";
		const refreshBtn = document.createElement("button");
		refreshBtn.type = "button";
		refreshBtn.className = "we-props-action-btn";
		refreshBtn.dataset.tip = "Refresh";
		refreshBtn.setAttribute("aria-label", "Refresh props");
		refreshBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M11.5 7C11.5 9.48528 9.48528 11.5 7 11.5C4.51472 11.5 2.5 9.48528 2.5 7C2.5 4.51472 4.51472 2.5 7 2.5C8.5 2.5 9.83 3.25 10.6 4.4M10.6 2V4.4H8.2" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
		const resetBtn = document.createElement("button");
		resetBtn.type = "button";
		resetBtn.className = "we-props-action-btn";
		resetBtn.dataset.tip = "Reset";
		resetBtn.setAttribute("aria-label", "Reset props changes");
		resetBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3 5.5H8.5C10.1569 5.5 11.5 6.84315 11.5 8.5C11.5 10.1569 10.1569 11.5 8.5 11.5H7M3 5.5L5.5 3M3 5.5L5.5 8" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
		titleActions.append(refreshBtn, resetBtn);
		metaTitleRow.append(titleLeft, titleActions);
		const statusEl = document.createElement("div");
		statusEl.className = "we-props-status";
		const warningEl = document.createElement("div");
		warningEl.className = "we-props-warning";
		warningEl.hidden = true;
		const errorEl = document.createElement("div");
		errorEl.className = "we-props-error";
		errorEl.hidden = true;
		const sourceRow = document.createElement("div");
		sourceRow.className = "we-props-source";
		sourceRow.hidden = true;
		const sourceLabelEl = document.createElement("span");
		sourceLabelEl.className = "we-props-source-label";
		sourceLabelEl.textContent = "Source";
		const sourcePathEl = document.createElement("span");
		sourcePathEl.className = "we-props-source-path";
		sourcePathEl.title = "";
		const openSourceBtn = document.createElement("button");
		openSourceBtn.type = "button";
		openSourceBtn.className = "we-props-source-btn";
		openSourceBtn.dataset.tip = "Open in VSCode";
		openSourceBtn.setAttribute("aria-label", "Open in VSCode");
		openSourceBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3.5 2.5H9.5V8.5M9 3L3 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
		sourceRow.append(sourceLabelEl, sourcePathEl, openSourceBtn);
		meta.append(metaTitleRow, statusEl, warningEl, errorEl, sourceRow);
		const list = document.createElement("div");
		list.className = "we-props-list";
		const emptyState = document.createElement("div");
		emptyState.className = "we-props-empty";
		emptyState.textContent = "Select an element to view props.";
		const rows = document.createElement("div");
		rows.className = "we-props-rows";
		list.append(emptyState, rows);
		root.append(meta, list);
		container.append(root);
		disposer.add(() => root.remove());
		function clearAllPendingWrites() {
			for (const [, entry] of pendingWrites) clearTimeout(entry.timeoutId);
			pendingWrites.clear();
		}
		/**
		* Flush all pending writes to the current target before switching elements.
		* This ensures user edits are not lost when selection changes quickly.
		*/
		function flushAllPendingWrites() {
			if (pendingWrites.size === 0) return;
			const keys = [...pendingWrites.keys()];
			for (const key of keys) {
				const entry = pendingWrites.get(key);
				if (!entry) continue;
				clearTimeout(entry.timeoutId);
				pendingWrites.delete(key);
				commitWrite(key, entry.value);
			}
		}
		disposer.add(clearAllPendingWrites);
		function cancelPendingWrite(key) {
			const existing = pendingWrites.get(key);
			if (!existing) return;
			clearTimeout(existing.timeoutId);
			pendingWrites.delete(key);
		}
		function flushPendingWrite(key) {
			const existing = pendingWrites.get(key);
			if (!existing) return;
			clearTimeout(existing.timeoutId);
			pendingWrites.delete(key);
			commitWrite(key, existing.value);
		}
		function scheduleWrite(key, value) {
			cancelPendingWrite(key);
			const timeoutId = window.setTimeout(() => {
				pendingWrites.delete(key);
				commitWrite(key, value);
			}, WRITE_DEBOUNCE_MS);
			pendingWrites.set(key, {
				timeoutId,
				value
			});
		}
		function renderMeta() {
			var _lastError;
			const hasTarget = Boolean(currentTarget && currentTarget.isConnected);
			const framework = lastData === null || lastData === void 0 ? void 0 : lastData.framework;
			const frameworkVersion = lastData === null || lastData === void 0 ? void 0 : lastData.frameworkVersion;
			componentEl.textContent = (lastData === null || lastData === void 0 ? void 0 : lastData.componentName) || "Props";
			frameworkEl.textContent = formatFramework(framework, frameworkVersion);
			statusEl.textContent = hasTarget ? buildStatusLine(loading, lastData, lastError) : "Select an element to view props.";
			warningEl.hidden = true;
			warningEl.textContent = "";
			if (hasTarget) {
				var _lastData$props;
				if (lastData === null || lastData === void 0 ? void 0 : lastData.needsRefresh) {
					warningEl.hidden = false;
					warningEl.textContent = "A page refresh is required for full props inspection/editing.";
				} else if ((lastData === null || lastData === void 0 ? void 0 : lastData.hookStatus) === "RENDERERS_NO_EDITING") {
					warningEl.hidden = false;
					warningEl.textContent = "Editing is unavailable (likely a production build without overrideProps).";
				} else if (lastData === null || lastData === void 0 || (_lastData$props = lastData.props) === null || _lastData$props === void 0 ? void 0 : _lastData$props.truncated) {
					warningEl.hidden = false;
					warningEl.textContent = "Props list is truncated.";
				}
			}
			errorEl.hidden = !lastError;
			errorEl.textContent = (_lastError = lastError) !== null && _lastError !== void 0 ? _lastError : "";
			const sourceText = hasTarget ? formatDebugSource(lastData === null || lastData === void 0 ? void 0 : lastData.debugSource) : "";
			sourceRow.hidden = !sourceText;
			sourcePathEl.textContent = sourceText;
			sourcePathEl.title = sourceText;
			openSourceBtn.disabled = !sourceText || loading;
			const hookStatus = lastData === null || lastData === void 0 ? void 0 : lastData.hookStatus;
			const canBenefitFromEarlyInjection = hookStatus === "HOOK_MISSING" || hookStatus === "HOOK_PRESENT_NO_RENDERERS";
			const showEnableReload = (lastData === null || lastData === void 0 ? void 0 : lastData.needsRefresh) && canBenefitFromEarlyInjection;
			refreshBtn.dataset.tip = showEnableReload ? "Enable & Reload" : "Refresh";
			refreshBtn.disabled = !hasTarget || loading;
			resetBtn.disabled = !hasTarget || loading || !getCanWrite(lastData);
		}
		function renderList() {
			rows.innerHTML = "";
			const hasTarget = Boolean(currentTarget && currentTarget.isConnected);
			const data = lastData;
			if (!hasTarget) {
				emptyState.hidden = false;
				emptyState.classList.remove("we-loading");
				emptyState.textContent = "Select an element to view props.";
				return;
			}
			if (loading) {
				emptyState.hidden = false;
				emptyState.classList.add("we-loading");
				emptyState.innerHTML = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" style="animation: we-spin 0.8s linear infinite;">
        <circle cx="7" cy="7" r="5.5" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-dasharray="20 14" />
      </svg><span>Loading props…</span>`;
				return;
			}
			emptyState.classList.remove("we-loading");
			if (!getCanRead(data)) {
				emptyState.hidden = false;
				const hook = data === null || data === void 0 ? void 0 : data.hookStatus;
				if ((data === null || data === void 0 ? void 0 : data.needsRefresh) || hook === "HOOK_MISSING" || hook === "HOOK_PRESENT_NO_RENDERERS") emptyState.textContent = "Props inspection is not ready. Refresh the page in development mode.";
				else if (hook === "RENDERERS_NO_EDITING") emptyState.textContent = "Props inspection/editing is unavailable in this build.";
				else emptyState.textContent = "Props inspection is not available for this element.";
				return;
			}
			const props = data === null || data === void 0 ? void 0 : data.props;
			if (!props || !Array.isArray(props.entries) || props.entries.length === 0) {
				emptyState.hidden = false;
				emptyState.textContent = (data === null || data === void 0 ? void 0 : data.framework) === "vue" ? "No props or attrs found." : "No props found.";
				return;
			}
			emptyState.hidden = true;
			const disableEdits = !getCanWrite(data) || loading;
			const isVue = (data === null || data === void 0 ? void 0 : data.framework) === "vue";
			const entries = props.entries;
			const groups = isVue && entries.some((e) => e.source === "attrs") ? [{
				title: "Props",
				entries: entries.filter((e) => e.source !== "attrs")
			}, {
				title: "Attrs",
				entries: entries.filter((e) => e.source === "attrs")
			}].filter((g) => g.entries.length > 0) : [{
				title: "",
				entries
			}];
			for (const group of groups) {
				if (group.title) {
					const groupHeader = document.createElement("div");
					groupHeader.className = "we-props-group";
					groupHeader.textContent = group.title;
					rows.append(groupHeader);
				}
				for (const entry of group.entries) {
					const row = document.createElement("div");
					row.className = "we-props-row";
					const keyEl = document.createElement("div");
					keyEl.className = "we-props-key";
					keyEl.textContent = entry.key;
					const valueEl = document.createElement("div");
					valueEl.className = "we-props-value";
					const keyIsDangerous = isDangerousPropKey(entry.key);
					const entryEditable = Boolean(entry.editable) && !keyIsDangerous;
					const filteredEnumValues = (Array.isArray(entry.enumValues) ? entry.enumValues : []).filter((v) => typeof v === "string" && v.trim().length > 0);
					if (entryEditable && entry.value.kind === "string" && filteredEnumValues.length > 0) {
						var _entry$value$value2;
						const select = document.createElement("select");
						select.className = "we-select we-props-input";
						select.disabled = disableEdits;
						select.dataset.propKey = entry.key;
						select.dataset.propKind = "enum";
						select.setAttribute("aria-label", `Select prop ${entry.key}`);
						const currentValue = (_entry$value$value2 = entry.value.value) !== null && _entry$value$value2 !== void 0 ? _entry$value$value2 : "";
						const seen = /* @__PURE__ */ new Set();
						if (currentValue && !filteredEnumValues.includes(currentValue)) {
							const opt = document.createElement("option");
							opt.value = currentValue;
							opt.textContent = `${currentValue} (current)`;
							select.append(opt);
							seen.add(currentValue);
						}
						for (const v of filteredEnumValues) {
							if (seen.has(v)) continue;
							seen.add(v);
							const opt = document.createElement("option");
							opt.value = v;
							opt.textContent = v;
							select.append(opt);
						}
						if (currentValue && seen.has(currentValue)) select.value = currentValue;
						valueEl.append(select);
					} else if (entryEditable && entry.value.kind === "boolean") {
						const label = document.createElement("label");
						label.className = "we-props-bool";
						const checkbox = document.createElement("input");
						checkbox.type = "checkbox";
						checkbox.className = "we-props-checkbox";
						checkbox.checked = Boolean(entry.value.value);
						checkbox.disabled = disableEdits;
						checkbox.dataset.propKey = entry.key;
						checkbox.dataset.propKind = "boolean";
						checkbox.setAttribute("aria-label", `Toggle prop ${entry.key}`);
						const text = document.createElement("span");
						text.textContent = checkbox.checked ? "true" : "false";
						text.dataset.weBoolText = "1";
						label.append(checkbox, text);
						valueEl.append(label);
					} else if (entryEditable && entry.value.kind === "string") {
						var _entry$value$value3;
						const input = document.createElement("input");
						input.type = "text";
						input.className = "we-input we-props-input";
						input.autocomplete = "off";
						input.spellcheck = false;
						input.value = (_entry$value$value3 = entry.value.value) !== null && _entry$value$value3 !== void 0 ? _entry$value$value3 : "";
						input.disabled = disableEdits;
						input.dataset.propKey = entry.key;
						input.dataset.propKind = "string";
						input.setAttribute("aria-label", `Edit prop ${entry.key}`);
						valueEl.append(input);
					} else if (entryEditable && entry.value.kind === "number" && canRenderEditableNumber(entry.value)) {
						const input = document.createElement("input");
						input.type = "text";
						input.inputMode = "decimal";
						input.className = "we-input we-props-input";
						input.autocomplete = "off";
						input.spellcheck = false;
						input.value = String(entry.value.value);
						input.disabled = disableEdits;
						input.dataset.propKey = entry.key;
						input.dataset.propKind = "number";
						input.setAttribute("aria-label", `Edit prop ${entry.key}`);
						valueEl.append(input);
					} else {
						valueEl.classList.add("we-props-value--readonly");
						valueEl.textContent = keyIsDangerous ? `${formatSerializedValue(entry.value)} (blocked)` : formatSerializedValue(entry.value);
					}
					row.append(keyEl, valueEl);
					rows.append(row);
				}
			}
		}
		function renderAll() {
			renderMeta();
			renderList();
		}
		function probeAndRead() {
			return _probeAndRead.apply(this, arguments);
		}
		function _probeAndRead() {
			_probeAndRead = _asyncToGenerator(function* () {
				if (disposer.isDisposed) return;
				if (!isVisible) {
					needsFetchOnVisible = true;
					return;
				}
				const target = currentTarget;
				const locator = currentLocator;
				if (!target || !target.isConnected || !locator) {
					lastData = null;
					lastError = null;
					loading = false;
					needsFetchOnVisible = false;
					renderAll();
					return;
				}
				const localSession = sessionId;
				loading = true;
				lastError = null;
				renderAll();
				try {
					var _probeResult$data;
					const probeResult = yield propsBridge.probe(locator);
					if (disposer.isDisposed || localSession !== sessionId) return;
					lastData = mergeResponseData(lastData, probeResult.data);
					if (!probeResult.ok) {
						var _probeResult$error;
						lastError = (_probeResult$error = probeResult.error) !== null && _probeResult$error !== void 0 ? _probeResult$error : "Props probe failed";
					}
					if (Boolean((_probeResult$data = probeResult.data) === null || _probeResult$data === void 0 || (_probeResult$data = _probeResult$data.capabilities) === null || _probeResult$data === void 0 ? void 0 : _probeResult$data.canRead)) {
						const readResult = yield propsBridge.read(locator);
						if (disposer.isDisposed || localSession !== sessionId) return;
						lastData = mergeResponseData(lastData, readResult.data);
						if (!readResult.ok) {
							var _readResult$error;
							lastError = (_readResult$error = readResult.error) !== null && _readResult$error !== void 0 ? _readResult$error : "Props read failed";
						}
					}
				} catch (err) {
					if (disposer.isDisposed || localSession !== sessionId) return;
					lastError = err instanceof Error ? err.message : String(err);
				} finally {
					if (!disposer.isDisposed && localSession === sessionId) {
						loading = false;
						needsFetchOnVisible = false;
						renderAll();
					}
				}
			});
			return _probeAndRead.apply(this, arguments);
		}
		function commitWrite(_x, _x2) {
			return _commitWrite.apply(this, arguments);
		}
		function _commitWrite() {
			_commitWrite = _asyncToGenerator(function* (key, value) {
				if (disposer.isDisposed) return;
				const target = currentTarget;
				const locator = currentLocator;
				if (!target || !target.isConnected || !locator) return;
				if (isDangerousPropKey(key)) {
					lastError = "Blocked prop key (security)";
					renderMeta();
					return;
				}
				const localSession = sessionId;
				if (!getCanWrite(lastData)) {
					lastError = "Props editing is not available for this element.";
					renderMeta();
					return;
				}
				try {
					const result = yield propsBridge.write(locator, [key], value);
					if (disposer.isDisposed || localSession !== sessionId) return;
					lastData = mergeResponseData(lastData, result.data);
					if (!result.ok) {
						var _result$error;
						lastError = (_result$error = result.error) !== null && _result$error !== void 0 ? _result$error : "Props write failed";
						renderMeta();
						return;
					}
					lastError = null;
					updateLocalPrimitiveSnapshot(lastData, key, value);
					renderMeta();
				} catch (err) {
					if (disposer.isDisposed || localSession !== sessionId) return;
					lastError = err instanceof Error ? err.message : String(err);
					renderMeta();
				}
			});
			return _commitWrite.apply(this, arguments);
		}
		function resetOverrides() {
			return _resetOverrides.apply(this, arguments);
		}
		function _resetOverrides() {
			_resetOverrides = _asyncToGenerator(function* () {
				if (disposer.isDisposed) return;
				const target = currentTarget;
				const locator = currentLocator;
				if (!target || !target.isConnected || !locator) return;
				const localSession = sessionId;
				clearAllPendingWrites();
				loading = true;
				lastError = null;
				renderAll();
				try {
					const result = yield propsBridge.reset(locator);
					if (disposer.isDisposed || localSession !== sessionId) return;
					lastData = mergeResponseData(lastData, result.data);
					if (!result.ok) {
						var _result$error2;
						lastError = (_result$error2 = result.error) !== null && _result$error2 !== void 0 ? _result$error2 : "Props reset failed";
					}
				} catch (err) {
					if (disposer.isDisposed || localSession !== sessionId) return;
					lastError = err instanceof Error ? err.message : String(err);
				} finally {
					if (!disposer.isDisposed && localSession === sessionId) {
						loading = false;
						renderMeta();
						probeAndRead();
					}
				}
			});
			return _resetOverrides.apply(this, arguments);
		}
		/**
		* Register early injection and reload the page.
		* This allows capturing React DevTools hook before React initializes.
		*/
		function registerEarlyInjectionAndReload() {
			return _registerEarlyInjectionAndReload.apply(this, arguments);
		}
		function _registerEarlyInjectionAndReload() {
			_registerEarlyInjectionAndReload = _asyncToGenerator(function* () {
				var _chrome$runtime;
				if (disposer.isDisposed) return;
				if (typeof chrome === "undefined" || !((_chrome$runtime = chrome.runtime) === null || _chrome$runtime === void 0 ? void 0 : _chrome$runtime.sendMessage)) {
					lastError = "Chrome runtime API not available";
					renderMeta();
					return;
				}
				if (!window.confirm("Props editing requires early injection to capture React renderers before they initialize.\n\nThis will:\n• Register a content script for this site\n• Reload the page immediately\n\nAfter reload, enable the editor again to access full Props functionality.\n\nContinue?")) return;
				try {
					const resp = yield chrome.runtime.sendMessage({ type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_PROPS_REGISTER_EARLY_INJECTION });
					if (!(resp === null || resp === void 0 ? void 0 : resp.success)) {
						var _resp$error;
						lastError = (_resp$error = resp === null || resp === void 0 ? void 0 : resp.error) !== null && _resp$error !== void 0 ? _resp$error : "Failed to register early injection";
						renderMeta();
					}
				} catch (err) {
					lastError = err instanceof Error ? err.message : String(err);
					renderMeta();
				}
			});
			return _registerEarlyInjectionAndReload.apply(this, arguments);
		}
		/**
		* Send message to background to open source file in VSCode.
		*/
		function openSourceInVSCode() {
			return _openSourceInVSCode.apply(this, arguments);
		}
		function _openSourceInVSCode() {
			_openSourceInVSCode = _asyncToGenerator(function* () {
				var _chrome$runtime2;
				if (disposer.isDisposed) return;
				const debugSource = lastData === null || lastData === void 0 ? void 0 : lastData.debugSource;
				if (!debugSource || !formatDebugSource(debugSource)) return;
				if (typeof chrome === "undefined" || !((_chrome$runtime2 = chrome.runtime) === null || _chrome$runtime2 === void 0 ? void 0 : _chrome$runtime2.sendMessage)) {
					lastError = "Chrome runtime API not available";
					renderMeta();
					return;
				}
				try {
					const resp = yield chrome.runtime.sendMessage({
						type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_OPEN_SOURCE,
						payload: { debugSource }
					});
					if ((resp === null || resp === void 0 ? void 0 : resp.success) === false) {
						var _resp$error2;
						lastError = (_resp$error2 = resp === null || resp === void 0 ? void 0 : resp.error) !== null && _resp$error2 !== void 0 ? _resp$error2 : "Failed to open source in VSCode";
						renderMeta();
					}
				} catch (err) {
					lastError = err instanceof Error ? err.message : String(err);
					renderMeta();
				}
			});
			return _openSourceInVSCode.apply(this, arguments);
		}
		const bindTooltip = (el) => {
			disposer.listen(el, "mouseenter", () => showTooltip(el));
			disposer.listen(el, "mouseleave", hideTooltip);
		};
		bindTooltip(refreshBtn);
		bindTooltip(resetBtn);
		bindTooltip(openSourceBtn);
		disposer.listen(refreshBtn, "click", (e) => {
			e.preventDefault();
			clearAllPendingWrites();
			const hookStatus = lastData === null || lastData === void 0 ? void 0 : lastData.hookStatus;
			const canBenefitFromEarlyInjection = hookStatus === "HOOK_MISSING" || hookStatus === "HOOK_PRESENT_NO_RENDERERS";
			if ((lastData === null || lastData === void 0 ? void 0 : lastData.needsRefresh) && canBenefitFromEarlyInjection) {
				registerEarlyInjectionAndReload();
				return;
			}
			probeAndRead();
		});
		disposer.listen(resetBtn, "click", (e) => {
			e.preventDefault();
			resetOverrides();
		});
		disposer.listen(openSourceBtn, "click", (e) => {
			e.preventDefault();
			openSourceInVSCode();
		});
		disposer.listen(rows, "input", (e) => {
			var _target$dataset$propK, _target$dataset$propK2;
			const target = e.target;
			if (!(target instanceof HTMLInputElement)) return;
			if (target.disabled) return;
			if (target.type === "checkbox") return;
			const key = (_target$dataset$propK = target.dataset.propKey) !== null && _target$dataset$propK !== void 0 ? _target$dataset$propK : "";
			const kind = (_target$dataset$propK2 = target.dataset.propKind) !== null && _target$dataset$propK2 !== void 0 ? _target$dataset$propK2 : "";
			if (!key || !kind) return;
			if (isDangerousPropKey(key)) return;
			if (e.isComposing) return;
			if (kind === "string") {
				scheduleWrite(key, target.value);
				return;
			}
			if (kind === "number") {
				const parsed = parseNumberInput(target.value);
				if (!target.value.trim()) {
					cancelPendingWrite(key);
					target.classList.remove("we-props-input--invalid");
					return;
				}
				if (!parsed.ok) {
					cancelPendingWrite(key);
					target.classList.add("we-props-input--invalid");
					return;
				}
				target.classList.remove("we-props-input--invalid");
				scheduleWrite(key, parsed.value);
			}
		});
		disposer.listen(rows, "change", (e) => {
			var _target$dataset$propK5, _target$dataset$propK6, _label$querySelector;
			const target = e.target;
			if (!target) return;
			if (target instanceof HTMLSelectElement) {
				var _target$dataset$propK3, _target$dataset$propK4;
				if (target.disabled) return;
				const key = (_target$dataset$propK3 = target.dataset.propKey) !== null && _target$dataset$propK3 !== void 0 ? _target$dataset$propK3 : "";
				const kind = (_target$dataset$propK4 = target.dataset.propKind) !== null && _target$dataset$propK4 !== void 0 ? _target$dataset$propK4 : "";
				if (!key || kind !== "enum") return;
				if (isDangerousPropKey(key)) return;
				commitWrite(key, target.value);
				return;
			}
			if (!(target instanceof HTMLInputElement)) return;
			if (target.disabled) return;
			if (target.type !== "checkbox") return;
			const key = (_target$dataset$propK5 = target.dataset.propKey) !== null && _target$dataset$propK5 !== void 0 ? _target$dataset$propK5 : "";
			const kind = (_target$dataset$propK6 = target.dataset.propKind) !== null && _target$dataset$propK6 !== void 0 ? _target$dataset$propK6 : "";
			if (!key || kind !== "boolean") return;
			if (isDangerousPropKey(key)) return;
			const label = target.closest(".we-props-bool");
			const text = label === null || label === void 0 || (_label$querySelector = label.querySelector) === null || _label$querySelector === void 0 ? void 0 : _label$querySelector.call(label, "span[data-we-bool-text=\"1\"]");
			if (text) text.textContent = target.checked ? "true" : "false";
			commitWrite(key, target.checked);
		});
		disposer.listen(rows, "keydown", (e) => {
			var _target$dataset$propK7, _target$dataset$propK8;
			const target = e.target;
			if (!(target instanceof HTMLInputElement)) return;
			if (target.disabled) return;
			const key = (_target$dataset$propK7 = target.dataset.propKey) !== null && _target$dataset$propK7 !== void 0 ? _target$dataset$propK7 : "";
			const kind = (_target$dataset$propK8 = target.dataset.propKind) !== null && _target$dataset$propK8 !== void 0 ? _target$dataset$propK8 : "";
			if (!key || !kind) return;
			if (e.key === "Enter") {
				if (e.isComposing) return;
				e.preventDefault();
				flushPendingWrite(key);
				try {
					target.blur();
				} catch (_unused) {}
				return;
			}
			if (e.key === "Escape") {
				e.preventDefault();
				cancelPendingWrite(key);
				const entry = findPropEntry(lastData, key);
				if (!entry) return;
				setInputFromEntry(entry, target);
			}
		});
		disposer.listen(rows, "focusout", (e) => {
			var _target$dataset$propK9, _target$dataset$propK10;
			const target = e.target;
			if (!(target instanceof HTMLInputElement)) return;
			if (target.disabled) return;
			const key = (_target$dataset$propK9 = target.dataset.propKey) !== null && _target$dataset$propK9 !== void 0 ? _target$dataset$propK9 : "";
			const kind = (_target$dataset$propK10 = target.dataset.propKind) !== null && _target$dataset$propK10 !== void 0 ? _target$dataset$propK10 : "";
			if (!key) return;
			if (kind === "number") {
				const parsed = parseNumberInput(target.value);
				if (!target.value.trim() || !parsed.ok) {
					cancelPendingWrite(key);
					target.classList.remove("we-props-input--invalid");
					const entry = findPropEntry(lastData, key);
					if (entry) setInputFromEntry(entry, target);
					return;
				}
			}
			flushPendingWrite(key);
		});
		function setTarget(element) {
			if (disposer.isDisposed) return;
			flushAllPendingWrites();
			sessionId += 1;
			currentTarget = element && element.isConnected ? element : null;
			currentLocator = currentTarget ? createElementLocator(currentTarget) : null;
			lastData = null;
			lastError = null;
			loading = false;
			needsFetchOnVisible = false;
			renderAll();
			if (isVisible) probeAndRead();
			else needsFetchOnVisible = true;
		}
		function refresh() {
			if (disposer.isDisposed) return;
			clearAllPendingWrites();
			probeAndRead();
		}
		function setVisible(visible) {
			if (disposer.isDisposed) return;
			isVisible = visible;
			if (visible && needsFetchOnVisible) probeAndRead();
		}
		function dispose() {
			currentTarget = null;
			currentLocator = null;
			lastData = null;
			lastError = null;
			loading = false;
			needsFetchOnVisible = false;
			disposer.dispose();
		}
		renderAll();
		return {
			setTarget,
			refresh,
			setVisible,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/ui/property-panel/property-panel.ts
	/**
	* Property Panel
	*
	* Right-side panel displaying Design controls, CSS styles, Props, and DOM tree for selected elements.
	*
	* Features:
	* - Tab switching between Design, CSS, Props, and DOM views
	* - Collapsible control groups (Position, Layout, Size, Spacing, Typography, Appearance, Border, Background, Effects)
	* - CSS panel showing matched rules and inheritance (Phase 4.6)
	* - Props panel for React/Vue component props editing (Phase 7.3)
	* - Empty state when no element is selected
	* - Close button integration
	* - Automatic control initialization and lifecycle management
	*/
	/** Control group configuration */
	var CONTROL_GROUPS = [
		{
			id: "position",
			label: "Position",
			collapsible: true
		},
		{
			id: "layout",
			label: "Layout",
			collapsible: true
		},
		{
			id: "size",
			label: "Size",
			collapsible: true
		},
		{
			id: "spacing",
			label: "Spacing",
			collapsible: true
		},
		{
			id: "typography",
			label: "Typography",
			collapsible: true
		},
		{
			id: "appearance",
			label: "Appearance",
			collapsible: true
		},
		{
			id: "border",
			label: "Border",
			collapsible: true
		},
		{
			id: "background",
			label: "Background",
			collapsible: true
		},
		{
			id: "effects",
			label: "Effects",
			collapsible: false
		}
	];
	var groupIdSeq = 0;
	/**
	* Format element label for display (tag + id/classes)
	*/
	function formatTargetLabel(element) {
		var _htmlEl$id, _element$classList;
		const tag = element.tagName.toLowerCase();
		const id = (_htmlEl$id = element.id) === null || _htmlEl$id === void 0 ? void 0 : _htmlEl$id.trim();
		if (id) return `${tag}#${id}`;
		const classes = Array.from((_element$classList = element.classList) !== null && _element$classList !== void 0 ? _element$classList : []).slice(0, 2);
		if (classes.length > 0) return `${tag}.${classes.join(".")}`;
		return tag;
	}
	/**
	* Create a control group (optionally collapsible)
	*/
	function createControlGroup(groupId, label, disposer, opts) {
		var _opts$collapsible;
		const uniqueId = `we_group_${groupId}_${++groupIdSeq}`;
		const collapsible = (_opts$collapsible = opts === null || opts === void 0 ? void 0 : opts.collapsible) !== null && _opts$collapsible !== void 0 ? _opts$collapsible : true;
		let collapsed = false;
		const root = document.createElement("section");
		root.className = "we-group";
		root.dataset.group = groupId;
		root.dataset.collapsed = "false";
		const header = document.createElement("div");
		header.className = "we-group-header";
		const labelSpan = document.createElement("span");
		labelSpan.textContent = label;
		let toggleEl;
		if (collapsible) {
			const toggleBtn = document.createElement("button");
			toggleBtn.type = "button";
			toggleBtn.className = "we-group-toggle";
			toggleBtn.setAttribute("aria-expanded", "true");
			toggleBtn.setAttribute("aria-controls", uniqueId);
			toggleBtn.append(labelSpan, createChevronIcon());
			disposer.listen(toggleBtn, "click", (event) => {
				event.preventDefault();
				toggle();
			});
			toggleEl = toggleBtn;
		} else {
			const staticLabel = document.createElement("div");
			staticLabel.className = "we-group-toggle we-group-toggle--static";
			staticLabel.append(labelSpan);
			toggleEl = staticLabel;
		}
		const headerActions = document.createElement("div");
		headerActions.className = "we-group-header-actions";
		header.append(toggleEl, headerActions);
		const body = document.createElement("div");
		body.className = "we-group-body";
		body.id = uniqueId;
		root.append(header, body);
		function setCollapsed(value) {
			if (!collapsible) return;
			collapsed = value;
			root.dataset.collapsed = collapsed ? "true" : "false";
			toggleEl.setAttribute("aria-expanded", collapsed ? "false" : "true");
		}
		function isCollapsed() {
			return collapsed;
		}
		function toggle() {
			if (!collapsible) return;
			setCollapsed(!collapsed);
		}
		return {
			root,
			body,
			headerActions,
			setCollapsed,
			isCollapsed,
			toggle
		};
	}
	/**
	* Create the Property Panel component
	*/
	function createPropertyPanel(options) {
		var _options$defaultTab, _options$initialPosit;
		const disposer = new Disposer();
		let currentTarget = null;
		let currentTab = (_options$defaultTab = options.defaultTab) !== null && _options$defaultTab !== void 0 ? _options$defaultTab : "design";
		let minimized = false;
		let floatingPosition = (_options$initialPosit = options.initialPosition) !== null && _options$initialPosit !== void 0 ? _options$initialPosit : null;
		const controlGroups = /* @__PURE__ */ new Map();
		const controls = [];
		let componentsTree = null;
		let cssPanel = null;
		let propsPanel = null;
		let sizeControl = null;
		let positionControl = null;
		let spacingControl = null;
		let styleObserver = null;
		let styleObserverTarget = null;
		let styleObserverRafId = null;
		const root = document.createElement("aside");
		root.className = "we-panel we-prop-panel";
		root.setAttribute("role", "complementary");
		root.setAttribute("aria-label", "Properties");
		root.dataset.tab = currentTab;
		root.dataset.empty = "true";
		root.dataset.minimized = "false";
		root.dataset.dragged = floatingPosition ? "true" : "false";
		const header = document.createElement("header");
		header.className = "we-header";
		const dragHandle = document.createElement("button");
		dragHandle.type = "button";
		dragHandle.className = "we-drag-handle";
		dragHandle.setAttribute("aria-label", "Drag property panel");
		dragHandle.dataset.tooltip = "Drag";
		dragHandle.append(createGripIcon());
		const targetLabel = document.createElement("div");
		targetLabel.className = "we-prop-target";
		targetLabel.hidden = true;
		const tabsContainer = document.createElement("div");
		tabsContainer.className = "we-prop-tabs";
		tabsContainer.setAttribute("role", "tablist");
		tabsContainer.setAttribute("aria-label", "Property tabs");
		const designTabBtn = document.createElement("button");
		designTabBtn.type = "button";
		designTabBtn.className = "we-tab";
		designTabBtn.setAttribute("role", "tab");
		designTabBtn.dataset.tab = "design";
		designTabBtn.textContent = "Design";
		const cssTabBtn = document.createElement("button");
		cssTabBtn.type = "button";
		cssTabBtn.className = "we-tab";
		cssTabBtn.setAttribute("role", "tab");
		cssTabBtn.dataset.tab = "css";
		cssTabBtn.textContent = "CSS";
		const propsTabBtn = document.createElement("button");
		propsTabBtn.type = "button";
		propsTabBtn.className = "we-tab";
		propsTabBtn.setAttribute("role", "tab");
		propsTabBtn.dataset.tab = "props";
		propsTabBtn.textContent = "Props";
		const domTabBtn = document.createElement("button");
		domTabBtn.type = "button";
		domTabBtn.className = "we-tab";
		domTabBtn.setAttribute("role", "tab");
		domTabBtn.dataset.tab = "dom";
		domTabBtn.textContent = "DOM";
		tabsContainer.append(designTabBtn, cssTabBtn, propsTabBtn, domTabBtn);
		const minimizeBtn = document.createElement("button");
		minimizeBtn.type = "button";
		minimizeBtn.className = "we-icon-btn we-minimize-btn";
		minimizeBtn.setAttribute("aria-label", "Minimize property panel");
		minimizeBtn.dataset.tooltip = "Minimize";
		minimizeBtn.append(createChevronUpIcon());
		header.append(dragHandle, tabsContainer, minimizeBtn, targetLabel);
		const body = document.createElement("div");
		body.className = "we-prop-body";
		const emptyState = document.createElement("div");
		emptyState.className = "we-prop-empty";
		emptyState.textContent = "Select an element to view and edit its properties.";
		const designPanel = document.createElement("div");
		designPanel.className = "we-prop-tab-content";
		designPanel.dataset.tabContent = "design";
		for (const { id, label, collapsible } of CONTROL_GROUPS) {
			const group = createControlGroup(id, label, disposer, { collapsible });
			controlGroups.set(id, group);
			designPanel.append(group.root);
		}
		const cssPanelContainer = document.createElement("div");
		cssPanelContainer.className = "we-prop-tab-content";
		cssPanelContainer.dataset.tabContent = "css";
		const propsPanelContainer = document.createElement("div");
		propsPanelContainer.className = "we-prop-tab-content";
		propsPanelContainer.dataset.tabContent = "props";
		const domPanel = document.createElement("div");
		domPanel.className = "we-prop-tab-content";
		domPanel.dataset.tabContent = "dom";
		body.append(emptyState, designPanel, cssPanelContainer, propsPanelContainer, domPanel);
		root.append(header, body);
		options.container.append(root);
		disposer.add(() => root.remove());
		const CLAMP_MARGIN_PX = 16;
		function clampToViewport(position) {
			const rect = root.getBoundingClientRect();
			const viewportW = window.innerWidth;
			const viewportH = window.innerHeight;
			const margin = CLAMP_MARGIN_PX;
			const maxLeft = Math.max(margin, viewportW - margin - rect.width);
			const maxTop = Math.max(margin, viewportH - margin - rect.height);
			const left = Number.isFinite(position.left) ? position.left : 0;
			const top = Number.isFinite(position.top) ? position.top : 0;
			return {
				left: Math.round(Math.min(maxLeft, Math.max(margin, left))),
				top: Math.round(Math.min(maxTop, Math.max(margin, top)))
			};
		}
		function syncFloatingPositionStyles() {
			root.dataset.dragged = floatingPosition ? "true" : "false";
			if (!floatingPosition || minimized) {
				root.style.left = "";
				root.style.top = "";
				root.style.right = "";
				root.style.bottom = "";
				return;
			}
			root.style.left = `${floatingPosition.left}px`;
			root.style.top = `${floatingPosition.top}px`;
			root.style.right = "auto";
			root.style.bottom = "auto";
		}
		function setPosition(position) {
			var _options$onPositionCh;
			floatingPosition = position ? clampToViewport(position) : null;
			syncFloatingPositionStyles();
			(_options$onPositionCh = options.onPositionChange) === null || _options$onPositionCh === void 0 || _options$onPositionCh.call(options, floatingPosition);
		}
		function getPosition() {
			return floatingPosition;
		}
		disposer.add(installFloatingDrag({
			handleEl: dragHandle,
			targetEl: root,
			clampMargin: CLAMP_MARGIN_PX,
			onPositionChange: (pos) => setPosition(pos)
		}));
		if (floatingPosition !== null) setPosition(floatingPosition);
		else syncFloatingPositionStyles();
		/**
		* Initialize all design controls.
		* Controls are created once and manage their own lifecycle.
		*/
		function initializeControls() {
			const sizeGroup = controlGroups.get("size");
			if (sizeGroup) {
				sizeControl = createSizeControl({
					container: sizeGroup.body,
					transactionManager: options.transactionManager
				});
				controls.push(sizeControl);
			}
			const spacingGroup = controlGroups.get("spacing");
			if (spacingGroup) {
				spacingControl = createSpacingControl({
					container: spacingGroup.body,
					transactionManager: options.transactionManager
				});
				controls.push(spacingControl);
			}
			const positionGroup = controlGroups.get("position");
			if (positionGroup) {
				positionControl = createPositionControl({
					container: positionGroup.body,
					transactionManager: options.transactionManager
				});
				controls.push(positionControl);
			}
			const layoutGroup = controlGroups.get("layout");
			if (layoutGroup) {
				const layoutControl = createLayoutControl({
					container: layoutGroup.body,
					transactionManager: options.transactionManager
				});
				controls.push(layoutControl);
			}
			const typographyGroup = controlGroups.get("typography");
			if (typographyGroup) {
				const typographyControl = createTypographyControl({
					container: typographyGroup.body,
					transactionManager: options.transactionManager,
					tokensService: options.tokensService
				});
				controls.push(typographyControl);
			}
			const appearanceGroup = controlGroups.get("appearance");
			if (appearanceGroup) {
				const appearanceControl = createAppearanceControl({
					container: appearanceGroup.body,
					transactionManager: options.transactionManager
				});
				controls.push(appearanceControl);
			}
			const borderGroup = controlGroups.get("border");
			if (borderGroup) {
				const borderControl = createBorderControl({
					container: borderGroup.body,
					transactionManager: options.transactionManager,
					tokensService: options.tokensService
				});
				controls.push(borderControl);
			}
			const backgroundGroup = controlGroups.get("background");
			if (backgroundGroup) {
				const backgroundControl = createBackgroundControl({
					container: backgroundGroup.body,
					transactionManager: options.transactionManager,
					tokensService: options.tokensService
				});
				controls.push(backgroundControl);
			}
			const effectsGroup = controlGroups.get("effects");
			if (effectsGroup) {
				const effectsControl = createEffectsControl({
					container: effectsGroup.body,
					transactionManager: options.transactionManager,
					tokensService: options.tokensService,
					headerActionsContainer: effectsGroup.headerActions
				});
				controls.push(effectsControl);
			}
		}
		initializeControls();
		componentsTree = createComponentsTree({
			container: domPanel,
			onSelect: (element) => {
				options.onSelectElement(element);
			}
		});
		cssPanel = createCssPanel({
			container: cssPanelContainer,
			transactionManager: options.transactionManager,
			onClassChange: () => {
				if (currentTarget) targetLabel.textContent = formatTargetLabel(currentTarget);
			}
		});
		propsPanel = createPropsPanel({
			container: propsPanelContainer,
			propsBridge: options.propsBridge
		});
		disposer.listen(designTabBtn, "click", (event) => {
			event.preventDefault();
			setTab("design");
		});
		disposer.listen(cssTabBtn, "click", (event) => {
			event.preventDefault();
			setTab("css");
		});
		disposer.listen(propsTabBtn, "click", (event) => {
			event.preventDefault();
			setTab("props");
		});
		disposer.listen(domTabBtn, "click", (event) => {
			event.preventDefault();
			setTab("dom");
		});
		disposer.listen(minimizeBtn, "click", (event) => {
			event.preventDefault();
			setMinimized(!minimized);
		});
		/**
		* Toggle minimized state of property panel
		*/
		function setMinimized(value) {
			minimized = value;
			root.dataset.minimized = minimized ? "true" : "false";
			body.hidden = minimized;
			tabsContainer.hidden = minimized;
			minimizeBtn.setAttribute("aria-label", minimized ? "Expand property panel" : "Minimize property panel");
			minimizeBtn.dataset.tooltip = minimized ? "Expand" : "Minimize";
			if (!minimized && floatingPosition) setPosition(floatingPosition);
			else syncFloatingPositionStyles();
		}
		/**
		* Update tab button states and panel visibility
		*/
		function renderTabs() {
			root.dataset.tab = currentTab;
			designTabBtn.setAttribute("aria-selected", currentTab === "design" ? "true" : "false");
			cssTabBtn.setAttribute("aria-selected", currentTab === "css" ? "true" : "false");
			propsTabBtn.setAttribute("aria-selected", currentTab === "props" ? "true" : "false");
			domTabBtn.setAttribute("aria-selected", currentTab === "dom" ? "true" : "false");
			const hasTarget = currentTarget !== null;
			designPanel.hidden = !hasTarget || currentTab !== "design";
			cssPanelContainer.hidden = !hasTarget || currentTab !== "css";
			propsPanelContainer.hidden = !hasTarget || currentTab !== "props";
			domPanel.hidden = !hasTarget || currentTab !== "dom";
			cssPanel === null || cssPanel === void 0 || cssPanel.setVisible(hasTarget && currentTab === "css");
			propsPanel === null || propsPanel === void 0 || propsPanel.setVisible(hasTarget && currentTab === "props");
		}
		/**
		* Update empty state visibility
		*/
		function renderEmptyState() {
			const hasTarget = currentTarget !== null;
			root.dataset.empty = hasTarget ? "false" : "true";
			emptyState.hidden = hasTarget;
			if (!hasTarget) targetLabel.textContent = "";
			renderTabs();
		}
		/**
		* Update all controls with current target
		*/
		function updateControls() {
			for (const control of controls) control.setTarget(currentTarget);
			componentsTree === null || componentsTree === void 0 || componentsTree.setTarget(currentTarget);
			cssPanel === null || cssPanel === void 0 || cssPanel.setTarget(currentTarget);
			propsPanel === null || propsPanel === void 0 || propsPanel.setTarget(currentTarget);
		}
		/**
		* Cancel pending rAF for style observer
		*/
		function cancelStyleObserverRaf() {
			if (styleObserverRafId !== null) {
				cancelAnimationFrame(styleObserverRafId);
				styleObserverRafId = null;
			}
		}
		/**
		* Schedule a throttled refresh of size/position/spacing controls.
		* Uses rAF to coalesce multiple style mutations within the same frame.
		*/
		function scheduleLiveStyleRefresh() {
			if (disposer.isDisposed) return;
			if (styleObserverRafId !== null) return;
			styleObserverRafId = requestAnimationFrame(() => {
				styleObserverRafId = null;
				if (disposer.isDisposed) return;
				if (!currentTarget || !currentTarget.isConnected) return;
				sizeControl === null || sizeControl === void 0 || sizeControl.refresh();
				positionControl === null || positionControl === void 0 || positionControl.refresh();
				spacingControl === null || spacingControl === void 0 || spacingControl.refresh();
			});
		}
		/**
		* Disconnect the style observer and clean up
		*/
		function disconnectStyleObserver() {
			cancelStyleObserverRaf();
			if (styleObserver) try {
				styleObserver.disconnect();
			} catch (_unused) {}
			styleObserver = null;
			styleObserverTarget = null;
		}
		/**
		* Connect a MutationObserver to watch for style attribute changes on the target.
		* This enables live sync when external code (like resize handles) modifies inline styles.
		*/
		function connectStyleObserver(target) {
			disconnectStyleObserver();
			if (!target || !target.isConnected) return;
			if (typeof MutationObserver === "undefined") return;
			styleObserverTarget = target;
			styleObserver = new MutationObserver(() => {
				if (disposer.isDisposed) return;
				if (styleObserverTarget !== currentTarget) return;
				scheduleLiveStyleRefresh();
			});
			try {
				styleObserver.observe(target, {
					attributes: true,
					attributeFilter: ["style"]
				});
			} catch (_unused2) {
				disconnectStyleObserver();
			}
		}
		disposer.add(disconnectStyleObserver);
		function setTarget(element) {
			if (disposer.isDisposed) return;
			currentTarget = element;
			if (element) targetLabel.textContent = formatTargetLabel(element);
			renderEmptyState();
			updateControls();
			connectStyleObserver(currentTarget);
		}
		function setTab(tab) {
			if (disposer.isDisposed) return;
			currentTab = tab;
			renderTabs();
		}
		function getTab() {
			return currentTab;
		}
		function refresh() {
			if (disposer.isDisposed) return;
			if (currentTarget) targetLabel.textContent = formatTargetLabel(currentTarget);
			for (const control of controls) control.refresh();
			componentsTree === null || componentsTree === void 0 || componentsTree.refresh();
			cssPanel === null || cssPanel === void 0 || cssPanel.refresh();
			propsPanel === null || propsPanel === void 0 || propsPanel.refresh();
		}
		function dispose() {
			componentsTree === null || componentsTree === void 0 || componentsTree.dispose();
			componentsTree = null;
			cssPanel === null || cssPanel === void 0 || cssPanel.dispose();
			cssPanel = null;
			propsPanel === null || propsPanel === void 0 || propsPanel.dispose();
			propsPanel = null;
			for (const control of controls) control.dispose();
			controls.length = 0;
			controlGroups.clear();
			currentTarget = null;
			disposer.dispose();
		}
		renderEmptyState();
		return {
			setTarget,
			setTab,
			getTab,
			refresh,
			getPosition,
			setPosition,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/props-bridge.ts
	/**
	* Custom error with response data attached
	*/
	var PropsError = class extends Error {
		constructor(message, data) {
			super(message);
			_defineProperty(this, "data", void 0);
			this.name = "PropsError";
			this.data = data;
		}
	};
	var EVENT_NAME = {
		REQUEST: "web-editor-props:request",
		RESPONSE: "web-editor-props:response",
		CLEANUP: "web-editor-props:cleanup"
	};
	var PROTOCOL_VERSION = 1;
	var DEFAULT_TIMEOUT_MS = 2500;
	var MIN_TIMEOUT_MS = 200;
	function createRequestId() {
		try {
			if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
		} catch (_unused) {}
		return `req-${Date.now()}-${Math.random().toString(16).slice(2)}`;
	}
	function encodePropValue(value) {
		if (value === void 0) return { $we: "undefined" };
		return value;
	}
	function isObject(value) {
		return value !== null && typeof value === "object";
	}
	function normalizeErrorMessage(err) {
		if (err instanceof Error) return err.message || String(err);
		return String(err);
	}
	function isEditablePrimitive(value) {
		if (value === null || value === void 0) return true;
		const t = typeof value;
		if (t === "string" || t === "boolean") return true;
		if (t === "number") return Number.isFinite(value);
		return false;
	}
	var DANGEROUS_KEYS = new Set([
		"__proto__",
		"constructor",
		"prototype",
		"__defineGetter__",
		"__defineSetter__",
		"__lookupGetter__",
		"__lookupSetter__"
	]);
	function hasDangerousKey(path) {
		return path.some((seg) => typeof seg === "string" && DANGEROUS_KEYS.has(seg));
	}
	/**
	* Create a Props Bridge instance for communicating with the MAIN world agent
	*/
	function createPropsBridge(options = {}) {
		var _options$defaultTimeo;
		const defaultTimeoutMs = Math.max(MIN_TIMEOUT_MS, (_options$defaultTimeo = options.defaultTimeoutMs) !== null && _options$defaultTimeo !== void 0 ? _options$defaultTimeo : DEFAULT_TIMEOUT_MS);
		const pending = /* @__PURE__ */ new Map();
		let disposed = false;
		function assertActive() {
			if (disposed) throw new PropsError("PropsBridge is disposed");
		}
		function clearPending(error) {
			for (const [requestId, entry] of pending) {
				clearTimeout(entry.timeoutId);
				entry.resolve({
					ok: false,
					error
				});
				pending.delete(requestId);
			}
		}
		function onResponse(event) {
			var _detail$data;
			if (disposed) return;
			const detail = event.detail;
			if (!isObject(detail)) return;
			if (detail.v !== PROTOCOL_VERSION) return;
			const requestId = typeof detail.requestId === "string" ? detail.requestId : "";
			if (!requestId) return;
			const entry = pending.get(requestId);
			if (!entry) return;
			pending.delete(requestId);
			clearTimeout(entry.timeoutId);
			const success = Boolean(detail.success);
			const data = (_detail$data = detail.data) !== null && _detail$data !== void 0 ? _detail$data : void 0;
			const error = typeof detail.error === "string" ? detail.error : void 0;
			entry.resolve({
				ok: success,
				data,
				error: success ? void 0 : error || "Props agent error"
			});
		}
		window.addEventListener(EVENT_NAME.RESPONSE, onResponse);
		function sendRequest(request, timeoutMs) {
			assertActive();
			const { requestId } = request;
			if (!requestId) return Promise.resolve({
				ok: false,
				error: "requestId is required"
			});
			if (pending.has(requestId)) return Promise.resolve({
				ok: false,
				error: `Duplicate requestId: ${requestId}`
			});
			return new Promise((resolve) => {
				const timeoutId = window.setTimeout(() => {
					pending.delete(requestId);
					resolve({
						ok: false,
						error: `Props agent timeout after ${timeoutMs}ms (op=${request.op})`
					});
				}, timeoutMs);
				pending.set(requestId, {
					resolve,
					timeoutId
				});
				try {
					window.dispatchEvent(new CustomEvent(EVENT_NAME.REQUEST, { detail: request }));
				} catch (err) {
					clearTimeout(timeoutId);
					pending.delete(requestId);
					resolve({
						ok: false,
						error: `Failed to dispatch props request: ${normalizeErrorMessage(err)}`
					});
				}
			});
		}
		function probe(_x, _x2) {
			return _probe.apply(this, arguments);
		}
		function _probe() {
			_probe = _asyncToGenerator(function* (locator, timeoutMs) {
				return sendRequest({
					v: PROTOCOL_VERSION,
					requestId: createRequestId(),
					op: "probe",
					locator
				}, Math.max(MIN_TIMEOUT_MS, timeoutMs !== null && timeoutMs !== void 0 ? timeoutMs : defaultTimeoutMs));
			});
			return _probe.apply(this, arguments);
		}
		function read(_x3, _x4) {
			return _read.apply(this, arguments);
		}
		function _read() {
			_read = _asyncToGenerator(function* (locator, timeoutMs) {
				return sendRequest({
					v: PROTOCOL_VERSION,
					requestId: createRequestId(),
					op: "read",
					locator
				}, Math.max(MIN_TIMEOUT_MS, timeoutMs !== null && timeoutMs !== void 0 ? timeoutMs : defaultTimeoutMs));
			});
			return _read.apply(this, arguments);
		}
		function write(_x5, _x6, _x7, _x8) {
			return _write.apply(this, arguments);
		}
		function _write() {
			_write = _asyncToGenerator(function* (locator, path, value, timeoutMs) {
				if (!Array.isArray(path) || path.length === 0) return {
					ok: false,
					error: "prop path is required"
				};
				if (hasDangerousKey(path)) return {
					ok: false,
					error: "Invalid prop path: contains dangerous key"
				};
				if (!isEditablePrimitive(value)) return {
					ok: false,
					error: "Only primitive prop values are supported"
				};
				return sendRequest({
					v: PROTOCOL_VERSION,
					requestId: createRequestId(),
					op: "write",
					locator,
					payload: {
						propPath: path,
						propValue: encodePropValue(value)
					}
				}, Math.max(MIN_TIMEOUT_MS, timeoutMs !== null && timeoutMs !== void 0 ? timeoutMs : defaultTimeoutMs));
			});
			return _write.apply(this, arguments);
		}
		function reset(_x9, _x10) {
			return _reset.apply(this, arguments);
		}
		function _reset() {
			_reset = _asyncToGenerator(function* (locator, timeoutMs) {
				return sendRequest({
					v: PROTOCOL_VERSION,
					requestId: createRequestId(),
					op: "reset",
					locator
				}, Math.max(MIN_TIMEOUT_MS, timeoutMs !== null && timeoutMs !== void 0 ? timeoutMs : defaultTimeoutMs));
			});
			return _reset.apply(this, arguments);
		}
		function cleanup(_x11) {
			return _cleanup.apply(this, arguments);
		}
		function _cleanup() {
			_cleanup = _asyncToGenerator(function* (timeoutMs) {
				if (disposed) return;
				const ms = Math.max(MIN_TIMEOUT_MS, timeoutMs !== null && timeoutMs !== void 0 ? timeoutMs : 800);
				try {
					yield sendRequest({
						v: PROTOCOL_VERSION,
						requestId: createRequestId(),
						op: "cleanup"
					}, ms);
				} catch (_unused2) {} finally {
					try {
						window.dispatchEvent(new CustomEvent(EVENT_NAME.CLEANUP));
					} catch (_unused3) {}
					dispose();
				}
			});
			return _cleanup.apply(this, arguments);
		}
		function dispose() {
			if (disposed) return;
			disposed = true;
			try {
				window.removeEventListener(EVENT_NAME.RESPONSE, onResponse);
			} catch (_unused4) {}
			clearPending("PropsBridge disposed");
		}
		function isDisposedFn() {
			return disposed;
		}
		return {
			probe,
			read,
			write,
			reset,
			cleanup,
			dispose,
			isDisposed: isDisposedFn
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/overlay/canvas-overlay.ts
	/**
	* Canvas Overlay
	*
	* High-performance overlay renderer for visual feedback (hover, selection, guides).
	*
	* Features:
	* - DPR-aware rendering for crisp visuals on HiDPI displays
	* - rAF-coalesced rendering via markDirty() pattern
	* - ResizeObserver-backed automatic sizing
	* - Separate layers for hover, selection, and future guides
	*
	* Performance considerations:
	* - Uses `desynchronized: true` for lower latency
	* - Batches all drawing to single rAF
	* - Only redraws when dirty flag is set
	* - Pixel-aligned strokes for crisp lines
	*/
	var CANVAS_ATTR = "data-mcp-canvas";
	var CANVAS_ATTR_VALUE = "overlay";
	/** Duration of hover rect transition animation in milliseconds */
	var HOVER_ANIMATION_DURATION_MS = 100;
	/** Default styles for different box types */
	var BOX_STYLES = {
		hover: {
			strokeColor: WEB_EDITOR_V2_COLORS.hover,
			fillColor: `${WEB_EDITOR_V2_COLORS.hover}15`,
			lineWidth: 2,
			dashPattern: [6, 4]
		},
		selection: {
			strokeColor: WEB_EDITOR_V2_COLORS.selected,
			fillColor: `${WEB_EDITOR_V2_COLORS.selected}20`,
			lineWidth: 2,
			dashPattern: []
		},
		dragGhost: {
			strokeColor: WEB_EDITOR_V2_COLORS.selectionBorder,
			fillColor: WEB_EDITOR_V2_COLORS.dragGhost,
			lineWidth: 2,
			dashPattern: [8, 6]
		}
	};
	function isFinitePositive(value) {
		return Number.isFinite(value) && value > 0;
	}
	function isValidRect$2(rect) {
		if (!rect) return false;
		return Number.isFinite(rect.left) && Number.isFinite(rect.top) && isFinitePositive(rect.width) && isFinitePositive(rect.height);
	}
	function isValidLine(line) {
		if (!line) return false;
		return Number.isFinite(line.x1) && Number.isFinite(line.y1) && Number.isFinite(line.x2) && Number.isFinite(line.y2);
	}
	function clamp$1(value, min, max) {
		if (!Number.isFinite(value)) return min;
		return Math.min(max, Math.max(min, value));
	}
	/** Cubic ease-out curve: fast start, slow end (matches CSS ease-out approximately) */
	function easeOutCubic(t) {
		return 1 - Math.pow(1 - t, 3);
	}
	/** Linear interpolation between two values */
	function lerp(a, b, t) {
		return a + (b - a) * t;
	}
	/** Interpolate between two rectangles */
	function lerpRect(from, to, t) {
		return {
			left: lerp(from.left, to.left, t),
			top: lerp(from.top, to.top, t),
			width: lerp(from.width, to.width, t),
			height: lerp(from.height, to.height, t)
		};
	}
	/**
	* Build a rounded rectangle path (without beginning a new path)
	*/
	function buildRoundedRectPath(ctx, x, y, w, h, r) {
		const radius = Math.max(0, Math.min(r, Math.min(w, h) / 2));
		ctx.moveTo(x + radius, y);
		ctx.arcTo(x + w, y, x + w, y + h, radius);
		ctx.arcTo(x + w, y + h, x, y + h, radius);
		ctx.arcTo(x, y + h, x, y, radius);
		ctx.arcTo(x, y, x + w, y, radius);
		ctx.closePath();
	}
	/**
	* Create a canvas overlay for rendering visual feedback.
	*/
	function createCanvasOverlay(options) {
		const { container } = options;
		const disposer = new Disposer();
		const existing = container.querySelector(`canvas[${CANVAS_ATTR}="${CANVAS_ATTR_VALUE}"]`);
		if (existing) existing.remove();
		const canvas = document.createElement("canvas");
		canvas.setAttribute(CANVAS_ATTR, CANVAS_ATTR_VALUE);
		canvas.setAttribute("aria-hidden", "true");
		Object.assign(canvas.style, {
			position: "absolute",
			inset: "0",
			width: "100%",
			height: "100%",
			pointerEvents: "none",
			display: "block"
		});
		container.append(canvas);
		disposer.add(() => canvas.remove());
		const ctxOrNull = canvas.getContext("2d", {
			alpha: true,
			desynchronized: true
		});
		if (!ctxOrNull) {
			disposer.dispose();
			throw new Error(`${WEB_EDITOR_V2_LOG_PREFIX} Failed to get canvas 2D context`);
		}
		const ctx = ctxOrNull;
		let hoverRect = null;
		let hoverAnimation = null;
		let selectionRect = null;
		let dragGhostRect = null;
		let insertionLine = null;
		let guideLines = null;
		let distanceLabels = null;
		let viewportWidth = 1;
		let viewportHeight = 1;
		let devicePixelRatio = 1;
		let dirty = true;
		let rafId = null;
		function cancelRaf() {
			if (rafId !== null) {
				cancelAnimationFrame(rafId);
				rafId = null;
			}
		}
		disposer.add(cancelRaf);
		function scheduleRaf() {
			if (rafId !== null || disposer.isDisposed) return;
			rafId = requestAnimationFrame(() => {
				rafId = null;
				render();
			});
		}
		function updateCanvasSize() {
			const nextDpr = Math.max(1, window.devicePixelRatio || 1);
			const cssWidth = Math.max(1, viewportWidth);
			const cssHeight = Math.max(1, viewportHeight);
			const pixelWidth = Math.round(cssWidth * nextDpr);
			const pixelHeight = Math.round(cssHeight * nextDpr);
			if (!(canvas.width !== pixelWidth || canvas.height !== pixelHeight || Math.abs(devicePixelRatio - nextDpr) > .001)) return false;
			devicePixelRatio = nextDpr;
			canvas.width = pixelWidth;
			canvas.height = pixelHeight;
			ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
			ctx.lineJoin = "round";
			ctx.lineCap = "round";
			return true;
		}
		function clearCanvas() {
			updateCanvasSize();
			ctx.clearRect(0, 0, viewportWidth, viewportHeight);
		}
		function drawBox(rect, style) {
			if (!isValidRect$2(rect)) return;
			const w = Math.round(rect.width);
			const h = Math.round(rect.height);
			if (w <= 0 || h <= 0) return;
			const x = Math.round(rect.left) + .5;
			const y = Math.round(rect.top) + .5;
			ctx.save();
			ctx.lineWidth = style.lineWidth;
			ctx.strokeStyle = style.strokeColor;
			ctx.fillStyle = style.fillColor;
			ctx.setLineDash(style.dashPattern);
			ctx.beginPath();
			ctx.rect(x, y, w, h);
			ctx.fill();
			ctx.stroke();
			ctx.restore();
		}
		/**
		* Draw an insertion indicator line (horizontal)
		*/
		function drawInsertionLine(line) {
			if (!isValidLine(line)) return;
			ctx.save();
			ctx.lineWidth = 3;
			ctx.strokeStyle = WEB_EDITOR_V2_COLORS.insertionLine;
			ctx.setLineDash([]);
			ctx.lineCap = "round";
			const x1 = Math.round(line.x1) + .5;
			const y1 = Math.round(line.y1) + .5;
			const x2 = Math.round(line.x2) + .5;
			const y2 = Math.round(line.y2) + .5;
			ctx.beginPath();
			ctx.moveTo(x1, y1);
			ctx.lineTo(x2, y2);
			ctx.stroke();
			ctx.restore();
		}
		/**
		* Draw alignment guide lines (Phase 4.2)
		*
		* Guide lines indicate snap alignments during resize operations.
		* Multiple lines may be drawn simultaneously (one per axis).
		*/
		function drawGuideLines(lines) {
			if (!lines || lines.length === 0) return;
			ctx.save();
			ctx.lineWidth = 1;
			ctx.strokeStyle = WEB_EDITOR_V2_COLORS.guideLine;
			ctx.setLineDash([]);
			ctx.lineCap = "round";
			ctx.beginPath();
			for (const line of lines) {
				if (!isValidLine(line)) continue;
				const x1 = Math.round(line.x1) + .5;
				const y1 = Math.round(line.y1) + .5;
				const x2 = Math.round(line.x2) + .5;
				const y2 = Math.round(line.y2) + .5;
				ctx.moveTo(x1, y1);
				ctx.lineTo(x2, y2);
			}
			ctx.stroke();
			ctx.restore();
		}
		/**
		* Draw distance labels (Phase 4.3)
		*
		* Renders:
		* - Measurement line (pink, matches guide line color)
		* - End ticks (perpendicular marks at each end)
		* - Text pill (dark translucent background with white text)
		*/
		function drawDistanceLabels(labels) {
			if (!labels || labels.length === 0) return;
			ctx.save();
			ctx.lineWidth = 1;
			ctx.strokeStyle = WEB_EDITOR_V2_COLORS.guideLine;
			ctx.setLineDash([]);
			ctx.lineCap = "round";
			const tick = 4;
			ctx.beginPath();
			for (const label of labels) {
				const line = label.line;
				if (!isValidLine(line)) continue;
				const x1 = Math.round(line.x1) + .5;
				const y1 = Math.round(line.y1) + .5;
				const x2 = Math.round(line.x2) + .5;
				const y2 = Math.round(line.y2) + .5;
				ctx.moveTo(x1, y1);
				ctx.lineTo(x2, y2);
				if (label.axis === "x") {
					ctx.moveTo(x1, y1 - tick);
					ctx.lineTo(x1, y1 + tick);
					ctx.moveTo(x2, y2 - tick);
					ctx.lineTo(x2, y2 + tick);
				} else {
					ctx.moveTo(x1 - tick, y1);
					ctx.lineTo(x1 + tick, y1);
					ctx.moveTo(x2 - tick, y2);
					ctx.lineTo(x2 + tick, y2);
				}
			}
			ctx.stroke();
			ctx.font = WEB_EDITOR_V2_DISTANCE_LABEL_FONT;
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			for (const label of labels) {
				const line = label.line;
				if (!isValidLine(line)) continue;
				const metrics = ctx.measureText(label.text);
				const textWidth = metrics.width;
				const textHeight = (Number.isFinite(metrics.actualBoundingBoxAscent) ? metrics.actualBoundingBoxAscent : 8) + (Number.isFinite(metrics.actualBoundingBoxDescent) ? metrics.actualBoundingBoxDescent : 3);
				const pillWidth = Math.ceil(textWidth + 12);
				const pillHeight = Math.ceil(textHeight + 6);
				const midX = (line.x1 + line.x2) / 2;
				const midY = (line.y1 + line.y2) / 2;
				const offset = 8;
				let pillX = midX - pillWidth / 2;
				let pillY = midY - pillHeight / 2;
				if (label.axis === "x") {
					pillY = midY - pillHeight / 2 - offset;
					if (pillY < 0) pillY = midY + offset - pillHeight / 2;
				} else {
					pillX = midX + offset - pillWidth / 2;
					if (pillX + pillWidth > viewportWidth) pillX = midX - offset - pillWidth / 2;
				}
				const maxPillX = Math.max(2, viewportWidth - pillWidth - 2);
				const maxPillY = Math.max(2, viewportHeight - pillHeight - 2);
				pillX = clamp$1(pillX, 2, maxPillX);
				pillY = clamp$1(pillY, 2, maxPillY);
				ctx.save();
				ctx.fillStyle = WEB_EDITOR_V2_COLORS.distanceLabelBg;
				ctx.strokeStyle = WEB_EDITOR_V2_COLORS.distanceLabelBorder;
				ctx.lineWidth = 1;
				ctx.beginPath();
				buildRoundedRectPath(ctx, pillX, pillY, pillWidth, pillHeight, 4);
				ctx.fill();
				ctx.stroke();
				ctx.fillStyle = WEB_EDITOR_V2_COLORS.distanceLabelText;
				ctx.fillText(label.text, pillX + pillWidth / 2, pillY + pillHeight / 2);
				ctx.restore();
			}
			ctx.restore();
		}
		function markDirty() {
			if (disposer.isDisposed) return;
			dirty = true;
			scheduleRaf();
		}
		function render() {
			if (disposer.isDisposed || !dirty) return;
			cancelRaf();
			dirty = false;
			const now = performance.now();
			let hoverRectToRender = hoverRect;
			if (hoverAnimation) {
				const progress = clamp$1((now - hoverAnimation.startTime) / hoverAnimation.durationMs, 0, 1);
				const easedProgress = easeOutCubic(progress);
				hoverRectToRender = lerpRect(hoverAnimation.start, hoverAnimation.end, easedProgress);
				if (progress >= 1) hoverAnimation = null;
				else dirty = true;
			}
			clearCanvas();
			drawBox(hoverRectToRender, BOX_STYLES.hover);
			drawBox(selectionRect, BOX_STYLES.selection);
			drawBox(dragGhostRect, BOX_STYLES.dragGhost);
			drawInsertionLine(insertionLine);
			drawGuideLines(guideLines);
			drawDistanceLabels(distanceLabels);
			if (dirty) scheduleRaf();
		}
		function setHoverRect(rect, options) {
			if (!((options === null || options === void 0 ? void 0 : options.animate) === true)) {
				hoverAnimation = null;
				hoverRect = rect;
				markDirty();
				return;
			}
			const now = performance.now();
			let fromRect = hoverRect;
			if (hoverAnimation) {
				const easedProgress = easeOutCubic(clamp$1((now - hoverAnimation.startTime) / hoverAnimation.durationMs, 0, 1));
				fromRect = lerpRect(hoverAnimation.start, hoverAnimation.end, easedProgress);
			}
			if (!isValidRect$2(fromRect) || !isValidRect$2(rect)) {
				hoverAnimation = null;
				hoverRect = rect;
				markDirty();
				return;
			}
			hoverAnimation = {
				start: _objectSpread2({}, fromRect),
				end: _objectSpread2({}, rect),
				startTime: now,
				durationMs: HOVER_ANIMATION_DURATION_MS
			};
			hoverRect = rect;
			markDirty();
		}
		function setSelectionRect(rect) {
			selectionRect = rect;
			markDirty();
		}
		function setDragGhostRect(rect) {
			dragGhostRect = rect;
			markDirty();
		}
		function setInsertionLine(line) {
			insertionLine = line;
			markDirty();
		}
		function setGuideLines(lines) {
			guideLines = lines && lines.length > 0 ? lines : null;
			markDirty();
		}
		function setDistanceLabels(labels) {
			distanceLabels = labels && labels.length > 0 ? labels : null;
			markDirty();
		}
		function clear() {
			hoverRect = null;
			hoverAnimation = null;
			selectionRect = null;
			dragGhostRect = null;
			insertionLine = null;
			guideLines = null;
			distanceLabels = null;
			markDirty();
		}
		try {
			const rect = container.getBoundingClientRect();
			viewportWidth = Math.max(1, rect.width);
			viewportHeight = Math.max(1, rect.height);
		} catch (error) {
			console.warn(`${WEB_EDITOR_V2_LOG_PREFIX} Initial size measurement failed:`, error);
		}
		disposer.observeResize(container, (entries) => {
			const entry = entries[0];
			const rect = entry === null || entry === void 0 ? void 0 : entry.contentRect;
			if (!rect) return;
			const nextWidth = Math.max(1, rect.width);
			const nextHeight = Math.max(1, rect.height);
			if (Math.abs(nextWidth - viewportWidth) < .5 && Math.abs(nextHeight - viewportHeight) < .5) return;
			viewportWidth = nextWidth;
			viewportHeight = nextHeight;
			markDirty();
		});
		markDirty();
		return {
			canvas,
			markDirty,
			render,
			clear,
			setHoverRect,
			setSelectionRect,
			setDragGhostRect,
			setInsertionLine,
			setGuideLines,
			setDistanceLabels,
			dispose: () => disposer.dispose()
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/snap-engine.ts
	/**
	* Snap Engine (Phase 4.2)
	*
	* Computes snapping and alignment guide lines for interactive resize operations.
	*
	* Architecture:
	* - Anchor collection (DOM reads) - called once per gesture to avoid layout thrash
	* - Pure geometry computation (called every frame) - no DOM access
	*
	* Performance considerations:
	* - Siblings are collected once when gesture threshold is exceeded
	* - Distance-based filtering limits anchor count to nearest N elements
	* - Lock/hysteresis mechanism prevents flicker at threshold boundaries
	*/
	function isFiniteNumber$2(value) {
		return typeof value === "number" && Number.isFinite(value);
	}
	function isValidRect$1(rect) {
		if (!rect) return false;
		return isFiniteNumber$2(rect.left) && isFiniteNumber$2(rect.top) && isFiniteNumber$2(rect.width) && isFiniteNumber$2(rect.height) && rect.width > .5 && rect.height > .5;
	}
	function readElementRect(element) {
		try {
			const r = element.getBoundingClientRect();
			const rect = {
				left: r.left,
				top: r.top,
				width: r.width,
				height: r.height
			};
			return isValidRect$1(rect) ? rect : null;
		} catch (_unused) {
			return null;
		}
	}
	function rectRight(r) {
		return r.left + r.width;
	}
	function rectBottom(r) {
		return r.top + r.height;
	}
	function rectCenterX(r) {
		return r.left + r.width / 2;
	}
	function rectCenterY(r) {
		return r.top + r.height / 2;
	}
	/** Get X coordinate for a specific anchor type from a rect */
	function getRectXValue(rect, type) {
		switch (type) {
			case "left": return rect.left;
			case "center": return rectCenterX(rect);
			case "right": return rectRight(rect);
		}
	}
	/** Get Y coordinate for a specific anchor type from a rect */
	function getRectYValue(rect, type) {
		switch (type) {
			case "top": return rect.top;
			case "middle": return rectCenterY(rect);
			case "bottom": return rectBottom(rect);
		}
	}
	function createEmptyAnchors() {
		return {
			x: [],
			y: []
		};
	}
	/**
	* Collect snap anchors from sibling elements.
	*
	* Strategy:
	* 1. Find target's index in parent.children
	* 2. Scan outward from target (windowed scan) to avoid missing nearby siblings
	*    when target is in the middle/end of a large children list
	* 3. Read bounding rects (single layout pass per element)
	* 4. Sort by distance to target center
	* 5. Take nearest N elements
	* 6. Extract left/center/right and top/middle/bottom anchors
	*
	* 中文说明：使用双向扫描策略，从 target 位置向两侧扩展，
	* 避免当 target 在 children 后半部分时完全扫描不到附近元素。
	*/
	function collectSiblingAnchors(target) {
		const parent = target.parentElement;
		if (!parent) return createEmptyAnchors();
		const targetRect = readElementRect(target);
		const refX = targetRect ? rectCenterX(targetRect) : 0;
		const refY = targetRect ? rectCenterY(targetRect) : 0;
		const children = parent.children;
		const childCount = children.length;
		let targetIndex = -1;
		for (let i = 0; i < childCount; i++) if (children[i] === target) {
			targetIndex = i;
			break;
		}
		if (targetIndex === -1) return createEmptyAnchors();
		const candidates = [];
		let scanned = 0;
		let leftOffset = 1;
		let rightOffset = 1;
		while (scanned < 300) {
			const leftIndex = targetIndex - leftOffset;
			const rightIndex = targetIndex + rightOffset;
			const canGoLeft = leftIndex >= 0;
			const canGoRight = rightIndex < childCount;
			if (!canGoLeft && !canGoRight) break;
			if (canGoLeft) {
				const child = children[leftIndex];
				const rect = readElementRect(child);
				if (rect) {
					const dx = rectCenterX(rect) - refX;
					const dy = rectCenterY(rect) - refY;
					candidates.push({
						rect,
						distanceSquared: dx * dx + dy * dy
					});
				}
				scanned++;
				leftOffset++;
			}
			if (canGoRight && scanned < 300) {
				const child = children[rightIndex];
				const rect = readElementRect(child);
				if (rect) {
					const dx = rectCenterX(rect) - refX;
					const dy = rectCenterY(rect) - refY;
					candidates.push({
						rect,
						distanceSquared: dx * dx + dy * dy
					});
				}
				scanned++;
				rightOffset++;
			}
		}
		candidates.sort((a, b) => a.distanceSquared - b.distanceSquared);
		const selected = candidates.slice(0, 30);
		const xAnchors = [];
		const yAnchors = [];
		for (const { rect } of selected) {
			xAnchors.push({
				type: "left",
				value: rect.left,
				source: "sibling",
				sourceRect: rect
			});
			xAnchors.push({
				type: "center",
				value: rectCenterX(rect),
				source: "sibling",
				sourceRect: rect
			});
			xAnchors.push({
				type: "right",
				value: rectRight(rect),
				source: "sibling",
				sourceRect: rect
			});
			yAnchors.push({
				type: "top",
				value: rect.top,
				source: "sibling",
				sourceRect: rect
			});
			yAnchors.push({
				type: "middle",
				value: rectCenterY(rect),
				source: "sibling",
				sourceRect: rect
			});
			yAnchors.push({
				type: "bottom",
				value: rectBottom(rect),
				source: "sibling",
				sourceRect: rect
			});
		}
		return {
			x: xAnchors,
			y: yAnchors
		};
	}
	/**
	* Collect snap anchors from viewport boundaries.
	*
	* Provides left/center/right edges at x=0, x=viewport/2, x=viewport
	* and top/middle/bottom edges at corresponding y positions.
	*/
	function collectViewportAnchors() {
		const viewportWidth = Math.max(1, window.innerWidth || 1);
		const viewportHeight = Math.max(1, window.innerHeight || 1);
		return {
			x: [
				{
					type: "left",
					value: 0,
					source: "viewport"
				},
				{
					type: "center",
					value: viewportWidth / 2,
					source: "viewport"
				},
				{
					type: "right",
					value: viewportWidth,
					source: "viewport"
				}
			],
			y: [
				{
					type: "top",
					value: 0,
					source: "viewport"
				},
				{
					type: "middle",
					value: viewportHeight / 2,
					source: "viewport"
				},
				{
					type: "bottom",
					value: viewportHeight,
					source: "viewport"
				}
			]
		};
	}
	/**
	* Merge multiple anchor collections into one.
	*/
	function mergeAnchors(...collections) {
		const x = [];
		const y = [];
		for (const collection of collections) {
			x.push(...collection.x);
			y.push(...collection.y);
		}
		return {
			x,
			y
		};
	}
	/**
	* Apply X-axis snap by adjusting rect to align specified edge/center with anchor value.
	*
	* @param rect Current rectangle
	* @param fixedEdge Which edge is fixed (opposite to drag direction)
	* @param type Which part of rect to align
	* @param value Target coordinate to snap to
	* @param minSize Minimum allowed width
	* @returns Adjusted rect or null if constraint violated
	*/
	function applyXSnap(rect, fixedEdge, type, value, minSize) {
		const left = rect.left;
		const right = rectRight(rect);
		if (fixedEdge === "left") {
			if (type === "right") {
				const width = value - left;
				if (!isFiniteNumber$2(width) || width < minSize) return null;
				return {
					left,
					top: rect.top,
					width,
					height: rect.height
				};
			}
			if (type === "center") {
				const width = (value - left) * 2;
				if (!isFiniteNumber$2(width) || width < minSize) return null;
				return {
					left,
					top: rect.top,
					width,
					height: rect.height
				};
			}
			return rect;
		}
		if (fixedEdge === "right") {
			if (type === "left") {
				const width = right - value;
				if (!isFiniteNumber$2(width) || width < minSize) return null;
				return {
					left: value,
					top: rect.top,
					width,
					height: rect.height
				};
			}
			if (type === "center") {
				const nextLeft = 2 * value - right;
				const width = right - nextLeft;
				if (!isFiniteNumber$2(width) || width < minSize) return null;
				return {
					left: nextLeft,
					top: rect.top,
					width,
					height: rect.height
				};
			}
			return rect;
		}
		return rect;
	}
	/**
	* Apply Y-axis snap by adjusting rect to align specified edge/center with anchor value.
	*/
	function applyYSnap(rect, fixedEdge, type, value, minSize) {
		const top = rect.top;
		const bottom = rectBottom(rect);
		if (fixedEdge === "top") {
			if (type === "bottom") {
				const height = value - top;
				if (!isFiniteNumber$2(height) || height < minSize) return null;
				return {
					left: rect.left,
					top,
					width: rect.width,
					height
				};
			}
			if (type === "middle") {
				const height = (value - top) * 2;
				if (!isFiniteNumber$2(height) || height < minSize) return null;
				return {
					left: rect.left,
					top,
					width: rect.width,
					height
				};
			}
			return rect;
		}
		if (fixedEdge === "bottom") {
			if (type === "top") {
				const height = bottom - value;
				if (!isFiniteNumber$2(height) || height < minSize) return null;
				return {
					left: rect.left,
					top: value,
					width: rect.width,
					height
				};
			}
			if (type === "middle") {
				const nextTop = 2 * value - bottom;
				const height = bottom - nextTop;
				if (!isFiniteNumber$2(height) || height < minSize) return null;
				return {
					left: rect.left,
					top: nextTop,
					width: rect.width,
					height
				};
			}
			return rect;
		}
		return rect;
	}
	/**
	* Find the best X-axis snap among all anchors.
	*
	* Selection criteria:
	* 1. Within threshold distance
	* 2. Produces valid rect (respects minSize)
	* 3. Closest distance wins
	* 4. Sibling anchors preferred over viewport at equal distance
	*/
	function findBestXSnap(rect, fixedEdge, anchors, allowedTypes, threshold, minSize) {
		let best = null;
		for (const anchor of anchors) {
			if (!allowedTypes.includes(anchor.type)) continue;
			const currentValue = getRectXValue(rect, anchor.type);
			const distance = Math.abs(anchor.value - currentValue);
			if (distance > threshold) continue;
			const snappedRect = applyXSnap(rect, fixedEdge, anchor.type, anchor.value, minSize);
			if (!snappedRect) continue;
			if (!best || distance < best.distance || distance === best.distance && anchor.source === "sibling" && best.anchor.source !== "sibling") best = {
				distance,
				anchor,
				snappedRect
			};
		}
		return best;
	}
	/**
	* Find the best Y-axis snap among all anchors.
	*/
	function findBestYSnap(rect, fixedEdge, anchors, allowedTypes, threshold, minSize) {
		let best = null;
		for (const anchor of anchors) {
			if (!allowedTypes.includes(anchor.type)) continue;
			const currentValue = getRectYValue(rect, anchor.type);
			const distance = Math.abs(anchor.value - currentValue);
			if (distance > threshold) continue;
			const snappedRect = applyYSnap(rect, fixedEdge, anchor.type, anchor.value, minSize);
			if (!snappedRect) continue;
			if (!best || distance < best.distance || distance === best.distance && anchor.source === "sibling" && best.anchor.source !== "sibling") best = {
				distance,
				anchor,
				snappedRect
			};
		}
		return best;
	}
	/**
	* Build guide lines from active snap locks.
	*
	* Guide line extent:
	* - For viewport anchors: full viewport span
	* - For sibling anchors: from source element edge to snapped element edge
	*
	* Note: viewport dimensions are passed as parameters to keep this function pure
	* (no global window access), enabling better testability and potential worker usage.
	*/
	function buildGuideLines(snappedRect, lockX, lockY, viewport) {
		const guides = [];
		const viewportWidth = Math.max(1, viewport.width);
		const viewportHeight = Math.max(1, viewport.height);
		if (lockX) {
			const x = lockX.value;
			if (lockX.source === "viewport" || !lockX.sourceRect) guides.push({
				x1: x,
				y1: 0,
				x2: x,
				y2: viewportHeight
			});
			else {
				const sourceRect = lockX.sourceRect;
				const y1 = Math.min(sourceRect.top, snappedRect.top);
				const y2 = Math.max(rectBottom(sourceRect), rectBottom(snappedRect));
				guides.push({
					x1: x,
					y1,
					x2: x,
					y2
				});
			}
		}
		if (lockY) {
			const y = lockY.value;
			if (lockY.source === "viewport" || !lockY.sourceRect) guides.push({
				x1: 0,
				y1: y,
				x2: viewportWidth,
				y2: y
			});
			else {
				const sourceRect = lockY.sourceRect;
				const x1 = Math.min(sourceRect.left, snappedRect.left);
				const x2 = Math.max(rectRight(sourceRect), rectRight(snappedRect));
				guides.push({
					x1,
					y1: y,
					x2,
					y2: y
				});
			}
		}
		return guides;
	}
	/**
	* Compute snapping for a resize operation.
	*
	* This function is pure (no DOM access) and should be called every frame
	* during resize drag operations.
	*
	* Snap semantics for resize:
	* - One edge is fixed (opposite to drag direction)
	* - The moving edge or center can snap to anchors
	* - Hysteresis keeps snap stable once activated
	*/
	function computeResizeSnap(params) {
		const { rect, resize, anchors, thresholdPx, hysteresisPx, minSizePx, viewport } = params;
		if (!isValidRect$1(rect)) return {
			snappedRect: rect,
			guideLines: [],
			lockX: null,
			lockY: null
		};
		const fixedEdgeX = resize.hasWest ? "right" : resize.hasEast ? "left" : null;
		const fixedEdgeY = resize.hasNorth ? "bottom" : resize.hasSouth ? "top" : null;
		const allowedXTypes = fixedEdgeX === "left" ? ["right", "center"] : fixedEdgeX === "right" ? ["left", "center"] : [];
		const allowedYTypes = fixedEdgeY === "top" ? ["bottom", "middle"] : fixedEdgeY === "bottom" ? ["top", "middle"] : [];
		let snappedRect = _objectSpread2({}, rect);
		let lockX = params.lockX;
		let lockY = params.lockY;
		if (fixedEdgeX) {
			if (lockX) if (!allowedXTypes.includes(lockX.type)) lockX = null;
			else {
				const currentValue = getRectXValue(snappedRect, lockX.type);
				const distance = Math.abs(lockX.value - currentValue);
				const canApply = applyXSnap(snappedRect, fixedEdgeX, lockX.type, lockX.value, minSizePx);
				if (distance > thresholdPx + hysteresisPx || !canApply) lockX = null;
			}
			if (lockX) {
				const applied = applyXSnap(snappedRect, fixedEdgeX, lockX.type, lockX.value, minSizePx);
				if (applied) snappedRect = applied;
			} else {
				const best = findBestXSnap(snappedRect, fixedEdgeX, anchors.x, allowedXTypes, thresholdPx, minSizePx);
				if (best) {
					var _best$anchor$sourceRe;
					lockX = {
						type: best.anchor.type,
						value: best.anchor.value,
						source: best.anchor.source,
						sourceRect: (_best$anchor$sourceRe = best.anchor.sourceRect) !== null && _best$anchor$sourceRe !== void 0 ? _best$anchor$sourceRe : null
					};
					snappedRect = best.snappedRect;
				}
			}
		} else lockX = null;
		if (fixedEdgeY) {
			if (lockY) if (!allowedYTypes.includes(lockY.type)) lockY = null;
			else {
				const currentValue = getRectYValue(snappedRect, lockY.type);
				const distance = Math.abs(lockY.value - currentValue);
				const canApply = applyYSnap(snappedRect, fixedEdgeY, lockY.type, lockY.value, minSizePx);
				if (distance > thresholdPx + hysteresisPx || !canApply) lockY = null;
			}
			if (lockY) {
				const applied = applyYSnap(snappedRect, fixedEdgeY, lockY.type, lockY.value, minSizePx);
				if (applied) snappedRect = applied;
			} else {
				const best = findBestYSnap(snappedRect, fixedEdgeY, anchors.y, allowedYTypes, thresholdPx, minSizePx);
				if (best) {
					var _best$anchor$sourceRe2;
					lockY = {
						type: best.anchor.type,
						value: best.anchor.value,
						source: best.anchor.source,
						sourceRect: (_best$anchor$sourceRe2 = best.anchor.sourceRect) !== null && _best$anchor$sourceRe2 !== void 0 ? _best$anchor$sourceRe2 : null
					};
					snappedRect = best.snappedRect;
				}
			}
		} else lockY = null;
		const guideLines = buildGuideLines(snappedRect, lockX, lockY, viewport);
		return {
			snappedRect,
			guideLines,
			lockX,
			lockY
		};
	}
	/**
	* Check if a gap should be shown as a distance label.
	* Requires gap > 0 (no overlap/touching) AND gap >= minGap threshold.
	*/
	function shouldShowGap(gap, minGap) {
		return isFiniteNumber$2(gap) && gap > 0 && gap >= minGap;
	}
	/**
	* Format a pixel value for display.
	*/
	function formatDistanceText(px) {
		const rounded = Math.round(px);
		return `${Object.is(rounded, -0) ? 0 : rounded}px`;
	}
	/**
	* Clamp a value within a range.
	*/
	function clamp(value, min, max) {
		if (!isFiniteNumber$2(value)) return min;
		return Math.min(max, Math.max(min, value));
	}
	/**
	* Compute distance labels from active snap locks.
	*
	* Rules (as per Phase 4.3 decisions):
	* - Hide when gap <= 0 (overlap or touching)
	* - Hide when gap < minGapPx (default 1px)
	* - For sibling locks:
	*   - lockX (vertical guide) → show vertical gap (Y) between rect and sourceRect
	*   - lockY (horizontal guide) → show horizontal gap (X) between rect and sourceRect
	* - For viewport locks:
	*   - Edge align shows the corresponding margin; if filtered, fallback to opposite side
	*   - Center align shows both margins (may yield 2 labels)
	*
	* 中文说明：
	* - 当发生对齐时，显示"另一个方向"的间距
	* - lockX 是垂直对齐线，所以显示 Y 方向的间距
	* - lockY 是水平对齐线，所以显示 X 方向的间距
	*/
	function computeDistanceLabels(params) {
		const { rect, lockX, lockY, viewport, minGapPx } = params;
		if (!isValidRect$1(rect)) return [];
		const viewportWidth = isFiniteNumber$2(viewport.width) ? Math.max(1, viewport.width) : 1;
		const viewportHeight = isFiniteNumber$2(viewport.height) ? Math.max(1, viewport.height) : 1;
		const minGap = Math.max(0, minGapPx);
		const labels = [];
		if (lockX && lockX.source === "sibling" && lockX.sourceRect) {
			const other = lockX.sourceRect;
			const gapAbove = rect.top - rectBottom(other);
			const gapBelow = other.top - rectBottom(rect);
			if (shouldShowGap(gapAbove, minGap)) labels.push({
				kind: "sibling",
				axis: "y",
				value: Math.round(gapAbove),
				text: formatDistanceText(gapAbove),
				line: {
					x1: lockX.value,
					y1: rectBottom(other),
					x2: lockX.value,
					y2: rect.top
				}
			});
			else if (shouldShowGap(gapBelow, minGap)) labels.push({
				kind: "sibling",
				axis: "y",
				value: Math.round(gapBelow),
				text: formatDistanceText(gapBelow),
				line: {
					x1: lockX.value,
					y1: rectBottom(rect),
					x2: lockX.value,
					y2: other.top
				}
			});
		}
		if (lockY && lockY.source === "sibling" && lockY.sourceRect) {
			const other = lockY.sourceRect;
			const gapLeft = rect.left - rectRight(other);
			const gapRight = other.left - rectRight(rect);
			if (shouldShowGap(gapLeft, minGap)) labels.push({
				kind: "sibling",
				axis: "x",
				value: Math.round(gapLeft),
				text: formatDistanceText(gapLeft),
				line: {
					x1: rectRight(other),
					y1: lockY.value,
					x2: rect.left,
					y2: lockY.value
				}
			});
			else if (shouldShowGap(gapRight, minGap)) labels.push({
				kind: "sibling",
				axis: "x",
				value: Math.round(gapRight),
				text: formatDistanceText(gapRight),
				line: {
					x1: rectRight(rect),
					y1: lockY.value,
					x2: other.left,
					y2: lockY.value
				}
			});
		}
		if (lockX && lockX.source === "viewport") {
			const y = clamp(rectCenterY(rect), 0, viewportHeight);
			const leftGap = rect.left;
			const rightGap = viewportWidth - rectRight(rect);
			const addLeft = () => {
				if (!shouldShowGap(leftGap, minGap)) return false;
				labels.push({
					kind: "viewport",
					axis: "x",
					value: Math.round(leftGap),
					text: formatDistanceText(leftGap),
					line: {
						x1: 0,
						y1: y,
						x2: rect.left,
						y2: y
					}
				});
				return true;
			};
			const addRight = () => {
				if (!shouldShowGap(rightGap, minGap)) return false;
				labels.push({
					kind: "viewport",
					axis: "x",
					value: Math.round(rightGap),
					text: formatDistanceText(rightGap),
					line: {
						x1: rectRight(rect),
						y1: y,
						x2: viewportWidth,
						y2: y
					}
				});
				return true;
			};
			if (lockX.type === "center") {
				addLeft();
				addRight();
			} else if (lockX.type === "left") {
				if (!addLeft()) addRight();
			} else if (!addRight()) addLeft();
		}
		if (lockY && lockY.source === "viewport") {
			const x = clamp(rectCenterX(rect), 0, viewportWidth);
			const topGap = rect.top;
			const bottomGap = viewportHeight - rectBottom(rect);
			const addTop = () => {
				if (!shouldShowGap(topGap, minGap)) return false;
				labels.push({
					kind: "viewport",
					axis: "y",
					value: Math.round(topGap),
					text: formatDistanceText(topGap),
					line: {
						x1: x,
						y1: 0,
						x2: x,
						y2: rect.top
					}
				});
				return true;
			};
			const addBottom = () => {
				if (!shouldShowGap(bottomGap, minGap)) return false;
				labels.push({
					kind: "viewport",
					axis: "y",
					value: Math.round(bottomGap),
					text: formatDistanceText(bottomGap),
					line: {
						x1: x,
						y1: rectBottom(rect),
						x2: x,
						y2: viewportHeight
					}
				});
				return true;
			};
			if (lockY.type === "middle") {
				addTop();
				addBottom();
			} else if (lockY.type === "top") {
				if (!addTop()) addBottom();
			} else if (!addBottom()) addTop();
		}
		return labels;
	}
	//#endregion
	//#region entrypoints/web-editor-v2/overlay/handles-controller.ts
	/**
	* Handles Controller (Phase 4.9)
	*
	* Renders interactive resize handles on top of the selected element.
	* Integrates drag-to-resize with TransactionManager.beginMultiStyle() so each gesture
	* becomes a single undo/redo step.
	*
	* Design notes:
	* - Uses DOM (not Canvas) for reliable hit targets, cursors, and pointer capture.
	* - Uses rAF-throttled updates to bound work to at most once per frame.
	* - Handles are positioned using transform for GPU-accelerated performance.
	*/
	/** Minimum element size in border-box pixels */
	var MIN_BORDER_BOX_SIZE_PX = 1;
	/** Minimum pointer movement (px) to start resizing (prevents click -> transaction) */
	var RESIZE_DRAG_THRESHOLD_PX = 3;
	/** All resize handle directions */
	var HANDLE_DIRS = [
		"nw",
		"n",
		"ne",
		"e",
		"se",
		"s",
		"sw",
		"w"
	];
	/** Cursor style for each direction */
	var CURSOR_BY_DIR = {
		n: "ns-resize",
		s: "ns-resize",
		e: "ew-resize",
		w: "ew-resize",
		ne: "nesw-resize",
		sw: "nesw-resize",
		nw: "nwse-resize",
		se: "nwse-resize"
	};
	function isFiniteNumber$1(value) {
		return typeof value === "number" && Number.isFinite(value);
	}
	function isValidRect(rect) {
		if (!rect) return false;
		return isFiniteNumber$1(rect.left) && isFiniteNumber$1(rect.top) && isFiniteNumber$1(rect.width) && isFiniteNumber$1(rect.height) && rect.width > .5 && rect.height > .5;
	}
	function clampMin(value, min) {
		if (!Number.isFinite(value)) return min;
		return value < min ? min : value;
	}
	/**
	* Parse a CSS pixel value (e.g., "10px", "auto", "10") to a number.
	* Returns null for non-numeric values like "auto".
	*/
	function parsePx(value) {
		const trimmed = value.trim();
		if (!trimmed || trimmed === "auto" || trimmed === "none") return null;
		const match = trimmed.match(/^(-?\d+(?:\.\d+)?)px$/);
		if (match) {
			const num = Number(match[1]);
			return Number.isFinite(num) ? num : null;
		}
		const num = Number(trimmed);
		return Number.isFinite(num) ? num : null;
	}
	/**
	* Format a number as a CSS pixel value.
	* Rounds to 2 decimal places to avoid floating point noise.
	*/
	function formatPx(value) {
		if (!Number.isFinite(value)) return "0px";
		const rounded = Math.round(value * 100) / 100;
		return `${Object.is(rounded, -0) ? 0 : rounded}px`;
	}
	/**
	* Get the resize position mode from a CSS position value.
	*/
	function getResizeMode(position) {
		const p = position.trim().toLowerCase();
		if (p === "fixed") return "fixed";
		if (p === "absolute") return "absolute";
		if (p === "relative" || p === "sticky") return "relative";
		return "static";
	}
	function dirHasWest(dir) {
		return dir === "w" || dir === "nw" || dir === "sw";
	}
	function dirHasEast(dir) {
		return dir === "e" || dir === "ne" || dir === "se";
	}
	function dirHasNorth(dir) {
		return dir === "n" || dir === "nw" || dir === "ne";
	}
	function dirHasSouth(dir) {
		return dir === "s" || dir === "sw" || dir === "se";
	}
	/**
	* Read an element's bounding rect in viewport coordinates.
	*/
	function readViewportRect(element) {
		try {
			const r = element.getBoundingClientRect();
			if (!Number.isFinite(r.left) || !Number.isFinite(r.top) || !Number.isFinite(r.width) || !Number.isFinite(r.height)) return null;
			return {
				left: r.left,
				top: r.top,
				width: Math.max(0, r.width),
				height: Math.max(0, r.height)
			};
		} catch (_unused) {
			return null;
		}
	}
	/**
	* Safely get computed style for an element.
	*/
	function safeGetComputedStyle(element) {
		try {
			return window.getComputedStyle(element);
		} catch (_unused2) {
			return null;
		}
	}
	/**
	* Sum two CSS property values as pixels.
	*/
	function sumStylePx(style, propA, propB) {
		var _parsePx, _parsePx2;
		return ((_parsePx = parsePx(style.getPropertyValue(propA))) !== null && _parsePx !== void 0 ? _parsePx : 0) + ((_parsePx2 = parsePx(style.getPropertyValue(propB))) !== null && _parsePx2 !== void 0 ? _parsePx2 : 0);
	}
	/**
	* Read box model extras (padding + border) from computed style.
	*/
	function readBoxExtras(style) {
		const boxSizing = style.getPropertyValue("box-sizing").trim() === "border-box" ? "border-box" : "content-box";
		const paddingX = sumStylePx(style, "padding-left", "padding-right");
		const paddingY = sumStylePx(style, "padding-top", "padding-bottom");
		const borderX = sumStylePx(style, "border-left-width", "border-right-width");
		const borderY = sumStylePx(style, "border-top-width", "border-bottom-width");
		return {
			boxSizing,
			horizontalExtras: paddingX + borderX,
			verticalExtras: paddingY + borderY
		};
	}
	/**
	* Convert border-box size to CSS width/height value based on box-sizing.
	*/
	function borderBoxToCssSize(borderBoxPx, extrasPx, boxSizing) {
		if (boxSizing === "border-box") return borderBoxPx;
		return Math.max(0, borderBoxPx - extrasPx);
	}
	/**
	* Compute the origin point for absolute positioning calculations.
	* For absolute elements, this is the padding-box of the offsetParent.
	*/
	function computeAbsoluteOrigin(target) {
		try {
			const op = target.offsetParent;
			if (op instanceof HTMLElement) {
				var _parsePx3, _parsePx4;
				const rect = op.getBoundingClientRect();
				const style = safeGetComputedStyle(op);
				const borderLeft = style ? (_parsePx3 = parsePx(style.getPropertyValue("border-left-width"))) !== null && _parsePx3 !== void 0 ? _parsePx3 : 0 : 0;
				const borderTop = style ? (_parsePx4 = parsePx(style.getPropertyValue("border-top-width"))) !== null && _parsePx4 !== void 0 ? _parsePx4 : 0 : 0;
				return {
					originX: rect.left + borderLeft,
					originY: rect.top + borderTop,
					scrollLeft: op.scrollLeft,
					scrollTop: op.scrollTop
				};
			}
		} catch (_unused3) {}
		return {
			originX: 0,
			originY: 0,
			scrollLeft: 0,
			scrollTop: 0
		};
	}
	/**
	* Stop event propagation and prevent default.
	*/
	function stopEvent(event) {
		if (event.cancelable) event.preventDefault();
		event.stopPropagation();
	}
	/**
	* Create a handles controller for resize interactions.
	*/
	function createHandlesController(options) {
		const disposer = new Disposer();
		const { container, canvasOverlay, transactionManager, positionTracker } = options;
		const layer = document.createElement("div");
		layer.className = "we-handles-layer";
		layer.setAttribute("aria-hidden", "true");
		container.append(layer);
		disposer.add(() => layer.remove());
		const frame = document.createElement("div");
		frame.className = "we-selection-frame";
		frame.hidden = true;
		layer.append(frame);
		const sizeHud = document.createElement("div");
		sizeHud.className = "we-size-hud";
		sizeHud.hidden = true;
		frame.append(sizeHud);
		const handleEls = /* @__PURE__ */ new Map();
		for (const dir of HANDLE_DIRS) {
			const el = document.createElement("div");
			el.className = "we-resize-handle";
			el.dataset.dir = dir;
			el.tabIndex = -1;
			frame.append(el);
			handleEls.set(dir, el);
		}
		let currentTarget = null;
		let currentSelectionRect = null;
		let session = null;
		let rafId = null;
		function cancelRaf() {
			if (rafId !== null) {
				cancelAnimationFrame(rafId);
				rafId = null;
			}
		}
		disposer.add(cancelRaf);
		/**
		* Render the selection frame at the given rect.
		*/
		function renderSelectionRect(rect) {
			if (!(!!currentTarget && isValidRect(rect))) {
				frame.hidden = true;
				return;
			}
			frame.hidden = false;
			frame.style.transform = `translate3d(${rect.left}px, ${rect.top}px, 0)`;
			frame.style.width = `${rect.width}px`;
			frame.style.height = `${rect.height}px`;
		}
		/**
		* Update the size HUD text.
		*/
		function setHud(text) {
			if (!text) {
				sizeHud.hidden = true;
				sizeHud.textContent = "";
				return;
			}
			sizeHud.hidden = false;
			sizeHud.textContent = text;
		}
		/**
		* Restore body styles after resize session ends.
		*/
		function restoreBodyStyles(s) {
			document.body.style.cursor = s.prevBodyCursor;
			document.body.style.userSelect = s.prevBodyUserSelect;
		}
		/**
		* Cancel the current resize session and rollback changes.
		*/
		function cancelSession(reason) {
			const s = session;
			if (!s) return;
			cancelRaf();
			session = null;
			if (s.tx) try {
				s.tx.rollback();
			} catch (error) {
				console.warn(`${WEB_EDITOR_V2_LOG_PREFIX} Resize rollback failed:`, error);
			}
			try {
				restoreBodyStyles(s);
			} catch (_unused4) {}
			try {
				canvasOverlay.setGuideLines(null);
				canvasOverlay.setDistanceLabels(null);
				canvasOverlay.render();
			} catch (_unused5) {}
			setHud(null);
			renderSelectionRect(currentSelectionRect);
			try {
				positionTracker.forceUpdate();
			} catch (_unused6) {}
			if (reason) console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Resize cancelled (${reason})`);
		}
		/**
		* Commit the current resize session.
		*/
		function commitSession() {
			const s = session;
			if (!s) return;
			cancelRaf();
			session = null;
			if (s.tx) try {
				s.tx.commit({ merge: false });
			} catch (error) {
				console.warn(`${WEB_EDITOR_V2_LOG_PREFIX} Resize commit failed:`, error);
				try {
					s.tx.rollback();
				} catch (_unused7) {}
			}
			try {
				restoreBodyStyles(s);
			} catch (_unused8) {}
			try {
				canvasOverlay.setGuideLines(null);
				canvasOverlay.setDistanceLabels(null);
				canvasOverlay.render();
			} catch (_unused9) {}
			setHud(null);
			try {
				positionTracker.forceUpdate();
			} catch (_unused10) {}
		}
		/**
		* Schedule an update frame if not already scheduled.
		*/
		function scheduleFrame() {
			if (rafId !== null || disposer.isDisposed) return;
			rafId = requestAnimationFrame(() => {
				rafId = null;
				updateFrame();
			});
		}
		/**
		* Update frame - apply style changes based on current drag position.
		*/
		function updateFrame() {
			const s = session;
			if (!s) return;
			if (!s.target.isConnected) {
				cancelSession("target_disconnected");
				return;
			}
			const dx = s.lastClientX - s.startClientX;
			const dy = s.lastClientY - s.startClientY;
			if (!s.hasPassedThreshold) {
				if (Math.hypot(dx, dy) < RESIZE_DRAG_THRESHOLD_PX) return;
				s.hasPassedThreshold = true;
				const startedTx = transactionManager.beginMultiStyle(s.target, Array.from(s.properties));
				if (!startedTx) {
					cancelSession("tx_unavailable");
					return;
				}
				s.tx = startedTx;
				try {
					s.anchors = mergeAnchors(collectSiblingAnchors(s.target), collectViewportAnchors());
				} catch (_unused11) {
					s.anchors = null;
				}
			}
			const tx = s.tx;
			if (!tx) {
				cancelSession("tx_missing");
				return;
			}
			let nextWidthBorderBox = s.startRect.width;
			let nextHeightBorderBox = s.startRect.height;
			if (s.affectsWidth) {
				if (dirHasEast(s.dir)) nextWidthBorderBox = clampMin(s.startRect.width + dx, MIN_BORDER_BOX_SIZE_PX);
				if (dirHasWest(s.dir)) nextWidthBorderBox = clampMin(s.startRect.width - dx, MIN_BORDER_BOX_SIZE_PX);
			}
			if (s.affectsHeight) {
				if (dirHasSouth(s.dir)) nextHeightBorderBox = clampMin(s.startRect.height + dy, MIN_BORDER_BOX_SIZE_PX);
				if (dirHasNorth(s.dir)) nextHeightBorderBox = clampMin(s.startRect.height - dy, MIN_BORDER_BOX_SIZE_PX);
			}
			const proposedLeftDelta = s.hasWest ? s.startRect.width - nextWidthBorderBox : 0;
			const proposedTopDelta = s.hasNorth ? s.startRect.height - nextHeightBorderBox : 0;
			const proposedRect = {
				left: s.startRect.left + proposedLeftDelta,
				top: s.startRect.top + proposedTopDelta,
				width: nextWidthBorderBox,
				height: nextHeightBorderBox
			};
			let finalRect = proposedRect;
			if (s.anchors) {
				const hasEast = dirHasEast(s.dir);
				const hasSouth = dirHasSouth(s.dir);
				const snapResult = computeResizeSnap({
					rect: proposedRect,
					resize: {
						hasWest: s.hasWest,
						hasEast,
						hasNorth: s.hasNorth,
						hasSouth
					},
					anchors: s.anchors,
					thresholdPx: 6,
					hysteresisPx: 2,
					minSizePx: MIN_BORDER_BOX_SIZE_PX,
					lockX: s.lockX,
					lockY: s.lockY,
					viewport: {
						width: window.innerWidth || 1,
						height: window.innerHeight || 1
					}
				});
				s.lockX = snapResult.lockX;
				s.lockY = snapResult.lockY;
				finalRect = snapResult.snappedRect;
				const distanceLabels = computeDistanceLabels({
					rect: finalRect,
					lockX: s.lockX,
					lockY: s.lockY,
					minGapPx: 1,
					viewport: {
						width: window.innerWidth || 1,
						height: window.innerHeight || 1
					}
				});
				const hasGuides = snapResult.guideLines.length > 0;
				const hasDistanceLabels = distanceLabels.length > 0;
				if (hasGuides || s.hadGuidesLastFrame || hasDistanceLabels || s.hadDistanceLabelsLastFrame) {
					try {
						canvasOverlay.setGuideLines(hasGuides ? snapResult.guideLines : null);
						canvasOverlay.setDistanceLabels(hasDistanceLabels ? distanceLabels : null);
						canvasOverlay.render();
					} catch (_unused12) {}
					s.hadGuidesLastFrame = hasGuides;
					s.hadDistanceLabelsLastFrame = hasDistanceLabels;
				}
				nextWidthBorderBox = finalRect.width;
				nextHeightBorderBox = finalRect.height;
			}
			const leftEdgeDelta = finalRect.left - s.startRect.left;
			const topEdgeDelta = finalRect.top - s.startRect.top;
			renderSelectionRect(finalRect);
			setHud(`${Math.round(finalRect.width)} × ${Math.round(finalRect.height)}`);
			const styles = {};
			if (s.affectsWidth) styles.width = formatPx(borderBoxToCssSize(nextWidthBorderBox, s.extras.horizontalExtras, s.extras.boxSizing));
			if (s.affectsHeight) styles.height = formatPx(borderBoxToCssSize(nextHeightBorderBox, s.extras.verticalExtras, s.extras.boxSizing));
			if (s.mode === "absolute" || s.mode === "fixed") {
				if (s.affectsWidth) {
					styles.left = formatPx(s.startPosX + leftEdgeDelta);
					styles.right = "";
				}
				if (s.affectsHeight) {
					styles.top = formatPx(s.startPosY + topEdgeDelta);
					styles.bottom = "";
				}
			} else if (s.mode === "relative") {
				if (s.affectsWidth && s.hasWest) styles.left = formatPx(s.startPosX + leftEdgeDelta);
				if (s.affectsHeight && s.hasNorth) styles.top = formatPx(s.startPosY + topEdgeDelta);
			} else {
				if (s.affectsWidth && s.hasWest) styles["margin-left"] = formatPx(s.startPosX + leftEdgeDelta);
				if (s.affectsHeight && s.hasNorth) styles["margin-top"] = formatPx(s.startPosY + topEdgeDelta);
			}
			try {
				tx.set(styles);
			} catch (error) {
				console.warn(`${WEB_EDITOR_V2_LOG_PREFIX} Resize preview apply failed:`, error);
				cancelSession("apply_failed");
			}
		}
		/**
		* Start a resize session.
		*/
		function startResize(dir, handleEl, event) {
			var _parsePx5, _parsePx6;
			if (disposer.isDisposed) return;
			if (event.button !== 0) return;
			const target = currentTarget;
			if (!target || !target.isConnected) return;
			if (session) cancelSession("restart");
			const computed = safeGetComputedStyle(target);
			if (!computed) return;
			const transform = computed.getPropertyValue("transform").trim();
			if (transform && transform !== "none") {
				console.warn(`${WEB_EDITOR_V2_LOG_PREFIX} Resize handles do not support transformed elements yet`);
				return;
			}
			const mode = getResizeMode(computed.getPropertyValue("position"));
			const hasWest = dirHasWest(dir);
			const hasNorth = dirHasNorth(dir);
			const affectsWidth = hasWest || dirHasEast(dir);
			const affectsHeight = hasNorth || dirHasSouth(dir);
			const marginLeftRaw = computed.getPropertyValue("margin-left").trim().toLowerCase();
			const marginTopRaw = computed.getPropertyValue("margin-top").trim().toLowerCase();
			const marginLeftPx = (_parsePx5 = parsePx(marginLeftRaw)) !== null && _parsePx5 !== void 0 ? _parsePx5 : 0;
			const marginTopPx = (_parsePx6 = parsePx(marginTopRaw)) !== null && _parsePx6 !== void 0 ? _parsePx6 : 0;
			if (mode === "static") {
				if (hasWest && marginLeftRaw === "auto") {
					console.warn(`${WEB_EDITOR_V2_LOG_PREFIX} Resize from west is disabled when margin-left is auto`);
					return;
				}
				if (hasNorth && marginTopRaw === "auto") {
					console.warn(`${WEB_EDITOR_V2_LOG_PREFIX} Resize from north is disabled when margin-top is auto`);
					return;
				}
			}
			const rect = isValidRect(currentSelectionRect) ? currentSelectionRect : readViewportRect(target);
			if (!rect || !isValidRect(rect)) return;
			const properties = [];
			if (affectsWidth) {
				properties.push("width");
				if (mode === "absolute" || mode === "fixed") properties.push("left", "right");
				else if (mode === "relative") {
					if (hasWest) properties.push("left");
				} else if (hasWest) properties.push("margin-left");
			}
			if (affectsHeight) {
				properties.push("height");
				if (mode === "absolute" || mode === "fixed") properties.push("top", "bottom");
				else if (mode === "relative") {
					if (hasNorth) properties.push("top");
				} else if (hasNorth) properties.push("margin-top");
			}
			let absOrigin = null;
			let startPosX = 0;
			let startPosY = 0;
			if (mode === "absolute") {
				absOrigin = computeAbsoluteOrigin(target);
				startPosX = affectsWidth ? rect.left - marginLeftPx - absOrigin.originX + absOrigin.scrollLeft : 0;
				startPosY = affectsHeight ? rect.top - marginTopPx - absOrigin.originY + absOrigin.scrollTop : 0;
			} else if (mode === "fixed") {
				absOrigin = {
					originX: 0,
					originY: 0,
					scrollLeft: 0,
					scrollTop: 0
				};
				startPosX = affectsWidth ? rect.left - marginLeftPx : 0;
				startPosY = affectsHeight ? rect.top - marginTopPx : 0;
			} else if (mode === "relative") {
				var _parsePx7, _parsePx8;
				startPosX = affectsWidth && hasWest ? (_parsePx7 = parsePx(computed.getPropertyValue("left"))) !== null && _parsePx7 !== void 0 ? _parsePx7 : 0 : 0;
				startPosY = affectsHeight && hasNorth ? (_parsePx8 = parsePx(computed.getPropertyValue("top"))) !== null && _parsePx8 !== void 0 ? _parsePx8 : 0 : 0;
			} else {
				startPosX = affectsWidth && hasWest ? marginLeftPx : 0;
				startPosY = affectsHeight && hasNorth ? marginTopPx : 0;
			}
			const extras = readBoxExtras(computed);
			const prevBodyCursor = document.body.style.cursor;
			const prevBodyUserSelect = document.body.style.userSelect;
			session = {
				pointerId: event.pointerId,
				dir,
				handleEl,
				target,
				mode,
				properties,
				tx: null,
				hasPassedThreshold: false,
				affectsWidth,
				affectsHeight,
				hasWest,
				hasNorth,
				anchors: null,
				lockX: null,
				lockY: null,
				hadGuidesLastFrame: false,
				hadDistanceLabelsLastFrame: false,
				startClientX: event.clientX,
				startClientY: event.clientY,
				lastClientX: event.clientX,
				lastClientY: event.clientY,
				startRect: rect,
				startPosX,
				startPosY,
				absOrigin,
				extras,
				prevBodyCursor,
				prevBodyUserSelect
			};
			try {
				handleEl.setPointerCapture(event.pointerId);
			} catch (_unused13) {}
			document.body.style.cursor = CURSOR_BY_DIR[dir];
			document.body.style.userSelect = "none";
			stopEvent(event);
			renderSelectionRect(rect);
			scheduleFrame();
		}
		function handlePointerMove(event) {
			const s = session;
			if (!s) return;
			if (event.pointerId !== s.pointerId) return;
			stopEvent(event);
			s.lastClientX = event.clientX;
			s.lastClientY = event.clientY;
			scheduleFrame();
		}
		function handlePointerUp(event) {
			const s = session;
			if (!s) return;
			if (event.pointerId !== s.pointerId) return;
			stopEvent(event);
			s.lastClientX = event.clientX;
			s.lastClientY = event.clientY;
			commitSession();
		}
		function handlePointerCancel(event) {
			const s = session;
			if (!s) return;
			if (event.pointerId !== s.pointerId) return;
			stopEvent(event);
			cancelSession(event.type);
		}
		/**
		* Handle ESC key - cancel resize without triggering EventController deselect.
		* Uses stopImmediatePropagation to prevent other handlers from seeing the event.
		*/
		function handleKeyDown(event) {
			if (!session) return;
			if (event.key !== "Escape") return;
			event.preventDefault();
			event.stopImmediatePropagation();
			event.stopPropagation();
			cancelSession("escape");
		}
		function handleWindowBlur() {
			if (!session) return;
			cancelSession("blur");
		}
		function handleVisibilityChange() {
			if (!session) return;
			if (document.visibilityState !== "visible") cancelSession("visibilitychange");
		}
		for (const [dir, el] of handleEls) {
			disposer.listen(el, "pointerdown", (event) => startResize(dir, el, event));
			disposer.listen(el, "pointermove", handlePointerMove);
			disposer.listen(el, "pointerup", handlePointerUp);
			disposer.listen(el, "pointercancel", handlePointerCancel);
			disposer.listen(el, "lostpointercapture", handlePointerCancel);
		}
		disposer.listen(document, "keydown", handleKeyDown, { capture: true });
		disposer.listen(window, "blur", handleWindowBlur);
		disposer.listen(document, "visibilitychange", handleVisibilityChange);
		function setTarget(target) {
			if (disposer.isDisposed) return;
			if (session) cancelSession("target_change");
			if (target instanceof HTMLElement && target.isConnected) currentTarget = target;
			else currentTarget = null;
			renderSelectionRect(currentSelectionRect);
		}
		function setSelectionRect(rect) {
			if (disposer.isDisposed) return;
			currentSelectionRect = isValidRect(rect) ? rect : null;
			if (!currentTarget || !currentTarget.isConnected) {
				frame.hidden = true;
				return;
			}
			if (session && !currentSelectionRect) {
				cancelSession("rect_lost");
				return;
			}
			if (!session) renderSelectionRect(currentSelectionRect);
		}
		function dispose() {
			cancelSession("dispose");
			currentTarget = null;
			currentSelectionRect = null;
			disposer.dispose();
		}
		renderSelectionRect(null);
		return {
			setTarget,
			setSelectionRect,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/drag/drag-reorder-controller.ts
	/**
	* Drag Reorder Controller (Phase 2.4-2.6)
	*
	* Coordinates drag-to-reorder interactions:
	* - Renders drag ghost + insertion indicator via CanvasOverlay
	* - Computes insertion position from pointer hit-testing
	* - Applies DOM move on drop (sibling insert only in Phase 1)
	* - Records the drag as a single move transaction (undo/redo)
	*
	* Phase 1 constraints:
	* - Sibling insertion only (before/after hit target), no "insert as child"
	* - No cross-root moves (Document/ShadowRoot boundary)
	* - Disallow moving HTML/BODY/HEAD
	* - Disallow inserting into own subtree
	* - Layout heuristic: supports 1D layouts (vertical block, flex-column, flex-row)
	* - Grid layouts are not supported (2D positioning is too complex)
	* - RTL direction is not handled (future enhancement)
	*/
	function isDocumentOrShadowRoot(value) {
		return value instanceof Document || value instanceof ShadowRoot;
	}
	function isDisallowedDragElement(element) {
		var _element$tagName;
		const tag = (_element$tagName = element.tagName) === null || _element$tagName === void 0 ? void 0 : _element$tagName.toUpperCase();
		return tag === "HTML" || tag === "BODY" || tag === "HEAD";
	}
	function toViewportRect$1(rect) {
		const { left, top, width, height } = rect;
		if (!Number.isFinite(left) || !Number.isFinite(top) || !Number.isFinite(width) || !Number.isFinite(height)) return null;
		return {
			left,
			top,
			width: Math.max(0, width),
			height: Math.max(0, height)
		};
	}
	/**
	* Get elements at a viewport point from a specific root (Document or ShadowRoot).
	* This is Shadow DOM aware - uses the root's elementsFromPoint to correctly
	* hit elements inside that shadow tree.
	*/
	function getHitElementsFromRoot(root, clientX, clientY) {
		if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return [];
		try {
			if (typeof root.elementsFromPoint === "function") return root.elementsFromPoint(clientX, clientY);
		} catch (_unused) {}
		try {
			const el = root.elementFromPoint(clientX, clientY);
			return el ? [el] : [];
		} catch (_unused2) {
			return [];
		}
	}
	/**
	* Determine the insertion axis for the parent container.
	* - Grid layouts are not supported (returns null)
	* - Flex row/column are supported with appropriate axis
	* - Non-flex layouts default to vertical (block flow)
	*/
	function getContainerAxis(parent) {
		try {
			const style = window.getComputedStyle(parent);
			const display = style.display;
			if (display === "grid" || display === "inline-grid") return null;
			if (display === "flex" || display === "inline-flex") {
				const wrap = style.flexWrap;
				if (wrap === "wrap" || wrap === "wrap-reverse") return null;
				switch (style.flexDirection) {
					case "row": return {
						axis: "x",
						reverse: false
					};
					case "row-reverse": return {
						axis: "x",
						reverse: true
					};
					case "column": return {
						axis: "y",
						reverse: false
					};
					case "column-reverse": return {
						axis: "y",
						reverse: true
					};
					default: return {
						axis: "y",
						reverse: false
					};
				}
			}
			return {
				axis: "y",
				reverse: false
			};
		} catch (_unused3) {
			return null;
		}
	}
	/**
	* Choose insert side with hysteresis to avoid flip-flopping.
	* Supports both X and Y axes, with proper handling for reverse layouts.
	*
	* @param clientPos - The client coordinate (clientX for X axis, clientY for Y axis)
	* @param rect - The bounding rect of the target element
	* @param prevSide - The previous side (for hysteresis)
	* @param axis - The axis to use for comparison ('x' or 'y')
	* @param reverse - Whether the layout is reversed (row-reverse, column-reverse)
	* @returns The DOM insertion side ('before' or 'after')
	*/
	function chooseSideWithHysteresis(clientPos, rect, prevSide, axis, reverse) {
		const mid = axis === "x" ? rect.left + rect.width / 2 : rect.top + rect.height / 2;
		const effectivePos = reverse ? -clientPos : clientPos;
		const effectiveMid = reverse ? -mid : mid;
		if (!prevSide) return effectivePos < effectiveMid ? "before" : "after";
		if (prevSide === "before") return effectivePos > effectiveMid + 6 ? "after" : "before";
		return effectivePos < effectiveMid - 6 ? "before" : "after";
	}
	/**
	* Check if the proposed move is a no-op (same position as current)
	*/
	function isNoopMove(draggedElement, parent, referenceNode) {
		if (draggedElement.parentNode !== parent) return false;
		if (referenceNode === draggedElement) return true;
		if (referenceNode === draggedElement.nextSibling) return true;
		if (referenceNode === null && draggedElement.nextSibling === null) return true;
		return false;
	}
	/**
	* Check if an element is a valid drop target
	*/
	function isValidDropTarget(el, draggedElement, draggedRoot, isOverlayElement) {
		var _el$getRootNode;
		if (!el.isConnected) return false;
		if (isOverlayElement(el)) return false;
		if (el === draggedElement) return false;
		if (isDisallowedDragElement(el)) return false;
		if (draggedElement.contains(el)) return false;
		if (!el.parentElement) return false;
		const root = (_el$getRootNode = el.getRootNode) === null || _el$getRootNode === void 0 ? void 0 : _el$getRootNode.call(el);
		if (!isDocumentOrShadowRoot(root)) return false;
		if (root !== draggedRoot) return false;
		return true;
	}
	function createDragReorderController(options) {
		const disposer = new Disposer();
		const { canvasOverlay, isOverlayElement, positionTracker, transactionManager, uiRoot } = options;
		let state = null;
		let rafId = null;
		function cancelRaf() {
			if (rafId !== null) {
				cancelAnimationFrame(rafId);
				rafId = null;
			}
		}
		disposer.add(cancelRaf);
		function setUiPointerEventsEnabled(enabled, s) {
			uiRoot.style.pointerEvents = enabled ? s.uiPointerEventsBefore : "none";
		}
		function clearVisuals() {
			canvasOverlay.setDragGhostRect(null);
			canvasOverlay.setInsertionLine(null);
			canvasOverlay.render();
		}
		function cleanup() {
			const s = state;
			if (!s) return;
			cancelRaf();
			setUiPointerEventsEnabled(true, s);
			clearVisuals();
			state = null;
		}
		/**
		* Compute the insertion position from current pointer location.
		* Uses the dragged element's root for hit-testing to correctly handle Shadow DOM.
		*/
		function computeInsertPosition(s) {
			const target = getHitElementsFromRoot(s.draggedRoot, s.lastClientX, s.lastClientY).slice(0, 8).find((el) => isValidDropTarget(el, s.draggedElement, s.draggedRoot, isOverlayElement));
			if (!target) return null;
			const parent = target.parentElement;
			if (!parent) return null;
			const container = getContainerAxis(parent);
			if (!container) return null;
			let rect;
			try {
				rect = target.getBoundingClientRect();
			} catch (_unused4) {
				return null;
			}
			if (!Number.isFinite(rect.left) || !Number.isFinite(rect.top) || rect.width <= .5 || rect.height <= .5) return null;
			const prevSide = s.preview && s.preview.target === target ? s.preview.side : null;
			const side = chooseSideWithHysteresis(container.axis === "x" ? s.lastClientX : s.lastClientY, rect, prevSide, container.axis, container.reverse);
			const referenceNode = side === "before" ? target : target.nextSibling;
			const noop = isNoopMove(s.draggedElement, parent, referenceNode);
			let indicatorLine;
			if (container.axis === "x") {
				const beforeX = container.reverse ? rect.left + rect.width : rect.left;
				const afterX = container.reverse ? rect.left : rect.left + rect.width;
				const x = side === "before" ? beforeX : afterX;
				indicatorLine = {
					x1: x,
					y1: rect.top,
					x2: x,
					y2: rect.top + rect.height
				};
			} else {
				const beforeY = container.reverse ? rect.top + rect.height : rect.top;
				const afterY = container.reverse ? rect.top : rect.top + rect.height;
				const y = side === "before" ? beforeY : afterY;
				indicatorLine = {
					x1: rect.left,
					y1: y,
					x2: rect.left + rect.width,
					y2: y
				};
			}
			return {
				target,
				parent,
				side,
				referenceNode,
				isNoop: noop,
				indicatorLine
			};
		}
		/**
		* Update frame: compute ghost rect and insertion preview, then render
		*/
		function updateFrame() {
			var _s$preview$indicatorL, _s$preview;
			rafId = null;
			const s = state;
			if (!s) return;
			if (!s.draggedElement.isConnected) {
				s.moveHandle.cancel();
				cleanup();
				return;
			}
			const ghostRect = {
				left: s.lastClientX - s.pointerOffsetX,
				top: s.lastClientY - s.pointerOffsetY,
				width: s.startRect.width,
				height: s.startRect.height
			};
			s.preview = computeInsertPosition(s);
			canvasOverlay.setDragGhostRect(ghostRect);
			canvasOverlay.setInsertionLine((_s$preview$indicatorL = (_s$preview = s.preview) === null || _s$preview === void 0 ? void 0 : _s$preview.indicatorLine) !== null && _s$preview$indicatorL !== void 0 ? _s$preview$indicatorL : null);
			canvasOverlay.render();
		}
		function scheduleUpdate() {
			if (disposer.isDisposed) return;
			if (rafId !== null) return;
			rafId = requestAnimationFrame(updateFrame);
		}
		/**
		* Apply the DOM move operation
		*/
		function applyDomMove(draggedElement, insert) {
			var _draggedElement$getRo, _parent$getRootNode;
			const parent = insert.parent;
			if (!parent.isConnected) return false;
			if (draggedElement === parent) return false;
			if (draggedElement.contains(parent)) return false;
			const rootA = (_draggedElement$getRo = draggedElement.getRootNode) === null || _draggedElement$getRo === void 0 ? void 0 : _draggedElement$getRo.call(draggedElement);
			const rootB = (_parent$getRootNode = parent.getRootNode) === null || _parent$getRootNode === void 0 ? void 0 : _parent$getRootNode.call(parent);
			if (!isDocumentOrShadowRoot(rootA) || !isDocumentOrShadowRoot(rootB) || rootA !== rootB) return false;
			if (!insert.target.isConnected) return false;
			if (insert.target.parentElement !== parent) return false;
			const ref = insert.side === "before" ? insert.target : insert.target.nextSibling;
			if (isNoopMove(draggedElement, parent, ref)) return true;
			try {
				parent.insertBefore(draggedElement, ref);
				return true;
			} catch (error) {
				console.warn(`${WEB_EDITOR_V2_LOG_PREFIX} DOM move failed:`, error);
				return false;
			}
		}
		function onDragStart(ev) {
			var _draggedElement$getRo2;
			if (disposer.isDisposed) return false;
			if (state) {
				state.moveHandle.cancel();
				cleanup();
			}
			const draggedElement = ev.draggedElement;
			if (!draggedElement || !(draggedElement instanceof Element)) return false;
			if (!draggedElement.isConnected) return false;
			if (isDisallowedDragElement(draggedElement)) return false;
			const rawRoot = (_draggedElement$getRo2 = draggedElement.getRootNode) === null || _draggedElement$getRo2 === void 0 ? void 0 : _draggedElement$getRo2.call(draggedElement);
			const draggedRoot = isDocumentOrShadowRoot(rawRoot) ? rawRoot : document;
			let rect;
			try {
				rect = draggedElement.getBoundingClientRect();
			} catch (_unused5) {
				return false;
			}
			const startRect = toViewportRect$1(rect);
			if (!startRect || startRect.width <= .5 || startRect.height <= .5) return false;
			const moveHandle = transactionManager.beginMove(draggedElement);
			if (!moveHandle) return false;
			const prevPointerEvents = uiRoot.style.pointerEvents;
			state = {
				pointerId: ev.pointerId,
				draggedElement,
				draggedRoot,
				startRect,
				pointerOffsetX: ev.startClientX - startRect.left,
				pointerOffsetY: ev.startClientY - startRect.top,
				lastClientX: ev.clientX,
				lastClientY: ev.clientY,
				preview: null,
				uiPointerEventsBefore: prevPointerEvents,
				moveHandle
			};
			setUiPointerEventsEnabled(false, state);
			scheduleUpdate();
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Drag started`);
			return true;
		}
		function onDragMove(ev) {
			const s = state;
			if (!s) return;
			if (ev.pointerId !== s.pointerId) return;
			s.lastClientX = ev.clientX;
			s.lastClientY = ev.clientY;
			scheduleUpdate();
		}
		function onDragEnd(ev) {
			const s = state;
			if (!s) return;
			if (ev.pointerId !== s.pointerId) return;
			s.lastClientX = ev.clientX;
			s.lastClientY = ev.clientY;
			cancelRaf();
			const insert = computeInsertPosition(s);
			if (!insert || insert.isNoop) {
				s.moveHandle.cancel();
				cleanup();
				console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Drag cancelled (no-op or no target)`);
				return;
			}
			if (!applyDomMove(s.draggedElement, insert)) {
				s.moveHandle.cancel();
				cleanup();
				console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Drag failed (DOM move error)`);
				return;
			}
			s.moveHandle.commit(s.draggedElement);
			positionTracker.forceUpdate();
			cleanup();
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Drag completed`);
		}
		function onDragCancel(_ev) {
			const s = state;
			if (!s) return;
			s.moveHandle.cancel();
			cleanup();
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Drag cancelled`);
		}
		disposer.add(() => {
			const s = state;
			if (!s) return;
			s.moveHandle.cancel();
			cleanup();
		});
		return {
			onDragStart,
			onDragMove,
			onDragEnd,
			onDragCancel,
			dispose: () => disposer.dispose()
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/event-controller.ts
	/**
	* Event Controller
	*
	* Capture-phase event interceptor for Web Editor V2.
	*
	* Responsibilities:
	* - Intercept document-level pointer/mouse/keyboard events in capture phase
	* - Allow editor UI events (Shadow DOM) to pass through unmodified
	* - Block page interactions while editor is active
	* - Provide hover/selecting mode state machine
	* - Trigger callbacks for element hover, selection, and deselection
	*
	* Performance considerations:
	* - Uses rAF throttling for hover updates (elementFromPoint is expensive)
	* - Supports both PointerEvents (modern) and MouseEvents (fallback)
	* - Events are blocked via stopImmediatePropagation for complete isolation
	*/
	/** Common capture-phase listener options */
	var CAPTURE_OPTIONS = {
		capture: true,
		passive: false
	};
	/** Events to completely block on document (page interaction prevention) */
	var BLOCKED_POINTER_EVENTS = [
		"pointerup",
		"pointercancel",
		"pointerover",
		"pointerout",
		"pointerenter",
		"pointerleave"
	];
	var BLOCKED_MOUSE_EVENTS = [
		"mouseup",
		"click",
		"dblclick",
		"contextmenu",
		"auxclick",
		"mouseover",
		"mouseout",
		"mouseenter",
		"mouseleave"
	];
	var BLOCKED_KEYBOARD_EVENTS = ["keyup", "keypress"];
	var BLOCKED_TOUCH_EVENTS = [
		"touchstart",
		"touchmove",
		"touchend",
		"touchcancel"
	];
	/**
	* Create an event controller for managing editor interactions.
	*
	* The controller operates in four modes:
	* - `hover`: Mouse movement triggers onHover callbacks, click transitions to selecting
	* - `selecting`: An element is selected, ESC key returns to hover mode
	* - `editing`: Text editing mode for the selected element (Phase 2.7)
	* - `dragging`: Drag reorder mode for the selected element (Phase 2.4-2.6)
	*/
	function createEventController(options) {
		const { isOverlayElement, onHover, onSelect, onDeselect, onStartEdit, findTargetForSelect, getSelectedElement, onStartDrag, onDragMove, onDragEnd, onDragCancel } = options;
		const disposer = new Disposer();
		const hasPointerEvents = typeof PointerEvent !== "undefined";
		let mode = "hover";
		let lastHoveredElement = null;
		/** Element currently being edited (Phase 2.7) */
		let editingElement = null;
		let dragCandidate = null;
		let draggingPointerId = null;
		/** True if the current dragging session was initiated by PointerEvent */
		let draggingIsPointerOrigin = false;
		/** Flag to suppress mode_change cancel when we're intentionally leaving dragging */
		let suppressModeChangeDragCancel = false;
		let hasPointerPosition = false;
		let lastClientX = 0;
		let lastClientY = 0;
		let hoverRafId = null;
		/**
		* Check if an event originated from the editor UI (Shadow DOM safe)
		*/
		function isEventFromEditorUi(event) {
			try {
				if (typeof event.composedPath === "function") return event.composedPath().some((node) => isOverlayElement(node));
			} catch (_unused) {}
			return isOverlayElement(event.target);
		}
		/**
		* Check if an event originated from the current editing element (Shadow DOM safe).
		* Used to allow native interactions (typing, selection) inside the editing element.
		*/
		function isEventFromEditingElement(event) {
			const el = editingElement;
			if (!el) return false;
			try {
				if (typeof event.composedPath === "function") return event.composedPath().some((node) => node === el);
			} catch (_unused2) {}
			const target = event.target;
			return target instanceof Node && el.contains(target);
		}
		/**
		* Block an event from reaching the page
		*/
		function blockPageEvent(event) {
			if (event.cancelable) event.preventDefault();
			event.stopImmediatePropagation();
			event.stopPropagation();
		}
		/**
		* Extract modifiers from an event
		*/
		function extractModifiers(event) {
			return {
				alt: event.altKey,
				shift: event.shiftKey,
				ctrl: event.ctrlKey,
				meta: event.metaKey
			};
		}
		/**
		* Get pointer ID from event (PointerEvent has pointerId, MouseEvent uses 0)
		*/
		function getEventPointerId(event) {
			return event instanceof PointerEvent ? event.pointerId : 0;
		}
		/**
		* Check if we should process this event as the primary pointer.
		* On browsers with PointerEvents, mouse events fire after pointer events;
		* we use mouse listeners only for blocking, not for interaction logic.
		*/
		function shouldProcessAsPrimaryPointer(event) {
			if (hasPointerEvents && !(event instanceof PointerEvent)) return false;
			return true;
		}
		/**
		* Check if an event originated from within a specific element (Shadow DOM safe)
		*/
		function isEventWithinElement(event, element) {
			try {
				if (typeof event.composedPath === "function") return event.composedPath().some((node) => node === element);
			} catch (_unused3) {}
			const target = event.target;
			return target instanceof Node && element.contains(target);
		}
		/**
		* Clear all drag-related state
		*/
		function clearDragState() {
			dragCandidate = null;
			draggingPointerId = null;
			draggingIsPointerOrigin = false;
		}
		/**
		* Cancel the current dragging session
		*/
		function cancelDragging(reason) {
			if (mode !== "dragging") return;
			clearDragState();
			try {
				onDragCancel === null || onDragCancel === void 0 || onDragCancel({ reason });
			} catch (_unused4) {}
			suppressModeChangeDragCancel = true;
			setMode("selecting");
		}
		/**
		* End the current dragging session (successful drop)
		*/
		function endDragging(pointerId, clientX, clientY) {
			if (mode !== "dragging") return;
			if (draggingPointerId === null || draggingPointerId !== pointerId) return;
			clearDragState();
			try {
				onDragEnd === null || onDragEnd === void 0 || onDragEnd({
					pointerId,
					clientX,
					clientY
				});
			} catch (_unused5) {}
			suppressModeChangeDragCancel = true;
			setMode("selecting");
		}
		/**
		* Get the topmost element at a viewport coordinate (fast, for hover).
		* Uses simple elementFromPoint to maintain 60FPS hover performance.
		*/
		function getTargetElementAtFast(clientX, clientY) {
			if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return null;
			const element = document.elementFromPoint(clientX, clientY);
			if (!element) return null;
			if (isOverlayElement(element)) return null;
			return element;
		}
		/**
		* Get the best target element for selection (can be slower, uses intelligent picking).
		* Uses custom findTargetForSelect if provided, otherwise falls back to fast method.
		*
		* The event parameter is passed to enable Shadow DOM-aware selection via composedPath().
		*/
		function getTargetElementForSelection(event, clientX, clientY, modifiers) {
			if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return null;
			if (findTargetForSelect) {
				const target = findTargetForSelect(clientX, clientY, modifiers, event);
				if (target && isOverlayElement(target)) return null;
				return target;
			}
			return getTargetElementAtFast(clientX, clientY);
		}
		/**
		* Cancel any pending hover rAF
		*/
		function cancelHoverRaf() {
			if (hoverRafId !== null) {
				cancelAnimationFrame(hoverRafId);
				hoverRafId = null;
			}
		}
		disposer.add(cancelHoverRaf);
		/**
		* Commit the hover update by finding element at current pointer position
		* Allowed in both 'hover' and 'selecting' modes to show hover highlight while element is selected
		*/
		function commitHoverUpdate(forceUpdate = false) {
			hoverRafId = null;
			if (disposer.isDisposed) return;
			if (mode !== "hover" && mode !== "selecting") return;
			if (!hasPointerPosition) return;
			const nextElement = getTargetElementAtFast(lastClientX, lastClientY);
			if (!forceUpdate && nextElement === lastHoveredElement) return;
			lastHoveredElement = nextElement;
			onHover(nextElement);
		}
		/**
		* Schedule a hover update on the next animation frame
		*/
		function scheduleHoverUpdate(forceUpdate = false) {
			if (hoverRafId !== null) return;
			if (disposer.isDisposed) return;
			hoverRafId = requestAnimationFrame(() => {
				commitHoverUpdate(forceUpdate);
			});
		}
		/**
		* Set the interaction mode.
		*
		* State cleanup invariants:
		* - Leaving `editing`: clear editingElement
		* - Leaving `selecting`: clear dragCandidate
		* - Leaving `dragging`: clear all drag state (candidate + pointer + origin flag)
		* - Entering `hover`: trigger onDeselect and resume hover tracking
		*/
		function setMode(nextMode) {
			if (disposer.isDisposed) return;
			if (mode === nextMode) return;
			const prevMode = mode;
			mode = nextMode;
			if (prevMode === "editing" && nextMode !== "editing") editingElement = null;
			if (prevMode === "selecting" && nextMode !== "selecting") dragCandidate = null;
			if (prevMode === "dragging" && nextMode !== "dragging") {
				const shouldNotify = !suppressModeChangeDragCancel;
				suppressModeChangeDragCancel = false;
				clearDragState();
				if (shouldNotify) try {
					onDragCancel === null || onDragCancel === void 0 || onDragCancel({ reason: "mode_change" });
				} catch (_unused6) {}
			} else suppressModeChangeDragCancel = false;
			if (prevMode === "hover" && nextMode !== "hover") {
				cancelHoverRaf();
				lastHoveredElement = null;
			}
			if (nextMode === "hover" && prevMode !== "hover") {
				lastHoveredElement = null;
				clearDragState();
				onDeselect();
				if (hasPointerPosition) scheduleHoverUpdate(true);
			}
		}
		/**
		* Handle pointer/mouse move for hover tracking
		*/
		function handlePointerMove(event) {
			if (mode === "editing" && isEventFromEditingElement(event)) return;
			if (isEventFromEditorUi(event)) {
				if (mode === "hover" && lastHoveredElement !== null) {
					lastHoveredElement = null;
					onHover(null);
				}
				return;
			}
			blockPageEvent(event);
			lastClientX = event.clientX;
			lastClientY = event.clientY;
			hasPointerPosition = true;
			if (mode === "dragging" && shouldProcessAsPrimaryPointer(event)) {
				const pointerId = getEventPointerId(event);
				const isPointerEvent = event instanceof PointerEvent;
				if (draggingIsPointerOrigin !== isPointerEvent) return;
				if (draggingPointerId !== null && pointerId === draggingPointerId) onDragMove === null || onDragMove === void 0 || onDragMove({
					pointerId,
					clientX: event.clientX,
					clientY: event.clientY
				});
				return;
			}
			if (mode === "selecting" && dragCandidate && shouldProcessAsPrimaryPointer(event)) {
				var _onStartDrag;
				const pointerId = getEventPointerId(event);
				if (pointerId !== dragCandidate.pointerId) return;
				const isPointerEvent = event instanceof PointerEvent;
				if (dragCandidate.isPointerEventOrigin !== isPointerEvent) return;
				const dx = event.clientX - dragCandidate.startClientX;
				const dy = event.clientY - dragCandidate.startClientY;
				if (Math.hypot(dx, dy) < 5) return;
				const startEvent = {
					pointerId,
					draggedElement: dragCandidate.selectedElement,
					startClientX: dragCandidate.startClientX,
					startClientY: dragCandidate.startClientY,
					clientX: event.clientX,
					clientY: event.clientY,
					modifiers: dragCandidate.modifiers
				};
				const wasPointerOrigin = dragCandidate.isPointerEventOrigin;
				dragCandidate = null;
				if (!((_onStartDrag = onStartDrag === null || onStartDrag === void 0 ? void 0 : onStartDrag(startEvent)) !== null && _onStartDrag !== void 0 ? _onStartDrag : false)) return;
				draggingPointerId = pointerId;
				draggingIsPointerOrigin = wasPointerOrigin;
				setMode("dragging");
				onDragMove === null || onDragMove === void 0 || onDragMove({
					pointerId,
					clientX: event.clientX,
					clientY: event.clientY
				});
				return;
			}
			if (mode !== "hover" && mode !== "selecting") return;
			scheduleHoverUpdate();
		}
		/**
		* Handle pointer/mouse down for element selection
		*/
		function handlePointerDown(event) {
			if (mode === "editing" && isEventFromEditingElement(event)) return;
			if (isEventFromEditorUi(event)) return;
			blockPageEvent(event);
			lastClientX = event.clientX;
			lastClientY = event.clientY;
			hasPointerPosition = true;
			if (event.button !== 0) return;
			const modifiers = extractModifiers(event);
			if (mode === "selecting") {
				var _getSelectedElement;
				if (!shouldProcessAsPrimaryPointer(event)) return;
				const selected = (_getSelectedElement = getSelectedElement === null || getSelectedElement === void 0 ? void 0 : getSelectedElement()) !== null && _getSelectedElement !== void 0 ? _getSelectedElement : null;
				const target = getTargetElementForSelection(event, event.clientX, event.clientY, modifiers);
				if (target && target !== selected) {
					dragCandidate = null;
					onSelect(target, modifiers);
					return;
				}
				if (onStartDrag && selected && selected.isConnected && isEventWithinElement(event, selected)) {
					const isPointerOrigin = event instanceof PointerEvent;
					dragCandidate = {
						pointerId: getEventPointerId(event),
						startClientX: event.clientX,
						startClientY: event.clientY,
						modifiers,
						selectedElement: selected,
						isPointerEventOrigin: isPointerOrigin
					};
				}
				return;
			}
			if (mode === "dragging") return;
			if (mode === "editing") {
				const target = getTargetElementForSelection(event, event.clientX, event.clientY, modifiers);
				setMode("selecting");
				if (target) onSelect(target, modifiers);
				return;
			}
			if (mode !== "hover") return;
			const target = getTargetElementForSelection(event, event.clientX, event.clientY, modifiers);
			if (!target) return;
			setMode("selecting");
			onSelect(target, modifiers);
		}
		/**
		* Handle double-click for entering edit mode (Phase 2.7)
		*/
		function handleDoubleClick(event) {
			if (mode === "editing" && isEventFromEditingElement(event)) return;
			if (isEventFromEditorUi(event)) return;
			blockPageEvent(event);
			if (event.button !== 0) return;
			if (!onStartEdit) return;
			const modifiers = extractModifiers(event);
			const target = getTargetElementForSelection(event, event.clientX, event.clientY, modifiers);
			if (!target) return;
			if (!onStartEdit(target, modifiers)) return;
			editingElement = target;
			setMode("editing");
		}
		/**
		* Handle keydown for ESC cancellation
		*/
		function handleKeyDown(event) {
			if (mode === "editing" && isEventFromEditingElement(event)) return;
			if (isEventFromEditorUi(event)) return;
			blockPageEvent(event);
			if (event.key === "Escape") {
				if (mode === "dragging") {
					cancelDragging("escape");
					return;
				}
				if (mode === "selecting") {
					dragCandidate = null;
					setMode("hover");
				}
			}
		}
		/**
		* Handle pointerup/mouseup for ending drag
		*/
		function handlePointerUp(event) {
			if (mode === "editing" && isEventFromEditingElement(event)) return;
			if (isEventFromEditorUi(event)) return;
			blockPageEvent(event);
			if (!shouldProcessAsPrimaryPointer(event)) return;
			const pointerId = getEventPointerId(event);
			const isPointerEvent = event instanceof PointerEvent;
			if (mode === "selecting" && dragCandidate && dragCandidate.pointerId === pointerId && dragCandidate.isPointerEventOrigin === isPointerEvent) dragCandidate = null;
			if (mode === "dragging" && draggingIsPointerOrigin === isPointerEvent) endDragging(pointerId, event.clientX, event.clientY);
		}
		/**
		* Handle pointercancel for cancelling drag.
		* Note: pointercancel is a PointerEvent-only event, so we only process
		* drag state that was initiated by PointerEvents.
		*/
		function handlePointerCancel(event) {
			if (mode === "editing" && isEventFromEditingElement(event)) return;
			if (isEventFromEditorUi(event)) return;
			blockPageEvent(event);
			const pointerId = event.pointerId;
			if (dragCandidate && dragCandidate.pointerId === pointerId && dragCandidate.isPointerEventOrigin) dragCandidate = null;
			if (mode !== "dragging") return;
			if (!draggingIsPointerOrigin) return;
			if (draggingPointerId === null || draggingPointerId !== pointerId) return;
			cancelDragging("pointercancel");
		}
		/**
		* Generic blocker for events that should never reach the page
		*/
		function handleBlockedEvent(event) {
			if (isEventFromEditorUi(event)) return;
			if (mode === "editing" && isEventFromEditingElement(event)) return;
			if (event.type === "dblclick") {
				handleDoubleClick(event);
				return;
			}
			if (event.type === "pointerup" || event.type === "mouseup") {
				handlePointerUp(event);
				return;
			}
			if (event.type === "pointercancel") {
				handlePointerCancel(event);
				return;
			}
			blockPageEvent(event);
		}
		if (hasPointerEvents) {
			disposer.listen(document, "pointermove", handlePointerMove, CAPTURE_OPTIONS);
			disposer.listen(document, "pointerdown", handlePointerDown, CAPTURE_OPTIONS);
			for (const eventType of BLOCKED_POINTER_EVENTS) disposer.listen(document, eventType, handleBlockedEvent, CAPTURE_OPTIONS);
		}
		disposer.listen(document, "mousemove", handlePointerMove, CAPTURE_OPTIONS);
		disposer.listen(document, "mousedown", handlePointerDown, CAPTURE_OPTIONS);
		for (const eventType of BLOCKED_MOUSE_EVENTS) disposer.listen(document, eventType, handleBlockedEvent, CAPTURE_OPTIONS);
		disposer.listen(document, "keydown", handleKeyDown, CAPTURE_OPTIONS);
		for (const eventType of BLOCKED_KEYBOARD_EVENTS) disposer.listen(document, eventType, handleBlockedEvent, CAPTURE_OPTIONS);
		for (const eventType of BLOCKED_TOUCH_EVENTS) disposer.listen(document, eventType, handleBlockedEvent, CAPTURE_OPTIONS);
		/**
		* Cancel dragging when window loses focus.
		* This prevents the UI from getting stuck with pointer-events: none
		* if the user switches to another application mid-drag.
		*/
		function handleWindowBlur() {
			if (mode === "selecting" && dragCandidate) dragCandidate = null;
			if (mode === "dragging") cancelDragging("blur");
		}
		/**
		* Cancel dragging when page becomes hidden.
		* This handles cases like switching browser tabs.
		*/
		function handleVisibilityChange() {
			if (document.visibilityState !== "visible") {
				if (mode === "selecting" && dragCandidate) dragCandidate = null;
				if (mode === "dragging") cancelDragging("visibilitychange");
			}
		}
		disposer.listen(window, "blur", handleWindowBlur);
		disposer.listen(document, "visibilitychange", handleVisibilityChange);
		disposer.add(() => {
			if (mode === "dragging") try {
				onDragCancel === null || onDragCancel === void 0 || onDragCancel({ reason: "dispose" });
			} catch (_unused7) {}
			clearDragState();
		});
		return {
			getMode: () => mode,
			setMode,
			dispose: () => disposer.dispose()
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/position-tracker.ts
	/** Passive listener options for scroll/resize */
	var PASSIVE_LISTENER = { passive: true };
	/** Sub-pixel threshold for rect comparison (avoids jitter-induced redraws) */
	var RECT_EPSILON$1 = .5;
	/**
	* MutationObserver options for selection sync.
	* Keep lightweight: only observe childList changes in subtree.
	* Attribute changes are not observed as they rarely affect element position/removal.
	*/
	var SELECTION_MUTATION_OPTIONS = {
		childList: true,
		subtree: true
	};
	/**
	* Convert DOMRect to ViewportRect, returning null for invalid values
	*/
	function toViewportRect(domRect) {
		const { left, top, width, height } = domRect;
		if (!Number.isFinite(left) || !Number.isFinite(top) || !Number.isFinite(width) || !Number.isFinite(height)) return null;
		return {
			left,
			top,
			width: Math.max(0, width),
			height: Math.max(0, height)
		};
	}
	/**
	* Check if two numbers are approximately equal
	*/
	function approximatelyEqual$1(a, b) {
		return Math.abs(a - b) < RECT_EPSILON$1;
	}
	/**
	* Check if two ViewportRects are approximately equal
	*/
	function rectApproximatelyEqual(a, b) {
		if (a === b) return true;
		if (!a || !b) return false;
		return approximatelyEqual$1(a.left, b.left) && approximatelyEqual$1(a.top, b.top) && approximatelyEqual$1(a.width, b.width) && approximatelyEqual$1(a.height, b.height);
	}
	/**
	* Check if two TrackedRects are approximately equal
	*/
	function trackedRectsEqual(a, b) {
		return rectApproximatelyEqual(a.hover, b.hover) && rectApproximatelyEqual(a.selection, b.selection);
	}
	/**
	* Create a position tracker for monitoring element positions.
	*
	* The tracker automatically updates when the viewport scrolls or resizes,
	* and notifies via callback when tracked element positions change.
	*/
	function createPositionTracker(options) {
		const { onPositionUpdate } = options;
		const disposer = new Disposer();
		let hoverElement = null;
		let selectionElement = null;
		let lastRects = {
			hover: null,
			selection: null
		};
		let rafId = null;
		function cancelRaf() {
			if (rafId !== null) {
				cancelAnimationFrame(rafId);
				rafId = null;
			}
		}
		disposer.add(cancelRaf);
		function scheduleUpdate() {
			if (disposer.isDisposed) return;
			if (rafId !== null) return;
			rafId = requestAnimationFrame(() => {
				rafId = null;
				updateIfChanged();
			});
		}
		/** Disposer for selection-specific observers (recreated when selection changes) */
		let selectionObservers = new Disposer();
		disposer.add(() => selectionObservers.dispose());
		/**
		* Reset selection observers when selection changes.
		* Disconnects old observers and sets up new ones for the current selection.
		*/
		function resetSelectionObservers() {
			var _target$getRootNode, _document$body;
			selectionObservers.dispose();
			selectionObservers = new Disposer();
			const target = selectionElement;
			if (!target) return;
			selectionObservers.observeResize(target, () => {
				if (disposer.isDisposed) return;
				if (selectionElement !== target) return;
				scheduleUpdate();
			});
			const mutationCallback = () => {
				if (disposer.isDisposed) return;
				if (selectionElement !== target) return;
				scheduleUpdate();
			};
			const rootNode = (_target$getRootNode = target.getRootNode) === null || _target$getRootNode === void 0 ? void 0 : _target$getRootNode.call(target);
			if (rootNode instanceof ShadowRoot) selectionObservers.observeMutation(rootNode, mutationCallback, SELECTION_MUTATION_OPTIONS);
			const body = (_document$body = document.body) !== null && _document$body !== void 0 ? _document$body : document.documentElement;
			if (body) selectionObservers.observeMutation(body, mutationCallback, SELECTION_MUTATION_OPTIONS);
		}
		/**
		* Get element if still connected to DOM, null otherwise
		*/
		function resolveConnected(element) {
			if (!element) return null;
			return element.isConnected ? element : null;
		}
		/**
		* Safely read element's viewport rect
		*/
		function readElementRect(element) {
			if (!element) return null;
			try {
				return toViewportRect(element.getBoundingClientRect());
			} catch (_unused) {
				return null;
			}
		}
		/**
		* Compute current rects for all tracked elements
		*/
		function computeRects() {
			const resolvedHover = resolveConnected(hoverElement);
			const resolvedSelection = resolveConnected(selectionElement);
			if (hoverElement && !resolvedHover) hoverElement = null;
			if (selectionElement && !resolvedSelection) {
				selectionElement = null;
				resetSelectionObservers();
			}
			if (resolvedHover && resolvedSelection && resolvedHover === resolvedSelection) {
				const rect = readElementRect(resolvedHover);
				return {
					hover: rect,
					selection: rect
				};
			}
			return {
				hover: readElementRect(resolvedHover),
				selection: readElementRect(resolvedSelection)
			};
		}
		/**
		* Update rects and notify if changed
		*/
		function updateIfChanged() {
			if (disposer.isDisposed) return;
			const nextRects = computeRects();
			if (trackedRectsEqual(nextRects, lastRects)) return;
			lastRects = nextRects;
			onPositionUpdate(nextRects);
		}
		function handleViewportChange() {
			if (!hoverElement && !selectionElement && !lastRects.hover && !lastRects.selection) return;
			scheduleUpdate();
		}
		disposer.listen(window, "scroll", handleViewportChange, PASSIVE_LISTENER);
		disposer.listen(document, "scroll", handleViewportChange, _objectSpread2(_objectSpread2({}, PASSIVE_LISTENER), {}, { capture: true }));
		disposer.listen(window, "resize", handleViewportChange, PASSIVE_LISTENER);
		function setHoverElement(element) {
			if (disposer.isDisposed) return;
			if (hoverElement === element) return;
			hoverElement = element;
			scheduleUpdate();
		}
		function setSelectionElement(element) {
			if (disposer.isDisposed) return;
			if (selectionElement === element) return;
			selectionElement = element;
			resetSelectionObservers();
			scheduleUpdate();
		}
		function forceUpdate() {
			if (disposer.isDisposed) return;
			cancelRaf();
			updateIfChanged();
		}
		return {
			setHoverElement,
			setSelectionElement,
			forceUpdate,
			dispose: () => disposer.dispose()
		};
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.126.0/helpers/objectWithoutPropertiesLoose.js
	function _objectWithoutPropertiesLoose(r, e) {
		if (null == r) return {};
		var t = {};
		for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
			if (e.includes(n)) continue;
			t[n] = r[n];
		}
		return t;
	}
	//#endregion
	//#region \0@oxc-project+runtime@0.126.0/helpers/objectWithoutProperties.js
	function _objectWithoutProperties(e, t) {
		if (null == e) return {};
		var o, r, i = _objectWithoutPropertiesLoose(e, t);
		if (Object.getOwnPropertySymbols) {
			var s = Object.getOwnPropertySymbols(e);
			for (r = 0; r < s.length; r++) o = s[r], t.includes(o) || {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
		}
		return i;
	}
	//#endregion
	//#region entrypoints/web-editor-v2/selection/selection-engine.ts
	/**
	* Selection Engine (Phase 1.6 - Basic)
	*
	* Heuristic-based target picking to reduce noisy selections.
	*
	* Goals:
	* - Skip invisible/transparent elements
	* - De-prioritize "wrapper-only" elements (single-child, no visual boundary)
	* - Prefer interactive elements (button/link/input/etc.)
	* - Prefer elements with visual boundaries (border/background/shadow)
	* - Support basic parent drilling via Alt modifier
	*
	* Scoring system:
	* - Positive scores: interactive elements, visual boundaries, appropriate size
	* - Negative scores: wrapper-only, too small/large, SVG internals
	* - Candidates sorted by score descending, then by DOM order
	*/
	var _excluded = ["hitOrder", "depthFromHit"];
	/** Max elements from elementsFromPoint to process */
	var MAX_HIT_ELEMENTS = 8;
	/** Max ancestor depth to traverse */
	var MAX_ANCESTOR_DEPTH = 6;
	/** Max total candidates to consider */
	var MAX_CANDIDATES = 60;
	/** Epsilon for rect comparisons */
	var RECT_EPSILON = .5;
	/** Tags that are inherently interactive */
	var INTERACTIVE_TAGS = new Set([
		"A",
		"BUTTON",
		"INPUT",
		"SELECT",
		"TEXTAREA",
		"LABEL",
		"SUMMARY",
		"DETAILS"
	]);
	/** ARIA roles that indicate interactivity */
	var INTERACTIVE_ROLES = new Set([
		"button",
		"link",
		"checkbox",
		"radio",
		"switch",
		"tab",
		"menuitem",
		"option",
		"combobox",
		"textbox"
	]);
	/** Tags commonly used as layout wrappers */
	var WRAPPER_TAGS = new Set([
		"DIV",
		"SPAN",
		"SECTION",
		"ARTICLE",
		"MAIN",
		"HEADER",
		"FOOTER",
		"NAV",
		"ASIDE"
	]);
	/**
	* Parse a CSS numeric value
	*/
	function parseNumber(value) {
		const n = Number.parseFloat(value);
		return Number.isFinite(n) ? n : 0;
	}
	/**
	* Check if a color is effectively transparent
	*/
	function isTransparentColor(value) {
		const v = value.trim().toLowerCase();
		if (v === "transparent") return true;
		const rgba = v.match(/^rgba?\((.+)\)$/);
		if (rgba) {
			const parts = rgba[1].split(",").map((p) => p.trim());
			if (parts.length >= 4) {
				const alpha = Number.parseFloat(parts[3]);
				return Number.isFinite(alpha) && alpha <= .01;
			}
			return false;
		}
		const hsla = v.match(/^hsla?\((.+)\)$/);
		if (hsla) {
			const parts = hsla[1].split(",").map((p) => p.trim());
			if (parts.length >= 4) {
				const alpha = Number.parseFloat(parts[3]);
				return Number.isFinite(alpha) && alpha <= .01;
			}
			return false;
		}
		return false;
	}
	/**
	* Check if element has direct text content (not just whitespace)
	*/
	function hasDirectNonWhitespaceText(element) {
		for (const node of Array.from(element.childNodes)) {
			var _node$textContent;
			if (node.nodeType === Node.TEXT_NODE && ((_node$textContent = node.textContent) === null || _node$textContent === void 0 ? void 0 : _node$textContent.trim())) return true;
		}
		return false;
	}
	/**
	* Get parent element, crossing Shadow DOM boundaries
	*/
	function getParentElementOrHost(element) {
		if (element.parentElement) return element.parentElement;
		try {
			var _element$getRootNode;
			const root = (_element$getRootNode = element.getRootNode) === null || _element$getRootNode === void 0 ? void 0 : _element$getRootNode.call(element);
			if (root instanceof ShadowRoot) return root.host;
		} catch (_unused) {}
		return null;
	}
	/**
	* Get elements at a viewport point
	*/
	function getHitElementsAtPoint(x, y) {
		if (!Number.isFinite(x) || !Number.isFinite(y)) return [];
		try {
			if (typeof document.elementsFromPoint === "function") return document.elementsFromPoint(x, y);
		} catch (_unused2) {}
		const el = document.elementFromPoint(x, y);
		return el ? [el] : [];
	}
	/**
	* Get viewport area for size ratio calculations
	*/
	function getViewportArea() {
		return Math.max(1, window.innerWidth || 1) * Math.max(1, window.innerHeight || 1);
	}
	/**
	* Safely read element rect
	*/
	function readRect(element) {
		try {
			const rect = element.getBoundingClientRect();
			if (!Number.isFinite(rect.left) || !Number.isFinite(rect.top)) return null;
			if (!Number.isFinite(rect.width) || !Number.isFinite(rect.height)) return null;
			return rect;
		} catch (_unused3) {
			return null;
		}
	}
	/**
	* Check if element is effectively invisible
	*/
	function isEffectivelyInvisible(style, rect) {
		if (style.display === "none") return true;
		if (style.visibility === "hidden" || style.visibility === "collapse") return true;
		if (parseNumber(style.opacity) <= .01) return true;
		if (style.contentVisibility === "hidden") return true;
		if (rect.width <= RECT_EPSILON || rect.height <= RECT_EPSILON) return true;
		return false;
	}
	/**
	* Score element based on visual boundary presence
	*/
	function getVisualBoundaryScore(element, style) {
		let points = 0;
		const reasons = [];
		if (!isTransparentColor(style.backgroundColor) || style.backgroundImage !== "none") {
			points += 2;
			reasons.push("visual:background:+2");
		}
		if ([
			parseNumber(style.borderTopWidth),
			parseNumber(style.borderRightWidth),
			parseNumber(style.borderBottomWidth),
			parseNumber(style.borderLeftWidth)
		].some((w) => w > RECT_EPSILON) && (style.borderTopStyle !== "none" || style.borderRightStyle !== "none" || style.borderBottomStyle !== "none" || style.borderLeftStyle !== "none")) {
			points += 3;
			reasons.push("visual:border:+3");
		}
		if (style.boxShadow && style.boxShadow !== "none") {
			points += 2;
			reasons.push("visual:shadow:+2");
		}
		if (style.outlineStyle !== "none" && parseNumber(style.outlineWidth) > RECT_EPSILON) {
			points += 1;
			reasons.push("visual:outline:+1");
		}
		const tag = element.tagName.toUpperCase();
		if (tag === "IMG" || tag === "VIDEO" || tag === "CANVAS" || tag === "SVG") {
			points += 2;
			reasons.push("visual:media:+2");
		}
		if (element instanceof SVGElement && tag !== "SVG") {
			points -= 1;
			reasons.push("visual:svg-sub:-1");
		}
		return {
			points,
			reasons
		};
	}
	/**
	* Score element based on interactivity
	*/
	function getInteractivityScore(element, style) {
		var _element$getAttribute, _element$getAttribute2;
		let points = 0;
		const reasons = [];
		const tag = element.tagName.toUpperCase();
		if (INTERACTIVE_TAGS.has(tag)) {
			points += 6;
			reasons.push(`type:${tag.toLowerCase()}:+6`);
		}
		const role = (_element$getAttribute = (_element$getAttribute2 = element.getAttribute("role")) === null || _element$getAttribute2 === void 0 ? void 0 : _element$getAttribute2.toLowerCase()) !== null && _element$getAttribute !== void 0 ? _element$getAttribute : "";
		if (role && INTERACTIVE_ROLES.has(role)) {
			points += 4;
			reasons.push(`role:${role}:+4`);
		}
		if (element instanceof HTMLAnchorElement && element.href) {
			points += 2;
			reasons.push("attr:href:+2");
		}
		if (element instanceof HTMLElement) {
			if (element.isContentEditable) {
				points += 5;
				reasons.push("attr:contenteditable:+5");
			}
			if (element.tabIndex >= 0) {
				points += 2;
				reasons.push("focusable:+2");
			}
		}
		if (style.cursor === "pointer") {
			points += 2;
			reasons.push("cursor:pointer:+2");
		}
		return {
			points,
			reasons
		};
	}
	/**
	* Score element based on size
	*/
	function getSizeScore(rect, viewportArea) {
		let points = 0;
		const reasons = [];
		const area = rect.width * rect.height;
		if (!Number.isFinite(area) || area <= 0) {
			points -= 6;
			reasons.push("size:invalid:-6");
			return {
				points,
				reasons
			};
		}
		if (rect.width < 4 || rect.height < 4) {
			points -= 6;
			reasons.push("size:tiny:-6");
		} else if (area < 256) {
			points -= 4;
			reasons.push("size:small:-4");
		} else if (area < 1936) {
			points -= 1;
			reasons.push("size:below-tap-target:-1");
		}
		const ratio = viewportArea > 0 ? area / viewportArea : 0;
		if (ratio > .85) {
			points -= 8;
			reasons.push("size:huge:-8");
		} else if (ratio > .6) {
			points -= 4;
			reasons.push("size:very-large:-4");
		}
		return {
			points,
			reasons
		};
	}
	/**
	* Check if element has meaningful padding
	*/
	function hasMeaningfulPadding(style) {
		return parseNumber(style.paddingTop) > RECT_EPSILON || parseNumber(style.paddingRight) > RECT_EPSILON || parseNumber(style.paddingBottom) > RECT_EPSILON || parseNumber(style.paddingLeft) > RECT_EPSILON;
	}
	/**
	* Check if element is a wrapper-only container
	*/
	function isWrapperOnly(element, style, visualScore, interactivityScore) {
		if (style.display === "contents") return true;
		if (interactivityScore > 0) return false;
		const tag = element.tagName.toUpperCase();
		if (!WRAPPER_TAGS.has(tag)) return false;
		if (element.children.length !== 1) return false;
		if (hasDirectNonWhitespaceText(element)) return false;
		if (visualScore > 0) return false;
		if (hasMeaningfulPadding(style)) return false;
		return true;
	}
	/**
	* Compare candidate metadata for ordering
	*/
	function compareMeta(a, b) {
		if (a.hitOrder !== b.hitOrder) return a.hitOrder - b.hitOrder;
		return a.depthFromHit - b.depthFromHit;
	}
	/**
	* Create a selection engine for intelligent element picking.
	*/
	function createSelectionEngine(options) {
		const disposer = new Disposer();
		const { isOverlayElement } = options;
		/**
		* Score a single element
		*/
		function scoreElement(element, styleCache, viewportArea) {
			if (!element.isConnected) return null;
			if (isOverlayElement(element)) return null;
			const tag = element.tagName.toUpperCase();
			if (tag === "HTML" || tag === "BODY") return null;
			const rect = readRect(element);
			if (!rect) return null;
			let style = styleCache.get(element);
			if (!style) {
				style = window.getComputedStyle(element);
				styleCache.set(element, style);
			}
			if (isEffectivelyInvisible(style, rect)) return null;
			const reasons = [];
			let score = 0;
			const interactivity = getInteractivityScore(element, style);
			score += interactivity.points;
			reasons.push(...interactivity.reasons);
			const visual = getVisualBoundaryScore(element, style);
			score += visual.points;
			reasons.push(...visual.reasons);
			const size = getSizeScore(rect, viewportArea);
			score += size.points;
			reasons.push(...size.reasons);
			const wrapperOnly = isWrapperOnly(element, style, visual.points, interactivity.points);
			if (wrapperOnly) {
				score -= 8;
				reasons.push("wrapperOnly:-8");
			}
			if (tag === "SPAN" && interactivity.points === 0 && visual.points === 0) {
				score -= 2;
				reasons.push("inline:span:-2");
			}
			const area = rect.width * rect.height;
			const ratio = viewportArea > 0 ? area / viewportArea : 0;
			if (style.position === "fixed" && ratio > .3) {
				score -= 2;
				reasons.push("position:fixed-large:-2");
			}
			return {
				element,
				score,
				reasons,
				wrapperOnly
			};
		}
		/**
		* Get all scored candidates at a point
		*/
		function getCandidatesAtPoint(x, y) {
			const hit = getHitElementsAtPoint(x, y);
			if (hit.length === 0) return [];
			const map = /* @__PURE__ */ new Map();
			function addCandidate(element, meta) {
				if (isOverlayElement(element)) return;
				if (map.size >= MAX_CANDIDATES && !map.has(element)) return;
				const prev = map.get(element);
				if (!prev || compareMeta(meta, prev) < 0) map.set(element, meta);
			}
			const limit = Math.min(hit.length, MAX_HIT_ELEMENTS);
			for (let i = 0; i < limit; i++) {
				const el = hit[i];
				addCandidate(el, {
					hitOrder: i,
					depthFromHit: 0
				});
				let current = el;
				for (let depth = 1; depth <= MAX_ANCESTOR_DEPTH; depth++) {
					current = current ? getParentElementOrHost(current) : null;
					if (!current) break;
					addCandidate(current, {
						hitOrder: i,
						depthFromHit: depth
					});
				}
			}
			const viewportArea = getViewportArea();
			const styleCache = /* @__PURE__ */ new Map();
			const scored = [];
			for (const [element, meta] of map) {
				const candidate = scoreElement(element, styleCache, viewportArea);
				if (!candidate) continue;
				scored.push(_objectSpread2(_objectSpread2({}, candidate), meta));
			}
			scored.sort((a, b) => {
				if (b.score !== a.score) return b.score - a.score;
				return compareMeta(a, b);
			});
			return scored.map((_ref) => {
				let { hitOrder: _, depthFromHit: __ } = _ref;
				return _objectWithoutProperties(_ref, _excluded);
			});
		}
		/**
		* Get a meaningful parent candidate for drill-up
		*/
		function getParentCandidate(current) {
			let parent = getParentElementOrHost(current);
			if (!parent) return null;
			getViewportArea();
			const styleCache = /* @__PURE__ */ new Map();
			while (parent) {
				if (isOverlayElement(parent)) return null;
				const tag = parent.tagName.toUpperCase();
				if (tag === "HTML" || tag === "BODY") return null;
				const rect = readRect(parent);
				if (!rect) {
					parent = getParentElementOrHost(parent);
					continue;
				}
				let style = styleCache.get(parent);
				if (!style) {
					style = window.getComputedStyle(parent);
					styleCache.set(parent, style);
				}
				if (isEffectivelyInvisible(style, rect)) {
					parent = getParentElementOrHost(parent);
					continue;
				}
				const interactivity = getInteractivityScore(parent, style);
				const visual = getVisualBoundaryScore(parent, style);
				if (!isWrapperOnly(parent, style, visual.points, interactivity.points)) return parent;
				parent = getParentElementOrHost(parent);
			}
			return null;
		}
		/**
		* Find the best target at a point with modifier support
		*/
		function findBestTarget(x, y, modifiers) {
			var _candidates$0$element, _candidates$;
			const best = (_candidates$0$element = (_candidates$ = getCandidatesAtPoint(x, y)[0]) === null || _candidates$ === void 0 ? void 0 : _candidates$.element) !== null && _candidates$0$element !== void 0 ? _candidates$0$element : null;
			if (!best) return null;
			if (modifiers.alt) {
				var _getParentCandidate;
				return (_getParentCandidate = getParentCandidate(best)) !== null && _getParentCandidate !== void 0 ? _getParentCandidate : best;
			}
			return best;
		}
		/**
		* Extract Element nodes from an event's composedPath(), filtering overlay elements.
		* Returns elements ordered from innermost to outermost.
		*
		* Why composedPath?
		* - When events bubble from inside Shadow DOM, they get "retargeted" at shadow boundaries
		* - By the time a document-level listener receives the event, event.target points to the shadow host
		* - composedPath() exposes the original event path before retargeting
		*/
		function getComposedPathElements(event) {
			try {
				const path = typeof event.composedPath === "function" ? event.composedPath() : null;
				if (!Array.isArray(path) || path.length === 0) return [];
				const elements = [];
				for (const node of path) {
					if (!(node instanceof Element)) continue;
					if (isOverlayElement(node)) continue;
					const tag = node.tagName.toUpperCase();
					if (tag === "HTML" || tag === "BODY") continue;
					elements.push(node);
				}
				return elements;
			} catch (_unused4) {
				return [];
			}
		}
		/**
		* Extract viewport coordinates from a MouseEvent/PointerEvent.
		*/
		function extractClientPoint(event) {
			const e = event;
			const x = typeof e.clientX === "number" ? e.clientX : NaN;
			const y = typeof e.clientY === "number" ? e.clientY : NaN;
			if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
			return {
				x,
				y
			};
		}
		/** Max elements to scan for innermost visible (performance guard) */
		const MAX_INNERMOST_SCAN = 32;
		/**
		* Find innermost visible element from composedPath (for Ctrl/Cmd + Click drill-in).
		* Returns the first element that passes visibility checks.
		* Limited to MAX_INNERMOST_SCAN elements to prevent performance issues in deep DOMs.
		*/
		function findInnermostVisible(pathElements) {
			const viewportArea = getViewportArea();
			const styleCache = /* @__PURE__ */ new Map();
			const limit = Math.min(pathElements.length, MAX_INNERMOST_SCAN);
			for (let i = 0; i < limit; i++) {
				const element = pathElements[i];
				const candidate = scoreElement(element, styleCache, viewportArea);
				if (candidate) return candidate.element;
			}
			return null;
		}
		/**
		* Event-aware selection entry point (Shadow DOM support).
		*
		* Uses composedPath() to access elements inside Shadow DOM that would
		* otherwise be inaccessible due to event retargeting.
		*
		* Strategy: "Hit-first, climb-if-meaningless"
		* - Default: Select the direct hit element (what user clicked)
		* - If direct hit is wrapper-only (no visual meaning), climb to first meaningful parent
		* - This ensures clicking on boxC selects boxC, not boxA
		*
		* Modifier behavior:
		* - Ctrl/Cmd + Click: Select innermost visible element (drill-in)
		* - Alt + Click: Select parent of best target (drill-up)
		*/
		function findBestTargetFromEvent(event, modifiers) {
			var _pathElements$;
			const pathElements = getComposedPathElements(event);
			const point = extractClientPoint(event);
			if (modifiers.ctrl || modifiers.meta) {
				const innermost = findInnermostVisible(pathElements);
				if (innermost) return innermost;
				return point ? findBestTarget(point.x, point.y, modifiers) : null;
			}
			const directHit = (_pathElements$ = pathElements[0]) !== null && _pathElements$ !== void 0 ? _pathElements$ : point ? getHitElementsAtPoint(point.x, point.y)[0] : null;
			if (!directHit) return point ? findBestTarget(point.x, point.y, modifiers) : null;
			const viewportArea = getViewportArea();
			const directCandidate = scoreElement(directHit, /* @__PURE__ */ new Map(), viewportArea);
			let base;
			if (directCandidate && !directCandidate.wrapperOnly) base = directHit;
			else {
				var _getParentCandidate2;
				base = (_getParentCandidate2 = getParentCandidate(directHit)) !== null && _getParentCandidate2 !== void 0 ? _getParentCandidate2 : directHit;
			}
			if (modifiers.alt) {
				var _getParentCandidate3;
				return (_getParentCandidate3 = getParentCandidate(base)) !== null && _getParentCandidate3 !== void 0 ? _getParentCandidate3 : base;
			}
			return base;
		}
		return {
			findBestTarget,
			findBestTargetFromEvent,
			getCandidatesAtPoint,
			getParentCandidate,
			dispose: () => disposer.dispose()
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/element-key.ts
	/** WeakMap cache for stable element keys */
	var elementKeyCache = /* @__PURE__ */ new WeakMap();
	/** WeakMap cache for shadow host stable identifiers */
	var shadowHostKeyCache = /* @__PURE__ */ new WeakMap();
	/** Auto-increment counter for elements without ID */
	var autoKeyCounter = 0;
	/** Auto-increment counter for shadow hosts without ID */
	var shadowHostCounter = 0;
	/** Cached frame context (computed once per execution context) */
	var cachedFrameContext;
	/** Priority order for fallback label attributes */
	var LABEL_ATTR_PRIORITY = [
		"data-testid",
		"data-test-id",
		"data-test",
		"data-qa",
		"data-cy",
		"name",
		"aria-label",
		"title",
		"alt"
	];
	/** Maximum length for attribute values in labels */
	var MAX_LABEL_ATTR_VALUE_LENGTH = 48;
	/** Maximum length for text content in labels */
	var MAX_TEXT_LABEL_LENGTH = 64;
	/**
	* Normalize element tag name to lowercase
	*/
	function normalizeTagName(element) {
		return ((element === null || element === void 0 ? void 0 : element.tagName) ? String(element.tagName) : "").toLowerCase().trim() || "unknown";
	}
	/**
	* Normalize attribute value to trimmed string
	*/
	function normalizeAttrValue(value) {
		return typeof value === "string" ? value.trim() : "";
	}
	/**
	* Normalize text by collapsing whitespace
	*/
	function normalizeText$2(value) {
		return String(value !== null && value !== void 0 ? value : "").replace(/\s+/g, " ").trim();
	}
	/**
	* Truncate string with ellipsis if exceeds max length
	*/
	function truncate$1(value, maxLength) {
		const str = String(value !== null && value !== void 0 ? value : "");
		if (str.length <= maxLength) return str;
		return str.slice(0, Math.max(0, maxLength - 1)).trimEnd() + "…";
	}
	/**
	* Get frame context prefix for iframe isolation.
	* Cached for performance.
	*/
	function getFrameContextPrefix() {
		if (cachedFrameContext !== void 0) return cachedFrameContext;
		let context = "";
		try {
			const frameEl = window.frameElement;
			if (frameEl instanceof HTMLIFrameElement) {
				const tag = normalizeTagName(frameEl);
				const id = normalizeAttrValue(frameEl.id || frameEl.getAttribute("id"));
				if (id) context = `${tag}#${id}`;
				else {
					const name = normalizeAttrValue(frameEl.name || frameEl.getAttribute("name"));
					if (name) context = `${tag}[name="${truncate$1(name, MAX_LABEL_ATTR_VALUE_LENGTH)}"]`;
					else {
						const src = normalizeAttrValue(frameEl.getAttribute("src") || frameEl.src);
						context = src ? `${tag}[src="${truncate$1(src, MAX_LABEL_ATTR_VALUE_LENGTH)}"]` : tag;
					}
				}
			}
		} catch (_unused) {
			context = "";
		}
		cachedFrameContext = context;
		return context;
	}
	/**
	* Generate a stable identifier for a shadow host element.
	* Uses WeakMap caching to ensure stability across class changes.
	*/
	function getStableShadowHostKey(host) {
		const cached = shadowHostKeyCache.get(host);
		if (cached) return cached;
		const tag = normalizeTagName(host);
		const id = normalizeAttrValue(host.id || host.getAttribute("id"));
		const key = id ? `${tag}#${id}` : `${tag}_h${++shadowHostCounter}`;
		shadowHostKeyCache.set(host, key);
		return key;
	}
	/**
	* Compute Shadow DOM context prefix by walking up the shadow host chain.
	* Uses stable host identifiers (not selectors) to avoid class sensitivity.
	*
	* Note: The provided shadowHostChain parameter is intentionally NOT used
	* for key generation because it may contain class-based selectors.
	* Instead, we derive stable host keys directly from the DOM.
	*/
	function computeShadowContextPrefix(element, _shadowHostChain) {
		const hosts = [];
		let current = element;
		while (true) {
			let root;
			try {
				var _current$getRootNode;
				root = (_current$getRootNode = current.getRootNode) === null || _current$getRootNode === void 0 ? void 0 : _current$getRootNode.call(current);
			} catch (_unused2) {
				root = null;
			}
			if (!(root instanceof ShadowRoot)) break;
			const host = root.host;
			if (!(host instanceof Element)) break;
			hosts.unshift(getStableShadowHostKey(host));
			current = host;
		}
		return hosts.length > 0 ? hosts.join(">") : "";
	}
	/**
	* Find the best attribute for labeling an element
	*/
	function readBestLabelAttribute(element) {
		for (const attr of LABEL_ATTR_PRIORITY) {
			const value = normalizeAttrValue(element.getAttribute(attr));
			if (value) return {
				attr,
				value
			};
		}
		return null;
	}
	/**
	* Generate a stable element key within the current page lifecycle.
	*
	* Key strategy:
	* - Prefer deterministic `tag#id` when id exists
	* - Otherwise assign a stable incremental key via WeakMap caching
	* - Prefix with Shadow DOM host chain and (reserved) iframe context
	*
	* @param element - The target DOM element
	* @param shadowHostChain - Optional shadow host selector chain from outer to inner
	* @returns A stable, unique key for the element
	*/
	function generateStableElementKey(element, shadowHostChain) {
		const cached = elementKeyCache.get(element);
		if (cached) return cached;
		const tag = normalizeTagName(element);
		const id = normalizeAttrValue(element.id || element.getAttribute("id"));
		const baseKey = id ? `${tag}#${id}` : `${tag}_${++autoKeyCounter}`;
		const parts = [];
		const frame = getFrameContextPrefix();
		if (frame) parts.push(`frame:${frame}`);
		const shadow = computeShadowContextPrefix(element, shadowHostChain);
		if (shadow) parts.push(`shadow:${shadow}`);
		parts.push(baseKey);
		const fullKey = parts.join("|");
		elementKeyCache.set(element, fullKey);
		return fullKey;
	}
	/**
	* Generate a human-friendly label for UI rendering (Chips/tooltips).
	*
	* This label is best-effort and may change if element text/attrs change.
	* It should NOT be used for element identification - use generateStableElementKey instead.
	*
	* @param element - The target DOM element
	* @returns A human-readable label for the element
	*/
	function generateElementLabel(element) {
		var _element$textContent;
		const tag = normalizeTagName(element);
		const id = normalizeAttrValue(element.id || element.getAttribute("id"));
		if (id) return `${tag}#${id}`;
		const bestAttr = readBestLabelAttribute(element);
		if (bestAttr) return `${tag}[${bestAttr.attr}="${truncate$1(bestAttr.value, MAX_LABEL_ATTR_VALUE_LENGTH)}"]`;
		const role = normalizeAttrValue(element.getAttribute("role"));
		if (role) return `${tag}[role="${truncate$1(role, MAX_LABEL_ATTR_VALUE_LENGTH)}"]`;
		if (element instanceof HTMLInputElement) {
			const type = normalizeAttrValue(element.getAttribute("type") || element.type);
			if (type && type !== "text") return `${tag}[type="${truncate$1(type, MAX_LABEL_ATTR_VALUE_LENGTH)}"]`;
			const placeholder = normalizeAttrValue(element.getAttribute("placeholder") || element.placeholder);
			if (placeholder) return `${tag}[placeholder="${truncate$1(placeholder, MAX_LABEL_ATTR_VALUE_LENGTH)}"]`;
		}
		if (element instanceof HTMLIFrameElement) {
			const src = normalizeAttrValue(element.getAttribute("src") || element.src);
			if (src) return `${tag}[src="${truncate$1(src, MAX_LABEL_ATTR_VALUE_LENGTH)}"]`;
		}
		const text = normalizeText$2((_element$textContent = element.textContent) !== null && _element$textContent !== void 0 ? _element$textContent : "");
		if (text) return `${tag}("${truncate$1(text, MAX_TEXT_LABEL_LENGTH)}")`;
		return tag;
	}
	/**
	* Generate a full label including shadow context for tooltips.
	*
	* @param element - The target DOM element
	* @param shadowHostChain - Optional shadow host selector chain
	* @returns A full label with context for detailed display
	*/
	function generateFullElementLabel(element, shadowHostChain) {
		const baseLabel = generateElementLabel(element);
		const shadow = computeShadowContextPrefix(element, shadowHostChain);
		if (shadow) return `${shadow} >> ${baseLabel}`;
		return baseLabel;
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/transaction-manager.ts
	var DEFAULT_MAX_HISTORY = 100;
	var DEFAULT_MERGE_WINDOW_MS = 800;
	var KEYBIND_OPTIONS = {
		capture: true,
		passive: false
	};
	/**
	* Normalize CSS property name to kebab-case.
	* Preserves custom properties (--var-name).
	*/
	function normalizePropertyName(property) {
		const p = property.trim();
		if (!p) return "";
		if (p.startsWith("--")) return p;
		if (p.includes("-")) return p.toLowerCase();
		return p.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`).toLowerCase();
	}
	/**
	* Safely get CSSStyleDeclaration from element
	*/
	function getInlineStyle(element) {
		const style = element.style;
		if (!style) return null;
		if (typeof style.getPropertyValue !== "function") return null;
		if (typeof style.setProperty !== "function") return null;
		if (typeof style.removeProperty !== "function") return null;
		return style;
	}
	/**
	* Read inline style property value
	*/
	function readStyleValue(style, property) {
		const prop = normalizePropertyName(property);
		if (!prop) return "";
		return style.getPropertyValue(prop).trim();
	}
	/**
	* Write inline style property value
	*/
	function writeStyleValue(style, property, value) {
		const prop = normalizePropertyName(property);
		if (!prop) return;
		const v = value.trim();
		if (!v) style.removeProperty(prop);
		else style.setProperty(prop, v);
	}
	/**
	* Apply a styles snapshot to an element
	*/
	function applyStylesSnapshot(element, styles) {
		if (!styles) return;
		const inlineStyle = getInlineStyle(element);
		if (!inlineStyle) return;
		for (const [property, value] of Object.entries(styles)) writeStyleValue(inlineStyle, property, value);
	}
	/**
	* Normalize class list: deduplicate, trim, remove empty tokens
	*/
	function normalizeClassList$1(input) {
		const out = [];
		const seen = /* @__PURE__ */ new Set();
		for (const raw of input !== null && input !== void 0 ? input : []) {
			const token = String(raw !== null && raw !== void 0 ? raw : "").trim();
			if (!token) continue;
			if (seen.has(token)) continue;
			seen.add(token);
			out.push(token);
		}
		return out;
	}
	/**
	* Check if two string arrays are equal (order-sensitive)
	*/
	function isSameStringList(a, b) {
		if (a.length !== b.length) return false;
		for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
		return true;
	}
	/**
	* Read class list from element (compatible with SVG elements)
	*/
	function readClassList(element) {
		try {
			const list = element.classList;
			if (list && typeof list[Symbol.iterator] === "function") return Array.from(list).filter(Boolean);
		} catch (_unused) {}
		try {
			var _element$getAttribute;
			return ((_element$getAttribute = element.getAttribute("class")) !== null && _element$getAttribute !== void 0 ? _element$getAttribute : "").split(/\s+/).map((t) => t.trim()).filter(Boolean);
		} catch (_unused2) {
			return [];
		}
	}
	/**
	* Apply class list to element (compatible with SVG elements)
	* Uses setAttribute for cross-browser SVG compatibility
	*/
	function applyClassListToElement(element, classes) {
		const value = normalizeClassList$1(classes).join(" ").trim();
		try {
			if (value) element.setAttribute("class", value);
			else element.removeAttribute("class");
		} catch (_unused3) {}
	}
	/**
	* Read element's inline styles as a plain object.
	* Only includes explicitly set inline properties (not computed styles).
	*/
	function readInlineStyleMap(element) {
		const style = getInlineStyle(element);
		if (!style) return void 0;
		const result = {};
		for (let i = 0; i < style.length; i++) {
			const prop = style.item(i);
			if (!prop) continue;
			const value = style.getPropertyValue(prop).trim();
			if (value) result[prop] = value;
		}
		return Object.keys(result).length > 0 ? result : void 0;
	}
	/**
	* Parse HTML string into a single root element.
	* Returns null if parsing fails or yields multiple root elements.
	*/
	function parseSingleRootElement(html) {
		const trimmed = String(html !== null && html !== void 0 ? html : "").trim();
		if (!trimmed) return null;
		try {
			const template = document.createElement("template");
			template.innerHTML = trimmed;
			const firstChild = template.content.firstElementChild;
			if (!firstChild || template.content.childElementCount !== 1) return null;
			return firstChild;
		} catch (_unused4) {
			return null;
		}
	}
	/**
	* Remove id attributes from an element and all its descendants.
	* Used by duplicate to avoid creating duplicate IDs on the page.
	*/
	function stripIdsFromSubtree(root) {
		try {
			root.removeAttribute("id");
			const descendantsWithId = root.querySelectorAll("[id]");
			for (const el of Array.from(descendantsWithId)) el.removeAttribute("id");
		} catch (_unused5) {}
	}
	/**
	* Insert an element into a parent at a specific position.
	* Used for deterministic undo/redo of delete/duplicate operations.
	*/
	function insertElementAtPosition(parent, element, position) {
		if (!parent.isConnected) return false;
		let reference = null;
		if (position.anchorLocator) {
			const anchor = locateElement(position.anchorLocator);
			if (anchor && anchor.parentElement === parent) reference = position.anchorPosition === "before" ? anchor : anchor.nextSibling;
		}
		if (!reference) {
			var _children$index;
			const children = Array.from(parent.children);
			reference = (_children$index = children[Math.max(0, Math.min(position.insertIndex, children.length))]) !== null && _children$index !== void 0 ? _children$index : null;
		}
		try {
			parent.insertBefore(element, reference);
			return true;
		} catch (_unused6) {
			return false;
		}
	}
	/**
	* Wrap an element with a new container at the same DOM position.
	* Returns the wrapper element on success, null on failure.
	*/
	function wrapElementWithContainer(target, wrapperTag, wrapperStyles) {
		const parent = target.parentElement;
		if (!parent) return null;
		const tag = String(wrapperTag || "div").toLowerCase();
		const wrapper = document.createElement(tag);
		if (wrapperStyles) applyStylesSnapshot(wrapper, wrapperStyles);
		try {
			parent.insertBefore(wrapper, target);
			wrapper.appendChild(target);
			return wrapper;
		} catch (_unused7) {
			return null;
		}
	}
	/**
	* Unwrap a container that has exactly one element child.
	* Moves the child to the container's position and removes the container.
	* Returns the unwrapped child on success, null on failure.
	*/
	function unwrapSingleChildContainer(wrapper) {
		const parent = wrapper.parentElement;
		if (!parent) return null;
		if (wrapper.childElementCount !== 1) return null;
		const child = wrapper.firstElementChild;
		if (!child) return null;
		try {
			parent.insertBefore(child, wrapper);
			wrapper.remove();
			return child;
		} catch (_unused8) {
			return null;
		}
	}
	/**
	* Build insertion position data for inserting after a target element.
	* Used by duplicate to record where the clone was inserted.
	*/
	function buildInsertAfterPosition(target) {
		const parent = target.parentElement;
		if (!parent) return null;
		const index = Array.from(parent.children).indexOf(target);
		if (index < 0) return null;
		return {
			parentLocator: createElementLocator(parent),
			insertIndex: index + 1,
			anchorLocator: createElementLocator(target),
			anchorPosition: "after"
		};
	}
	var transactionSeq = 0;
	/**
	* Generate unique transaction ID
	*/
	function generateTransactionId(timestamp) {
		transactionSeq += 1;
		return `tx_${timestamp.toString(36)}_${transactionSeq.toString(36)}`;
	}
	/**
	* Create a style transaction record from style maps.
	* This is the core factory used by both single-style and multi-style APIs.
	*
	* @param id - Unique transaction identifier
	* @param locator - Target element locator
	* @param beforeStyles - Style values before the change
	* @param afterStyles - Style values after the change
	* @param timestamp - Transaction timestamp
	* @param elementKey - Optional stable element key for transaction grouping
	*/
	function createStyleTransactionFromStyles(id, locator, beforeStyles, afterStyles, timestamp, elementKey) {
		return {
			id,
			type: "style",
			targetLocator: locator,
			elementKey,
			before: {
				locator,
				styles: beforeStyles
			},
			after: {
				locator,
				styles: afterStyles
			},
			timestamp,
			merged: false
		};
	}
	/**
	* Create a style transaction record for a single property.
	* Convenience wrapper around createStyleTransactionFromStyles.
	*
	* @param id - Unique transaction identifier
	* @param locator - Target element locator
	* @param property - CSS property name
	* @param beforeValue - Property value before the change
	* @param afterValue - Property value after the change
	* @param timestamp - Transaction timestamp
	* @param elementKey - Optional stable element key for transaction grouping
	*/
	function createStyleTransaction(id, locator, property, beforeValue, afterValue, timestamp, elementKey) {
		const prop = normalizePropertyName(property);
		return createStyleTransactionFromStyles(id, locator, { [prop]: beforeValue }, { [prop]: afterValue }, timestamp, elementKey);
	}
	/**
	* Create a text transaction record (Phase 2.7)
	*
	* @param id - Unique transaction identifier
	* @param locator - Target element locator
	* @param beforeText - Text content before the change
	* @param afterText - Text content after the change
	* @param timestamp - Transaction timestamp
	* @param elementKey - Optional stable element key for transaction grouping
	*/
	function createTextTransaction(id, locator, beforeText, afterText, timestamp, elementKey) {
		return {
			id,
			type: "text",
			targetLocator: locator,
			elementKey,
			before: {
				locator,
				text: beforeText
			},
			after: {
				locator,
				text: afterText
			},
			timestamp,
			merged: false
		};
	}
	/**
	* Create a class transaction record (Phase 4.7)
	*
	* Uses separate before/after locators to improve undo/redo recovery
	* when CSS selectors include class-based matching.
	*
	* @param id - Unique transaction identifier
	* @param beforeLocator - Element locator before class change
	* @param afterLocator - Element locator after class change
	* @param beforeClasses - Class list before the change
	* @param afterClasses - Class list after the change
	* @param timestamp - Transaction timestamp
	* @param elementKey - Optional stable element key for transaction grouping
	*/
	function createClassTransaction(id, beforeLocator, afterLocator, beforeClasses, afterClasses, timestamp, elementKey) {
		return {
			id,
			type: "class",
			targetLocator: afterLocator,
			elementKey,
			before: {
				locator: beforeLocator,
				classes: beforeClasses
			},
			after: {
				locator: afterLocator,
				classes: afterClasses
			},
			timestamp,
			merged: false
		};
	}
	/**
	* Create a move transaction record (Phase 2.4-2.6)
	*
	* @param id - Unique transaction identifier
	* @param beforeLocator - Element locator before move
	* @param afterLocator - Element locator after move
	* @param moveData - Move operation data (from/to positions)
	* @param timestamp - Transaction timestamp
	* @param elementKey - Optional stable element key for transaction grouping
	*/
	function createMoveTransaction(id, beforeLocator, afterLocator, moveData, timestamp, elementKey) {
		return {
			id,
			type: "move",
			targetLocator: afterLocator,
			elementKey,
			before: { locator: beforeLocator },
			after: { locator: afterLocator },
			moveData,
			timestamp,
			merged: false
		};
	}
	/**
	* Create a structure transaction record (Phase 5.5)
	*
	* Used for wrap/unwrap/delete/duplicate operations.
	* delete/duplicate store position + html for deterministic undo/redo.
	*
	* @param id - Unique transaction identifier
	* @param targetLocator - Primary target element locator
	* @param beforeLocator - Element locator before structure change
	* @param afterLocator - Element locator after structure change
	* @param structureData - Structure operation data
	* @param timestamp - Transaction timestamp
	* @param elementKey - Optional stable element key for transaction grouping
	*/
	function createStructureTransaction(id, targetLocator, beforeLocator, afterLocator, structureData, timestamp, elementKey) {
		return {
			id,
			type: "structure",
			targetLocator,
			elementKey,
			before: { locator: beforeLocator },
			after: { locator: afterLocator },
			structureData,
			timestamp,
			merged: false
		};
	}
	/**
	* Check if element is a disallowed target for structure operations (HTML/BODY/HEAD)
	* These elements should not be wrapped, deleted, duplicated, or unwrapped.
	*/
	function isDisallowedStructureTarget(element) {
		var _element$tagName;
		const tag = (_element$tagName = element.tagName) === null || _element$tagName === void 0 ? void 0 : _element$tagName.toUpperCase();
		return tag === "HTML" || tag === "BODY" || tag === "HEAD";
	}
	/**
	* Check if element is a disallowed parent container for structure operations (HTML/HEAD only)
	* BODY is allowed as a parent container (unlike as a target).
	*/
	function isDisallowedStructureContainer(element) {
		var _element$tagName2;
		const tag = (_element$tagName2 = element.tagName) === null || _element$tagName2 === void 0 ? void 0 : _element$tagName2.toUpperCase();
		return tag === "HTML" || tag === "HEAD";
	}
	/**
	* Check if element is a disallowed move target (HTML/BODY/HEAD)
	*/
	function isDisallowedMoveElement(element) {
		var _element$tagName3;
		const tag = (_element$tagName3 = element.tagName) === null || _element$tagName3 === void 0 ? void 0 : _element$tagName3.toUpperCase();
		return tag === "HTML" || tag === "BODY" || tag === "HEAD";
	}
	/**
	* Build MoveOperationData from element's current DOM position
	*/
	function buildMoveOperationData(element) {
		const parent = element.parentElement;
		if (!parent) return null;
		const insertIndex = Array.from(parent.children).indexOf(element);
		if (insertIndex < 0) return null;
		const parentLocator = createElementLocator(parent);
		const next = element.nextElementSibling;
		if (next) return {
			parentLocator,
			insertIndex,
			anchorLocator: createElementLocator(next),
			anchorPosition: "before"
		};
		const prev = element.previousElementSibling;
		if (prev) return {
			parentLocator,
			insertIndex,
			anchorLocator: createElementLocator(prev),
			anchorPosition: "after"
		};
		return {
			parentLocator,
			insertIndex,
			anchorPosition: "before"
		};
	}
	/**
	* Apply a move operation (for undo/redo)
	*/
	function applyMoveOperation(target, op) {
		var _target$getRootNode, _parent$getRootNode;
		if (!target.isConnected) return false;
		if (isDisallowedMoveElement(target)) return false;
		const parent = locateElement(op.parentLocator);
		if (!parent) return false;
		if (!parent.isConnected) return false;
		const targetRoot = (_target$getRootNode = target.getRootNode) === null || _target$getRootNode === void 0 ? void 0 : _target$getRootNode.call(target);
		const parentRoot = (_parent$getRootNode = parent.getRootNode) === null || _parent$getRootNode === void 0 ? void 0 : _parent$getRootNode.call(parent);
		if (targetRoot && parentRoot && targetRoot !== parentRoot) return false;
		if (target === parent || target.contains(parent)) return false;
		let reference = null;
		if (op.anchorLocator) {
			const anchor = locateElement(op.anchorLocator);
			if (anchor && anchor !== target && anchor.parentElement === parent) {
				reference = op.anchorPosition === "before" ? anchor : anchor.nextSibling;
				if (reference === target) reference = target.nextSibling;
			}
		}
		if (!reference) {
			var _children$index2;
			const children = Array.from(parent.children);
			const existingIndex = children.indexOf(target);
			if (existingIndex !== -1) children.splice(existingIndex, 1);
			reference = (_children$index2 = children[Math.max(0, Math.min(op.insertIndex, children.length))]) !== null && _children$index2 !== void 0 ? _children$index2 : null;
		}
		try {
			parent.insertBefore(target, reference);
			return true;
		} catch (_unused9) {
			return false;
		}
	}
	/**
	* Get the single style property from a transaction (if applicable)
	*/
	function getSingleStyleProperty(tx) {
		const keys = /* @__PURE__ */ new Set();
		if (tx.before.styles) for (const k of Object.keys(tx.before.styles)) keys.add(k);
		if (tx.after.styles) for (const k of Object.keys(tx.after.styles)) keys.add(k);
		return keys.size === 1 ? Array.from(keys)[0] : null;
	}
	/**
	* Check if two transactions can be merged
	*/
	function canMerge(prev, next, mergeWindowMs) {
		if (prev.type !== "style" || next.type !== "style") return false;
		if (Math.abs(next.timestamp - prev.timestamp) > mergeWindowMs) return false;
		if (locatorKey(prev.targetLocator) !== locatorKey(next.targetLocator)) return false;
		const prevProp = getSingleStyleProperty(prev);
		const nextProp = getSingleStyleProperty(next);
		if (!prevProp || !nextProp || prevProp !== nextProp) return false;
		return true;
	}
	/**
	* Merge next transaction into prev (mutates prev)
	*/
	function mergeInto(prev, next) {
		var _next$after$styles;
		const prop = getSingleStyleProperty(prev);
		if (!prop) return false;
		const nextValue = (_next$after$styles = next.after.styles) === null || _next$after$styles === void 0 ? void 0 : _next$after$styles[prop];
		if (nextValue === void 0) return false;
		if (!prev.after.styles) prev.after.styles = {};
		prev.after.styles[prop] = nextValue;
		prev.timestamp = next.timestamp;
		prev.merged = true;
		return true;
	}
	/**
	* Apply a structure transaction (undo or redo) - Phase 5.5
	*
	* Structure operations may create/remove nodes, so delete/duplicate
	* store position + html to make redo/undo deterministic.
	*/
	function applyStructureTransaction(tx, direction) {
		const data = tx.structureData;
		if (!data) return false;
		const isRedo = direction === "redo";
		switch (data.action) {
			case "wrap": {
				var _locateElement2;
				if (isRedo) {
					var _ref, _locateElement, _data$wrapperTag;
					const target = (_ref = (_locateElement = locateElement(tx.before.locator)) !== null && _locateElement !== void 0 ? _locateElement : locateElement(tx.targetLocator)) !== null && _ref !== void 0 ? _ref : locateElement(tx.after.locator);
					if (!target || !target.isConnected) return false;
					if (isDisallowedStructureTarget(target)) return false;
					const parent = target.parentElement;
					if (!parent || !parent.isConnected || isDisallowedStructureContainer(parent)) return false;
					const wrapper = wrapElementWithContainer(target, (_data$wrapperTag = data.wrapperTag) !== null && _data$wrapperTag !== void 0 ? _data$wrapperTag : "div", data.wrapperStyles);
					if (!wrapper || !wrapper.isConnected) return false;
					const wrapperLocator = createElementLocator(wrapper);
					tx.after.locator = wrapperLocator;
					tx.targetLocator = wrapperLocator;
					return true;
				}
				const wrapper = (_locateElement2 = locateElement(tx.after.locator)) !== null && _locateElement2 !== void 0 ? _locateElement2 : locateElement(tx.targetLocator);
				if (!wrapper || !wrapper.isConnected) return false;
				if (isDisallowedStructureTarget(wrapper)) return false;
				const child = unwrapSingleChildContainer(wrapper);
				if (!child || !child.isConnected) return false;
				tx.before.locator = createElementLocator(child);
				return true;
			}
			case "unwrap": {
				var _locateElement6, _data$wrapperTag2;
				if (isRedo) {
					var _ref2, _locateElement3, _locateElement4, _locateElement5;
					const wrapper = (_ref2 = (_locateElement3 = locateElement(tx.before.locator)) !== null && _locateElement3 !== void 0 ? _locateElement3 : (_locateElement4 = locateElement(tx.after.locator)) === null || _locateElement4 === void 0 ? void 0 : _locateElement4.parentElement) !== null && _ref2 !== void 0 ? _ref2 : (_locateElement5 = locateElement(tx.targetLocator)) === null || _locateElement5 === void 0 ? void 0 : _locateElement5.parentElement;
					if (!wrapper || !wrapper.isConnected) return false;
					if (isDisallowedStructureTarget(wrapper)) return false;
					const child = unwrapSingleChildContainer(wrapper);
					if (!child || !child.isConnected) return false;
					const childLocator = createElementLocator(child);
					tx.after.locator = childLocator;
					tx.targetLocator = childLocator;
					return true;
				}
				const child = (_locateElement6 = locateElement(tx.after.locator)) !== null && _locateElement6 !== void 0 ? _locateElement6 : locateElement(tx.targetLocator);
				if (!child || !child.isConnected) return false;
				if (isDisallowedStructureTarget(child)) return false;
				const parent = child.parentElement;
				if (!parent || !parent.isConnected || isDisallowedStructureContainer(parent)) return false;
				const wrapper = wrapElementWithContainer(child, (_data$wrapperTag2 = data.wrapperTag) !== null && _data$wrapperTag2 !== void 0 ? _data$wrapperTag2 : "div", data.wrapperStyles);
				if (!wrapper || !wrapper.isConnected) return false;
				tx.before.locator = createElementLocator(wrapper);
				return true;
			}
			case "delete": {
				if (isRedo) {
					var _locateElement7;
					const target = (_locateElement7 = locateElement(tx.before.locator)) !== null && _locateElement7 !== void 0 ? _locateElement7 : locateElement(tx.targetLocator);
					if (!target || !target.isConnected) return false;
					if (isDisallowedStructureTarget(target)) return false;
					target.remove();
					return true;
				}
				if (!data.position || !data.html) return false;
				const parent = locateElement(data.position.parentLocator);
				if (!parent || !parent.isConnected || isDisallowedStructureContainer(parent)) return false;
				const element = parseSingleRootElement(data.html);
				if (!element) return false;
				if (!insertElementAtPosition(parent, element, data.position)) return false;
				const locator = createElementLocator(element);
				tx.before.locator = locator;
				tx.targetLocator = locator;
				return true;
			}
			case "duplicate": {
				var _locateElement8;
				if (isRedo) {
					if (!data.position || !data.html) return false;
					const parent = locateElement(data.position.parentLocator);
					if (!parent || !parent.isConnected || isDisallowedStructureContainer(parent)) return false;
					const element = parseSingleRootElement(data.html);
					if (!element) return false;
					if (!insertElementAtPosition(parent, element, data.position)) return false;
					const locator = createElementLocator(element);
					tx.after.locator = locator;
					tx.targetLocator = locator;
					return true;
				}
				const clone = (_locateElement8 = locateElement(tx.after.locator)) !== null && _locateElement8 !== void 0 ? _locateElement8 : locateElement(tx.targetLocator);
				if (!clone || !clone.isConnected) return false;
				if (isDisallowedStructureTarget(clone)) return false;
				clone.remove();
				return true;
			}
			default: return false;
		}
	}
	/**
	* Apply a transaction (undo or redo)
	* Returns true on success, false on failure
	*/
	function applyTransaction(tx, direction) {
		if (tx.type === "move") {
			var _ref3, _locateElement9;
			const moveData = tx.moveData;
			if (!moveData) return false;
			const primaryLocator = direction === "undo" ? tx.after.locator : tx.before.locator;
			const fallbackLocator = direction === "undo" ? tx.before.locator : tx.after.locator;
			const target = (_ref3 = (_locateElement9 = locateElement(primaryLocator)) !== null && _locateElement9 !== void 0 ? _locateElement9 : locateElement(fallbackLocator)) !== null && _ref3 !== void 0 ? _ref3 : locateElement(tx.targetLocator);
			if (!target) return false;
			return applyMoveOperation(target, direction === "undo" ? moveData.from : moveData.to);
		}
		if (tx.type === "class") {
			var _ref4, _locateElement10;
			const primaryLocator = direction === "undo" ? tx.after.locator : tx.before.locator;
			const fallbackLocator = direction === "undo" ? tx.before.locator : tx.after.locator;
			const target = (_ref4 = (_locateElement10 = locateElement(primaryLocator)) !== null && _locateElement10 !== void 0 ? _locateElement10 : locateElement(fallbackLocator)) !== null && _ref4 !== void 0 ? _ref4 : locateElement(tx.targetLocator);
			if (!target) return false;
			const snapshot = direction === "undo" ? tx.before : tx.after;
			applyClassListToElement(target, Array.isArray(snapshot.classes) ? snapshot.classes : []);
			return true;
		}
		if (tx.type === "structure") return applyStructureTransaction(tx, direction);
		if (tx.type !== "style" && tx.type !== "text") return true;
		const target = locateElement(tx.targetLocator);
		if (!target) return false;
		const snapshot = direction === "undo" ? tx.before : tx.after;
		if (tx.type === "style") {
			applyStylesSnapshot(target, snapshot.styles);
			return true;
		}
		if (tx.type === "text") {
			var _snapshot$text;
			target.textContent = (_snapshot$text = snapshot.text) !== null && _snapshot$text !== void 0 ? _snapshot$text : "";
			return true;
		}
		return true;
	}
	/**
	* Create a Transaction Manager instance
	*/
	function createTransactionManager(options = {}) {
		var _options$maxHistory, _options$mergeWindowM, _options$now;
		const disposer = new Disposer();
		const maxHistory = Math.max(1, (_options$maxHistory = options.maxHistory) !== null && _options$maxHistory !== void 0 ? _options$maxHistory : DEFAULT_MAX_HISTORY);
		const mergeWindowMs = Math.max(0, (_options$mergeWindowM = options.mergeWindowMs) !== null && _options$mergeWindowM !== void 0 ? _options$mergeWindowM : DEFAULT_MERGE_WINDOW_MS);
		const now = (_options$now = options.now) !== null && _options$now !== void 0 ? _options$now : (() => Date.now());
		const undoStack = [];
		const redoStack = [];
		function emit(action, transaction) {
			var _options$onChange;
			(_options$onChange = options.onChange) === null || _options$onChange === void 0 || _options$onChange.call(options, {
				action,
				transaction,
				undoCount: undoStack.length,
				redoCount: redoStack.length
			});
		}
		function enforceMaxHistory() {
			if (undoStack.length > maxHistory) undoStack.splice(0, undoStack.length - maxHistory);
		}
		function pushTransaction(tx, allowMerge) {
			const hadRedo = redoStack.length > 0;
			if (hadRedo) redoStack.length = 0;
			if (!hadRedo && allowMerge && undoStack.length > 0) {
				const last = undoStack[undoStack.length - 1];
				if (canMerge(last, tx, mergeWindowMs) && mergeInto(last, tx)) {
					emit("merge", last);
					return;
				}
			}
			undoStack.push(tx);
			enforceMaxHistory();
			emit("push", tx);
		}
		function recordStyle(locator, property, beforeValue, afterValue, recordOptions) {
			if (disposer.isDisposed) return null;
			const prop = normalizePropertyName(property);
			if (!prop) return null;
			const before = beforeValue.trim();
			const after = afterValue.trim();
			if (before === after) return null;
			const tx = createStyleTransaction(generateTransactionId(now()), locator, prop, before, after, now());
			pushTransaction(tx, (recordOptions === null || recordOptions === void 0 ? void 0 : recordOptions.merge) !== false);
			return tx;
		}
		/**
		* Record a text transaction (Phase 2.7)
		*/
		function recordText(target, beforeText, afterText) {
			if (disposer.isDisposed) return null;
			const before = String(beforeText !== null && beforeText !== void 0 ? beforeText : "");
			const after = String(afterText !== null && afterText !== void 0 ? afterText : "");
			if (before === after) return null;
			const locator = createElementLocator(target);
			const timestamp = now();
			const tx = createTextTransaction(generateTransactionId(timestamp), locator, before, after, timestamp, generateStableElementKey(target, locator.shadowHostChain));
			pushTransaction(tx, false);
			return tx;
		}
		/**
		* Record a class list change and create transaction (Phase 4.7)
		*
		* Notes:
		* - Uses setAttribute/removeAttribute for SVG compatibility
		* - Captures before/after locators to improve redo/undo recovery
		*   when CSS selectors include class-based matching
		* - No merge support (class edits should be discrete undo steps)
		*/
		function recordClass(target, beforeClasses, afterClasses) {
			if (disposer.isDisposed) return null;
			if (!target.isConnected) return null;
			const domClasses = normalizeClassList$1(readClassList(target));
			const beforeInput = normalizeClassList$1(beforeClasses);
			const after = normalizeClassList$1(afterClasses);
			const before = isSameStringList(beforeInput, domClasses) ? beforeInput : domClasses;
			if (isSameStringList(before, after)) return null;
			const timestamp = now();
			const id = generateTransactionId(timestamp);
			const beforeLocator = createElementLocator(target);
			const elementKey = generateStableElementKey(target, beforeLocator.shadowHostChain);
			applyClassListToElement(target, after);
			const tx = createClassTransaction(id, beforeLocator, createElementLocator(target), before, after, timestamp, elementKey);
			pushTransaction(tx, false);
			return tx;
		}
		/**
		* Apply a structure operation and record a transaction (Phase 5.5)
		*
		* Performs the DOM mutation immediately and records the transaction.
		* delete/duplicate store position + html for deterministic undo/redo.
		* unwrap is limited to single-child containers to keep the schema minimal.
		*/
		function applyStructure(target, input) {
			if (disposer.isDisposed) return null;
			if (!target.isConnected) return null;
			if (isDisallowedStructureTarget(target)) return null;
			const action = input === null || input === void 0 ? void 0 : input.action;
			const timestamp = now();
			const id = generateTransactionId(timestamp);
			if (action === "wrap") {
				var _input$wrapperTag, _input$wrapperTag2;
				const parent = target.parentElement;
				if (!parent || !parent.isConnected || isDisallowedStructureContainer(parent)) return null;
				const beforeLocator = createElementLocator(target);
				const wrapper = wrapElementWithContainer(target, (_input$wrapperTag = input.wrapperTag) !== null && _input$wrapperTag !== void 0 ? _input$wrapperTag : "div", input.wrapperStyles);
				if (!wrapper || !wrapper.isConnected) return null;
				const wrapperLocator = createElementLocator(wrapper);
				const elementKey = generateStableElementKey(wrapper, wrapperLocator.shadowHostChain);
				const tx = createStructureTransaction(id, wrapperLocator, beforeLocator, wrapperLocator, {
					action: "wrap",
					wrapperTag: (_input$wrapperTag2 = input.wrapperTag) !== null && _input$wrapperTag2 !== void 0 ? _input$wrapperTag2 : "div",
					wrapperStyles: input.wrapperStyles
				}, timestamp, elementKey);
				pushTransaction(tx, false);
				return tx;
			}
			if (action === "unwrap") {
				const wrapper = target;
				const parent = wrapper.parentElement;
				if (!parent || !parent.isConnected || isDisallowedStructureContainer(parent)) return null;
				if (wrapper.childElementCount !== 1) return null;
				const beforeLocator = createElementLocator(wrapper);
				const wrapperTag = wrapper.tagName.toLowerCase();
				const wrapperStyles = readInlineStyleMap(wrapper);
				const child = unwrapSingleChildContainer(wrapper);
				if (!child || !child.isConnected) return null;
				const childLocator = createElementLocator(child);
				const elementKey = generateStableElementKey(child, childLocator.shadowHostChain);
				const tx = createStructureTransaction(id, childLocator, beforeLocator, childLocator, {
					action: "unwrap",
					wrapperTag,
					wrapperStyles
				}, timestamp, elementKey);
				pushTransaction(tx, false);
				return tx;
			}
			if (action === "delete") {
				var _target$outerHTML;
				const position = buildMoveOperationData(target);
				if (!position) return null;
				const html = String((_target$outerHTML = target.outerHTML) !== null && _target$outerHTML !== void 0 ? _target$outerHTML : "").trim();
				if (!html) return null;
				const beforeLocator = createElementLocator(target);
				const elementKey = generateStableElementKey(target, beforeLocator.shadowHostChain);
				const afterLocator = position.parentLocator;
				try {
					target.remove();
				} catch (_unused10) {
					return null;
				}
				const tx = createStructureTransaction(id, beforeLocator, beforeLocator, afterLocator, {
					action: "delete",
					position,
					html
				}, timestamp, elementKey);
				pushTransaction(tx, false);
				return tx;
			}
			if (action === "duplicate") {
				var _clone$outerHTML;
				const parent = target.parentElement;
				if (!parent || !parent.isConnected || isDisallowedStructureContainer(parent)) return null;
				const position = buildInsertAfterPosition(target);
				if (!position) return null;
				const beforeLocator = createElementLocator(target);
				const clone = target.cloneNode(true);
				stripIdsFromSubtree(clone);
				try {
					parent.insertBefore(clone, target.nextSibling);
				} catch (_unused11) {
					return null;
				}
				const html = String((_clone$outerHTML = clone.outerHTML) !== null && _clone$outerHTML !== void 0 ? _clone$outerHTML : "").trim();
				if (!html) return null;
				const cloneLocator = createElementLocator(clone);
				const elementKey = generateStableElementKey(clone, cloneLocator.shadowHostChain);
				const tx = createStructureTransaction(id, cloneLocator, beforeLocator, cloneLocator, {
					action: "duplicate",
					position,
					html
				}, timestamp, elementKey);
				pushTransaction(tx, false);
				return tx;
			}
			return null;
		}
		/**
		* Begin a move transaction for drag-reorder (Phase 2.4-2.6)
		*
		* Records the element's location at drag start. Call commit() after DOM move
		* to record the final location and create the transaction.
		*/
		function beginMove(target) {
			if (disposer.isDisposed) return null;
			if (!target.isConnected) return null;
			if (isDisallowedMoveElement(target)) return null;
			const from = buildMoveOperationData(target);
			if (!from) return null;
			const id = generateTransactionId(now());
			const beforeLocator = createElementLocator(target);
			let completed = false;
			function commit(targetAfterMove) {
				if (completed || disposer.isDisposed) return null;
				completed = true;
				if (!targetAfterMove.isConnected) return null;
				if (isDisallowedMoveElement(targetAfterMove)) return null;
				const to = buildMoveOperationData(targetAfterMove);
				if (!to) return null;
				const sameParent = locatorKey(from.parentLocator) === locatorKey(to.parentLocator);
				const sameIndex = from.insertIndex === to.insertIndex;
				const sameAnchorPos = from.anchorPosition === to.anchorPosition;
				const sameAnchor = !from.anchorLocator && !to.anchorLocator || from.anchorLocator && to.anchorLocator && locatorKey(from.anchorLocator) === locatorKey(to.anchorLocator);
				if (sameParent && sameIndex && sameAnchor && sameAnchorPos) return null;
				const afterLocator = createElementLocator(targetAfterMove);
				const elementKey = generateStableElementKey(targetAfterMove, afterLocator.shadowHostChain);
				const tx = createMoveTransaction(id, beforeLocator, afterLocator, {
					from,
					to
				}, now(), elementKey);
				pushTransaction(tx, false);
				return tx;
			}
			function cancel() {
				if (completed || disposer.isDisposed) return;
				completed = true;
			}
			return {
				id,
				beforeLocator,
				from,
				commit,
				cancel
			};
		}
		function beginStyle(target, property) {
			if (disposer.isDisposed) return null;
			const inlineStyleOrNull = getInlineStyle(target);
			if (!inlineStyleOrNull) return null;
			const inlineStyle = inlineStyleOrNull;
			const prop = normalizePropertyName(property);
			if (!prop) return null;
			const locator = createElementLocator(target);
			const beforeValue = readStyleValue(inlineStyle, prop);
			const id = generateTransactionId(now());
			const elementKey = generateStableElementKey(target, locator.shadowHostChain);
			let completed = false;
			function set(value) {
				if (completed || disposer.isDisposed) return;
				writeStyleValue(inlineStyle, prop, value);
			}
			function commit(commitOptions) {
				if (completed || disposer.isDisposed) return null;
				completed = true;
				const afterValue = readStyleValue(inlineStyle, prop);
				if (afterValue === beforeValue) return null;
				const tx = createStyleTransaction(id, locator, prop, beforeValue, afterValue, now(), elementKey);
				pushTransaction(tx, (commitOptions === null || commitOptions === void 0 ? void 0 : commitOptions.merge) !== false);
				return tx;
			}
			function rollback() {
				if (completed || disposer.isDisposed) return;
				completed = true;
				writeStyleValue(inlineStyle, prop, beforeValue);
				emit("rollback", null);
			}
			return {
				id,
				property: prop,
				targetLocator: locator,
				set,
				commit,
				rollback
			};
		}
		/**
		* Begin an interactive multi-style edit (Phase 4.9)
		*
		* For operations that modify multiple CSS properties atomically,
		* such as resize handles (width + height) or position handles (top + left).
		*
		* Key differences from beginStyle:
		* - Tracks multiple properties at once
		* - Only records properties that actually changed
		* - Default merge is disabled to preserve gesture undo granularity
		*/
		function beginMultiStyle(target, properties) {
			if (disposer.isDisposed) return null;
			const inlineStyleOrNull = getInlineStyle(target);
			if (!inlineStyleOrNull) return null;
			const inlineStyle = inlineStyleOrNull;
			const normalizedProps = Array.from(new Set(properties.map((p) => normalizePropertyName(String(p))).filter((p) => !!p)));
			if (normalizedProps.length === 0) return null;
			const trackedProps = new Set(normalizedProps);
			const locator = createElementLocator(target);
			const id = generateTransactionId(now());
			const elementKey = generateStableElementKey(target, locator.shadowHostChain);
			const beforeValues = {};
			for (const prop of normalizedProps) beforeValues[prop] = readStyleValue(inlineStyle, prop);
			let completed = false;
			/**
			* Update one or more style values (live preview).
			* Only properties declared in the initial list are applied.
			*/
			function set(values) {
				if (completed || disposer.isDisposed) return;
				for (const [rawKey, rawVal] of Object.entries(values)) {
					const prop = normalizePropertyName(rawKey);
					if (!prop || !trackedProps.has(prop)) continue;
					writeStyleValue(inlineStyle, prop, String(rawVal !== null && rawVal !== void 0 ? rawVal : ""));
				}
			}
			/**
			* Commit the transaction and record to history.
			* Only properties that actually changed are included in the transaction.
			*/
			function commit(commitOptions) {
				if (completed || disposer.isDisposed) return null;
				completed = true;
				const beforeStyles = {};
				const afterStyles = {};
				for (const prop of normalizedProps) {
					var _beforeValues$prop;
					const beforeVal = (_beforeValues$prop = beforeValues[prop]) !== null && _beforeValues$prop !== void 0 ? _beforeValues$prop : "";
					const afterVal = readStyleValue(inlineStyle, prop);
					if (afterVal === beforeVal) continue;
					beforeStyles[prop] = beforeVal;
					afterStyles[prop] = afterVal;
				}
				if (Object.keys(beforeStyles).length === 0) return null;
				const tx = createStyleTransactionFromStyles(id, locator, beforeStyles, afterStyles, now(), elementKey);
				pushTransaction(tx, (commitOptions === null || commitOptions === void 0 ? void 0 : commitOptions.merge) === true);
				return tx;
			}
			/**
			* Rollback all tracked properties to original values without recording.
			*/
			function rollback() {
				if (completed || disposer.isDisposed) return;
				completed = true;
				for (const prop of normalizedProps) {
					var _beforeValues$prop2;
					writeStyleValue(inlineStyle, prop, (_beforeValues$prop2 = beforeValues[prop]) !== null && _beforeValues$prop2 !== void 0 ? _beforeValues$prop2 : "");
				}
				emit("rollback", null);
			}
			return {
				id,
				properties: normalizedProps,
				targetLocator: locator,
				set,
				commit,
				rollback
			};
		}
		function applyStyle(target, property, value, applyOptions) {
			const handle = beginStyle(target, property);
			if (!handle) return null;
			handle.set(value);
			return handle.commit(applyOptions);
		}
		function undo() {
			if (disposer.isDisposed) return null;
			const tx = undoStack.pop();
			if (!tx) return null;
			if (!applyTransaction(tx, "undo")) {
				var _options$onApplyError;
				undoStack.push(tx);
				(_options$onApplyError = options.onApplyError) === null || _options$onApplyError === void 0 || _options$onApplyError.call(options, /* @__PURE__ */ new Error(`Failed to locate element for undo: ${tx.id}`));
				return null;
			}
			redoStack.push(tx);
			emit("undo", tx);
			return tx;
		}
		function redo() {
			if (disposer.isDisposed) return null;
			const tx = redoStack.pop();
			if (!tx) return null;
			if (!applyTransaction(tx, "redo")) {
				var _options$onApplyError2;
				redoStack.push(tx);
				(_options$onApplyError2 = options.onApplyError) === null || _options$onApplyError2 === void 0 || _options$onApplyError2.call(options, /* @__PURE__ */ new Error(`Failed to locate element for redo: ${tx.id}`));
				return null;
			}
			undoStack.push(tx);
			enforceMaxHistory();
			emit("redo", tx);
			return tx;
		}
		function canUndo() {
			return undoStack.length > 0;
		}
		function canRedo() {
			return redoStack.length > 0;
		}
		function getUndoStack() {
			return undoStack.slice();
		}
		function getRedoStack() {
			return redoStack.slice();
		}
		function clear() {
			undoStack.length = 0;
			redoStack.length = 0;
			emit("clear", null);
		}
		if (options.enableKeyBindings) disposer.listen(window, "keydown", (event) => {
			var _options$isEventFromE;
			if ((_options$isEventFromE = options.isEventFromEditorUi) === null || _options$isEventFromE === void 0 ? void 0 : _options$isEventFromE.call(options, event)) return;
			if (!(event.metaKey || event.ctrlKey) || event.altKey) return;
			const key = event.key.toLowerCase();
			if (key === "z") {
				if (event.shiftKey) redo();
				else undo();
				event.preventDefault();
				event.stopPropagation();
				event.stopImmediatePropagation();
			} else if (key === "y") {
				redo();
				event.preventDefault();
				event.stopPropagation();
				event.stopImmediatePropagation();
			}
		}, KEYBIND_OPTIONS);
		function dispose() {
			undoStack.length = 0;
			redoStack.length = 0;
			disposer.dispose();
		}
		return {
			beginStyle,
			beginMultiStyle,
			beginMove,
			applyStyle,
			recordStyle,
			recordText,
			recordClass,
			applyStructure,
			undo,
			redo,
			canUndo,
			canRedo,
			getUndoStack,
			getRedoStack,
			clear,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/payload-builder.ts
	/**
	* Read optional string value
	*/
	function readString(value) {
		if (typeof value === "string") return value.trim() || void 0;
	}
	/**
	* Normalize text snippet for display
	*/
	function normalizeText$1(text, maxLength) {
		return String(text !== null && text !== void 0 ? text : "").replace(/\s+/g, " ").trim().slice(0, maxLength);
	}
	/**
	* Build fingerprint from DOM element
	*/
	function buildFingerprintFromElement(element) {
		var _element$tagName$toLo, _element$tagName, _element$classList, _element$textContent;
		return {
			tag: (_element$tagName$toLo = (_element$tagName = element.tagName) === null || _element$tagName === void 0 ? void 0 : _element$tagName.toLowerCase()) !== null && _element$tagName$toLo !== void 0 ? _element$tagName$toLo : "unknown",
			id: readString(element.id),
			classes: Array.from((_element$classList = element.classList) !== null && _element$classList !== void 0 ? _element$classList : []).slice(0, 24),
			text: readString(normalizeText$1((_element$textContent = element.textContent) !== null && _element$textContent !== void 0 ? _element$textContent : "", 96))
		};
	}
	/**
	* Build fingerprint from locator (fallback when element not available)
	*/
	function buildFingerprintFromLocator(locator) {
		var _readString;
		const parts = ((_readString = readString(locator.fingerprint)) !== null && _readString !== void 0 ? _readString : "").split("|").filter(Boolean);
		const tag = parts[0] || "unknown";
		let id;
		let classes = [];
		let text;
		for (const part of parts.slice(1)) if (part.startsWith("id=")) id = readString(part.slice(3));
		else if (part.startsWith("class=")) classes = part.slice(6).split(".").filter(Boolean);
		else if (part.startsWith("text=")) text = readString(part.slice(5));
		return {
			tag,
			id,
			classes,
			text
		};
	}
	/** Tailwind class patterns */
	var TAILWIND_PATTERNS = [
		/^bg-/,
		/^text-/,
		/^p[trblxy]?-/,
		/^m[trblxy]?-/,
		/^flex$/,
		/^grid$/,
		/^items-/,
		/^justify-/,
		/^gap-/,
		/^rounded/,
		/^shadow/,
		/^border/,
		/^w-/,
		/^h-/
	];
	/**
	* Detect if element uses Tailwind CSS
	*/
	function detectTailwind(classes) {
		return classes.some((cls) => TAILWIND_PATTERNS.some((p) => p.test(cls)));
	}
	/**
	* Resolve component hints from element
	*/
	function resolveComponentHints(element) {
		var _element$classList2;
		let targetFile;
		let debugSource;
		const hints = /* @__PURE__ */ new Set();
		let node = element;
		for (let depth = 0; depth < 20 && node; depth++) {
			const react = findReactDebugSource(node);
			if (react === null || react === void 0 ? void 0 : react.file) {
				hints.add("React");
				if (!targetFile && !react.file.includes("node_modules")) {
					targetFile = react.file;
					debugSource = react;
					break;
				}
			}
			const vue = findVueDebugSource(node);
			if (vue === null || vue === void 0 ? void 0 : vue.file) {
				hints.add("Vue");
				if (!targetFile && !vue.file.includes("node_modules")) {
					targetFile = vue.file;
					debugSource = vue;
					break;
				}
			}
			node = node.parentElement;
		}
		if (detectTailwind(Array.from((_element$classList2 = element.classList) !== null && _element$classList2 !== void 0 ? _element$classList2 : []).slice(0, 128))) hints.add("Tailwind");
		return {
			targetFile,
			debugSource,
			techStackHint: hints.size > 0 ? Array.from(hints) : void 0
		};
	}
	/**
	* Compute style diff from transaction
	*/
	function computeStyleDiff(tx) {
		var _tx$before$styles, _tx$after$styles;
		const beforeRaw = (_tx$before$styles = tx.before.styles) !== null && _tx$before$styles !== void 0 ? _tx$before$styles : {};
		const afterRaw = (_tx$after$styles = tx.after.styles) !== null && _tx$after$styles !== void 0 ? _tx$after$styles : {};
		const keys = new Set([...Object.keys(beforeRaw), ...Object.keys(afterRaw)]);
		if (keys.size === 0) return null;
		const before = {};
		const after = {};
		const set = {};
		const removed = [];
		for (const key of keys) {
			var _beforeRaw$key, _afterRaw$key;
			const b = String((_beforeRaw$key = beforeRaw[key]) !== null && _beforeRaw$key !== void 0 ? _beforeRaw$key : "").trim();
			const a = String((_afterRaw$key = afterRaw[key]) !== null && _afterRaw$key !== void 0 ? _afterRaw$key : "").trim();
			if (b === a) continue;
			before[key] = b;
			after[key] = a;
			if (a) set[key] = a;
			else removed.push(key);
		}
		if (Object.keys(before).length === 0 && Object.keys(after).length === 0) return null;
		return {
			before,
			after,
			set,
			removed
		};
	}
	/**
	* Build human-readable style description
	*/
	function buildStyleDescription(locator, diff, maxSelectors) {
		var _locator$selectors;
		const selectorPreview = ((_locator$selectors = locator.selectors) !== null && _locator$selectors !== void 0 ? _locator$selectors : []).filter(Boolean).slice(0, maxSelectors).join(" | ");
		const changes = [];
		for (const [prop, nextVal] of Object.entries(diff.after)) {
			var _diff$before$prop;
			const prevVal = (_diff$before$prop = diff.before[prop]) !== null && _diff$before$prop !== void 0 ? _diff$before$prop : "";
			if (nextVal) changes.push(`${prop}: "${prevVal}" -> "${nextVal}"`);
			else changes.push(`${prop}: remove (was "${prevVal}")`);
		}
		return `Update element styles (${selectorPreview ? `selectors: ${selectorPreview}` : "selectors: (unavailable)"}). ${changes.join("; ")}`;
	}
	/**
	* Build human-readable text update description (Phase 2.7)
	*/
	function buildTextDescription(locator, beforeText, afterText, maxSelectors) {
		var _locator$selectors2;
		const selectorPreview = ((_locator$selectors2 = locator.selectors) !== null && _locator$selectors2 !== void 0 ? _locator$selectors2 : []).filter(Boolean).slice(0, maxSelectors).join(" | ");
		return `Update element text (${selectorPreview ? `selectors: ${selectorPreview}` : "selectors: (unavailable)"}). "${beforeText.length > 96 ? beforeText.slice(0, 93) + "..." : beforeText}" -> "${afterText.length > 96 ? afterText.slice(0, 93) + "..." : afterText}"`;
	}
	/**
	* Build Apply payload from a Transaction
	* Supports style and text transactions (Phase 2.7)
	*/
	function buildApplyPayload(tx, options = {}) {
		var _readString2, _options$pageUrl, _globalThis$location, _options$maxSelectors;
		const pageUrl = (_readString2 = readString((_options$pageUrl = options.pageUrl) !== null && _options$pageUrl !== void 0 ? _options$pageUrl : (_globalThis$location = globalThis.location) === null || _globalThis$location === void 0 ? void 0 : _globalThis$location.href)) !== null && _readString2 !== void 0 ? _readString2 : "";
		if (!pageUrl) return null;
		const locator = tx.targetLocator;
		const element = options.element !== void 0 ? options.element : locateElement(locator, document);
		const fingerprint = element ? buildFingerprintFromElement(element) : buildFingerprintFromLocator(locator);
		const hints = element ? resolveComponentHints(element) : {};
		const maxSelectors = Math.max(0, (_options$maxSelectors = options.maxSelectorsInDescription) !== null && _options$maxSelectors !== void 0 ? _options$maxSelectors : 3);
		if (tx.type === "style") {
			var _locator$selectors3;
			const diff = computeStyleDiff(tx);
			if (!diff) return null;
			const description = buildStyleDescription(locator, diff, maxSelectors);
			return {
				pageUrl,
				targetFile: hints.targetFile,
				fingerprint,
				techStackHint: hints.techStackHint,
				instruction: {
					type: "update_style",
					description,
					style: Object.keys(diff.set).length > 0 ? diff.set : void 0
				},
				locator: hints.debugSource ? _objectSpread2(_objectSpread2({}, locator), {}, { debugSource: hints.debugSource }) : locator,
				selectorCandidates: (_locator$selectors3 = locator.selectors) === null || _locator$selectors3 === void 0 ? void 0 : _locator$selectors3.slice(0, 8),
				debugSource: hints.debugSource,
				operation: {
					type: "update_style",
					before: diff.before,
					after: diff.after,
					removed: diff.removed
				}
			};
		}
		if (tx.type === "text") {
			var _tx$before$text, _tx$after$text, _locator$selectors4;
			const beforeText = String((_tx$before$text = tx.before.text) !== null && _tx$before$text !== void 0 ? _tx$before$text : "");
			const afterText = String((_tx$after$text = tx.after.text) !== null && _tx$after$text !== void 0 ? _tx$after$text : "");
			if (beforeText === afterText) return null;
			const description = buildTextDescription(locator, beforeText, afterText, maxSelectors);
			return {
				pageUrl,
				targetFile: hints.targetFile,
				fingerprint,
				techStackHint: hints.techStackHint,
				instruction: {
					type: "update_text",
					description,
					text: afterText
				},
				locator: hints.debugSource ? _objectSpread2(_objectSpread2({}, locator), {}, { debugSource: hints.debugSource }) : locator,
				selectorCandidates: (_locator$selectors4 = locator.selectors) === null || _locator$selectors4 === void 0 ? void 0 : _locator$selectors4.slice(0, 8),
				debugSource: hints.debugSource
			};
		}
		return null;
	}
	/**
	* Send Apply payload to background script
	*/
	function sendApplyPayload(_x) {
		return _sendApplyPayload.apply(this, arguments);
	}
	function _sendApplyPayload() {
		_sendApplyPayload = _asyncToGenerator(function* (payload) {
			var _chrome$runtime;
			if (typeof chrome === "undefined" || !((_chrome$runtime = chrome.runtime) === null || _chrome$runtime === void 0 ? void 0 : _chrome$runtime.sendMessage)) throw new Error("Chrome runtime API not available");
			return chrome.runtime.sendMessage({
				type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_APPLY,
				payload
			});
		});
		return _sendApplyPayload.apply(this, arguments);
	}
	/**
	* Build and send Transaction to Agent in one call
	*/
	function sendTransactionToAgent(_x2) {
		return _sendTransactionToAgent.apply(this, arguments);
	}
	function _sendTransactionToAgent() {
		_sendTransactionToAgent = _asyncToGenerator(function* (tx, options = {}) {
			const payload = buildApplyPayload(tx, options);
			if (!payload) throw new Error("Unable to build payload from transaction");
			return sendApplyPayload(payload);
		});
		return _sendTransactionToAgent.apply(this, arguments);
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/transaction-aggregator.ts
	/** Maximum length for text preview in UI */
	var TEXT_PREVIEW_MAX_LENGTH = 96;
	/** Maximum length for fallback labels */
	var FALLBACK_LABEL_MAX_LENGTH = 64;
	/** Transaction types that can be applied to Agent */
	var APPLICABLE_TX_TYPES = new Set([
		"style",
		"text",
		"class"
	]);
	/**
	* Normalize a key string value
	*/
	function normalizeKey(value) {
		return String(value !== null && value !== void 0 ? value : "").trim();
	}
	/**
	* Normalize a style property value
	*/
	function normalizeStyleValue(value) {
		return String(value !== null && value !== void 0 ? value : "").trim();
	}
	/**
	* Normalize text for preview display
	*/
	function normalizePreviewText(value) {
		return String(value !== null && value !== void 0 ? value : "").replace(/\s+/g, " ").trim();
	}
	/**
	* Truncate string with ellipsis
	*/
	function truncate(value, maxLength) {
		const str = String(value !== null && value !== void 0 ? value : "");
		if (str.length <= maxLength) return str;
		return str.slice(0, Math.max(0, maxLength - 1)).trimEnd() + "…";
	}
	/**
	* Normalize and dedupe a class list
	*/
	function normalizeClassList(input) {
		const out = [];
		const seen = /* @__PURE__ */ new Set();
		for (const raw of input !== null && input !== void 0 ? input : []) {
			const token = String(raw !== null && raw !== void 0 ? raw : "").trim();
			if (!token) continue;
			if (seen.has(token)) continue;
			seen.add(token);
			out.push(token);
		}
		return out;
	}
	/**
	* Safely locate an element from a locator
	*/
	function safeLocateElement(locator) {
		if (typeof document === "undefined") return null;
		try {
			return locateElement(locator);
		} catch (_unused) {
			return null;
		}
	}
	/**
	* Build fallback labels when element cannot be located
	*/
	function buildFallbackLabels(locator, elementKey) {
		var _locator$frameChain, _locator$shadowHostCh;
		let label = "";
		const fingerprint = normalizeKey(locator.fingerprint);
		if (fingerprint) {
			var _parts$;
			const parts = fingerprint.split("|").map((p) => p.trim()).filter(Boolean);
			const tag = (_parts$ = parts[0]) !== null && _parts$ !== void 0 ? _parts$ : "element";
			const idPart = parts.find((p) => p.startsWith("id="));
			const id = idPart ? idPart.slice(3).trim() : "";
			label = id ? `${tag}#${id}` : tag;
		} else if (Array.isArray(locator.selectors) && locator.selectors.length > 0) label = truncate(normalizeKey(locator.selectors[0]), FALLBACK_LABEL_MAX_LENGTH) || "element";
		else label = truncate(elementKey, FALLBACK_LABEL_MAX_LENGTH) || "element";
		const prefixParts = [];
		const frame = ((_locator$frameChain = locator.frameChain) !== null && _locator$frameChain !== void 0 ? _locator$frameChain : []).join(">").trim();
		const shadow = ((_locator$shadowHostCh = locator.shadowHostChain) !== null && _locator$shadowHostCh !== void 0 ? _locator$shadowHostCh : []).join(">").trim();
		if (frame) prefixParts.push(frame);
		if (shadow) prefixParts.push(shadow);
		const fullLabel = prefixParts.length ? `${prefixParts.join(">")} >> ${label}` : label;
		return {
			label,
			fullLabel
		};
	}
	/**
	* Resolve labels for an element (live DOM lookup with fallback)
	*/
	function resolveLabels(locator, elementKey) {
		const element = safeLocateElement(locator);
		if (!element) return buildFallbackLabels(locator, elementKey);
		return {
			label: generateElementLabel(element),
			fullLabel: generateFullElementLabel(element, locator.shadowHostChain)
		};
	}
	/**
	* Infer the change type from what operations are present
	*/
	function inferChangeType(hasStyle, hasText, hasClass) {
		if (Number(hasStyle) + Number(hasText) + Number(hasClass) > 1) return "mixed";
		if (hasStyle) return "style";
		if (hasText) return "text";
		if (hasClass) return "class";
		return "mixed";
	}
	/**
	* Compute net style effect from multiple style transactions
	*/
	function computeStyleNetEffect(txs) {
		const firstBeforeByProp = /* @__PURE__ */ new Map();
		const lastAfterByProp = /* @__PURE__ */ new Map();
		for (const tx of txs) {
			var _tx$before$styles, _tx$after$styles;
			if (tx.type !== "style") continue;
			const beforeRaw = (_tx$before$styles = tx.before.styles) !== null && _tx$before$styles !== void 0 ? _tx$before$styles : {};
			const afterRaw = (_tx$after$styles = tx.after.styles) !== null && _tx$after$styles !== void 0 ? _tx$after$styles : {};
			const keys = new Set([...Object.keys(beforeRaw), ...Object.keys(afterRaw)]);
			for (const rawProp of keys) {
				const prop = String(rawProp !== null && rawProp !== void 0 ? rawProp : "").trim();
				if (!prop) continue;
				const b = normalizeStyleValue(beforeRaw[prop]);
				const a = normalizeStyleValue(afterRaw[prop]);
				if (!firstBeforeByProp.has(prop)) firstBeforeByProp.set(prop, b);
				lastAfterByProp.set(prop, a);
			}
		}
		if (firstBeforeByProp.size === 0 && lastAfterByProp.size === 0) return null;
		const before = {};
		const after = {};
		const allProps = new Set([...firstBeforeByProp.keys(), ...lastAfterByProp.keys()]);
		for (const prop of allProps) {
			var _firstBeforeByProp$ge, _lastAfterByProp$get;
			const b = (_firstBeforeByProp$ge = firstBeforeByProp.get(prop)) !== null && _firstBeforeByProp$ge !== void 0 ? _firstBeforeByProp$ge : "";
			const a = (_lastAfterByProp$get = lastAfterByProp.get(prop)) !== null && _lastAfterByProp$get !== void 0 ? _lastAfterByProp$get : "";
			if (b === a) continue;
			before[prop] = b;
			after[prop] = a;
		}
		const changedProps = Array.from(new Set([...Object.keys(before), ...Object.keys(after)])).sort();
		if (changedProps.length === 0) return null;
		let added = 0;
		let removed = 0;
		let modified = 0;
		for (const prop of changedProps) {
			const b = normalizeStyleValue(before[prop]);
			const a = normalizeStyleValue(after[prop]);
			if (!b && a) added += 1;
			else if (b && !a) removed += 1;
			else modified += 1;
		}
		return {
			before,
			after,
			added,
			removed,
			modified,
			details: changedProps
		};
	}
	/**
	* Compute net text effect from multiple text transactions
	*/
	function computeTextNetEffect(txs) {
		let before;
		let after;
		for (const tx of txs) {
			var _tx$after$text;
			if (tx.type !== "text") continue;
			if (before === void 0) {
				var _tx$before$text;
				before = String((_tx$before$text = tx.before.text) !== null && _tx$before$text !== void 0 ? _tx$before$text : "");
			}
			after = String((_tx$after$text = tx.after.text) !== null && _tx$after$text !== void 0 ? _tx$after$text : "");
		}
		if (before === void 0 || after === void 0) return null;
		if (before === after) return null;
		const beforePreview = truncate(normalizePreviewText(before), TEXT_PREVIEW_MAX_LENGTH);
		const afterPreview = truncate(normalizePreviewText(after), TEXT_PREVIEW_MAX_LENGTH);
		return {
			before,
			after,
			beforePreview,
			afterPreview
		};
	}
	/**
	* Compute net class effect from multiple class transactions
	*/
	function computeClassNetEffect(txs) {
		let beforeRaw;
		let afterRaw;
		for (const tx of txs) {
			if (tx.type !== "class") continue;
			if (!beforeRaw) beforeRaw = normalizeClassList(tx.before.classes);
			afterRaw = normalizeClassList(tx.after.classes);
		}
		if (!beforeRaw || !afterRaw) return null;
		const beforeSet = new Set(beforeRaw);
		const afterSet = new Set(afterRaw);
		const added = Array.from(afterSet).filter((c) => !beforeSet.has(c)).sort();
		const removed = Array.from(beforeSet).filter((c) => !afterSet.has(c)).sort();
		if (added.length === 0 && removed.length === 0) return null;
		return {
			before: Array.from(beforeSet).sort(),
			after: Array.from(afterSet).sort(),
			added,
			removed
		};
	}
	/**
	* Aggregate transactions by element key and compute net effect summaries.
	*
	* @param transactions - Array of transactions (typically the undo stack)
	* @returns Array of element change summaries, sorted by most recent first
	*
	* Notes:
	* - Input is expected to be an undo stack (chronological), but this function
	*   sorts by timestamp to ensure deterministic results.
	* - For legacy transactions without elementKey, locatorKey(targetLocator) is
	*   used as a fallback. This may cause grouping issues when selectors change.
	* - Only applicable transaction types (style/text/class) are included in output.
	* - Elements with no net effect (changes that cancel out) are filtered.
	*/
	function aggregateTransactionsByElement(transactions) {
		const indexed = transactions.map((tx, index) => ({
			tx,
			index
		}));
		indexed.sort((a, b) => {
			var _a$tx$timestamp, _b$tx$timestamp;
			const at = Number((_a$tx$timestamp = a.tx.timestamp) !== null && _a$tx$timestamp !== void 0 ? _a$tx$timestamp : 0);
			const bt = Number((_b$tx$timestamp = b.tx.timestamp) !== null && _b$tx$timestamp !== void 0 ? _b$tx$timestamp : 0);
			if (at !== bt) return at - bt;
			return a.index - b.index;
		});
		const groups = /* @__PURE__ */ new Map();
		for (const { tx } of indexed) {
			if (!APPLICABLE_TX_TYPES.has(tx.type)) continue;
			const rawElementKey = normalizeKey(tx.elementKey);
			let key;
			if (rawElementKey) key = rawElementKey;
			else try {
				key = locatorKey(tx.targetLocator);
			} catch (_unused2) {
				key = `unknown:${tx.id}`;
			}
			const list = groups.get(key);
			if (list) list.push(tx);
			else groups.set(key, [tx]);
		}
		const summaries = [];
		for (const [elementKey, txs] of groups.entries()) {
			var _lastTx$after$locator, _lastTx$after;
			if (txs.length === 0) continue;
			const lastTx = txs[txs.length - 1];
			const locator = (_lastTx$after$locator = (_lastTx$after = lastTx.after) === null || _lastTx$after === void 0 ? void 0 : _lastTx$after.locator) !== null && _lastTx$after$locator !== void 0 ? _lastTx$after$locator : lastTx.targetLocator;
			const style = computeStyleNetEffect(txs);
			const text = computeTextNetEffect(txs);
			const cls = computeClassNetEffect(txs);
			const hasStyle = style !== null;
			const hasText = text !== null;
			const hasClass = cls !== null;
			if (!hasStyle && !hasText && !hasClass) continue;
			const { label, fullLabel } = resolveLabels(locator, elementKey);
			const netEffect = {
				elementKey,
				locator
			};
			if (style) netEffect.styleChanges = {
				before: style.before,
				after: style.after
			};
			if (text) netEffect.textChange = {
				before: text.before,
				after: text.after
			};
			if (cls) netEffect.classChanges = {
				before: cls.before,
				after: cls.after
			};
			const changes = {};
			if (style) changes.style = {
				added: style.added,
				removed: style.removed,
				modified: style.modified,
				details: style.details
			};
			if (text) changes.text = {
				beforePreview: text.beforePreview,
				afterPreview: text.afterPreview
			};
			if (cls) changes.class = {
				added: cls.added,
				removed: cls.removed
			};
			const updatedAt = txs.reduce((max, tx) => {
				var _tx$timestamp;
				const ts = Number((_tx$timestamp = tx.timestamp) !== null && _tx$timestamp !== void 0 ? _tx$timestamp : 0);
				return Number.isFinite(ts) ? Math.max(max, ts) : max;
			}, 0);
			const type = inferChangeType(hasStyle, hasText, hasClass);
			summaries.push({
				elementKey,
				label,
				fullLabel,
				locator,
				type,
				changes,
				transactionIds: txs.map((tx) => tx.id),
				netEffect,
				updatedAt,
				debugSource: locator.debugSource
			});
		}
		summaries.sort((a, b) => b.updatedAt - a.updatedAt || a.label.localeCompare(b.label));
		return summaries;
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/execution-tracker.ts
	/**
	* Execution Tracker (Phase 3.10)
	*
	* Tracks Agent execution status for Apply operations via background polling.
	* Provides real-time feedback on execution progress without requiring SSE.
	*
	* Design:
	* - Uses message passing to background for status queries
	* - Lightweight polling approach (avoids complexity of SSE in content script)
	* - Disposer pattern for cleanup
	*/
	var DEFAULT_POLL_INTERVAL = 2e3;
	var DEFAULT_TIMEOUT = 12e4;
	var TERMINAL_STATUSES = [
		"completed",
		"failed",
		"error",
		"timeout",
		"cancelled"
	];
	function isTerminalStatus(status) {
		return TERMINAL_STATUSES.includes(status);
	}
	function getStatusMessage(status) {
		switch (status) {
			case "pending": return "Waiting...";
			case "starting": return "Starting Agent...";
			case "running": return "Running...";
			case "locating": return "Locating code...";
			case "applying": return "Applying changes...";
			case "completed": return "Completed";
			case "failed":
			case "error": return "Failed";
			case "timeout": return "Timed out";
			case "cancelled": return "Cancelled";
			default: return "";
		}
	}
	var ExecutionTracker = class {
		constructor(options = {}) {
			var _options$pollInterval, _options$timeout;
			_defineProperty(this, "disposer", new Disposer());
			_defineProperty(this, "executions", /* @__PURE__ */ new Map());
			_defineProperty(this, "pollTimers", /* @__PURE__ */ new Map());
			_defineProperty(this, "pollInterval", void 0);
			_defineProperty(this, "timeout", void 0);
			_defineProperty(this, "onStatusChange", void 0);
			this.pollInterval = (_options$pollInterval = options.pollInterval) !== null && _options$pollInterval !== void 0 ? _options$pollInterval : DEFAULT_POLL_INTERVAL;
			this.timeout = (_options$timeout = options.timeout) !== null && _options$timeout !== void 0 ? _options$timeout : DEFAULT_TIMEOUT;
			this.onStatusChange = options.onStatusChange;
			this.disposer.add(() => this.stopAllPolling());
		}
		/**
		* Track a new execution by requestId
		*/
		track(requestId, sessionId) {
			const now = Date.now();
			const state = {
				requestId,
				sessionId,
				status: "pending",
				message: getStatusMessage("pending"),
				startedAt: now,
				updatedAt: now
			};
			this.executions.set(requestId, state);
			this.startPolling(requestId);
			return state;
		}
		/**
		* Get current state for a request
		*/
		getState(requestId) {
			return this.executions.get(requestId);
		}
		/**
		* Cancel tracking for a request.
		* Sends a real cancel request to the background to abort the execution on the server.
		* @returns Promise that resolves when cancel is complete (or fails silently)
		*/
		cancel(requestId) {
			var _this = this;
			return _asyncToGenerator(function* () {
				const state = _this.executions.get(requestId);
				if (!state) return;
				_this.stopPolling(requestId);
				if (isTerminalStatus(state.status)) return;
				_this.updateState(requestId, {
					status: "cancelled",
					message: "Cancelling..."
				});
				try {
					const response = yield chrome.runtime.sendMessage({
						type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_CANCEL_EXECUTION,
						payload: {
							sessionId: state.sessionId,
							requestId: state.requestId
						}
					});
					if (response === null || response === void 0 ? void 0 : response.success) _this.updateState(requestId, {
						status: "cancelled",
						message: "Cancelled by user"
					});
					else {
						console.warn("[ExecutionTracker] Cancel request failed:", response === null || response === void 0 ? void 0 : response.error);
						_this.updateState(requestId, {
							status: "cancelled",
							message: "Cancelled (server may still be running)"
						});
					}
				} catch (error) {
					console.warn("[ExecutionTracker] Cancel request error:", error);
					_this.updateState(requestId, {
						status: "cancelled",
						message: "Cancelled by user"
					});
				}
			})();
		}
		/**
		* Manually update status (for background message handler)
		*/
		updateFromBackground(requestId, update) {
			this.updateState(requestId, update);
		}
		/**
		* Clean up
		*/
		dispose() {
			this.disposer.dispose();
			this.executions.clear();
		}
		startPolling(requestId) {
			var _this2 = this;
			const timeoutTimer = window.setTimeout(() => {
				const state = this.executions.get(requestId);
				if (state && !isTerminalStatus(state.status)) {
					this.updateState(requestId, {
						status: "timeout",
						message: "Execution timed out"
					});
					this.stopPolling(requestId);
				}
			}, this.timeout);
			this.disposer.add(() => window.clearTimeout(timeoutTimer));
			const poll = function() {
				var _ref = _asyncToGenerator(function* () {
					const state = _this2.executions.get(requestId);
					if (!state || isTerminalStatus(state.status)) {
						_this2.stopPolling(requestId);
						return;
					}
					try {
						const result = yield _this2.queryStatus(requestId, state.sessionId);
						if (result) {
							_this2.updateState(requestId, result);
							if (isTerminalStatus(result.status)) {
								_this2.stopPolling(requestId);
								return;
							}
						}
					} catch (_unused) {}
					if (!_this2.disposer.isDisposed) {
						const timer = window.setTimeout(poll, _this2.pollInterval);
						_this2.pollTimers.set(requestId, timer);
					}
				});
				return function poll() {
					return _ref.apply(this, arguments);
				};
			}();
			const initialTimer = window.setTimeout(poll, 500);
			this.pollTimers.set(requestId, initialTimer);
		}
		stopPolling(requestId) {
			const timer = this.pollTimers.get(requestId);
			if (timer !== void 0) {
				window.clearTimeout(timer);
				this.pollTimers.delete(requestId);
			}
		}
		stopAllPolling() {
			for (const timer of this.pollTimers.values()) window.clearTimeout(timer);
			this.pollTimers.clear();
		}
		updateState(requestId, update) {
			var _this$onStatusChange;
			const state = this.executions.get(requestId);
			if (!state) return;
			const newState = _objectSpread2(_objectSpread2(_objectSpread2({}, state), update), {}, { updatedAt: Date.now() });
			if (update.status && !update.message) newState.message = getStatusMessage(update.status);
			this.executions.set(requestId, newState);
			(_this$onStatusChange = this.onStatusChange) === null || _this$onStatusChange === void 0 || _this$onStatusChange.call(this, newState);
		}
		queryStatus(requestId, sessionId) {
			return _asyncToGenerator(function* () {
				try {
					const response = yield chrome.runtime.sendMessage({
						type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_STATUS_QUERY,
						requestId,
						sessionId
					});
					if (response === null || response === void 0 ? void 0 : response.status) return {
						status: response.status,
						message: response.message,
						result: response.result
					};
				} catch (_unused2) {}
				return null;
			})();
		}
	};
	/**
	* Create an ExecutionTracker instance
	*/
	function createExecutionTracker(options) {
		return new ExecutionTracker(options);
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/css-compare.ts
	var DEFAULT_PX_EPSILON = .5;
	var DEFAULT_MATRIX_EPSILON = .001;
	var PX_VALUE_REGEX = /(-?\d*\.?\d+(?:e[+-]?\d+)?)px/gi;
	var MATRIX_NUMBER_REGEX = /-?\d*\.?\d+(?:e[+-]?\d+)?/gi;
	/**
	* Normalize text content for robust comparison.
	* Collapses whitespace and trims edges.
	*/
	function normalizeText(text) {
		return String(text !== null && text !== void 0 ? text : "").replace(/\s+/g, " ").trim();
	}
	/**
	* Read computed style values for specified CSS properties.
	*
	* @param element - Target element
	* @param properties - CSS property names to read
	* @returns Map of property name to computed value (normalized)
	*/
	function readComputedMap(element, properties) {
		const result = {};
		const uniqueProps = [];
		const seen = /* @__PURE__ */ new Set();
		for (const raw of properties) {
			const prop = String(raw !== null && raw !== void 0 ? raw : "").trim();
			if (!prop || seen.has(prop)) continue;
			seen.add(prop);
			uniqueProps.push(prop);
		}
		let computed = null;
		try {
			computed = window.getComputedStyle(element);
		} catch (_unused) {
			computed = null;
		}
		for (const property of uniqueProps) {
			let value = "";
			try {
				var _computed$getProperty;
				value = (_computed$getProperty = computed === null || computed === void 0 ? void 0 : computed.getPropertyValue(property)) !== null && _computed$getProperty !== void 0 ? _computed$getProperty : "";
			} catch (_unused2) {
				value = "";
			}
			result[property] = normalizeCssValue(value);
		}
		return result;
	}
	/**
	* Compare two computed style maps with numeric tolerance.
	*
	* Comparison strategy:
	* 1. Exact string match → pass
	* 2. matrix()/matrix3d() numeric tolerance → pass if within epsilon
	* 3. px-based numeric tolerance → pass if same shape and within epsilon
	* 4. Otherwise → fail
	*
	* @param expected - Baseline computed values
	* @param actual - Current computed values
	* @param options - Comparison options
	* @returns Comparison result with per-property diffs
	*/
	function compareComputed(expected, actual, options = {}) {
		const pxEps = Number.isFinite(options.pxEpsilon) ? options.pxEpsilon : DEFAULT_PX_EPSILON;
		const matrixEps = Number.isFinite(options.matrixEpsilon) ? options.matrixEpsilon : DEFAULT_MATRIX_EPSILON;
		const diffs = [];
		for (const property of Object.keys(expected)) {
			var _expected$property, _actual$property;
			const exp = normalizeCssValue((_expected$property = expected[property]) !== null && _expected$property !== void 0 ? _expected$property : "");
			const act = normalizeCssValue((_actual$property = actual[property]) !== null && _actual$property !== void 0 ? _actual$property : "");
			const { match, reason } = compareSingleValue(exp, act, pxEps, matrixEps);
			diffs.push({
				property,
				expected: exp,
				actual: act,
				match,
				reason
			});
		}
		return {
			matches: diffs.every((d) => d.match),
			diffs
		};
	}
	/**
	* Normalize a CSS value string for consistent comparison.
	* Collapses whitespace and normalizes spacing around punctuation.
	*/
	function normalizeCssValue(raw) {
		return String(raw !== null && raw !== void 0 ? raw : "").replace(/\s+/g, " ").replace(/,\s+/g, ",").replace(/\(\s+/g, "(").replace(/\s+\)/g, ")").trim();
	}
	/**
	* Check if two numbers are approximately equal within epsilon.
	*/
	function approximatelyEqual(a, b, epsilon) {
		return Math.abs(a - b) <= epsilon;
	}
	/**
	* Check if value looks like a CSS matrix transform.
	*/
	function isMatrixValue(value) {
		const lower = value.toLowerCase();
		return lower.startsWith("matrix(") || lower.startsWith("matrix3d(");
	}
	/**
	* Extract numeric components from a matrix() or matrix3d() value.
	* Returns null if not a valid matrix or contains invalid numbers.
	*/
	function extractMatrixNumbers(value) {
		if (!isMatrixValue(value)) return null;
		const matches = value.match(MATRIX_NUMBER_REGEX);
		if (!matches || matches.length === 0) return null;
		const nums = [];
		for (const m of matches) {
			const n = Number(m);
			if (!Number.isFinite(n)) return null;
			nums.push(n);
		}
		return nums.length > 0 ? nums : null;
	}
	/**
	* Extract px numeric values from a CSS value string.
	* Returns null if no px values found or contains invalid numbers.
	*/
	function extractPxNumbers(value) {
		const nums = [];
		PX_VALUE_REGEX.lastIndex = 0;
		let match;
		while ((match = PX_VALUE_REGEX.exec(value)) !== null) {
			const n = Number(match[1]);
			if (!Number.isFinite(n)) return null;
			nums.push(n);
		}
		return nums.length > 0 ? nums : null;
	}
	/**
	* Get the "shape" of a px-based value by replacing numeric values with placeholders.
	* Used to ensure we're comparing structurally similar values.
	*/
	function pxValueShape(value) {
		PX_VALUE_REGEX.lastIndex = 0;
		return normalizeCssValue(value).replace(PX_VALUE_REGEX, "#px");
	}
	/**
	* Compare two matrix values with numeric tolerance.
	*/
	function compareMatrixWithEpsilon(expected, actual, epsilon) {
		const expNums = extractMatrixNumbers(expected);
		const actNums = extractMatrixNumbers(actual);
		if (!expNums || !actNums) return false;
		if (expNums.length !== actNums.length) return false;
		if ((expected.toLowerCase().startsWith("matrix3d(") ? "matrix3d" : "matrix") !== (actual.toLowerCase().startsWith("matrix3d(") ? "matrix3d" : "matrix")) return false;
		for (let i = 0; i < expNums.length; i++) if (!approximatelyEqual(expNums[i], actNums[i], epsilon)) return false;
		return true;
	}
	/**
	* Compare two px-based values with numeric tolerance.
	*/
	function comparePxWithEpsilon(expected, actual, epsilon) {
		const expNums = extractPxNumbers(expected);
		const actNums = extractPxNumbers(actual);
		if (!expNums || !actNums) return false;
		if (expNums.length !== actNums.length) return false;
		if (pxValueShape(expected) !== pxValueShape(actual)) return false;
		for (let i = 0; i < expNums.length; i++) if (!approximatelyEqual(expNums[i], actNums[i], epsilon)) return false;
		return true;
	}
	/**
	* Compare a single CSS value pair with all available strategies.
	*/
	function compareSingleValue(expected, actual, pxEpsilon, matrixEpsilon) {
		if (expected === actual) return {
			match: true,
			reason: "exact"
		};
		if (isMatrixValue(expected) && isMatrixValue(actual)) {
			if (compareMatrixWithEpsilon(expected, actual, matrixEpsilon)) return {
				match: true,
				reason: "matrix_epsilon"
			};
		}
		const expHasPx = PX_VALUE_REGEX.test(expected);
		PX_VALUE_REGEX.lastIndex = 0;
		const actHasPx = PX_VALUE_REGEX.test(actual);
		PX_VALUE_REGEX.lastIndex = 0;
		if (expHasPx && actHasPx) {
			if (comparePxWithEpsilon(expected, actual, pxEpsilon)) return {
				match: true,
				reason: "px_epsilon"
			};
		}
		return {
			match: false,
			reason: "string"
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/hmr-consistency.ts
	var DEFAULT_QUIET_WINDOW_MS = 300;
	var DEFAULT_SETTLE_DEADLINE_MS = 8e3;
	var DEFAULT_NO_SIGNAL_DEADLINE_MS = 2e3;
	var DEFAULT_RELAXED_LOCATE_MAX_ELEMENTS = 200;
	var DEFAULT_GEOMETRIC_MAX_CANDIDATES = 16;
	/** MutationObserver options for head (CSS changes) */
	var HEAD_MUTATION_OPTIONS = {
		childList: true,
		subtree: true,
		characterData: true,
		attributes: true
	};
	/** MutationObserver options for DOM (structure, text, and relevant attribute changes) */
	var DOM_MUTATION_OPTIONS = {
		childList: true,
		subtree: true,
		attributes: true,
		attributeFilter: [
			"class",
			"style",
			"id"
		],
		characterData: true
	};
	var TERMINAL_EXEC_STATUSES = new Set([
		"completed",
		"failed",
		"error",
		"timeout",
		"cancelled"
	]);
	var RELAXED_CONFIDENCE_THRESHOLD = 8;
	var GEOMETRIC_CONFIDENCE_THRESHOLD = 6;
	function safeReadRect(element) {
		try {
			const r = element.getBoundingClientRect();
			if (!Number.isFinite(r.left) || !Number.isFinite(r.top)) return null;
			if (!Number.isFinite(r.width) || !Number.isFinite(r.height)) return null;
			return r;
		} catch (_unused) {
			return null;
		}
	}
	function rectCenter(rect) {
		return {
			x: rect.left + rect.width / 2,
			y: rect.top + rect.height / 2
		};
	}
	function safeElementsFromPoint(x, y) {
		try {
			const els = document.elementsFromPoint(x, y);
			return Array.isArray(els) ? els.filter((e) => e instanceof Element) : [];
		} catch (_unused2) {
			try {
				const el = document.elementFromPoint(x, y);
				return el ? [el] : [];
			} catch (_unused3) {
				return [];
			}
		}
	}
	function safeQuerySelectorAll(root, selector, maxCount) {
		try {
			const list = root.querySelectorAll(selector);
			const out = [];
			const limit = Math.min(maxCount, list.length);
			for (let i = 0; i < limit; i++) out.push(list[i]);
			return out;
		} catch (_unused4) {
			return [];
		}
	}
	function isHtmlOrBody(element) {
		var _element$tagName$toUp, _element$tagName, _element$tagName$toUp2;
		const tag = (_element$tagName$toUp = (_element$tagName = element.tagName) === null || _element$tagName === void 0 || (_element$tagName$toUp2 = _element$tagName.toUpperCase) === null || _element$tagName$toUp2 === void 0 ? void 0 : _element$tagName$toUp2.call(_element$tagName)) !== null && _element$tagName$toUp !== void 0 ? _element$tagName$toUp : "";
		return tag === "HTML" || tag === "BODY";
	}
	function isValidCandidate(element, isOverlayElement) {
		if (!element.isConnected) return false;
		if (isHtmlOrBody(element)) return false;
		if (isOverlayElement === null || isOverlayElement === void 0 ? void 0 : isOverlayElement(element)) return false;
		return true;
	}
	function parseFingerprint(raw) {
		const parts = String(raw !== null && raw !== void 0 ? raw : "").trim().split("|").filter(Boolean);
		const tag = parts[0] || "unknown";
		let id;
		let classes = [];
		let text;
		for (const part of parts.slice(1)) if (part.startsWith("id=")) id = part.slice(3) || void 0;
		else if (part.startsWith("class=")) classes = part.slice(6).split(".").filter(Boolean);
		else if (part.startsWith("text=")) text = part.slice(5) || void 0;
		return {
			tag,
			id,
			classes,
			text
		};
	}
	function intersectCount(a, b) {
		if (!a.length || !b.length) return 0;
		const set = new Set(b);
		return a.filter((item) => set.has(item)).length;
	}
	function commonPrefixLength(a, b) {
		const n = Math.min(a.length, b.length);
		let i = 0;
		while (i < n && a[i] === b[i]) i++;
		return i;
	}
	/** Score an element candidate against expected fingerprint */
	function scoreCandidate(params) {
		var _locator$path;
		const { element, expected, locator, anchorCenter } = params;
		const candidateFp = parseFingerprint(computeFingerprint(element));
		if (candidateFp.tag !== expected.tag) return -Infinity;
		if (expected.id && candidateFp.id !== expected.id) return -Infinity;
		let score = 0;
		if (expected.id) score += 12;
		score += Math.min(8, intersectCount(expected.classes, candidateFp.classes) * 2);
		if (expected.text) {
			var _element$textContent;
			const expectedText = normalizeText(expected.text);
			if (normalizeText((_element$textContent = element.textContent) !== null && _element$textContent !== void 0 ? _element$textContent : "").includes(expectedText)) score += 4;
		}
		if ((_locator$path = locator.path) === null || _locator$path === void 0 ? void 0 : _locator$path.length) {
			const path = computeDomPath(element);
			const prefix = commonPrefixLength(locator.path, path);
			score += prefix / locator.path.length * 6;
			if (prefix === locator.path.length && path.length === locator.path.length) score += 2;
		}
		if (anchorCenter && Number.isFinite(anchorCenter.x)) {
			const rect = safeReadRect(element);
			if (rect) {
				const c = rectCenter(rect);
				const dist = Math.hypot(c.x - anchorCenter.x, c.y - anchorCenter.y);
				score += Math.max(0, 6 - dist / 50);
			}
		}
		return score;
	}
	/** Relaxed locate: scan selectors without uniqueness constraint, score candidates */
	function relaxedLocate(params) {
		var _locator$selectors;
		const { locator, expected, isOverlayElement, maxElements, anchorCenter } = params;
		let best = null;
		let scanned = 0;
		if (expected.id) {
			const byId = document.getElementById(expected.id);
			if (byId && isValidCandidate(byId, isOverlayElement)) {
				const score = scoreCandidate({
					element: byId,
					expected,
					locator,
					anchorCenter
				});
				if (Number.isFinite(score)) best = {
					element: byId,
					score
				};
			}
		}
		for (const selector of (_locator$selectors = locator.selectors) !== null && _locator$selectors !== void 0 ? _locator$selectors : []) {
			if (scanned >= maxElements) break;
			const remaining = maxElements - scanned;
			if (remaining <= 0) break;
			const elements = safeQuerySelectorAll(document, selector, remaining);
			for (const element of elements) {
				scanned++;
				if (!isValidCandidate(element, isOverlayElement)) continue;
				const score = scoreCandidate({
					element,
					expected,
					locator,
					anchorCenter
				});
				if (!Number.isFinite(score)) continue;
				if (!best || score > best.score) best = {
					element,
					score
				};
			}
		}
		return best;
	}
	/** Geometric locate: find elements at anchor point and score them */
	function geometricLocate(params) {
		const { expected, locator, anchorCenter, isOverlayElement, selectionEngine, maxCandidates } = params;
		const candidates = [];
		if (selectionEngine) try {
			for (const c of selectionEngine.getCandidatesAtPoint(anchorCenter.x, anchorCenter.y)) {
				candidates.push(c.element);
				if (candidates.length >= maxCandidates) break;
			}
		} catch (_unused5) {}
		if (candidates.length === 0) for (const el of safeElementsFromPoint(anchorCenter.x, anchorCenter.y)) {
			candidates.push(el);
			if (candidates.length >= maxCandidates) break;
		}
		let best = null;
		const seen = /* @__PURE__ */ new Set();
		for (const element of candidates) {
			if (seen.has(element)) continue;
			seen.add(element);
			if (!isValidCandidate(element, isOverlayElement)) continue;
			const score = scoreCandidate({
				element,
				expected,
				locator,
				anchorCenter
			});
			if (!Number.isFinite(score)) continue;
			if (!best || score > best.score) best = {
				element,
				score
			};
		}
		return best;
	}
	/** Collect style properties from a transaction */
	function collectStyleProperties(tx) {
		var _tx$before$styles, _tx$after$styles;
		const set = /* @__PURE__ */ new Set();
		for (const key of Object.keys((_tx$before$styles = tx.before.styles) !== null && _tx$before$styles !== void 0 ? _tx$before$styles : {})) set.add(key);
		for (const key of Object.keys((_tx$after$styles = tx.after.styles) !== null && _tx$after$styles !== void 0 ? _tx$after$styles : {})) set.add(key);
		return Array.from(set).filter(Boolean);
	}
	/**
	* Create an HMR Consistency Verifier.
	*
	* Usage:
	* 1. Call `start()` when Apply succeeds
	* 2. Forward `ExecutionTracker.onStatusChange` to `onExecutionStatus()`
	* 3. Forward `TransactionManager.onChange` to `onTransactionChange()`
	* 4. Forward selection changes to `onSelectionChange()`
	* 5. Results are emitted via `options.onResult` callback
	*/
	function createHmrConsistencyVerifier(options) {
		var _options$quietWindowM, _options$settleDeadli, _options$noSignalDead, _options$relaxedLocat, _options$geometricMax;
		const disposer = new Disposer();
		const now = () => Date.now();
		const quietWindowMs = Math.max(0, (_options$quietWindowM = options.quietWindowMs) !== null && _options$quietWindowM !== void 0 ? _options$quietWindowM : DEFAULT_QUIET_WINDOW_MS);
		const settleDeadlineMs = Math.max(0, (_options$settleDeadli = options.settleDeadlineMs) !== null && _options$settleDeadli !== void 0 ? _options$settleDeadli : DEFAULT_SETTLE_DEADLINE_MS);
		const noSignalDeadlineMs = Math.max(0, (_options$noSignalDead = options.noSignalDeadlineMs) !== null && _options$noSignalDead !== void 0 ? _options$noSignalDead : DEFAULT_NO_SIGNAL_DEADLINE_MS);
		const relaxedLocateMaxElements = Math.max(1, (_options$relaxedLocat = options.relaxedLocateMaxElements) !== null && _options$relaxedLocat !== void 0 ? _options$relaxedLocat : DEFAULT_RELAXED_LOCATE_MAX_ELEMENTS);
		const geometricMaxCandidates = Math.max(1, (_options$geometricMax = options.geometricMaxCandidates) !== null && _options$geometricMax !== void 0 ? _options$geometricMax : DEFAULT_GEOMETRIC_MAX_CANDIDATES);
		let sessionSeq = 0;
		let active = null;
		let lastResult = null;
		disposer.add(() => finalizeActive("skipped", "disposed"));
		function setToolbar(status, message) {
			var _options$setToolbarSt;
			(_options$setToolbarSt = options.setToolbarStatus) === null || _options$setToolbarSt === void 0 || _options$setToolbarSt.call(options, status, message);
		}
		function buildResult(session, params) {
			var _session$txId, _session$txTimestamp, _session$txType, _session$signals$hadR, _session$signals$hadE, _session$startedAt, _session$executionCom;
			const finalizedAt = now();
			return {
				outcome: params.outcome,
				reason: params.reason,
				requestId: session === null || session === void 0 ? void 0 : session.requestId,
				sessionId: session === null || session === void 0 ? void 0 : session.sessionId,
				txId: (_session$txId = session === null || session === void 0 ? void 0 : session.txId) !== null && _session$txId !== void 0 ? _session$txId : "",
				txTimestamp: (_session$txTimestamp = session === null || session === void 0 ? void 0 : session.txTimestamp) !== null && _session$txTimestamp !== void 0 ? _session$txTimestamp : 0,
				txType: (_session$txType = session === null || session === void 0 ? void 0 : session.txType) !== null && _session$txType !== void 0 ? _session$txType : "style",
				resolved: params.resolved,
				style: params.style,
				text: params.text,
				signals: {
					hadRelevantMutation: (_session$signals$hadR = session === null || session === void 0 ? void 0 : session.signals.hadRelevantMutation) !== null && _session$signals$hadR !== void 0 ? _session$signals$hadR : false,
					hadElementDisconnect: (_session$signals$hadE = session === null || session === void 0 ? void 0 : session.signals.hadElementDisconnect) !== null && _session$signals$hadE !== void 0 ? _session$signals$hadE : false
				},
				timing: {
					startedAt: (_session$startedAt = session === null || session === void 0 ? void 0 : session.startedAt) !== null && _session$startedAt !== void 0 ? _session$startedAt : finalizedAt,
					executionCompletedAt: (_session$executionCom = session === null || session === void 0 ? void 0 : session.executionCompletedAt) !== null && _session$executionCom !== void 0 ? _session$executionCom : void 0,
					finalizedAt
				}
			};
		}
		function emitAndStore(result) {
			var _options$onResult;
			lastResult = result;
			(_options$onResult = options.onResult) === null || _options$onResult === void 0 || _options$onResult.call(options, result);
		}
		function clearTimers(s) {
			if (s.timers.quietTimer !== null) {
				window.clearTimeout(s.timers.quietTimer);
				s.timers.quietTimer = null;
			}
			if (s.timers.deadlineTimer !== null) {
				window.clearTimeout(s.timers.deadlineTimer);
				s.timers.deadlineTimer = null;
			}
			if (s.timers.noSignalTimer !== null) {
				window.clearTimeout(s.timers.noSignalTimer);
				s.timers.noSignalTimer = null;
			}
		}
		function finalizeActive(outcome, reason, extra) {
			const s = active;
			if (!s) return;
			const result = buildResult(s, {
				outcome,
				reason,
				resolved: extra === null || extra === void 0 ? void 0 : extra.resolved,
				style: extra === null || extra === void 0 ? void 0 : extra.style,
				text: extra === null || extra === void 0 ? void 0 : extra.text
			});
			clearTimers(s);
			s.disposer.dispose();
			active = null;
			const hadTakenControl = s.phase === "settling" || s.phase === "verifying";
			if (extra === null || extra === void 0 ? void 0 : extra.toolbar) setToolbar(extra.toolbar.status, extra.toolbar.message);
			else if (outcome === "skipped" && hadTakenControl) setToolbar("idle");
			emitAndStore(result);
		}
		function isLatestTxStillSame(txId, txTimestamp) {
			try {
				const undo = options.transactionManager.getUndoStack();
				if (undo.length === 0) return false;
				const latest = undo[undo.length - 1];
				return latest.id === txId && latest.timestamp === txTimestamp;
			} catch (_unused6) {
				return false;
			}
		}
		function isMutationFromOverlay(record) {
			if (!options.isOverlayElement) return false;
			const t = record.target;
			if (t instanceof Element && options.isOverlayElement(t)) return true;
			if (record.type === "childList") return [...record.addedNodes, ...record.removedNodes].some((n) => {
				var _options$isOverlayEle;
				return n instanceof Element && ((_options$isOverlayEle = options.isOverlayElement) === null || _options$isOverlayEle === void 0 ? void 0 : _options$isOverlayEle.call(options, n));
			});
			return false;
		}
		function isDomMutationRelevant(record, target) {
			if (!target) return false;
			if (isMutationFromOverlay(record)) return false;
			const recTarget = record.target;
			if (record.type === "characterData") {
				if (recTarget instanceof Text) {
					const parent = recTarget.parentElement;
					if (parent && (parent === target || parent.contains(target) || target.contains(parent))) return true;
				}
				return false;
			}
			if (!(recTarget instanceof Element)) return false;
			if (record.type === "attributes") try {
				return recTarget === target || recTarget.contains(target) || target.contains(recTarget);
			} catch (_unused7) {
				return false;
			}
			if (record.type === "childList") {
				try {
					if (recTarget === target || recTarget.contains(target) || target.contains(recTarget)) return true;
				} catch (_unused8) {}
				for (const n of record.removedNodes) {
					if (n === target) return true;
					if (n instanceof Element) try {
						if (n.contains(target)) return true;
					} catch (_unused9) {}
				}
			}
			return false;
		}
		function scheduleVerify(s, reason) {
			if (s.disposer.isDisposed) return;
			if (s.phase !== "settling") return;
			if (s.timers.quietTimer !== null) {
				window.clearTimeout(s.timers.quietTimer);
				s.timers.quietTimer = null;
			}
			s.timers.quietTimer = window.setTimeout(() => {
				s.timers.quietTimer = null;
				runVerify(`quiet:${reason}`);
			}, quietWindowMs);
		}
		function markMutationSignal(s) {
			s.signals.hadRelevantMutation = true;
			scheduleVerify(s, "mutation");
		}
		function enterSettling(s) {
			var _s$originalElement, _s$originalElement$ge, _document$body;
			if (s.disposer.isDisposed) return;
			if (s.phase === "settling" || s.phase === "verifying") return;
			s.phase = "settling";
			s.executionCompletedAt = now();
			setToolbar("verifying", "Waiting for HMR…");
			const head = document.head;
			if (head) s.disposer.observeMutation(head, () => {
				if ((active === null || active === void 0 ? void 0 : active.key) !== s.key || active.phase !== "settling") return;
				markMutationSignal(active);
			}, HEAD_MUTATION_OPTIONS);
			const targetRootNode = (_s$originalElement = s.originalElement) === null || _s$originalElement === void 0 || (_s$originalElement$ge = _s$originalElement.getRootNode) === null || _s$originalElement$ge === void 0 ? void 0 : _s$originalElement$ge.call(_s$originalElement);
			const domTarget = targetRootNode instanceof ShadowRoot ? targetRootNode : (_document$body = document.body) !== null && _document$body !== void 0 ? _document$body : document.documentElement;
			if (domTarget) s.disposer.observeMutation(domTarget, (records) => {
				if ((active === null || active === void 0 ? void 0 : active.key) !== s.key || active.phase !== "settling") return;
				const el = active.originalElement;
				if (el && !el.isConnected) active.signals.hadElementDisconnect = true;
				if (records.some((r) => isDomMutationRelevant(r, el))) markMutationSignal(active);
			}, DOM_MUTATION_OPTIONS);
			s.timers.deadlineTimer = window.setTimeout(() => {
				if ((active === null || active === void 0 ? void 0 : active.key) !== s.key) return;
				finalizeActive("uncertain", "timeout waiting for HMR", { toolbar: {
					status: "uncertain",
					message: "Uncertain (timeout)"
				} });
			}, settleDeadlineMs);
			s.timers.noSignalTimer = window.setTimeout(() => {
				if ((active === null || active === void 0 ? void 0 : active.key) !== s.key || active.phase !== "settling") return;
				runVerify("no_signal");
			}, noSignalDeadlineMs);
			scheduleVerify(s, "initial");
		}
		function resolveTarget(s) {
			const isOvl = options.isOverlayElement;
			const current = s.originalElement;
			if (current && isValidCandidate(current, isOvl)) return {
				element: current,
				source: "current",
				confidence: "high"
			};
			const strict = locateElement(s.locator);
			if (strict && isValidCandidate(strict, isOvl)) return {
				element: strict,
				source: "strict",
				confidence: "high"
			};
			const expected = parseFingerprint(s.locator.fingerprint);
			const relaxedBest = relaxedLocate({
				locator: s.locator,
				expected,
				isOverlayElement: isOvl,
				maxElements: relaxedLocateMaxElements,
				anchorCenter: s.anchorCenter
			});
			if (relaxedBest && isValidCandidate(relaxedBest.element, isOvl)) {
				if (relaxedBest.score >= RELAXED_CONFIDENCE_THRESHOLD) return {
					element: relaxedBest.element,
					source: "relaxed",
					confidence: "medium",
					score: relaxedBest.score
				};
			}
			if (s.anchorCenter) {
				const geoBest = geometricLocate({
					expected,
					locator: s.locator,
					anchorCenter: s.anchorCenter,
					isOverlayElement: isOvl,
					selectionEngine: options.selectionEngine,
					maxCandidates: geometricMaxCandidates
				});
				if (geoBest && isValidCandidate(geoBest.element, isOvl)) {
					if (geoBest.score >= GEOMETRIC_CONFIDENCE_THRESHOLD) return {
						element: geoBest.element,
						source: "geometric",
						confidence: "low",
						score: geoBest.score
					};
				}
			}
			return null;
		}
		function maybeReselect(s, element) {
			var _options$getSelectedE, _options$getSelectedE2;
			if (!options.onReselect) return;
			if (((_options$getSelectedE = (_options$getSelectedE2 = options.getSelectedElement) === null || _options$getSelectedE2 === void 0 ? void 0 : _options$getSelectedE2.call(options)) !== null && _options$getSelectedE !== void 0 ? _options$getSelectedE : null) === element) return;
			s.flags.suppressNextSelectionChange = true;
			options.onReselect(element);
		}
		function verifyStyle(s, element) {
			const spec = s.expectedStyle;
			if (!(spec === null || spec === void 0 ? void 0 : spec.computed)) return { ok: false };
			const actual = readComputedMap(element, spec.properties);
			return {
				ok: true,
				style: compareComputed(spec.computed, actual)
			};
		}
		function verifyText(s, element) {
			var _element$textContent2;
			const expected = s.expectedText;
			if (expected === null) return { ok: false };
			const actual = normalizeText((_element$textContent2 = element.textContent) !== null && _element$textContent2 !== void 0 ? _element$textContent2 : "");
			return {
				ok: true,
				text: {
					expected,
					actual,
					match: expected === actual
				}
			};
		}
		function runVerify(_x) {
			return _runVerify.apply(this, arguments);
		}
		function _runVerify() {
			_runVerify = _asyncToGenerator(function* (trigger) {
				const s = active;
				if (!s || s.disposer.isDisposed || s.phase !== "settling" || s.flags.verifying) return;
				s.flags.verifying = true;
				s.phase = "verifying";
				setToolbar("verifying", "Verifying…");
				try {
					if (!isLatestTxStillSame(s.txId, s.txTimestamp)) {
						finalizeActive("skipped", "skipped: new edits detected");
						return;
					}
					if (s.flags.selectionChanged) {
						finalizeActive("skipped", "skipped: selection changed");
						return;
					}
					if (s.originalElement && !s.originalElement.isConnected) s.signals.hadElementDisconnect = true;
					const resolved = resolveTarget(s);
					if (!resolved) {
						finalizeActive("lost", `lost: unable to locate target (${trigger})`, { toolbar: {
							status: "lost",
							message: "Target lost"
						} });
						return;
					}
					maybeReselect(s, resolved.element);
					const resolvedMeta = {
						source: resolved.source,
						confidence: resolved.confidence,
						score: resolved.score
					};
					const hasHmrSignal = s.signals.hadRelevantMutation || s.signals.hadElementDisconnect;
					if (resolved.confidence === "low") {
						finalizeActive("uncertain", `uncertain: low confidence resolution (${resolved.source})`, {
							resolved: resolvedMeta,
							toolbar: {
								status: "uncertain",
								message: "Uncertain (low confidence)"
							}
						});
						return;
					}
					if (s.txType === "style") {
						const check = verifyStyle(s, resolved.element);
						if (!check.ok || !check.style) {
							finalizeActive("uncertain", "uncertain: missing computed baseline", {
								resolved: resolvedMeta,
								toolbar: {
									status: "uncertain",
									message: "Uncertain (no baseline)"
								}
							});
							return;
						}
						const mismatches = check.style.diffs.filter((d) => !d.match);
						if (mismatches.length > 0) {
							finalizeActive("mismatch", `mismatch: ${mismatches.length} property mismatch`, {
								resolved: resolvedMeta,
								style: check.style,
								toolbar: {
									status: "mismatch",
									message: `Mismatch (${mismatches.length})`
								}
							});
							return;
						}
						if (!hasHmrSignal) {
							finalizeActive("uncertain", "uncertain: no HMR signal observed", {
								resolved: resolvedMeta,
								style: check.style,
								toolbar: {
									status: "uncertain",
									message: "Uncertain (no HMR signal)"
								}
							});
							return;
						}
						finalizeActive("verified", "verified", {
							resolved: resolvedMeta,
							style: check.style,
							toolbar: {
								status: "verified",
								message: "Verified"
							}
						});
						return;
					}
					if (s.txType === "text") {
						const check = verifyText(s, resolved.element);
						if (!check.ok || !check.text) {
							finalizeActive("uncertain", "uncertain: missing text baseline", {
								resolved: resolvedMeta,
								toolbar: {
									status: "uncertain",
									message: "Uncertain (no baseline)"
								}
							});
							return;
						}
						if (!check.text.match) {
							finalizeActive("mismatch", "mismatch: text differs from expected", {
								resolved: resolvedMeta,
								text: check.text,
								toolbar: {
									status: "mismatch",
									message: "Mismatch (text)"
								}
							});
							return;
						}
						if (!hasHmrSignal) {
							finalizeActive("uncertain", "uncertain: no HMR signal observed", {
								resolved: resolvedMeta,
								text: check.text,
								toolbar: {
									status: "uncertain",
									message: "Uncertain (no HMR signal)"
								}
							});
							return;
						}
						finalizeActive("verified", "verified", {
							resolved: resolvedMeta,
							text: check.text,
							toolbar: {
								status: "verified",
								message: "Verified"
							}
						});
						return;
					}
					finalizeActive("skipped", `skipped: tx type "${s.txType}" not supported`);
				} finally {
					if ((active === null || active === void 0 ? void 0 : active.key) === s.key) active.flags.verifying = false;
				}
			});
			return _runVerify.apply(this, arguments);
		}
		function start(args) {
			const { tx, requestId, sessionId, element } = args;
			if (tx.type !== "style" && tx.type !== "text") return;
			finalizeActive("skipped", "skipped: superseded by new apply");
			const key = `hmr_${now().toString(36)}_${(++sessionSeq).toString(36)}`;
			const sessionDisposer = new Disposer();
			const el = (element === null || element === void 0 ? void 0 : element.isConnected) ? element : null;
			const anchorRect = el ? safeReadRect(el) : null;
			const anchorCenter = anchorRect ? rectCenter(anchorRect) : null;
			let expectedStyle = null;
			let expectedText = null;
			if (tx.type === "style") {
				const properties = collectStyleProperties(tx);
				const computed = el ? readComputedMap(el, properties) : null;
				expectedStyle = computed ? {
					properties,
					computed
				} : null;
			} else if (tx.type === "text") {
				var _el$textContent, _tx$after$text;
				expectedText = normalizeText(el ? (_el$textContent = el.textContent) !== null && _el$textContent !== void 0 ? _el$textContent : "" : (_tx$after$text = tx.after.text) !== null && _tx$after$text !== void 0 ? _tx$after$text : "");
			}
			active = {
				key,
				phase: "executing",
				requestId: (requestId === null || requestId === void 0 ? void 0 : requestId.trim()) || void 0,
				sessionId: (sessionId === null || sessionId === void 0 ? void 0 : sessionId.trim()) || void 0,
				txId: tx.id,
				txTimestamp: tx.timestamp,
				txType: tx.type,
				locator: tx.targetLocator,
				originalElement: el,
				expectedStyle,
				expectedText,
				anchorRect,
				anchorCenter,
				startedAt: now(),
				executionCompletedAt: null,
				signals: {
					hadRelevantMutation: false,
					hadElementDisconnect: false
				},
				flags: {
					verifying: false,
					selectionChanged: false,
					suppressNextSelectionChange: false
				},
				timers: {
					quietTimer: null,
					deadlineTimer: null,
					noSignalTimer: null
				},
				disposer: sessionDisposer
			};
			if (!isLatestTxStillSame(tx.id, tx.timestamp)) finalizeActive("skipped", "skipped: transaction no longer latest");
		}
		function onExecutionStatus(state) {
			const s = active;
			if (!s || s.disposer.isDisposed) return;
			if (s.requestId && state.requestId !== s.requestId) return;
			if (!TERMINAL_EXEC_STATUSES.has(state.status)) return;
			if (state.status === "completed") enterSettling(s);
			else finalizeActive("skipped", `skipped: execution ${state.status}`);
		}
		function onTransactionChange(_event) {
			const s = active;
			if (!s || s.disposer.isDisposed) return;
			if (!isLatestTxStillSame(s.txId, s.txTimestamp)) finalizeActive("skipped", "skipped: new edits detected");
		}
		function onSelectionChange(element) {
			const s = active;
			if (!s || s.disposer.isDisposed) return;
			if (s.flags.suppressNextSelectionChange) {
				s.flags.suppressNextSelectionChange = false;
				return;
			}
			const expected = s.originalElement;
			if (element === null && expected) {
				s.flags.selectionChanged = true;
				finalizeActive("skipped", "skipped: selection cleared");
				return;
			}
			if (expected && element && element !== expected) {
				s.flags.selectionChanged = true;
				finalizeActive("skipped", "skipped: selection changed");
			}
		}
		function getSnapshot() {
			var _s$phase;
			const s = active;
			return {
				phase: (_s$phase = s === null || s === void 0 ? void 0 : s.phase) !== null && _s$phase !== void 0 ? _s$phase : "idle",
				activeRequestId: s === null || s === void 0 ? void 0 : s.requestId,
				activeTxId: s === null || s === void 0 ? void 0 : s.txId,
				lastResult
			};
		}
		function dispose() {
			disposer.dispose();
			setToolbar("idle");
		}
		return {
			start,
			onExecutionStatus,
			onTransactionChange,
			onSelectionChange,
			getSnapshot,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/perf-monitor.ts
	/**
	* Performance Monitor (Phase 5.3)
	*
	* Lightweight FPS + JS heap monitor for debugging.
	*
	* Design:
	* - Disabled by default (no persistent rAF)
	* - Uses a single rAF loop only when enabled
	* - Updates UI at low frequency (FPS: 500ms, heap: 1s)
	* - Pauses automatically when the document is hidden
	*
	* Notes:
	* - Heap metrics rely on Chrome's non-standard `performance.memory` API.
	*/
	var DEFAULT_FPS_UI_INTERVAL_MS = 500;
	var DEFAULT_MEMORY_SAMPLE_INTERVAL_MS = 1e3;
	function isFiniteNumber(value) {
		return typeof value === "number" && Number.isFinite(value);
	}
	function bytesToMb(bytes) {
		return bytes / (1024 * 1024);
	}
	function formatMb(bytes, digits) {
		const mb = bytesToMb(bytes);
		return Number.isFinite(mb) ? mb.toFixed(digits) : "N/A";
	}
	function readPerformanceMemory() {
		try {
			const memory = performance.memory;
			if (!memory) return null;
			const used = memory.usedJSHeapSize;
			const limit = memory.jsHeapSizeLimit;
			const total = memory.totalJSHeapSize;
			if (!isFiniteNumber(used)) return null;
			if (!isFiniteNumber(limit)) return null;
			if (!isFiniteNumber(total)) return null;
			return {
				usedJSHeapSize: used,
				totalJSHeapSize: total,
				jsHeapSizeLimit: limit
			};
		} catch (_unused) {
			return null;
		}
	}
	/**
	* Create a perf monitor HUD.
	*
	* The HUD is appended to `overlayRoot` and is `pointer-events: none`.
	* It is hidden by default and only starts rAF when enabled.
	*/
	function createPerfMonitor(options) {
		var _options$fpsUiInterva, _options$memorySample, _fpsEl$textContent, _heapEl$textContent;
		const disposer = new Disposer();
		const container = options.container;
		const fpsUiIntervalMs = Math.max(100, Math.floor((_options$fpsUiInterva = options.fpsUiIntervalMs) !== null && _options$fpsUiInterva !== void 0 ? _options$fpsUiInterva : DEFAULT_FPS_UI_INTERVAL_MS));
		const memorySampleIntervalMs = Math.max(250, Math.floor((_options$memorySample = options.memorySampleIntervalMs) !== null && _options$memorySample !== void 0 ? _options$memorySample : DEFAULT_MEMORY_SAMPLE_INTERVAL_MS));
		const root = document.createElement("div");
		root.className = "we-perf-hud";
		root.hidden = true;
		root.setAttribute("aria-hidden", "true");
		const fpsEl = document.createElement("div");
		fpsEl.className = "we-perf-hud-line";
		fpsEl.textContent = "FPS: --";
		const heapEl = document.createElement("div");
		heapEl.className = "we-perf-hud-line";
		heapEl.textContent = "Heap: --";
		root.append(fpsEl, heapEl);
		container.append(root);
		disposer.add(() => root.remove());
		let enabled = false;
		let rafId = null;
		let frameCount = 0;
		let lastFpsUiTime = 0;
		let lastMemorySampleTime = 0;
		let lastFpsText = (_fpsEl$textContent = fpsEl.textContent) !== null && _fpsEl$textContent !== void 0 ? _fpsEl$textContent : "";
		let lastHeapText = (_heapEl$textContent = heapEl.textContent) !== null && _heapEl$textContent !== void 0 ? _heapEl$textContent : "";
		function cancelRaf() {
			if (rafId !== null) {
				cancelAnimationFrame(rafId);
				rafId = null;
			}
		}
		disposer.add(cancelRaf);
		function setText(el, next, cache) {
			if (cache === "fps") {
				if (next === lastFpsText) return;
				lastFpsText = next;
			} else {
				if (next === lastHeapText) return;
				lastHeapText = next;
			}
			el.textContent = next;
		}
		function updateHeapText() {
			const memory = readPerformanceMemory();
			if (!memory) {
				setText(heapEl, "Heap: N/A", "heap");
				return;
			}
			setText(heapEl, `Heap: ${formatMb(memory.usedJSHeapSize, 1)} / ${formatMb(memory.jsHeapSizeLimit, 0)} MB`, "heap");
		}
		function resetSampling(now) {
			frameCount = 0;
			lastFpsUiTime = now;
			lastMemorySampleTime = now - memorySampleIntervalMs;
			setText(fpsEl, "FPS: --", "fps");
			updateHeapText();
		}
		function scheduleNextFrame() {
			if (disposer.isDisposed) return;
			if (!enabled) return;
			if (rafId !== null) return;
			if (document.visibilityState !== "visible") return;
			rafId = requestAnimationFrame(onFrame);
		}
		function onFrame(now) {
			rafId = null;
			if (disposer.isDisposed) return;
			if (!enabled) return;
			if (document.visibilityState !== "visible") return;
			frameCount += 1;
			const fpsElapsed = now - lastFpsUiTime;
			if (fpsElapsed >= fpsUiIntervalMs) {
				const fps = fpsElapsed > 0 ? frameCount * 1e3 / fpsElapsed : 0;
				setText(fpsEl, `FPS: ${Math.max(0, Math.round(fps))}`, "fps");
				frameCount = 0;
				lastFpsUiTime = now;
			}
			if (now - lastMemorySampleTime >= memorySampleIntervalMs) {
				lastMemorySampleTime = now;
				updateHeapText();
			}
			scheduleNextFrame();
		}
		function handleVisibilityChange() {
			if (!enabled) return;
			if (document.visibilityState !== "visible") {
				cancelRaf();
				return;
			}
			resetSampling(performance.now());
			scheduleNextFrame();
		}
		disposer.listen(document, "visibilitychange", handleVisibilityChange);
		function setEnabled(next) {
			if (enabled === next) return;
			enabled = next;
			if (!enabled) {
				root.hidden = true;
				cancelRaf();
				return;
			}
			root.hidden = false;
			if (document.visibilityState !== "visible") return;
			resetSampling(performance.now());
			scheduleNextFrame();
		}
		function toggle() {
			setEnabled(!enabled);
			return enabled;
		}
		return {
			isEnabled: () => enabled,
			setEnabled,
			toggle,
			dispose: () => {
				enabled = false;
				root.hidden = true;
				disposer.dispose();
			}
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/design-tokens/token-detector.ts
	var DEFAULT_MAX_DECLARATIONS_PER_TOKEN = 50;
	var DEFAULT_MAX_INLINE_DEPTH = 8;
	/**
	* Create a token detector instance.
	*/
	function createTokenDetector(options = {}) {
		var _options$maxDeclarati, _options$maxInlineDep;
		const maxDeclarationsPerToken = Math.max(1, Math.floor((_options$maxDeclarati = options.maxDeclarationsPerToken) !== null && _options$maxDeclarati !== void 0 ? _options$maxDeclarati : DEFAULT_MAX_DECLARATIONS_PER_TOKEN));
		const defaultInlineDepth = Math.max(0, Math.floor((_options$maxInlineDep = options.maxInlineDepth) !== null && _options$maxInlineDep !== void 0 ? _options$maxInlineDep : DEFAULT_MAX_INLINE_DEPTH));
		/**
		* Safely read cssRules from a stylesheet.
		* Returns null if access is blocked (e.g., cross-origin).
		*/
		function safeReadCssRules(sheet) {
			try {
				return sheet.cssRules;
			} catch (_unused) {
				return null;
			}
		}
		/**
		* Check if a stylesheet is applicable (not disabled, media matches).
		*/
		function isSheetApplicable(sheet) {
			if (sheet.disabled) return false;
			try {
				var _sheet$media$mediaTex, _sheet$media;
				const mediaText = (_sheet$media$mediaTex = (_sheet$media = sheet.media) === null || _sheet$media === void 0 || (_sheet$media = _sheet$media.mediaText) === null || _sheet$media === void 0 ? void 0 : _sheet$media.trim()) !== null && _sheet$media$mediaTex !== void 0 ? _sheet$media$mediaTex : "";
				if (!mediaText || mediaText.toLowerCase() === "all") return true;
				return window.matchMedia(mediaText).matches;
			} catch (_unused2) {
				return true;
			}
		}
		/**
		* Create a human-readable reference to a stylesheet.
		*/
		function describeStyleSheet(sheet, fallbackIndex) {
			const href = typeof sheet.href === "string" ? sheet.href : void 0;
			if (href) {
				var _href$split$pop$split, _href$split$pop;
				return {
					url: href,
					label: (_href$split$pop$split = (_href$split$pop = href.split("/").pop()) === null || _href$split$pop === void 0 ? void 0 : _href$split$pop.split("?")[0]) !== null && _href$split$pop$split !== void 0 ? _href$split$pop$split : href
				};
			}
			const ownerNode = sheet.ownerNode;
			if ((ownerNode === null || ownerNode === void 0 ? void 0 : ownerNode.nodeType) === Node.ELEMENT_NODE) return { label: `<${ownerNode.tagName.toLowerCase()} #${fallbackIndex}>` };
			return { label: `<constructed #${fallbackIndex}>` };
		}
		/**
		* Evaluate @media rule condition.
		*/
		function evalMediaRule(rule, warnings) {
			try {
				var _rule$media$mediaText, _rule$media;
				const mediaText = (_rule$media$mediaText = (_rule$media = rule.media) === null || _rule$media === void 0 || (_rule$media = _rule$media.mediaText) === null || _rule$media === void 0 ? void 0 : _rule$media.trim()) !== null && _rule$media$mediaText !== void 0 ? _rule$media$mediaText : "";
				if (!mediaText || mediaText.toLowerCase() === "all") return true;
				return window.matchMedia(mediaText).matches;
			} catch (e) {
				warnings.push(`Failed to evaluate @media: ${String(e)}`);
				return false;
			}
		}
		/**
		* Evaluate @supports rule condition.
		*/
		function evalSupportsRule(rule, warnings) {
			try {
				var _rule$conditionText$t, _rule$conditionText, _CSS;
				const cond = (_rule$conditionText$t = (_rule$conditionText = rule.conditionText) === null || _rule$conditionText === void 0 ? void 0 : _rule$conditionText.trim()) !== null && _rule$conditionText$t !== void 0 ? _rule$conditionText$t : "";
				if (!cond) return true;
				if (typeof ((_CSS = CSS) === null || _CSS === void 0 ? void 0 : _CSS.supports) !== "function") return true;
				return CSS.supports(cond);
			} catch (e) {
				warnings.push(`Failed to evaluate @supports: ${String(e)}`);
				return false;
			}
		}
		/**
		* Extract custom property declarations from a style declaration.
		*/
		function extractCustomProperties(style) {
			var _style$length;
			const results = [];
			const len = Number((_style$length = style === null || style === void 0 ? void 0 : style.length) !== null && _style$length !== void 0 ? _style$length : 0);
			for (let i = 0; i < len; i++) {
				let name = "";
				try {
					var _style$item;
					name = String((_style$item = style.item(i)) !== null && _style$item !== void 0 ? _style$item : "").trim();
				} catch (_unused3) {
					continue;
				}
				if (!name.startsWith("--")) continue;
				let value = "";
				let important = false;
				try {
					var _style$getPropertyVal;
					value = String((_style$getPropertyVal = style.getPropertyValue(name)) !== null && _style$getPropertyVal !== void 0 ? _style$getPropertyVal : "").trim();
					important = style.getPropertyPriority(name) === "important";
				} catch (_unused4) {}
				results.push({
					name,
					value,
					important
				});
			}
			return results;
		}
		function collectRootIndex(root) {
			const rootType = root instanceof ShadowRoot ? "shadow" : "document";
			const warnings = [];
			const tokens = /* @__PURE__ */ new Map();
			let rulesScanned = 0;
			let totalDeclarations = 0;
			let order = 0;
			/**
			* Add a declaration to the index.
			*/
			function addDeclaration(decl) {
				var _tokens$get;
				const list = (_tokens$get = tokens.get(decl.name)) !== null && _tokens$get !== void 0 ? _tokens$get : [];
				if (list.length >= maxDeclarationsPerToken) return;
				list.push(_objectSpread2(_objectSpread2({}, decl), {}, { order: order++ }));
				tokens.set(decl.name, list);
				totalDeclarations++;
			}
			/**
			* Recursively walk a rule list.
			*/
			function walkRules(rules, context) {
				for (const rule of Array.from(rules)) {
					var _anyRule$cssRules;
					rulesScanned++;
					if (rule.type === CSSRule.IMPORT_RULE) {
						const importRule = rule;
						const imported = importRule.styleSheet;
						if (imported && !context.visited.has(imported)) {
							try {
								var _importRule$media$med, _importRule$media;
								const importMedia = (_importRule$media$med = (_importRule$media = importRule.media) === null || _importRule$media === void 0 || (_importRule$media = _importRule$media.mediaText) === null || _importRule$media === void 0 ? void 0 : _importRule$media.trim()) !== null && _importRule$media$med !== void 0 ? _importRule$media$med : "";
								if (importMedia && importMedia.toLowerCase() !== "all") {
									if (!window.matchMedia(importMedia).matches) continue;
								}
							} catch (_unused5) {}
							if (!isSheetApplicable(imported)) continue;
							const importedRules = safeReadCssRules(imported);
							const importSource = describeStyleSheet(imported, context.sheetIndex);
							if (!importedRules) {
								var _importSource$url;
								warnings.push(`Skipped @import (cross-origin): ${(_importSource$url = importSource.url) !== null && _importSource$url !== void 0 ? _importSource$url : importSource.label}`);
								continue;
							}
							context.visited.add(imported);
							try {
								walkRules(importedRules, _objectSpread2(_objectSpread2({}, context), {}, { source: importSource }));
							} finally {
								context.visited.delete(imported);
							}
						}
						continue;
					}
					if (rule.type === CSSRule.MEDIA_RULE) {
						if (evalMediaRule(rule, warnings)) walkRules(rule.cssRules, context);
						continue;
					}
					if (rule.type === CSSRule.SUPPORTS_RULE) {
						if (evalSupportsRule(rule, warnings)) walkRules(rule.cssRules, context);
						continue;
					}
					if (rule.type === CSSRule.STYLE_RULE) {
						var _styleRule$selectorTe;
						const styleRule = rule;
						const selectorText = String((_styleRule$selectorTe = styleRule.selectorText) !== null && _styleRule$selectorTe !== void 0 ? _styleRule$selectorTe : "").trim() || void 0;
						const customProps = extractCustomProperties(styleRule.style);
						for (const prop of customProps) addDeclaration({
							name: prop.name,
							value: prop.value,
							important: prop.important,
							origin: "rule",
							rootType,
							styleSheet: context.source,
							selectorText
						});
						continue;
					}
					const anyRule = rule;
					if ((_anyRule$cssRules = anyRule.cssRules) === null || _anyRule$cssRules === void 0 ? void 0 : _anyRule$cssRules.length) try {
						walkRules(anyRule.cssRules, context);
					} catch (_unused6) {}
				}
			}
			const docOrShadow = root;
			const styleSheets = [];
			try {
				var _docOrShadow$styleShe;
				for (const s of Array.from((_docOrShadow$styleShe = docOrShadow.styleSheets) !== null && _docOrShadow$styleShe !== void 0 ? _docOrShadow$styleShe : [])) if (s instanceof CSSStyleSheet) styleSheets.push(s);
			} catch (_unused7) {}
			try {
				var _docOrShadow$adoptedS;
				const adopted = Array.from((_docOrShadow$adoptedS = docOrShadow.adoptedStyleSheets) !== null && _docOrShadow$adoptedS !== void 0 ? _docOrShadow$adoptedS : []);
				for (const s of adopted) if (s instanceof CSSStyleSheet) styleSheets.push(s);
			} catch (_unused8) {}
			for (let sheetIndex = 0; sheetIndex < styleSheets.length; sheetIndex++) {
				const sheet = styleSheets[sheetIndex];
				if (!isSheetApplicable(sheet)) continue;
				const sheetSource = describeStyleSheet(sheet, sheetIndex);
				const cssRules = safeReadCssRules(sheet);
				if (!cssRules) {
					var _sheetSource$url;
					warnings.push(`Skipped stylesheet (cross-origin): ${(_sheetSource$url = sheetSource.url) !== null && _sheetSource$url !== void 0 ? _sheetSource$url : sheetSource.label}`);
					continue;
				}
				walkRules(cssRules, {
					sheetIndex,
					source: sheetSource,
					visited: new Set([sheet])
				});
			}
			const stats = {
				styleSheets: styleSheets.length,
				rulesScanned,
				tokens: tokens.size,
				declarations: totalDeclarations
			};
			return {
				rootType,
				tokens,
				warnings: [...new Set(warnings)],
				stats
			};
		}
		/**
		* Get parent element, crossing shadow boundaries if needed.
		*/
		function getParentElementOrHost(element) {
			if (element.parentElement) return element.parentElement;
			try {
				var _element$getRootNode;
				const root = (_element$getRootNode = element.getRootNode) === null || _element$getRootNode === void 0 ? void 0 : _element$getRootNode.call(element);
				if (root instanceof ShadowRoot) return root.host;
			} catch (_unused9) {}
			return null;
		}
		function collectInlineTokenNames(element, options) {
			var _options$maxDepth;
			const maxDepth = Math.max(0, Math.floor((_options$maxDepth = options === null || options === void 0 ? void 0 : options.maxDepth) !== null && _options$maxDepth !== void 0 ? _options$maxDepth : defaultInlineDepth));
			const result = /* @__PURE__ */ new Set();
			let current = element;
			let depth = 0;
			while (current && depth <= maxDepth) {
				depth++;
				try {
					const style = current.style;
					if (style) {
						var _style$length2;
						const len = Number((_style$length2 = style.length) !== null && _style$length2 !== void 0 ? _style$length2 : 0);
						for (let i = 0; i < len; i++) {
							var _style$item2;
							const name = String((_style$item2 = style.item(i)) !== null && _style$item2 !== void 0 ? _style$item2 : "").trim();
							if (name.startsWith("--")) result.add(name);
						}
					}
				} catch (_unused10) {}
				current = getParentElementOrHost(current);
			}
			return result;
		}
		return {
			collectRootIndex,
			collectInlineTokenNames
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/design-tokens/token-resolver.ts
	/**
	* Create a token resolver instance.
	*/
	function createTokenResolver(options = {}) {
		const enableProbe = Boolean(options.enableProbe);
		function formatCssVar(name, fallback) {
			const fb = typeof fallback === "string" ? fallback.trim() : "";
			return fb ? `var(${name}, ${fb})` : `var(${name})`;
		}
		function parseCssVar(value) {
			const raw = String(value !== null && value !== void 0 ? value : "").trim();
			if (!raw.toLowerCase().startsWith("var(")) return null;
			let depth = 0;
			let endIndex = -1;
			for (let i = 0; i < raw.length; i++) {
				const ch = raw[i];
				if (ch === "(") depth++;
				else if (ch === ")") {
					depth--;
					if (depth === 0) {
						endIndex = i;
						break;
					}
				}
			}
			if (endIndex < 0 || endIndex !== raw.length - 1) return null;
			const inner = raw.slice(4, endIndex).trim();
			if (!inner) return null;
			let commaIndex = -1;
			depth = 0;
			for (let i = 0; i < inner.length; i++) {
				const ch = inner[i];
				if (ch === "(") depth++;
				else if (ch === ")") depth = Math.max(0, depth - 1);
				else if (ch === "," && depth === 0) {
					commaIndex = i;
					break;
				}
			}
			const nameStr = (commaIndex >= 0 ? inner.slice(0, commaIndex) : inner).trim();
			const fallbackStr = commaIndex >= 0 ? inner.slice(commaIndex + 1).trim() : "";
			if (!nameStr.startsWith("--")) return null;
			const name = nameStr;
			return fallbackStr ? {
				name,
				fallback: fallbackStr
			} : { name };
		}
		function extractCssVarNames(value) {
			const results = [];
			const str = String(value !== null && value !== void 0 ? value : "");
			const regex = /var\(\s*(--[\w-]+)/g;
			let match;
			while (match = regex.exec(str)) {
				var _match$;
				const name = (_match$ = match[1]) === null || _match$ === void 0 ? void 0 : _match$.trim();
				if (name === null || name === void 0 ? void 0 : name.startsWith("--")) results.push(name);
			}
			return results;
		}
		function readComputedValue(element, name) {
			try {
				return window.getComputedStyle(element).getPropertyValue(name).trim();
			} catch (_unused) {
				return "";
			}
		}
		function resolveToken(element, name) {
			const computedValue = readComputedValue(element, name);
			return {
				token: name,
				computedValue,
				availability: computedValue ? "available" : "unset"
			};
		}
		function resolveTokenForProperty(element, name, cssProperty, options = {}) {
			const cssValue = formatCssVar(name, options.fallback);
			const method = enableProbe && options.preview ? "probe" : "computed";
			let resolvedValue;
			if (method === "computed" && options.preview) resolvedValue = readComputedValue(element, name) || void 0;
			return {
				token: name,
				cssProperty,
				cssValue,
				resolvedValue,
				method
			};
		}
		return {
			formatCssVar,
			parseCssVar,
			extractCssVarNames,
			readComputedValue,
			resolveToken,
			resolveTokenForProperty
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/design-tokens/design-tokens-service.ts
	/**
	* Design Tokens Service (Phase 5.4)
	*
	* Central orchestrator for design token functionality.
	*
	* Responsibilities:
	* - Token index caching per root (Document/ShadowRoot)
	* - Cache invalidation on stylesheet changes
	* - Unified query interface for UI components
	* - Integration with TransactionManager for applying tokens
	*
	* Cache strategy:
	* - Root-level WeakMap cache (auto-GC when roots are removed)
	* - Optional TTL for handling adoptedStyleSheets changes (no native events)
	* - MutationObserver on document.head for stylesheet injection detection
	*/
	/**
	* Create a design tokens service instance.
	*/
	function createDesignTokensService(options = {}) {
		var _options$now, _options$cacheMaxAgeM, _options$maxInlineDep, _options$detector, _options$resolver;
		const disposer = new Disposer();
		const getNow = (_options$now = options.now) !== null && _options$now !== void 0 ? _options$now : (() => performance.now());
		const cacheMaxAgeMs = Math.max(0, Math.floor((_options$cacheMaxAgeM = options.cacheMaxAgeMs) !== null && _options$cacheMaxAgeM !== void 0 ? _options$cacheMaxAgeM : 0));
		const observeHead = options.observeHead !== false;
		const observeShadowRoots = Boolean(options.observeShadowRoots);
		const maxInlineDepth = Math.max(0, Math.floor((_options$maxInlineDep = options.maxInlineDepth) !== null && _options$maxInlineDep !== void 0 ? _options$maxInlineDep : 8));
		const detector = (_options$detector = options.detector) !== null && _options$detector !== void 0 ? _options$detector : createTokenDetector(options.detectorOptions);
		const resolver = (_options$resolver = options.resolver) !== null && _options$resolver !== void 0 ? _options$resolver : createTokenResolver(options.resolverOptions);
		const rootCache = /* @__PURE__ */ new WeakMap();
		const observedRoots = /* @__PURE__ */ new WeakSet();
		const invalidationListeners = /* @__PURE__ */ new Set();
		function getRootType(root) {
			return root instanceof ShadowRoot ? "shadow" : "document";
		}
		function emitInvalidation(root, reason) {
			const event = {
				root,
				rootType: getRootType(root),
				reason,
				timestamp: getNow()
			};
			for (const handler of invalidationListeners) try {
				handler(event);
			} catch (_unused) {}
		}
		function getElementRoot(element) {
			try {
				var _element$getRootNode, _element$ownerDocumen;
				const root = (_element$getRootNode = element.getRootNode) === null || _element$getRootNode === void 0 ? void 0 : _element$getRootNode.call(element);
				if (root instanceof ShadowRoot) return root;
				return (_element$ownerDocumen = element.ownerDocument) !== null && _element$ownerDocumen !== void 0 ? _element$ownerDocumen : document;
			} catch (_unused2) {
				var _element$ownerDocumen2;
				return (_element$ownerDocumen2 = element.ownerDocument) !== null && _element$ownerDocumen2 !== void 0 ? _element$ownerDocumen2 : document;
			}
		}
		function ensureObserved(root) {
			if (observedRoots.has(root)) return;
			observedRoots.add(root);
			if (root instanceof ShadowRoot) {
				if (!observeShadowRoots) return;
				disposer.observeMutation(root, () => invalidateRoot(root, "shadow_mutation"), {
					childList: true,
					subtree: true,
					characterData: true,
					attributes: true
				});
				return;
			}
			if (!observeHead) return;
			const head = root.head;
			if (!head) return;
			disposer.observeMutation(head, () => invalidateRoot(root, "head_mutation"), {
				childList: true,
				subtree: true,
				characterData: true,
				attributes: true
			});
		}
		function getOrCollectIndex(root) {
			const cached = rootCache.get(root);
			if (cached) if (cacheMaxAgeMs > 0) if (getNow() - cached.collectedAt >= cacheMaxAgeMs) invalidateRoot(root, "ttl");
			else return cached.index;
			else return cached.index;
			const index = detector.collectRootIndex(root);
			rootCache.set(root, {
				index,
				collectedAt: getNow()
			});
			return index;
		}
		function invalidateRoot(root, reason = "manual") {
			rootCache.delete(root);
			emitInvalidation(root, reason);
		}
		function toDesignToken(name, declarations) {
			return {
				name,
				kind: "unknown",
				declarations: [...declarations].sort((a, b) => a.order - b.order)
			};
		}
		function getRootTokens(root, options = {}) {
			ensureObserved(root);
			const index = getOrCollectIndex(root);
			const tokens = [];
			for (const [name, declarations] of index.tokens) tokens.push(toDesignToken(name, declarations));
			if (options.sortByName !== false) tokens.sort((a, b) => a.name.localeCompare(b.name));
			return {
				tokens,
				warnings: index.warnings,
				stats: index.stats
			};
		}
		function getContextTokens(element, options = {}) {
			const root = getElementRoot(element);
			ensureObserved(root);
			const index = getOrCollectIndex(root);
			const candidateNames = /* @__PURE__ */ new Set();
			for (const name of index.tokens.keys()) candidateNames.add(name);
			if (options.includeInlineAncestors !== false) {
				var _options$inlineMaxDep;
				const inlineDepth = (_options$inlineMaxDep = options.inlineMaxDepth) !== null && _options$inlineMaxDep !== void 0 ? _options$inlineMaxDep : maxInlineDepth;
				const inlineNames = detector.collectInlineTokenNames(element, { maxDepth: inlineDepth });
				for (const name of inlineNames) candidateNames.add(name);
			}
			const results = [];
			let computedStyle = null;
			try {
				computedStyle = window.getComputedStyle(element);
			} catch (_unused3) {}
			if (computedStyle) for (const name of candidateNames) {
				var _index$tokens$get;
				let computedValue = "";
				try {
					computedValue = computedStyle.getPropertyValue(name).trim();
				} catch (_unused4) {}
				if (!computedValue) continue;
				const declarations = (_index$tokens$get = index.tokens.get(name)) !== null && _index$tokens$get !== void 0 ? _index$tokens$get : [];
				results.push({
					token: toDesignToken(name, declarations),
					computedValue
				});
			}
			if (options.sortByName !== false) results.sort((a, b) => a.token.name.localeCompare(b.token.name));
			return {
				tokens: results,
				warnings: index.warnings,
				stats: index.stats
			};
		}
		function resolveToken(element, name) {
			return resolver.resolveToken(element, name);
		}
		function resolveTokenForProperty(element, name, cssProperty, options) {
			return resolver.resolveTokenForProperty(element, name, cssProperty, options);
		}
		function formatCssVar(name, fallback) {
			return resolver.formatCssVar(name, fallback);
		}
		function parseCssVar(value) {
			return resolver.parseCssVar(value);
		}
		function extractCssVarNames(value) {
			return resolver.extractCssVarNames(value);
		}
		function applyTokenToStyle(transactionManager, target, cssProperty, tokenName, options) {
			const value = formatCssVar(tokenName, options === null || options === void 0 ? void 0 : options.fallback);
			return transactionManager.applyStyle(target, cssProperty, value, { merge: options === null || options === void 0 ? void 0 : options.merge });
		}
		function onInvalidation(handler) {
			invalidationListeners.add(handler);
			return () => invalidationListeners.delete(handler);
		}
		function dispose() {
			invalidationListeners.clear();
			disposer.dispose();
		}
		return {
			getRootTokens,
			getContextTokens,
			resolveToken,
			resolveTokenForProperty,
			formatCssVar,
			parseCssVar,
			extractCssVarNames,
			invalidateRoot,
			onInvalidation,
			applyTokenToStyle,
			dispose
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2/core/editor.ts
	/**
	* Create the Web Editor V2 instance.
	*
	* This is the main factory function that creates the editor API.
	* The returned object implements WebEditorV2Api and is exposed on window.__MCP_WEB_EDITOR_V2__
	*/
	function createWebEditorV2() {
		const state = {
			active: false,
			shadowHost: null,
			canvasOverlay: null,
			handlesController: null,
			eventController: null,
			positionTracker: null,
			selectionEngine: null,
			dragReorderController: null,
			transactionManager: null,
			executionTracker: null,
			hmrConsistencyVerifier: null,
			toolbar: null,
			breadcrumbs: null,
			propertyPanel: null,
			propsBridge: null,
			tokensService: null,
			perfMonitor: null,
			perfHotkeyCleanup: null,
			hoveredElement: null,
			pendingHoverTransition: false,
			selectedElement: null,
			applyingSnapshot: null,
			toolbarPosition: null,
			propertyPanelPosition: null,
			uiResizeCleanup: null
		};
		/** Default modifiers for programmatic selection (e.g., from breadcrumbs) */
		const DEFAULT_MODIFIERS = {
			alt: false,
			shift: false,
			ctrl: false,
			meta: false
		};
		let editSession = null;
		/** Check if element is a valid text edit target */
		function isTextEditTarget(element) {
			if (!(element instanceof HTMLElement)) return false;
			if (element instanceof HTMLInputElement) return false;
			if (element instanceof HTMLTextAreaElement) return false;
			if (element.childElementCount > 0) return false;
			return true;
		}
		/** Restore element to pre-edit state */
		function restoreEditTarget(session) {
			const { element, beforeContentEditable, beforeSpellcheck } = session;
			if (beforeContentEditable === null) element.removeAttribute("contenteditable");
			else element.setAttribute("contenteditable", beforeContentEditable);
			element.spellcheck = beforeSpellcheck;
			element.removeEventListener("keydown", session.keydownHandler, true);
			element.removeEventListener("blur", session.blurHandler, true);
		}
		/** Commit the current edit session */
		function commitEdit() {
			var _element$textContent;
			const session = editSession;
			if (!session) return;
			editSession = null;
			const element = session.element;
			const afterText = (_element$textContent = element.textContent) !== null && _element$textContent !== void 0 ? _element$textContent : "";
			element.textContent = afterText;
			restoreEditTarget(session);
			if (session.beforeText !== afterText) {
				var _state$transactionMan;
				(_state$transactionMan = state.transactionManager) === null || _state$transactionMan === void 0 || _state$transactionMan.recordText(element, session.beforeText, afterText);
			}
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Text edit committed`);
		}
		/** Cancel the current edit session */
		function cancelEdit() {
			const session = editSession;
			if (!session) return;
			editSession = null;
			session.element.textContent = session.beforeText;
			restoreEditTarget(session);
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Text edit cancelled`);
		}
		/** Start editing an element */
		function startEdit(element, modifiers) {
			var _element$textContent2;
			if (!isTextEditTarget(element)) return false;
			if (!element.isConnected) return false;
			if (state.selectedElement !== element) handleSelect(element, modifiers);
			if ((editSession === null || editSession === void 0 ? void 0 : editSession.element) === element) return true;
			if (editSession) commitEdit();
			const beforeText = (_element$textContent2 = element.textContent) !== null && _element$textContent2 !== void 0 ? _element$textContent2 : "";
			const beforeContentEditable = element.getAttribute("contenteditable");
			const beforeSpellcheck = element.spellcheck;
			const keydownHandler = (ev) => {
				var _state$eventControlle;
				if (ev.key !== "Escape") return;
				ev.preventDefault();
				ev.stopPropagation();
				ev.stopImmediatePropagation();
				cancelEdit();
				(_state$eventControlle = state.eventController) === null || _state$eventControlle === void 0 || _state$eventControlle.setMode("selecting");
			};
			const blurHandler = () => {
				var _state$eventControlle2;
				commitEdit();
				(_state$eventControlle2 = state.eventController) === null || _state$eventControlle2 === void 0 || _state$eventControlle2.setMode("selecting");
			};
			element.addEventListener("keydown", keydownHandler, true);
			element.addEventListener("blur", blurHandler, true);
			element.setAttribute("contenteditable", "true");
			element.spellcheck = false;
			try {
				element.focus({ preventScroll: true });
			} catch (_unused) {
				try {
					element.focus();
				} catch (_unused2) {}
			}
			editSession = {
				element,
				beforeText,
				beforeContentEditable,
				beforeSpellcheck,
				keydownHandler,
				blurHandler
			};
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Text edit started`);
			return true;
		}
		/**
		* Handle hover state changes from EventController
		*/
		function handleHover(element) {
			const prevElement = state.hoveredElement;
			state.hoveredElement = element;
			state.pendingHoverTransition = prevElement !== null && element !== null && prevElement !== element;
			if (state.positionTracker) {
				state.positionTracker.setHoverElement(element);
				state.positionTracker.forceUpdate();
			}
		}
		/**
		* Handle element selection from EventController
		*/
		function handleSelect(element, modifiers) {
			var _state$breadcrumbs, _state$propertyPanel, _state$handlesControl, _state$hmrConsistency;
			if (editSession && editSession.element !== element) commitEdit();
			state.selectedElement = element;
			state.hoveredElement = null;
			if (state.positionTracker) {
				state.positionTracker.setHoverElement(null);
				state.positionTracker.setSelectionElement(element);
				state.positionTracker.forceUpdate();
			}
			(_state$breadcrumbs = state.breadcrumbs) === null || _state$breadcrumbs === void 0 || _state$breadcrumbs.setTarget(element);
			(_state$propertyPanel = state.propertyPanel) === null || _state$propertyPanel === void 0 || _state$propertyPanel.setTarget(element);
			(_state$handlesControl = state.handlesController) === null || _state$handlesControl === void 0 || _state$handlesControl.setTarget(element);
			(_state$hmrConsistency = state.hmrConsistencyVerifier) === null || _state$hmrConsistency === void 0 || _state$hmrConsistency.onSelectionChange(element);
			broadcastSelectionChanged(element);
			const modInfo = modifiers.alt ? " (Alt: drill-up)" : "";
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Selected${modInfo}:`, element.tagName, element);
		}
		/**
		* Handle deselection (ESC key) from EventController
		*/
		function handleDeselect() {
			var _state$breadcrumbs2, _state$propertyPanel2, _state$handlesControl2, _state$hmrConsistency2;
			state.selectedElement = null;
			if (state.positionTracker) {
				state.positionTracker.setSelectionElement(null);
				state.positionTracker.forceUpdate();
			}
			(_state$breadcrumbs2 = state.breadcrumbs) === null || _state$breadcrumbs2 === void 0 || _state$breadcrumbs2.setTarget(null);
			(_state$propertyPanel2 = state.propertyPanel) === null || _state$propertyPanel2 === void 0 || _state$propertyPanel2.setTarget(null);
			(_state$handlesControl2 = state.handlesController) === null || _state$handlesControl2 === void 0 || _state$handlesControl2.setTarget(null);
			(_state$hmrConsistency2 = state.hmrConsistencyVerifier) === null || _state$hmrConsistency2 === void 0 || _state$hmrConsistency2.onSelectionChange(null);
			broadcastSelectionChanged(null);
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Deselected`);
		}
		/**
		* Handle position updates from PositionTracker (scroll/resize sync)
		*/
		function handlePositionUpdate(rects) {
			var _state$breadcrumbs3, _state$handlesControl3;
			(_state$breadcrumbs3 = state.breadcrumbs) === null || _state$breadcrumbs3 === void 0 || _state$breadcrumbs3.setAnchorRect(rects.selection);
			const animateHover = state.pendingHoverTransition;
			state.pendingHoverTransition = false;
			if (!state.canvasOverlay) return;
			state.canvasOverlay.setHoverRect(rects.hover, { animate: animateHover });
			state.canvasOverlay.setSelectionRect(rects.selection);
			(_state$handlesControl3 = state.handlesController) === null || _state$handlesControl3 === void 0 || _state$handlesControl3.setSelectionRect(rects.selection);
			state.canvasOverlay.render();
		}
		const TX_CHANGED_BROADCAST_DEBOUNCE_MS = 100;
		let txChangedBroadcastTimer = null;
		let pendingTxAction = "push";
		/**
		* Broadcast aggregated transaction state to extension UI (e.g., Sidepanel).
		*
		* This runs on a short debounce because TransactionManager can emit frequent
		* merge events during continuous interactions (e.g., dragging sliders).
		*
		* NOTE: tabId is set to 0 here; background script will fill in the actual
		* tabId from sender.tab.id and update storage with per-tab keys.
		*/
		function broadcastTxChanged(action) {
			pendingTxAction = action;
			const shouldBroadcastImmediately = action === "clear";
			if (txChangedBroadcastTimer !== null) {
				window.clearTimeout(txChangedBroadcastTimer);
				txChangedBroadcastTimer = null;
			}
			const doBroadcast = () => {
				var _chrome$runtime;
				const tm = state.transactionManager;
				if (!tm) return;
				const undoStack = tm.getUndoStack();
				const redoStack = tm.getRedoStack();
				const elements = aggregateTransactionsByElement(undoStack);
				const payload = {
					tabId: 0,
					action: pendingTxAction,
					elements,
					undoCount: undoStack.length,
					redoCount: redoStack.length,
					hasApplicableChanges: elements.length > 0,
					pageUrl: window.location.href
				};
				if (typeof chrome !== "undefined" && ((_chrome$runtime = chrome.runtime) === null || _chrome$runtime === void 0 ? void 0 : _chrome$runtime.sendMessage)) chrome.runtime.sendMessage({
					type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_TX_CHANGED,
					payload
				}).catch(() => {});
			};
			if (shouldBroadcastImmediately) doBroadcast();
			else txChangedBroadcastTimer = window.setTimeout(doBroadcast, TX_CHANGED_BROADCAST_DEBOUNCE_MS);
		}
		/** Last broadcasted selection key to avoid duplicate broadcasts */
		let lastBroadcastedSelectionKey = null;
		/**
		* Broadcast selection change to sidepanel (no debounce - immediate).
		* Called when user selects or deselects an element.
		*/
		function broadcastSelectionChanged(element) {
			var _chrome$runtime2;
			let selected = null;
			if (element) {
				const elementKey = generateStableElementKey(element);
				if (elementKey === lastBroadcastedSelectionKey) return;
				lastBroadcastedSelectionKey = elementKey;
				selected = {
					elementKey,
					locator: createElementLocator(element),
					label: generateElementLabel(element),
					fullLabel: generateFullElementLabel(element),
					tagName: element.tagName.toLowerCase(),
					updatedAt: Date.now()
				};
			} else {
				if (lastBroadcastedSelectionKey === null) return;
				lastBroadcastedSelectionKey = null;
			}
			const payload = {
				tabId: 0,
				selected,
				pageUrl: window.location.href
			};
			if (typeof chrome !== "undefined" && ((_chrome$runtime2 = chrome.runtime) === null || _chrome$runtime2 === void 0 ? void 0 : _chrome$runtime2.sendMessage)) chrome.runtime.sendMessage({
				type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_SELECTION_CHANGED,
				payload
			}).catch(() => {});
		}
		/**
		* Broadcast "editor cleared" state when stopping.
		* Sends empty TX and null selection to remove chips from sidepanel.
		*/
		function broadcastEditorCleared() {
			var _chrome$runtime3;
			lastBroadcastedSelectionKey = null;
			if (typeof chrome === "undefined" || !((_chrome$runtime3 = chrome.runtime) === null || _chrome$runtime3 === void 0 ? void 0 : _chrome$runtime3.sendMessage)) return;
			const pageUrl = window.location.href;
			const txPayload = {
				tabId: 0,
				action: "clear",
				elements: [],
				undoCount: 0,
				redoCount: 0,
				hasApplicableChanges: false,
				pageUrl
			};
			const selectionPayload = {
				tabId: 0,
				selected: null,
				pageUrl
			};
			chrome.runtime.sendMessage({
				type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_TX_CHANGED,
				payload: txPayload
			}).catch(() => {});
			chrome.runtime.sendMessage({
				type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_SELECTION_CHANGED,
				payload: selectionPayload
			}).catch(() => {});
		}
		/**
		* Handle transaction changes from TransactionManager
		*/
		function handleTransactionChange(event) {
			var _state$toolbar, _state$hmrConsistency3;
			const { action, undoCount, redoCount } = event;
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Transaction: ${action} (undo: ${undoCount}, redo: ${redoCount})`);
			(_state$toolbar = state.toolbar) === null || _state$toolbar === void 0 || _state$toolbar.setHistory(undoCount, redoCount);
			if (action === "undo" || action === "redo") {
				var _state$propertyPanel3;
				(_state$propertyPanel3 = state.propertyPanel) === null || _state$propertyPanel3 === void 0 || _state$propertyPanel3.refresh();
			}
			broadcastTxChanged(action);
			(_state$hmrConsistency3 = state.hmrConsistencyVerifier) === null || _state$hmrConsistency3 === void 0 || _state$hmrConsistency3.onTransactionChange(event);
		}
		function checkApplyingTxStatus() {
			const snapshot = state.applyingSnapshot;
			if (!snapshot) return "no_snapshot";
			const tm = state.transactionManager;
			if (!tm) return "tm_unavailable";
			const undoStack = tm.getUndoStack();
			if (undoStack.length === 0) return "stack_empty";
			const latest = undoStack[undoStack.length - 1];
			if (latest.id !== snapshot.txId || latest.timestamp !== snapshot.txTimestamp) return "tx_changed";
			return "ok";
		}
		/**
		* Attempt to rollback the applying transaction on failure.
		* Returns a descriptive error message based on rollback result.
		*
		* Rollback is only attempted when:
		* - The transaction is still the latest in undo stack
		* - No new edits were made during the apply operation
		*/
		function attemptRollbackOnFailure(originalError) {
			const status = checkApplyingTxStatus();
			if (status === "no_snapshot" || status === "tm_unavailable") {
				console.error(`${WEB_EDITOR_V2_LOG_PREFIX} Apply failed, unable to revert (${status})`);
				return `${originalError} (unable to revert)`;
			}
			if (status === "stack_empty") {
				console.warn(`${WEB_EDITOR_V2_LOG_PREFIX} Apply failed, stack empty (already reverted?)`);
				return `${originalError} (already reverted)`;
			}
			if (status === "tx_changed") {
				console.warn(`${WEB_EDITOR_V2_LOG_PREFIX} Apply failed but new edits detected, skipping auto-rollback`);
				return `${originalError} (new edits detected, not reverted)`;
			}
			if (state.transactionManager.undo()) {
				console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Apply failed, changes auto-reverted`);
				return `${originalError} (changes reverted)`;
			}
			console.error(`${WEB_EDITOR_V2_LOG_PREFIX} Apply failed and auto-revert also failed`);
			return `${originalError} (revert failed)`;
		}
		function _applyLatestTransaction() {
			_applyLatestTransaction = _asyncToGenerator(function* () {
				const tm = state.transactionManager;
				if (!tm) throw new Error("Transaction manager not ready");
				if (state.applyingSnapshot) throw new Error("Apply already in progress");
				const undoStack = tm.getUndoStack();
				const tx = undoStack.length > 0 ? undoStack[undoStack.length - 1] : null;
				if (!tx) throw new Error("No changes to apply");
				if (tx.type !== "style" && tx.type !== "text") throw new Error(`Apply does not support "${tx.type}" transactions yet`);
				state.applyingSnapshot = {
					txId: tx.id,
					txTimestamp: tx.timestamp
				};
				const ROLLBACK_MARKERS = [
					"(changes reverted)",
					"(new edits detected",
					"(revert failed)",
					"(unable to revert)",
					"(already reverted)"
				];
				const isAlreadyProcessed = (err) => err instanceof Error && ROLLBACK_MARKERS.some((m) => err.message.includes(m));
				try {
					const r = yield sendTransactionToAgent(tx);
					if (r && r.success === true) {
						var _state$hmrConsistency4;
						const requestId = typeof r.requestId === "string" ? r.requestId : void 0;
						const sessionId = typeof r.sessionId === "string" ? r.sessionId : void 0;
						if (requestId && sessionId && state.executionTracker) state.executionTracker.track(requestId, sessionId);
						(_state$hmrConsistency4 = state.hmrConsistencyVerifier) === null || _state$hmrConsistency4 === void 0 || _state$hmrConsistency4.start({
							tx,
							requestId,
							sessionId,
							element: state.selectedElement
						});
						return {
							requestId,
							sessionId
						};
					}
					const errorMsg = typeof (r === null || r === void 0 ? void 0 : r.error) === "string" ? r.error : "Agent request failed";
					throw new Error(attemptRollbackOnFailure(errorMsg));
				} catch (error) {
					if (isAlreadyProcessed(error)) throw error;
					const originalMsg = error instanceof Error ? error.message : String(error);
					throw new Error(attemptRollbackOnFailure(originalMsg));
				} finally {
					state.applyingSnapshot = null;
				}
			});
			return _applyLatestTransaction.apply(this, arguments);
		}
		/**
		* Apply all applicable transactions to Agent (batch Apply to Code)
		*
		* Phase 1.4: Aggregates the undo stack by element and sends a single batch request.
		* Unlike applyLatestTransaction, this does NOT auto-rollback on failure.
		*/
		function applyAllTransactions() {
			return _applyAllTransactions.apply(this, arguments);
		}
		function _applyAllTransactions() {
			_applyAllTransactions = _asyncToGenerator(function* () {
				const tm = state.transactionManager;
				if (!tm) throw new Error("Transaction manager not ready");
				if (state.applyingSnapshot) throw new Error("Apply already in progress");
				const undoStack = tm.getUndoStack();
				if (undoStack.length === 0) throw new Error("No changes to apply");
				for (const tx of undoStack) {
					if (tx.type === "move") throw new Error("Apply does not support reorder operations yet");
					if (tx.type === "structure") throw new Error("Apply does not support structure operations yet");
					if (tx.type !== "style" && tx.type !== "text" && tx.type !== "class") throw new Error(`Apply does not support "${tx.type}" transactions`);
				}
				const elements = aggregateTransactionsByElement(undoStack);
				if (elements.length === 0) throw new Error("No net changes to apply");
				const latestTx = undoStack[undoStack.length - 1];
				state.applyingSnapshot = {
					txId: latestTx.id,
					txTimestamp: latestTx.timestamp
				};
				try {
					var _chrome$runtime4;
					if (typeof chrome === "undefined" || !((_chrome$runtime4 = chrome.runtime) === null || _chrome$runtime4 === void 0 ? void 0 : _chrome$runtime4.sendMessage)) throw new Error("Chrome runtime API not available");
					const payload = {
						tabId: 0,
						elements,
						excludedKeys: [],
						pageUrl: window.location.href
					};
					const r = yield chrome.runtime.sendMessage({
						type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_APPLY_BATCH,
						payload
					});
					if (r && r.success === true) {
						const requestId = typeof r.requestId === "string" ? r.requestId : void 0;
						const sessionId = typeof r.sessionId === "string" ? r.sessionId : void 0;
						if (requestId && sessionId && state.executionTracker) state.executionTracker.track(requestId, sessionId);
						tm.clear();
						handleDeselect();
						return {
							requestId,
							sessionId
						};
					}
					const errorMsg = typeof (r === null || r === void 0 ? void 0 : r.error) === "string" ? r.error : "Agent request failed";
					throw new Error(errorMsg);
				} finally {
					state.applyingSnapshot = null;
				}
			});
			return _applyAllTransactions.apply(this, arguments);
		}
		/**
		* Revert a specific element to its baseline state (Phase 2 - Selective Undo).
		* Creates compensating transactions so the user can undo the revert.
		*/
		function revertElement(_x2) {
			return _revertElement.apply(this, arguments);
		}
		function _revertElement() {
			_revertElement = _asyncToGenerator(function* (elementKey) {
				const key = String(elementKey !== null && elementKey !== void 0 ? elementKey : "").trim();
				if (!key) return {
					success: false,
					error: "elementKey is required"
				};
				const tm = state.transactionManager;
				if (!tm) return {
					success: false,
					error: "Transaction manager not ready"
				};
				if (state.applyingSnapshot) return {
					success: false,
					error: "Cannot revert while Apply is in progress"
				};
				try {
					var _state$propertyPanel4;
					const summary = aggregateTransactionsByElement(tm.getUndoStack()).find((s) => s.elementKey === key);
					if (!summary) return {
						success: false,
						error: "Element not found in current changes"
					};
					const element = locateElement(summary.locator);
					if (!element || !element.isConnected) return {
						success: false,
						error: "Failed to locate element for revert"
					};
					const reverted = {};
					let didRevert = false;
					const classChanges = summary.netEffect.classChanges;
					if (classChanges) {
						const baselineClasses = Array.isArray(classChanges.before) ? classChanges.before : [];
						const beforeClasses = (() => {
							var _element$getAttribute;
							try {
								const list = element.classList;
								if (list && typeof list[Symbol.iterator] === "function") return Array.from(list).filter(Boolean);
							} catch (_unused3) {}
							return ((_element$getAttribute = element.getAttribute("class")) !== null && _element$getAttribute !== void 0 ? _element$getAttribute : "").split(/\s+/).map((t) => t.trim()).filter(Boolean);
						})();
						if (tm.recordClass(element, beforeClasses, baselineClasses)) {
							reverted.class = true;
							didRevert = true;
						}
					}
					const textChange = summary.netEffect.textChange;
					if (textChange) {
						var _textChange$before, _element$textContent3;
						const baselineText = String((_textChange$before = textChange.before) !== null && _textChange$before !== void 0 ? _textChange$before : "");
						const beforeText = (_element$textContent3 = element.textContent) !== null && _element$textContent3 !== void 0 ? _element$textContent3 : "";
						if (beforeText !== baselineText) {
							element.textContent = baselineText;
							if (tm.recordText(element, beforeText, baselineText)) {
								reverted.text = true;
								didRevert = true;
							}
						}
					}
					const styleChanges = summary.netEffect.styleChanges;
					if (styleChanges) {
						var _styleChanges$before, _styleChanges$after;
						const before = (_styleChanges$before = styleChanges.before) !== null && _styleChanges$before !== void 0 ? _styleChanges$before : {};
						const after = (_styleChanges$after = styleChanges.after) !== null && _styleChanges$after !== void 0 ? _styleChanges$after : {};
						const properties = Array.from(new Set([...Object.keys(before), ...Object.keys(after)])).map((p) => String(p !== null && p !== void 0 ? p : "").trim()).filter(Boolean);
						if (properties.length > 0) {
							const handle = tm.beginMultiStyle(element, properties);
							if (handle) {
								handle.set(before);
								if (handle.commit({ merge: false })) {
									reverted.style = true;
									didRevert = true;
								}
							}
						}
					}
					if (!didRevert) return {
						success: false,
						error: "No changes were reverted"
					};
					(_state$propertyPanel4 = state.propertyPanel) === null || _state$propertyPanel4 === void 0 || _state$propertyPanel4.refresh();
					return {
						success: true,
						reverted
					};
				} catch (error) {
					console.error(`${WEB_EDITOR_V2_LOG_PREFIX} Revert element failed:`, error);
					return {
						success: false,
						error: error instanceof Error ? error.message : String(error)
					};
				}
			});
			return _revertElement.apply(this, arguments);
		}
		/**
		* Clear current selection (called from sidepanel after send).
		* Triggers handleDeselect which broadcasts null selection to sidepanel.
		*/
		function clearSelection() {
			if (!state.selectedElement) return;
			if (state.eventController) {
				state.eventController.setMode("hover");
				if (state.selectedElement) handleDeselect();
			} else handleDeselect();
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Selection cleared (from sidepanel)`);
		}
		/**
		* Handle transaction apply errors
		*/
		function handleTransactionError(error) {
			console.error(`${WEB_EDITOR_V2_LOG_PREFIX} Transaction apply error:`, error);
		}
		/**
		* Start the editor
		*/
		function start() {
			if (state.active) {
				console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Already active`);
				return;
			}
			try {
				var _state$shadowHost2, _state$selectionEngin3;
				state.shadowHost = mountShadowHost({});
				const elements = state.shadowHost.getElements();
				if (!(elements === null || elements === void 0 ? void 0 : elements.overlayRoot)) throw new Error("Shadow host overlayRoot not available");
				state.canvasOverlay = createCanvasOverlay({ container: elements.overlayRoot });
				state.perfMonitor = createPerfMonitor({
					container: elements.overlayRoot,
					fpsUiIntervalMs: 500,
					memorySampleIntervalMs: 1e3
				});
				const perfHotkeyHandler = (event) => {
					if (event.repeat) return;
					if (!(event.metaKey || event.ctrlKey)) return;
					if (!event.shiftKey) return;
					if (event.altKey) return;
					if ((event.key || "").toLowerCase() !== "p") return;
					const monitor = state.perfMonitor;
					if (!monitor) return;
					monitor.toggle();
					event.preventDefault();
					event.stopPropagation();
					event.stopImmediatePropagation();
				};
				const hotkeyOptions = {
					capture: true,
					passive: false
				};
				window.addEventListener("keydown", perfHotkeyHandler, hotkeyOptions);
				state.perfHotkeyCleanup = () => {
					window.removeEventListener("keydown", perfHotkeyHandler, hotkeyOptions);
				};
				state.selectionEngine = createSelectionEngine({ isOverlayElement: state.shadowHost.isOverlayElement });
				state.positionTracker = createPositionTracker({ onPositionUpdate: handlePositionUpdate });
				state.transactionManager = createTransactionManager({
					enableKeyBindings: true,
					isEventFromEditorUi: (event) => {
						var _state$shadowHost;
						if ((_state$shadowHost = state.shadowHost) === null || _state$shadowHost === void 0 ? void 0 : _state$shadowHost.isEventFromUi(event)) return true;
						const session = editSession;
						if (session === null || session === void 0 ? void 0 : session.element) try {
							const path = typeof event.composedPath === "function" ? event.composedPath() : null;
							if (path === null || path === void 0 ? void 0 : path.some((node) => node === session.element)) return true;
						} catch (_unused4) {
							const target = event.target;
							if (target instanceof Node && session.element.contains(target)) return true;
						}
						return false;
					},
					onChange: handleTransactionChange,
					onApplyError: handleTransactionError
				});
				state.handlesController = createHandlesController({
					container: elements.overlayRoot,
					canvasOverlay: state.canvasOverlay,
					transactionManager: state.transactionManager,
					positionTracker: state.positionTracker
				});
				state.dragReorderController = createDragReorderController({
					isOverlayElement: state.shadowHost.isOverlayElement,
					uiRoot: elements.uiRoot,
					canvasOverlay: state.canvasOverlay,
					positionTracker: state.positionTracker,
					transactionManager: state.transactionManager
				});
				state.eventController = createEventController({
					isOverlayElement: state.shadowHost.isOverlayElement,
					onHover: handleHover,
					onSelect: handleSelect,
					onDeselect: handleDeselect,
					onStartEdit: startEdit,
					findTargetForSelect: (_x, _y, modifiers, event) => {
						var _state$selectionEngin, _state$selectionEngin2;
						return (_state$selectionEngin = (_state$selectionEngin2 = state.selectionEngine) === null || _state$selectionEngin2 === void 0 ? void 0 : _state$selectionEngin2.findBestTargetFromEvent(event, modifiers)) !== null && _state$selectionEngin !== void 0 ? _state$selectionEngin : null;
					},
					getSelectedElement: () => state.selectedElement,
					onStartDrag: (ev) => {
						var _state$dragReorderCon, _state$dragReorderCon2;
						return (_state$dragReorderCon = (_state$dragReorderCon2 = state.dragReorderController) === null || _state$dragReorderCon2 === void 0 ? void 0 : _state$dragReorderCon2.onDragStart(ev)) !== null && _state$dragReorderCon !== void 0 ? _state$dragReorderCon : false;
					},
					onDragMove: (ev) => {
						var _state$dragReorderCon3;
						return (_state$dragReorderCon3 = state.dragReorderController) === null || _state$dragReorderCon3 === void 0 ? void 0 : _state$dragReorderCon3.onDragMove(ev);
					},
					onDragEnd: (ev) => {
						var _state$dragReorderCon4;
						return (_state$dragReorderCon4 = state.dragReorderController) === null || _state$dragReorderCon4 === void 0 ? void 0 : _state$dragReorderCon4.onDragEnd(ev);
					},
					onDragCancel: (ev) => {
						var _state$dragReorderCon5;
						return (_state$dragReorderCon5 = state.dragReorderController) === null || _state$dragReorderCon5 === void 0 ? void 0 : _state$dragReorderCon5.onDragCancel(ev);
					}
				});
				state.executionTracker = createExecutionTracker({ onStatusChange: (execState) => {
					var _state$hmrConsistency5, _state$hmrConsistency6, _state$hmrConsistency7;
					if (!(((_state$hmrConsistency5 = (_state$hmrConsistency6 = state.hmrConsistencyVerifier) === null || _state$hmrConsistency6 === void 0 ? void 0 : _state$hmrConsistency6.getSnapshot().phase) !== null && _state$hmrConsistency5 !== void 0 ? _state$hmrConsistency5 : "idle") !== "idle") || execState.status !== "completed") {
						var _statusMap$execState$, _state$toolbar2;
						const toolbarStatus = (_statusMap$execState$ = {
							pending: "applying",
							starting: "starting",
							running: "running",
							locating: "locating",
							applying: "applying",
							completed: "completed",
							failed: "failed",
							error: "failed",
							timeout: "timeout",
							cancelled: "cancelled"
						}[execState.status]) !== null && _statusMap$execState$ !== void 0 ? _statusMap$execState$ : "running";
						(_state$toolbar2 = state.toolbar) === null || _state$toolbar2 === void 0 || _state$toolbar2.setStatus(toolbarStatus, execState.message);
					}
					(_state$hmrConsistency7 = state.hmrConsistencyVerifier) === null || _state$hmrConsistency7 === void 0 || _state$hmrConsistency7.onExecutionStatus(execState);
				} });
				state.hmrConsistencyVerifier = createHmrConsistencyVerifier({
					transactionManager: state.transactionManager,
					getSelectedElement: () => state.selectedElement,
					onReselect: (element) => handleSelect(element, DEFAULT_MODIFIERS),
					onDeselect: handleDeselect,
					setToolbarStatus: (status, message) => {
						var _state$toolbar3;
						return (_state$toolbar3 = state.toolbar) === null || _state$toolbar3 === void 0 ? void 0 : _state$toolbar3.setStatus(status, message);
					},
					isOverlayElement: (_state$shadowHost2 = state.shadowHost) === null || _state$shadowHost2 === void 0 ? void 0 : _state$shadowHost2.isOverlayElement,
					selectionEngine: (_state$selectionEngin3 = state.selectionEngine) !== null && _state$selectionEngin3 !== void 0 ? _state$selectionEngin3 : void 0
				});
				state.toolbar = createToolbar({
					container: elements.uiRoot,
					dock: "top",
					initialPosition: state.toolbarPosition,
					onPositionChange: (position) => {
						state.toolbarPosition = position;
					},
					getApplyBlockReason: () => {
						const tm = state.transactionManager;
						if (!tm) return void 0;
						const undoStack = tm.getUndoStack();
						if (undoStack.length === 0) return void 0;
						for (const tx of undoStack) {
							if (tx.type === "move") return "Apply does not support reorder operations yet";
							if (tx.type === "structure") return "Apply does not support structure operations yet";
							if (tx.type !== "style" && tx.type !== "text" && tx.type !== "class") return `Apply does not support "${tx.type}" transactions`;
						}
					},
					getSelectedElement: () => state.selectedElement,
					onStructure: (data) => {
						const target = state.selectedElement;
						if (!target) return;
						const tm = state.transactionManager;
						if (!tm) return;
						const tx = tm.applyStructure(target, data);
						if (!tx) return;
						if (data.action === "delete") handleDeselect();
						else {
							const newTarget = locateElement(tx.targetLocator);
							if (newTarget && newTarget.isConnected) handleSelect(newTarget, DEFAULT_MODIFIERS);
						}
					},
					onApply: applyAllTransactions,
					onUndo: () => {
						var _state$transactionMan2;
						return (_state$transactionMan2 = state.transactionManager) === null || _state$transactionMan2 === void 0 ? void 0 : _state$transactionMan2.undo();
					},
					onRedo: () => {
						var _state$transactionMan3;
						return (_state$transactionMan3 = state.transactionManager) === null || _state$transactionMan3 === void 0 ? void 0 : _state$transactionMan3.redo();
					},
					onRequestClose: () => stop()
				});
				state.toolbar.setHistory(state.transactionManager.getUndoStack().length, state.transactionManager.getRedoStack().length);
				state.breadcrumbs = createBreadcrumbs({
					container: elements.uiRoot,
					dock: "top",
					onSelect: (element) => {
						if (element.isConnected) handleSelect(element, DEFAULT_MODIFIERS);
					}
				});
				state.propsBridge = createPropsBridge({});
				state.tokensService = createDesignTokensService();
				state.propertyPanel = createPropertyPanel({
					container: elements.uiRoot,
					transactionManager: state.transactionManager,
					propsBridge: state.propsBridge,
					tokensService: state.tokensService,
					initialPosition: state.propertyPanelPosition,
					onPositionChange: (position) => {
						state.propertyPanelPosition = position;
					},
					defaultTab: "design",
					onSelectElement: (element) => {
						if (element.isConnected) handleSelect(element, DEFAULT_MODIFIERS);
					},
					onRequestClose: () => stop()
				});
				let uiResizeRafId = null;
				const clampFloatingUi = () => {
					const toolbarPos = state.toolbarPosition;
					const panelPos = state.propertyPanelPosition;
					if (state.toolbar && toolbarPos) state.toolbar.setPosition(toolbarPos);
					if (state.propertyPanel && panelPos) state.propertyPanel.setPosition(panelPos);
				};
				const onWindowResize = () => {
					if (!state.active) return;
					if (uiResizeRafId !== null) return;
					uiResizeRafId = window.requestAnimationFrame(() => {
						uiResizeRafId = null;
						clampFloatingUi();
					});
				};
				window.addEventListener("resize", onWindowResize, { passive: true });
				state.uiResizeCleanup = () => {
					window.removeEventListener("resize", onWindowResize);
					if (uiResizeRafId !== null) {
						window.cancelAnimationFrame(uiResizeRafId);
						uiResizeRafId = null;
					}
				};
				clampFloatingUi();
				state.active = true;
				console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Started`);
			} catch (error) {
				var _state$uiResizeCleanu, _state$propertyPanel5, _state$tokensService, _state$propsBridge, _state$breadcrumbs4, _state$toolbar4, _state$eventControlle3, _state$dragReorderCon6, _state$handlesControl4, _state$transactionMan4, _state$positionTracke, _state$selectionEngin4, _state$perfHotkeyClea, _state$perfMonitor, _state$canvasOverlay, _state$shadowHost3;
				(_state$uiResizeCleanu = state.uiResizeCleanup) === null || _state$uiResizeCleanu === void 0 || _state$uiResizeCleanu.call(state);
				state.uiResizeCleanup = null;
				(_state$propertyPanel5 = state.propertyPanel) === null || _state$propertyPanel5 === void 0 || _state$propertyPanel5.dispose();
				state.propertyPanel = null;
				(_state$tokensService = state.tokensService) === null || _state$tokensService === void 0 || _state$tokensService.dispose();
				state.tokensService = null;
				(_state$propsBridge = state.propsBridge) === null || _state$propsBridge === void 0 || _state$propsBridge.dispose();
				state.propsBridge = null;
				(_state$breadcrumbs4 = state.breadcrumbs) === null || _state$breadcrumbs4 === void 0 || _state$breadcrumbs4.dispose();
				state.breadcrumbs = null;
				(_state$toolbar4 = state.toolbar) === null || _state$toolbar4 === void 0 || _state$toolbar4.dispose();
				state.toolbar = null;
				(_state$eventControlle3 = state.eventController) === null || _state$eventControlle3 === void 0 || _state$eventControlle3.dispose();
				state.eventController = null;
				(_state$dragReorderCon6 = state.dragReorderController) === null || _state$dragReorderCon6 === void 0 || _state$dragReorderCon6.dispose();
				state.dragReorderController = null;
				(_state$handlesControl4 = state.handlesController) === null || _state$handlesControl4 === void 0 || _state$handlesControl4.dispose();
				state.handlesController = null;
				(_state$transactionMan4 = state.transactionManager) === null || _state$transactionMan4 === void 0 || _state$transactionMan4.dispose();
				state.transactionManager = null;
				(_state$positionTracke = state.positionTracker) === null || _state$positionTracke === void 0 || _state$positionTracke.dispose();
				state.positionTracker = null;
				(_state$selectionEngin4 = state.selectionEngine) === null || _state$selectionEngin4 === void 0 || _state$selectionEngin4.dispose();
				state.selectionEngine = null;
				(_state$perfHotkeyClea = state.perfHotkeyCleanup) === null || _state$perfHotkeyClea === void 0 || _state$perfHotkeyClea.call(state);
				state.perfHotkeyCleanup = null;
				(_state$perfMonitor = state.perfMonitor) === null || _state$perfMonitor === void 0 || _state$perfMonitor.dispose();
				state.perfMonitor = null;
				(_state$canvasOverlay = state.canvasOverlay) === null || _state$canvasOverlay === void 0 || _state$canvasOverlay.dispose();
				state.canvasOverlay = null;
				(_state$shadowHost3 = state.shadowHost) === null || _state$shadowHost3 === void 0 || _state$shadowHost3.dispose();
				state.shadowHost = null;
				state.hoveredElement = null;
				state.selectedElement = null;
				state.applyingSnapshot = null;
				state.active = false;
				console.error(`${WEB_EDITOR_V2_LOG_PREFIX} Failed to start:`, error);
			}
		}
		/**
		* Stop the editor
		*/
		function stop() {
			if (!state.active) return;
			state.active = false;
			if (txChangedBroadcastTimer !== null) {
				window.clearTimeout(txChangedBroadcastTimer);
				txChangedBroadcastTimer = null;
			}
			try {
				var _state$uiResizeCleanu2, _state$propertyPanel6, _state$tokensService2, _state$propsBridge2, _state$breadcrumbs5, _state$toolbar5, _state$eventControlle4, _state$dragReorderCon7, _state$handlesControl5, _state$executionTrack, _state$hmrConsistency8, _state$transactionMan5, _state$positionTracke2, _state$selectionEngin5, _state$perfHotkeyClea2, _state$perfMonitor2, _state$canvasOverlay2, _state$shadowHost4;
				if (editSession) commitEdit();
				(_state$uiResizeCleanu2 = state.uiResizeCleanup) === null || _state$uiResizeCleanu2 === void 0 || _state$uiResizeCleanu2.call(state);
				state.uiResizeCleanup = null;
				(_state$propertyPanel6 = state.propertyPanel) === null || _state$propertyPanel6 === void 0 || _state$propertyPanel6.dispose();
				state.propertyPanel = null;
				(_state$tokensService2 = state.tokensService) === null || _state$tokensService2 === void 0 || _state$tokensService2.dispose();
				state.tokensService = null;
				(_state$propsBridge2 = state.propsBridge) === null || _state$propsBridge2 === void 0 || _state$propsBridge2.cleanup();
				state.propsBridge = null;
				(_state$breadcrumbs5 = state.breadcrumbs) === null || _state$breadcrumbs5 === void 0 || _state$breadcrumbs5.dispose();
				state.breadcrumbs = null;
				(_state$toolbar5 = state.toolbar) === null || _state$toolbar5 === void 0 || _state$toolbar5.dispose();
				state.toolbar = null;
				(_state$eventControlle4 = state.eventController) === null || _state$eventControlle4 === void 0 || _state$eventControlle4.dispose();
				state.eventController = null;
				(_state$dragReorderCon7 = state.dragReorderController) === null || _state$dragReorderCon7 === void 0 || _state$dragReorderCon7.dispose();
				state.dragReorderController = null;
				(_state$handlesControl5 = state.handlesController) === null || _state$handlesControl5 === void 0 || _state$handlesControl5.dispose();
				state.handlesController = null;
				(_state$executionTrack = state.executionTracker) === null || _state$executionTrack === void 0 || _state$executionTrack.dispose();
				state.executionTracker = null;
				(_state$hmrConsistency8 = state.hmrConsistencyVerifier) === null || _state$hmrConsistency8 === void 0 || _state$hmrConsistency8.dispose();
				state.hmrConsistencyVerifier = null;
				(_state$transactionMan5 = state.transactionManager) === null || _state$transactionMan5 === void 0 || _state$transactionMan5.dispose();
				state.transactionManager = null;
				(_state$positionTracke2 = state.positionTracker) === null || _state$positionTracke2 === void 0 || _state$positionTracke2.dispose();
				state.positionTracker = null;
				(_state$selectionEngin5 = state.selectionEngine) === null || _state$selectionEngin5 === void 0 || _state$selectionEngin5.dispose();
				state.selectionEngine = null;
				(_state$perfHotkeyClea2 = state.perfHotkeyCleanup) === null || _state$perfHotkeyClea2 === void 0 || _state$perfHotkeyClea2.call(state);
				state.perfHotkeyCleanup = null;
				(_state$perfMonitor2 = state.perfMonitor) === null || _state$perfMonitor2 === void 0 || _state$perfMonitor2.dispose();
				state.perfMonitor = null;
				(_state$canvasOverlay2 = state.canvasOverlay) === null || _state$canvasOverlay2 === void 0 || _state$canvasOverlay2.dispose();
				state.canvasOverlay = null;
				(_state$shadowHost4 = state.shadowHost) === null || _state$shadowHost4 === void 0 || _state$shadowHost4.dispose();
				state.shadowHost = null;
				state.hoveredElement = null;
				state.selectedElement = null;
				state.applyingSnapshot = null;
				console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Stopped`);
			} catch (error) {
				console.error(`${WEB_EDITOR_V2_LOG_PREFIX} Error during cleanup:`, error);
				state.propertyPanel = null;
				state.propsBridge = null;
				state.breadcrumbs = null;
				state.toolbar = null;
				state.eventController = null;
				state.dragReorderController = null;
				state.handlesController = null;
				state.transactionManager = null;
				state.positionTracker = null;
				state.selectionEngine = null;
				state.perfHotkeyCleanup = null;
				state.perfMonitor = null;
				state.canvasOverlay = null;
				state.shadowHost = null;
				state.hoveredElement = null;
				state.selectedElement = null;
				state.applyingSnapshot = null;
			} finally {
				broadcastEditorCleared();
			}
		}
		/**
		* Toggle the editor on/off
		*/
		function toggle() {
			if (state.active) stop();
			else start();
			return state.active;
		}
		/**
		* Get current editor state
		*/
		function getState() {
			return {
				active: state.active,
				version: 2
			};
		}
		return {
			start,
			stop,
			toggle,
			getState,
			revertElement,
			clearSelection
		};
	}
	//#endregion
	//#region common/web-editor-types.ts
	/**
	* Action types for web editor V2 messages
	*
	* IMPORTANT: V2 uses versioned action names (suffix _v2) to avoid
	* conflicts with V1 when both scripts might be injected in the same tab.
	* This prevents double-response race conditions.
	*
	* V1 uses: web_editor_ping, web_editor_toggle, etc.
	* V2 uses: web_editor_ping_v2, web_editor_toggle_v2, etc.
	*/
	var WEB_EDITOR_V2_ACTIONS = {
		PING: "web_editor_ping_v2",
		TOGGLE: "web_editor_toggle_v2",
		START: "web_editor_start_v2",
		STOP: "web_editor_stop_v2",
		HIGHLIGHT_ELEMENT: "web_editor_highlight_element_v2",
		REVERT_ELEMENT: "web_editor_revert_element_v2",
		CLEAR_SELECTION: "web_editor_clear_selection_v2"
	};
	//#endregion
	//#region entrypoints/web-editor-v2/core/message-listener.ts
	/**
	* Type guard to check if a request is a V2 editor request
	*/
	function isV2Request(request) {
		if (!request || typeof request !== "object") return false;
		const action = request.action;
		return action === WEB_EDITOR_V2_ACTIONS.PING || action === WEB_EDITOR_V2_ACTIONS.TOGGLE || action === WEB_EDITOR_V2_ACTIONS.START || action === WEB_EDITOR_V2_ACTIONS.STOP;
	}
	/**
	* Type guard for highlight request
	*/
	function isHighlightRequest(request) {
		if (!request || typeof request !== "object") return false;
		const r = request;
		if (r.action !== WEB_EDITOR_V2_ACTIONS.HIGHLIGHT_ELEMENT) return false;
		if (r.mode !== "hover" && r.mode !== "clear") return false;
		if (r.mode === "clear") return true;
		const hasSelector = typeof r.selector === "string" && r.selector.trim().length > 0;
		const hasLocator = r.locator !== null && typeof r.locator === "object";
		return hasSelector || hasLocator;
	}
	/**
	* Type guard for revert element request (Phase 2)
	*/
	function isRevertRequest(request) {
		if (!request || typeof request !== "object") return false;
		const r = request;
		return r.action === WEB_EDITOR_V2_ACTIONS.REVERT_ELEMENT && typeof r.elementKey === "string" && r.elementKey.trim().length > 0;
	}
	/**
	* Type guard for clear selection request
	*/
	function isClearSelectionRequest(request) {
		if (!request || typeof request !== "object") return false;
		return request.action === WEB_EDITOR_V2_ACTIONS.CLEAR_SELECTION;
	}
	var currentHighlightOverlay = null;
	/**
	* Clear any existing highlight overlay
	*/
	function clearHighlight() {
		if (currentHighlightOverlay && currentHighlightOverlay.parentNode) currentHighlightOverlay.parentNode.removeChild(currentHighlightOverlay);
		currentHighlightOverlay = null;
	}
	/**
	* Create and show highlight overlay for an element
	*/
	function showHighlight(element) {
		clearHighlight();
		const rect = element.getBoundingClientRect();
		if (rect.width === 0 && rect.height === 0) return;
		const overlay = document.createElement("div");
		overlay.setAttribute("data-web-editor-highlight", "true");
		overlay.style.cssText = `
    position: fixed;
    top: ${rect.top}px;
    left: ${rect.left}px;
    width: ${rect.width}px;
    height: ${rect.height}px;
    background-color: rgba(59, 130, 246, 0.15);
    border: 2px solid rgba(59, 130, 246, 0.8);
    border-radius: 4px;
    pointer-events: none;
    z-index: 2147483646;
    box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
    transition: all 0.15s ease;
  `;
		document.body.appendChild(overlay);
		currentHighlightOverlay = overlay;
	}
	/**
	* Find element by CSS selector (fallback when locator-based resolution fails)
	*/
	function findElementBySelector(selector) {
		try {
			return document.querySelector(selector);
		} catch (_unused) {
			return null;
		}
	}
	/**
	* Install the message listener for background communication.
	* Returns a function to remove the listener.
	*
	* Handles:
	* - PING: Check if editor is active
	* - TOGGLE/START/STOP: Control editor state
	* - HIGHLIGHT_ELEMENT: Highlight element from sidepanel hover
	* - REVERT_ELEMENT: Revert element to original state
	* - CLEAR_SELECTION: Clear current selection (from sidepanel after send)
	*
	* @param api The WebEditorV2Api instance to delegate commands to
	* @returns Function to remove the listener
	*/
	function installMessageListener(api) {
		const listener = (request, _sender, sendResponse) => {
			if (isHighlightRequest(request)) {
				if (request.mode === "clear") {
					clearHighlight();
					sendResponse({ success: true });
				} else {
					let element = null;
					if (request.locator) try {
						element = locateElement(request.locator);
					} catch (_unused2) {
						element = null;
					}
					if (!element && typeof request.selector === "string") element = findElementBySelector(request.selector);
					if (element) {
						showHighlight(element);
						sendResponse({ success: true });
					} else sendResponse({
						success: false,
						error: "Element not found"
					});
				}
				return false;
			}
			if (isRevertRequest(request)) {
				_asyncToGenerator(function* () {
					try {
						sendResponse(yield api.revertElement(request.elementKey));
					} catch (error) {
						sendResponse({
							success: false,
							error: error instanceof Error ? error.message : String(error)
						});
					}
				})();
				return true;
			}
			if (isClearSelectionRequest(request)) {
				api.clearSelection();
				sendResponse({ success: true });
				return false;
			}
			if (!isV2Request(request)) return false;
			switch (request.action) {
				case WEB_EDITOR_V2_ACTIONS.PING:
					sendResponse({
						status: "pong",
						active: api.getState().active,
						version: 2
					});
					return false;
				case WEB_EDITOR_V2_ACTIONS.TOGGLE:
					sendResponse({ active: api.toggle() });
					return false;
				case WEB_EDITOR_V2_ACTIONS.START:
					api.start();
					sendResponse({ active: true });
					return false;
				case WEB_EDITOR_V2_ACTIONS.STOP:
					api.stop();
					sendResponse({ active: false });
					return false;
				default: return false;
			}
		};
		chrome.runtime.onMessage.addListener(listener);
		return () => {
			chrome.runtime.onMessage.removeListener(listener);
			clearHighlight();
		};
	}
	//#endregion
	//#region entrypoints/web-editor-v2.ts
	/**
	* Web Editor V2 - Inject Script Entry Point
	*
	* This is the main entry point for the visual editor, injected into web pages
	* via chrome.scripting.executeScript from the background script.
	*
	* Architecture:
	* - Uses WXT's defineUnlistedScript for TypeScript compilation
	* - Exposes API on window.__MCP_WEB_EDITOR_V2__
	* - Communicates with background via chrome.runtime.onMessage
	*
	* Module structure:
	* - web-editor-v2/constants.ts - Configuration values
	* - web-editor-v2/utils/disposables.ts - Resource cleanup
	* - web-editor-v2/ui/shadow-host.ts - Shadow DOM isolation
	* - web-editor-v2/core/editor.ts - Main orchestrator
	* - web-editor-v2/core/message-listener.ts - Background communication
	*
	* Build output: .output/chrome-mv3/web-editor-v2.js
	*/
	var web_editor_v2_default = defineUnlistedScript(() => {
		if (window !== window.top) return;
		if (window.__MCP_WEB_EDITOR_V2__) {
			console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Already installed, skipping initialization`);
			return;
		}
		const api = createWebEditorV2();
		window.__MCP_WEB_EDITOR_V2__ = api;
		installMessageListener(api);
		console.log(`${WEB_EDITOR_V2_LOG_PREFIX} Installed successfully`);
	});
	//#endregion
	//#region \0virtual:wxt-unlisted-script-entrypoint?/home/aomkoyo/mcp-chrome/app/chrome-extension/entrypoints/web-editor-v2.ts
	function print(method, ...args) {}
	/** Wrapper around `console` with a "[wxt]" prefix */
	var logger = {
		debug: (...args) => print(console.debug, ...args),
		log: (...args) => print(console.log, ...args),
		warn: (...args) => print(console.warn, ...args),
		error: (...args) => print(console.error, ...args)
	};
	//#endregion
	return (() => {
		let result;
		try {
			result = web_editor_v2_default.main();
			if (result instanceof Promise) result = result.catch((err) => {
				logger.error(`The unlisted script "web-editor-v2" crashed on startup!`, err);
				throw err;
			});
		} catch (err) {
			logger.error(`The unlisted script "web-editor-v2" crashed on startup!`, err);
			throw err;
		}
		return result;
	})();
})();

webEditorV2;